# Fog Trial

A top-down 2D browser game in the style of Dead by Daylight. Play as the killer against survivor bots, play as a survivor with three bot teammates against a killer bot, or play 2v8 (two killers against eight survivors) from either side.

Run it with any static server from this folder (ES modules need http, not file://):

```
python3 -m http.server 8000
# open http://localhost:8000/index.html
```

`node tools/bundle.mjs` writes a single-file build to `dist/index.html` (used for the hosted page).

## Multiplayer (online custom matches)

`server/` is an authoritative Node server with no dependencies (its own small WebSocket implementation in `server/ws.js`). It serves the game page and runs custom-match rooms like Dead by Daylight's: the host creates a room and shares the 4-letter code (or the invite link), players take killer or survivor slots, the host sets the mode (1v4 or 2v8), the map and every bot slot's difficulty (and the bot killer). Any slot nobody takes is played by the game's AI. A player who leaves mid-match is replaced by a bot.

- The server runs the real simulation at 60 Hz and sends each player ~20 snapshots a second (field-level diffs, ~1 KB each). Clients keep a mirror of the match built from the same seed, predict their own movement and reconcile with the server, and smooth everyone else. Skill checks are judged on the client against the needle the player saw.
- `npm run build` writes `dist/index.html` and the ready-to-deploy `deploy/` folder: `server.mjs` (the whole server in one file), `index.html` and `package.json`. Run it with `node server.mjs` (PORT env var, default 8080).
- Run from source: `node tools/bundle.mjs && npm start`, then open http://localhost:8080 in several tabs.
- Limitation: the server sends every client the full state (the renderer hides what your character can't see), so a modified client could reveal hidden positions — fine for playing with friends.

## Modes (main menu)

- **Play as Killer** — pick a killer, perks, add-ons, map, survivor count and survivor difficulty.
- **Play as Survivor** — pick a character, four perks, an item and add-on, a map, a killer (or random), the killer bot's difficulty and your teammates' difficulty. Three bot teammates treat you as one of the team (they heal you, rescue you, follow your lead).
- **2v8 Mode** — two killers vs eight survivors on an enlarged map: 13 generators, 8 to power 3 exit gates, hooks send survivors to cages elsewhere on the map (90 s per stage), no self-healing except the Medic, no hatch, Revealed status (chase start, a kicked generator within 20 m, finishing a generator). Classes replace perks and items: survivors Escapist / Guide / Medic / Scout, killers Brute / Enforcer / Fearmonger / Shadow (`js/modes/`). Play Killer A (bot Killer B), a survivor (7 bot teammates, 2 killer bots) or spectate.
- **Story Mode** — 146 killer scenarios over nine chapters (all unlocked, filterable, plus a random scenario).
- **Custom Match** — every survivor bot set individually (difficulty, personality, perks, item, add-on), rules and modifiers.
- **Killer Selection**, **Survivor Loadout**, **Settings** (volume, zoom, mouse wheel, simulation detail, debug overlay, control hints), **Controls**, **AI Lab** (all test suites in the browser, spectator matches incl. 2v8).

Difficulties are independent: killer bot, survivor bots, your teammates and the second 2v8 killer each have their own 1–10 setting. Difficulty changes how bots think (reaction time, attention, prediction, mind-games, power use, pallet and hook decisions…), never their movement speed.

## Controls

Killer: WASD move · mouse aim · LMB attack · RMB/Q power (also drops a carried survivor) · E secondary · F / wheel cycle (Lich spells, Singularity pods, Unknown teleport) · SPACE interact · Esc pause · \` or F3 AI debug overlay.

Survivor: WASD move · Shift walk · C/Ctrl crouch · mouse look · SPACE vault / drop pallet / skill checks · E hold to interact (repair, heal, unhook, open gates, chests, totems, devices…) · Q/RMB item or power counter (EMP, spray, vaccine) · F active perk · A/D wiggle when carried · Enter skip when dead · Tab next teammate.

## Killers (24)

- Trapper (bear traps; setting a trap gives 10% Haste for 4 s, no stacking — `js/core/balance.js`), Hillbilly, Wraith, Ghost Face, Clown, Executioner, Huntress, Legion, Hag, Deathslinger, Dredge, Knight, Cenobite (chain/gateway regression fixed and tested), Mastermind, Houndmaster, Lich.
- **Singularity (reworked)** — shoot biopods onto walls (22 m), view through a pod, 0.8 s reticle lock to Slipstream, Slipstream spreads within 6 m after 2 s, teleport to a pod (lock on a Slipstreamed survivor + LMB) or by shooting a Slipstreamed survivor, Overclock (pallet stuns break the pallet and Overheat him), 4 EMP printers (97% passive, survivors finish them), EMP arms in 2.5 s, clears Slipstream and disables pods 45 s; disabled pods can be destroyed from inside. Camera and line of sight move to the pod.
- **Cannibal (reworked)** — 3 charges (0.25/s), 2 s rev, sweep accelerating to 5.35 m/s over 2.5 s, dash spends a charge, multi-downs, tantrum on walls or a 3 s over-rev (3 s + 1 s per charge, Hindered 90%), saws through dropped pallets, cooldowns hit 2 s / miss 1.5 s + 1 s per charge / pallet 1 s.
- **New:** Skull Merchant (drones with rotating scan lines, lock-ons, claw traps, hacking, recall → Undetectable), Blight (5 rush tokens, slams, lethal rush, special attack, fatigue), Nurse (blinks through walls, chain blink, blink attacks, fatigue, no vaulting), Unknown (bouncing UVX, Weakened, gaze to recover, hallucinations, dispel, teleport), Nemesis (tentacle strike, Mutation Rate, pallet smashing, contamination, vaccines, two zombies) and Ghoul (Kagune Leap latch → grab attack, Kagune Mark, Enraged, wall cling).

Every killer has a power profile (`js/killers/powerData.js`), a survivor counterplay profile (`js/ai/killerProfiles.js`, `profilesExpansion.js`, `profilesNew.js`) and a killer-bot power controller (`js/ai/killer/powers.js`). Research notes: `docs/research-notes.md`.

## Killer bot (`js/ai/killer/`)

| Layer | File |
|---|---|
| Difficulty → parameters (reaction, attention, view range, memory, prediction, lunge skill, mind-games, pallet IQ, stun avoidance, chase patience, patrol IQ, pressure, hook IQ, tunnelling, slugging, perk IQ, power IQ, aim, mistakes, coordination) | `params.js` |
| Perception: per-survivor beliefs with reaction delay and line of sight, crouching in grass, scratch marks, blood, grunts, loud noises, gen progress, auras from perks/powers — no omniscience | `perception.js` |
| Strategy (utility scoring with commitment): PATROLLING, INVESTIGATING, SEARCHING, CHASING, PICKING_UP_SURVIVOR, CARRYING_SURVIVOR, HOOKING_SURVIVOR, DEFENDING_OBJECTIVE, INTERRUPTING_RESCUE, USING_POWER, BREAKING_PALLET, DAMAGING_GENERATOR, ENDGAME_PRESSURE… | `killerAI.js` |
| A* steering with vault / pallet links and stuck recovery | `steering.js` |
| Chase: prediction, loop cuts, mind-games, pallet baiting, lunge timing, Dead Hard reads | `chase.js` |
| Power controllers for all 24 killers | `powers.js` |
| 2v8 coordination: shared sightings, target claims, regions, roles | `team.js` |

The survivor AI (perception and killer belief, utility goals, behaviour tree, chase fields, team blackboard, perk brain) is unchanged in structure and now also tracks multiple killers (`js/ai/survivorAI.js`, `killerPrediction.js`, `chaseAI.js`, `utilityAI.js`, `blackboard.js`, `perkAI.js`).

## Tests

```
node js/tests/run.mjs        # 23 survivor-AI scenarios (in-game AI Lab too)
node js/tests/mech.mjs       # 13 power checks: Trapper haste (G), Cenobite chain regression (H),
                             # Singularity (D), Cannibal (E), the six new killers + their counterplay (F)
node js/tests/net.mjs [secs]  # multiplayer sync: every killer through the host → snapshot → client mirror
node js/tests/modes.mjs      # A1 full Play-as-Survivor match through the player controller,
                             # B1 killer difficulty 1/5/10, C1–C3 both 2v8 configs + coordination,
                             # I1 every killer plays a full bot match (slow: several minutes)
```
