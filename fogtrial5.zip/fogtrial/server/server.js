// Fog Trial multiplayer server: serves the game page and runs custom-match rooms.
// The server is authoritative: it runs the real simulation (bots included) at 60 Hz and sends
// each player 20 snapshots a second. Start with `npm start` (PORT env var, default 8080).
import { createServer } from 'node:http';
import { readFileSync, existsSync } from 'node:fs';
import { WebSocketServer } from './ws.js';
import { Room, newCode, MAX_PLAYERS } from './rooms.js';
import { NetHost } from '../js/net/host.js';
import { NET_VERSION, SNAP_HZ } from '../js/net/protocol.js';

const PORT = +process.env.PORT || 8080;
const STEP = 1 / 60;
const SPEED = Math.max(1, +process.env.FOG_SPEED || 1); // testing only: run matches faster than real time
// the bundled page lives next to the bundled server (dist/), or in ../dist when run from source
const pagePath = [new URL('./index.html', import.meta.url), new URL('../dist/index.html', import.meta.url)].find((u) => existsSync(u));
let page = pagePath ? readFileSync(pagePath) : Buffer.from('<h1>Fog Trial server</h1><p>Build the game first: npm run build</p>');

const http = createServer((req, res) => {
  const url = (req.url || '/').split('?')[0];
  if (url === '/health') { res.writeHead(200, { 'content-type': 'text/plain' }); res.end('ok'); return; }
  if (url === '/' || url === '/index.html') { res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-cache' }); res.end(page); return; }
  res.writeHead(404); res.end('not found');
});
const wss = new WebSocketServer({ server: http, maxPayload: 64 * 1024 });
const rooms = new Map();
let nextId = 1;

const send = (p, msg) => { if (p.ws.readyState === 1) p.ws.send(typeof msg === 'string' ? msg : JSON.stringify(msg)); };
process.on('uncaughtException', (e) => console.error('uncaught', e));
const broadcastRoom = (room) => { for (const p of room.players.values()) send(p, room.state(p.id)); };

wss.on('connection', (ws) => {
  const p = { id: 'p' + nextId++, name: 'Player', ws, room: null, loadout: {}, alive: true };
  ws.on('message', (raw) => {
    let msg; try { msg = JSON.parse(raw); } catch { return; }
    try { handle(p, msg); } catch (e) { console.error('message error', e); send(p, { t: 'err', msg: 'Server error: ' + e.message }); }
  });
  ws.on('close', () => { const r = p.room; if (r) { r.remove(p); if (!r.players.size) rooms.delete(r.code); else broadcastRoom(r); } });
});

function handle(p, msg) {
  const r = p.room;
  switch (msg.t) {
    case 'hello':
      p.name = String(msg.name || 'Player').replace(/[<>]/g, '').slice(0, 16) || 'Player';
      if (msg.v !== NET_VERSION) send(p, { t: 'err', msg: 'Your game version differs from the server — reload the page.' });
      send(p, { t: 'welcome', pid: p.id, v: NET_VERSION }); return;
    case 'create': {
      if (r) r.remove(p);
      const room = new Room(newCode(rooms), p); rooms.set(room.code, room);
      if (msg.loadout) room.loadout(p, msg.loadout);
      broadcastRoom(room); return;
    }
    case 'join': {
      const room = rooms.get(String(msg.code || '').toUpperCase().trim());
      if (!room) { send(p, { t: 'err', msg: 'No room with that code.' }); return; }
      if (room.players.size >= MAX_PLAYERS + 4) { send(p, { t: 'err', msg: 'That room is full.' }); return; }
      if (r) r.remove(p);
      room.add(p); if (msg.loadout) room.loadout(p, msg.loadout);
      broadcastRoom(room);
      if (room.match) send(p, { t: 'err', msg: 'A match is running — you will join the next one (you can watch the lobby until then).' });
      return;
    }
  }
  if (!r) return;
  switch (msg.t) {
    case 'leave': r.remove(p); if (!r.players.size) rooms.delete(r.code); else broadcastRoom(r); send(p, { t: 'left' }); return;
    case 'settings': r.settings(p, msg); break;
    case 'slot': r.editSlot(p, msg); break;
    case 'take': r.take(p, msg.i); break;
    case 'unslot': r.unslot(p); break;
    case 'loadout': r.loadout(p, msg); p.ready = false; break;
    case 'ready': p.ready = !!msg.v; break;
    case 'chat': r.say(p, msg.text); break;
    case 'start': {
      const err = r.start(p); if (err) { send(p, { t: 'err', msg: err }); return; }
      for (const q of r.players.values()) {
        const h = r.match.humans.find((x) => x.pid === q.id);
        send(q, { t: 'start', cfg: r.match.cfg, role: h ? h.role : 'spectator', index: h ? h.index : -1 });
      }
      break;
    }
    case 'in': if (r.match) r.match.host.input(p.id, msg); return;
    case 'chk': if (r.match) r.match.host.check(p.id, msg.res); return;
    default: return;
  }
  broadcastRoom(r);
}

// ---------------------------------------------------------------- simulation loop
let last = performance.now();
setInterval(() => {
  const now = performance.now(); const dt = Math.min(0.25, (now - last) / 1000); last = now;
  for (const r of rooms.values()) {
    const M = r.match; if (!M) continue;
    M.acc += dt * SPEED; let n = 0;
    try {
      while (M.acc >= STEP && n < 6 * SPEED) {
        M.host.step(STEP); M.acc -= STEP; n++; M.steps++;
        if (M.steps % (60 / SNAP_HZ) === 0) {
          M.host.buildFrame();
          for (const q of r.players.values()) send(q, NetHost.serialize(M.host.snapshotFor(q.id)));
        }
        if (M.host.over) break;
      }
      if (M.acc > SPEED) M.acc = 0; // a stalled server skips ahead instead of fast-forwarding
    } catch (e) { console.error('match crashed', e); for (const q of r.players.values()) send(q, { t: 'err', msg: 'The match crashed on the server: ' + e.message }); r.end(); broadcastRoom(r); continue; }
    if (M.host.over) {
      const res = M.host.results();
      for (const q of r.players.values()) send(q, { t: 'end', results: res });
      r.end(); broadcastRoom(r);
    }
  }
}, 1000 / 60);
// drop dead connections (Render keeps idle sockets otherwise)
setInterval(() => { for (const ws of wss.clients) { if (ws._fogDead) { ws.terminate(); continue; } ws._fogDead = true; ws.ping(); } }, 30000);
wss.on('connection', (ws) => ws.on('pong', () => (ws._fogDead = false)));

http.listen(PORT, () => console.log(`Fog Trial server on http://localhost:${PORT}`));
