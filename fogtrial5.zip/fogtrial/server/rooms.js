// Lobby rooms for custom matches (no sockets here — server.js wires them).
// A room has slots like a Dead by Daylight custom match: 1 killer + 4 survivors (1v4) or
// 2 killers + 8 survivors (2v8). Every slot is either a human or a bot; the host sets the bots'
// difficulty (and the bot killer's killer), anyone can take a bot slot, and at start every
// remaining bot slot is filled by the game's AI.
import { KILLERS, KILLER_LIST } from '../js/killers/index.js';
import { KILLER_PERKS } from '../js/perks/killerPerks.js';
import { SURVIVOR_PERKS } from '../js/perks/survivorPerks.js';
import { ITEMS, ITEM_ADDONS } from '../js/items/items.js';
import { MAPS } from '../js/maps/maps.js';
import { SURVIVOR_ROSTER } from '../js/ai/personality.js';
import { config2v8, SURVIVOR_CLASSES, KILLER_CLASSES } from '../js/modes/twoVeight.js';
import { NetHost } from '../js/net/host.js';

const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
export const MAX_PLAYERS = 10;

export class Room {
  constructor(code, host) {
    this.code = code; this.hostId = host.id; this.players = new Map(); this.mode = '1v4'; this.mapId = 'rotwood';
    this.slots = []; this.match = null; this.chat = []; this.buildSlots();
    this.add(host);
  }
  buildSlots() {
    const old = this.slots; const nk = this.mode === '2v8' ? 2 : 1, ns = this.mode === '2v8' ? 8 : 4;
    const kOld = old.filter((s) => s.role === 'killer'), sOld = old.filter((s) => s.role === 'survivor');
    const killerPool = ['trapper', 'wraith', 'huntress', 'hillbilly'];
    this.slots = [
      ...Array.from({ length: nk }, (_, i) => ({ role: 'killer', idx: i, pid: kOld[i]?.pid || null, botDiff: kOld[i]?.botDiff ?? 5, botKiller: kOld[i]?.botKiller || killerPool[i], cls: kOld[i]?.cls || ['brute', 'enforcer'][i] })),
      ...Array.from({ length: ns }, (_, i) => ({ role: 'survivor', idx: i, pid: sOld[i]?.pid || null, botDiff: sOld[i]?.botDiff ?? 5, cls: sOld[i]?.cls || ['escapist', 'guide', 'medic', 'scout'][i % 4] })),
    ];
    // players who lost their slot become spectators
    for (const p of this.players.values()) p.slot = this.slots.findIndex((s) => s.pid === p.id);
  }
  add(p) {
    p.room = this; p.ready = false; p.slot = -1; this.players.set(p.id, p);
    // drop newcomers into the first free survivor slot, else the killer slot, else spectate
    if (!this.match) { const free = this.slots.findIndex((s) => s.role === 'survivor' && !s.pid); const fk = this.slots.findIndex((s) => s.role === 'killer' && !s.pid); this.take(p, free >= 0 ? free : fk); }
    this.say(null, `${p.name} joined`);
  }
  remove(p) {
    this.players.delete(p.id); p.room = null;
    const s = this.slots.find((q) => q.pid === p.id); if (s) s.pid = null;
    if (this.match) this.match.host.dropHuman(p.id);
    if (this.hostId === p.id) { const next = this.players.values().next().value; this.hostId = next ? next.id : null; if (next) this.say(null, `${next.name} is now the host`); }
    this.say(null, `${p.name} left`);
  }
  take(p, i) {
    const s = this.slots[i]; if (!s || (s.pid && s.pid !== p.id) || this.match) return false;
    for (const q of this.slots) if (q.pid === p.id) q.pid = null;
    s.pid = p.id; p.slot = i; p.ready = false; return true;
  }
  unslot(p) { for (const q of this.slots) if (q.pid === p.id) q.pid = null; p.slot = -1; p.ready = false; }
  say(p, text) { this.chat.push({ who: p ? p.name : '', text: String(text).slice(0, 200), t: Date.now() }); if (this.chat.length > 40) this.chat.shift(); }
  settings(p, o) {
    if (p.id !== this.hostId || this.match) return;
    if (o.mode === '1v4' || o.mode === '2v8') { if (o.mode !== this.mode) { this.mode = o.mode; this.buildSlots(); for (const q of this.players.values()) q.ready = false; } }
    if (o.mapId && MAPS[o.mapId]) this.mapId = o.mapId; else if (o.mapId === 'random') this.mapId = 'random';
  }
  editSlot(p, o) {
    const s = this.slots[o.i]; if (!s || this.match) return;
    const own = s.pid === p.id, host = p.id === this.hostId;
    if (host && o.kick && s.pid && s.pid !== p.id) { const q = this.players.get(s.pid); if (q) this.unslot(q); }
    if (host && o.botDiff >= 1 && o.botDiff <= 10) s.botDiff = Math.round(o.botDiff);
    if (host && o.botKiller && KILLERS[o.botKiller]) s.botKiller = o.botKiller;
    if ((host || own) && o.cls && (SURVIVOR_CLASSES[o.cls] || KILLER_CLASSES[o.cls])) s.cls = o.cls;
  }
  loadout(p, o) {
    const L = {};
    if (o.killer && KILLERS[o.killer]) L.killer = o.killer;
    if (Array.isArray(o.kperks)) L.kperks = o.kperks.filter((x) => KILLER_PERKS[x]).slice(0, 4);
    if (Array.isArray(o.addons) && L.killer) L.addons = o.addons.filter((x) => KILLERS[L.killer].addons[x]).slice(0, 2);
    if (Array.isArray(o.sperks)) L.sperks = o.sperks.filter((x) => SURVIVOR_PERKS[x]).slice(0, 4);
    if (o.item === null || ITEMS[o.item]) L.item = o.item || null;
    if (o.addon && ITEM_ADDONS[o.addon]) L.addon = o.addon;
    if (Number.isInteger(o.character) && SURVIVOR_ROSTER[o.character]) L.character = o.character;
    p.loadout = { ...(p.loadout || {}), ...L };
  }
  canStart() {
    const humans = this.slots.filter((s) => s.pid);
    if (!humans.length) return 'Take a slot first';
    for (const s of humans) { const q = this.players.get(s.pid); if (!q || (!q.ready && q.id !== this.hostId)) return `${q ? q.name : 'A player'} is not ready`; }
    return null;
  }
  // Match config: the game's own config, with human flags on the human slots
  buildConfig() {
    const seed = Math.floor(Math.random() * 1e9);
    const mapId = this.mapId === 'random' ? Object.keys(MAPS)[Math.floor(Math.random() * Object.keys(MAPS).length)] : this.mapId;
    const pl = (s) => (s.pid ? this.players.get(s.pid) : null);
    const ks = this.slots.filter((s) => s.role === 'killer'), ss = this.slots.filter((s) => s.role === 'survivor');
    const humans = [];
    const killerOf = (s) => { const p = pl(s); return p ? p.loadout?.killer || 'trapper' : s.botKiller || KILLER_LIST[Math.floor(Math.random() * KILLER_LIST.length)].id; };
    let cfg;
    if (this.mode === '2v8') {
      cfg = config2v8({ role: 'spectate', killerA: killerOf(ks[0]), killerB: killerOf(ks[1]), killerAClass: ks[0].cls, killerBClass: ks[1].cls, mapId, seed, killerDifficulty: ks[0].botDiff, killerBDifficulty: ks[1].botDiff });
      ks.forEach((s, i) => { const p = pl(s); if (p) { cfg.killers[i].human = true; cfg.killers[i].addons = p.loadout?.addons || []; humans.push({ pid: p.id, name: p.name, role: 'killer', index: i }); } });
      ss.forEach((s, i) => {
        const p = pl(s); const sc = cfg.survivors[i]; sc.perks = [SURVIVOR_CLASSES[s.cls]?.id || 'class_escapist']; sc.cls = s.cls; sc.difficulty = s.botDiff;
        if (p) { sc.human = true; sc.name = p.name; humans.push({ pid: p.id, name: p.name, role: 'survivor', index: i }); }
      });
    } else {
      const k = ks[0], kp = pl(k);
      cfg = { mode: '1v4', mapId, seed, perkMode: 'random', itemMode: 'random', difficulty: 5, survivorCount: 4, gensRequired: 5, gensOnMap: 7,
        killers: [kp ? { killerId: killerOf(k), perks: kp.loadout?.kperks || [], addons: kp.loadout?.addons || [], human: true } : { killerId: killerOf(k), perks: (KILLERS[killerOf(k)]?.signature || []).slice(0, 3), difficulty: k.botDiff }],
        survivors: ss.map((s) => { const p = pl(s); if (!p) return { difficulty: s.botDiff }; const L = p.loadout || {}; return { human: true, name: p.name, difficulty: 5, perks: L.sperks || [], item: L.item ?? null, itemAddons: L.addon ? [L.addon] : [] }; }),
      };
      if (kp) humans.push({ pid: kp.id, name: kp.name, role: 'killer', index: 0 });
      ss.forEach((s, i) => { const p = pl(s); if (p) humans.push({ pid: p.id, name: p.name, role: 'survivor', index: i }); });
    }
    cfg.playerRole = 'net'; cfg.killerId = cfg.killers[0].killerId;
    return { cfg, humans };
  }
  start(p) {
    if (p.id !== this.hostId || this.match) return 'Only the host can start';
    const why = this.canStart(); if (why) return why;
    const { cfg, humans } = this.buildConfig();
    const host = new NetHost(cfg, humans);
    this.match = { host, cfg, humans, acc: 0, steps: 0, t0: Date.now() };
    return null;
  }
  end() { this.match = null; for (const p of this.players.values()) p.ready = false; }
  state(forPid) {
    return {
      t: 'room', code: this.code, hostId: this.hostId, you: forPid, mode: this.mode, mapId: this.mapId, playing: !!this.match,
      players: [...this.players.values()].map((p) => ({ id: p.id, name: p.name, slot: p.slot, ready: p.ready, loadout: p.loadout || {} })),
      slots: this.slots.map((s, i) => ({ i, role: s.role, idx: s.idx, pid: s.pid, botDiff: s.botDiff, botKiller: s.botKiller, cls: s.cls })),
      chat: this.chat.slice(-20),
    };
  }
}
export function newCode(rooms) { for (;;) { let c = ''; for (let i = 0; i < 4; i++) c += CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)]; if (!rooms.has(c)) return c; } }
