// Minimal WebSocket server (RFC 6455) on top of node:http — text frames, ping/pong, close,
// fragmented messages. No dependencies, so the server runs with plain `node`.
import { createHash } from 'node:crypto';
import { EventEmitter } from 'node:events';

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

class Socket extends EventEmitter {
  constructor(sock, maxPayload) {
    super(); this.sock = sock; this.readyState = 1; this.buf = Buffer.alloc(0); this.frags = []; this.maxPayload = maxPayload;
    sock.setNoDelay(true);
    sock.on('data', (d) => { this.buf = this.buf.length ? Buffer.concat([this.buf, d]) : d; try { this.parse(); } catch (e) { this.terminate(); } });
    sock.on('close', () => this.closed());
    sock.on('error', () => this.closed());
  }
  closed() { if (this.readyState === 3) return; this.readyState = 3; this.emit('close'); }
  parse() {
    for (;;) {
      const b = this.buf; if (b.length < 2) return;
      const fin = b[0] & 0x80, op = b[0] & 0x0f, masked = b[1] & 0x80; let len = b[1] & 0x7f, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
      if (len > this.maxPayload) { this.close(1009); return; }
      const mOff = off; if (masked) off += 4;
      if (b.length < off + len) return;
      let data = b.subarray(off, off + len);
      if (masked) { const mask = b.subarray(mOff, mOff + 4); data = Buffer.from(data); for (let i = 0; i < data.length; i++) data[i] ^= mask[i & 3]; }
      this.buf = b.subarray(off + len);
      if (op === 0x8) { this.close(); return; }
      if (op === 0x9) { this.frame(0xA, data); continue; }
      if (op === 0xA) { this.emit('pong'); continue; }
      if (op === 0x1 || op === 0x2 || op === 0x0) {
        this.frags.push(data);
        if (fin) { const msg = Buffer.concat(this.frags); this.frags = []; this.emit('message', msg.toString('utf8')); }
      }
    }
  }
  frame(op, payload) {
    if (this.readyState !== 1) return;
    const n = payload.length; let head;
    if (n < 126) { head = Buffer.alloc(2); head[1] = n; }
    else if (n < 65536) { head = Buffer.alloc(4); head[1] = 126; head.writeUInt16BE(n, 2); }
    else { head = Buffer.alloc(10); head[1] = 127; head.writeBigUInt64BE(BigInt(n), 2); }
    head[0] = 0x80 | op;
    this.sock.write(Buffer.concat([head, payload]));
  }
  send(text) { this.frame(0x1, Buffer.from(text, 'utf8')); }
  ping() { this.frame(0x9, Buffer.alloc(0)); }
  close(code = 1000) { if (this.readyState !== 1) return; const p = Buffer.alloc(2); p.writeUInt16BE(code, 0); this.frame(0x8, p); this.readyState = 2; this.sock.end(); setTimeout(() => this.sock.destroy(), 1000); }
  terminate() { this.sock.destroy(); this.closed(); }
}

export class WebSocketServer extends EventEmitter {
  constructor({ server, maxPayload = 1 << 20 }) {
    super(); this.clients = new Set();
    server.on('upgrade', (req, sock) => {
      const key = req.headers['sec-websocket-key'];
      if (!key || (req.headers.upgrade || '').toLowerCase() !== 'websocket') { sock.end('HTTP/1.1 400 Bad Request\r\n\r\n'); return; }
      const accept = createHash('sha1').update(key + GUID).digest('base64');
      sock.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${accept}\r\n\r\n`);
      const ws = new Socket(sock, maxPayload); this.clients.add(ws);
      ws.on('close', () => this.clients.delete(ws));
      this.emit('connection', ws, req);
    });
  }
}
