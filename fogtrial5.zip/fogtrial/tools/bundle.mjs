// Tiny bundler: wraps each ES module in a function, rewrites import/export,
// and inlines CSS + JS into one standalone HTML page (dist/index.html).
// Usage: node tools/bundle.mjs
import fs from 'fs';
import path from 'path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const entry = 'js/main.js';
const mods = new Map(); const order = []; const visiting = new Set();

function resolve(from, spec) { return path.posix.normalize(path.posix.join(path.posix.dirname(from), spec)); }

function load(id) {
  if (mods.has(id)) return;
  if (visiting.has(id)) throw new Error('import cycle at ' + id);
  visiting.add(id);
  let src = fs.readFileSync(path.join(root, id), 'utf8');
  const deps = [];
  // static imports (possibly multi-line)
  src = src.replace(/import\s*\{([^}]*)\}\s*from\s*['"]([^'"]+)['"];?/g, (m, names, spec) => {
    const dep = resolve(id, spec); deps.push(dep);
    const binds = names.split(',').map((s) => s.trim()).filter(Boolean).map((s) => { const [a, b] = s.split(/\s+as\s+/); return b ? `${a.trim()}: ${b.trim()}` : a.trim(); });
    return `const { ${binds.join(', ')} } = __req(${JSON.stringify(dep)});`;
  });
  // dynamic imports → resolved promise of the bundled module
  src = src.replace(/import\(\s*['"]([^'"]+)['"]\s*\)/g, (m, spec) => { const dep = resolve(id, spec); deps.push(dep); return `Promise.resolve(__req(${JSON.stringify(dep)}))`; });
  const exportsList = [];
  src = src.replace(/export\s+(const|let|class|function|async function)\s+([A-Za-z_$][\w$]*)/g, (m, kw, name) => { exportsList.push(name); return `${kw} ${name}`; });
  src = src.replace(/export\s*\{([^}]*)\};?/g, (m, names) => { for (const n of names.split(',').map((s) => s.trim()).filter(Boolean)) exportsList.push(n); return ''; });
  if (/\bexport\b\s/.test(src.replace(/\/\/.*$/gm, ''))) console.warn('possible unhandled export in', id);
  for (const d of deps) if (d !== id) load(d);
  visiting.delete(id);
  mods.set(id, { src, exportsList });
  order.push(id);
}
load(entry);
// also bundle modules only reached dynamically (already followed above)

let js = `(function(){\n'use strict';\nconst __defs = {}, __cache = {};\nfunction __req(id){ if (__cache[id]) return __cache[id]; const f = __defs[id]; if (!f) throw new Error('missing module ' + id); return (__cache[id] = f()); }\n`;
for (const id of order) {
  const { src, exportsList } = mods.get(id);
  js += `__defs[${JSON.stringify(id)}] = function(){\n${src}\nreturn { ${exportsList.join(', ')} };\n};\n`;
}
js += `__req(${JSON.stringify(entry)});\n})();\n`;
// Guard against a stray closing script tag inside the code
js = js.replace(/<\/script/gi, '<\\/script');

const css = ['css/main.css', 'css/hud.css', 'css/menus.css'].map((f) => fs.readFileSync(path.join(root, f), 'utf8')).join('\n');
let html = '<meta charset="utf-8">\n' + fs.readFileSync(path.join(root, 'index.html'), 'utf8');
html = html.replace(/<link rel="stylesheet" href="css\/[^"]+">\n?/g, '');
html = html.replace('</noscript>', `</noscript>\n<style>\n${css}\n</style>`);
html = html.replace(/<script type="module" src="js\/main.js"><\/script>/, `<script>\n${js}</script>`);
fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
fs.writeFileSync(path.join(root, 'dist/index.html'), html);
console.log('bundled', order.length, 'modules →', (html.length / 1024).toFixed(0) + ' KB');
