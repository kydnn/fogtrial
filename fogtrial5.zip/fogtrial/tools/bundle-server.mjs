// Bundles the multiplayer server (server/server.js + the game modules it uses) into one file,
// and writes a ready-to-deploy folder: deploy/{server.mjs, index.html, package.json}.
// Those three files are all a host like Render needs. Usage: node tools/bundle-server.mjs
// (run tools/bundle.mjs first so dist/index.html is fresh).
import fs from 'fs';
import path from 'path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const entry = 'server/server.js';
const mods = new Map(); const order = []; const visiting = new Set(); const externals = new Set();
const resolve = (from, spec) => path.posix.normalize(path.posix.join(path.posix.dirname(from), spec));

function load(id) {
  if (mods.has(id)) return;
  if (visiting.has(id)) throw new Error('import cycle at ' + id);
  visiting.add(id);
  let src = fs.readFileSync(path.join(root, id), 'utf8');
  const deps = [];
  src = src.replace(/import\s*\{([^}]*)\}\s*from\s*['"]([^'"]+)['"];?/g, (m, names, spec) => {
    if (!spec.startsWith('.')) { externals.add(m.trim().replace(/;?$/, ';')); return ''; } // node: built-ins stay real imports
    const dep = resolve(id, spec); deps.push(dep);
    const binds = names.split(',').map((s) => s.trim()).filter(Boolean).map((s) => { const [a, b] = s.split(/\s+as\s+/); return b ? `${a.trim()}: ${b.trim()}` : a.trim(); });
    return `const { ${binds.join(', ')} } = __req(${JSON.stringify(dep)});`;
  });
  src = src.replace(/import\(\s*['"]([^'"]+)['"]\s*\)/g, (m, spec) => { const dep = resolve(id, spec); deps.push(dep); return `Promise.resolve(__req(${JSON.stringify(dep)}))`; });
  const exportsList = [];
  src = src.replace(/export\s+(const|let|class|function|async function)\s+([A-Za-z_$][\w$]*)/g, (m, kw, name) => { exportsList.push(name); return `${kw} ${name}`; });
  src = src.replace(/export\s*\{([^}]*)\};?/g, (m, names) => { for (const n of names.split(',').map((s) => s.trim()).filter(Boolean)) exportsList.push(n); return ''; });
  for (const d of deps) if (d !== id) load(d);
  visiting.delete(id);
  mods.set(id, { src, exportsList }); order.push(id);
}
load(entry);
let js = `// Fog Trial multiplayer server — bundled build. Run: node server.mjs (PORT env var, default 8080)\n${[...externals].join('\n')}\nconst __defs = {}, __cache = {};\nfunction __req(id){ if (__cache[id]) return __cache[id]; const f = __defs[id]; if (!f) throw new Error('missing module ' + id); return (__cache[id] = f()); }\n`;
for (const id of order) { const { src, exportsList } = mods.get(id); js += `__defs[${JSON.stringify(id)}] = function(){\n${src}\nreturn { ${exportsList.join(', ')} };\n};\n`; }
js += `__req(${JSON.stringify(entry)});\n`;
const out = path.join(root, 'deploy'); fs.mkdirSync(out, { recursive: true });
fs.writeFileSync(path.join(out, 'server.mjs'), js);
fs.copyFileSync(path.join(root, 'dist/index.html'), path.join(out, 'index.html'));
fs.writeFileSync(path.join(out, 'package.json'), JSON.stringify({ name: 'fogtrial-server', version: '1.0.0', private: true, type: 'module', scripts: { start: 'node server.mjs' }, engines: { node: '>=18' } }, null, 2) + '\n');
console.log('server bundled:', order.length, 'modules →', (js.length / 1024).toFixed(0) + ' KB · deploy/ ready (server.mjs, index.html, package.json)');
