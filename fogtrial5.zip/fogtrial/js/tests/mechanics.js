// Mechanics / regression tests for killer powers (spec §23 D, E, G, H and the new killers).
// Each test drives the real match simulation with scripted inputs and checks the rules.
import { M, dist } from '../core/util.js';
import { setup, place, run } from './aiScenarios.js';
import { Match } from '../core/game.js';

const idle = (k) => { const i = k.input; i.mx = 0; i.my = 0; i.rmb = false; i.lmb = false; };
const freeze = (m) => { for (const s of m.survivors) { if (s.ai) s.ai.update = () => {}; s.input && (s.input.mx = 0); } };
const still = (m) => { m.aiPaused = false; for (const s of m.survivors) { s.ai && (s.ai.update = () => { s.moveDir = null; }); } };

export const MECH_TESTS = [
  // ------------------------------------------------------------------ G: Trapper
  {
    id: 'G1', name: 'Trapper: Haste on trap set, expires, no stacking',
    run() {
      const m = setup({ killer: 'trapper', survivors: 1 }); freeze(m);
      const k = m.killer, pw = k.power; place(k, 30, 25); place(m.survivors[0], 60, 40); pw.carried = 2;
      const setOne = () => { run(m, 0.05, () => { idle(k); k.input.rmbP = true; k.input.rmb = true; }); run(m, 3, () => { idle(k); k.input.rmb = true; }); };
      setOne();
      const h1 = k.status.list.filter((s) => s.id === 'haste' && s.source === 'trap_set');
      const ok1 = h1.length === 1 && Math.abs(h1[0].value - 0.10) < 1e-6;
      place(k, 36, 25); k.facing = 0; setOne();
      const h2 = k.status.list.filter((s) => s.id === 'haste' && s.source === 'trap_set').length;
      run(m, 4.5, () => idle(k));
      const h3 = k.status.list.filter((s) => s.id === 'haste' && s.source === 'trap_set').length;
      return { pass: ok1 && h2 === 1 && h3 === 0 && m.traps.filter((t) => t.state === 'set').length === 2, detail: `haste after set: ${h1.length} (value ${h1[0]?.value}), after 2nd set: ${h2} entry, after 4.5 s: ${h3}, traps set ${m.traps.filter((t) => t.state === 'set').length}` };
    },
  },
  // ------------------------------------------------------------------ H: Cenobite chain regression
  {
    id: 'H1', name: 'Cenobite: repeated chain / gateway / stun never freezes him',
    run() {
      const m = setup({ killer: 'cenobite', survivors: 1, map: { tiles: [{ key: 'short_wall', ox: 30, oy: 22 }] } }); freeze(m);
      const k = m.killer, pw = k.power, s = m.survivors[0]; place(k, 20, 25); place(s, 34, 25);
      let stuck = 0;
      for (let i = 0; i < 12; i++) {
        pw.setCd('chain', 0); pw.setCd('gateway', 0);
        const viaGateway = i % 3 === 1, stunMid = i % 3 === 2;
        if (viaGateway) run(m, 0.1, () => { idle(k); k.input.aim = 0; k.input.aimDist = 6 * M; k.input.eP = true; });
        run(m, 0.6, (mm, t) => { idle(k); k.input.aim = Math.atan2(s.y - k.y, s.x - k.x); k.input.rmb = true; if (stunMid && t > 0.2 && t < 0.25) k.stun(mm, 1, 'pallet'); });
        run(m, 2.2, () => idle(k));
        // he must be able to walk again
        const x0 = k.x, y0 = k.y; run(m, 1.0, () => { idle(k); k.input.mx = i % 2 ? 1 : -1; });
        if (dist(k.x, k.y, x0, y0) < 1.5 * M || pw.state === 'chain' || pw.chain) stuck++;
        place(k, 20, 25); k.stunT = 0; s.status.remove('chained'); place(s, 34, 25);
      }
      return { pass: stuck === 0, detail: `${12 - stuck}/12 chain cycles (plain, via Gateway, stunned mid-chain) ended with him moving; final state ${pw.state}` };
    },
  },
  // ------------------------------------------------------------------ D: Singularity
  {
    id: 'D1', name: 'Singularity: pods stick to walls, lock Slipstreams, teleport, EMP disables',
    run() {
      const m = setup({ killer: 'singularity', survivors: 2, map: { tiles: [{ key: 'short_wall', ox: 30, oy: 22 }] } }); still(m);
      const k = m.killer, pw = k.power, [a, b] = m.survivors; place(k, 18, 25); place(a, 40, 34); place(b, 60, 40);
      // shoot a pod at the wall to the east (border at x≈68 m is within 22 m? no) — shoot north at the border
      place(k, 20, 12); k.facing = -Math.PI / 2;
      run(m, 0.3, () => { idle(k); k.input.aim = -Math.PI / 2; k.input.rmb = true; }); run(m, 0.6, () => idle(k));
      const pods1 = pw.pods.length;
      // miss: shooting down a long open lane (> 22 m) wastes the shot
      place(k, 10, 25); run(m, 0.3, () => { idle(k); k.input.aim = 0.02; k.input.rmb = true; }); run(m, 1, () => idle(k));
      const pods2 = pw.pods.length;
      // place a pod directly and control it
      pw.attachPod(m, 36 * M, 40 * M); const pod = pw.pods.find((p) => dist(p.x, p.y, 36 * M, 40 * M) < 1); place(k, 10, 10);
      run(m, 0.1, () => { idle(k); k.input.aimX = pod.x; k.input.aimY = pod.y; k.input.eP = true; });
      const inCtl = pw.state === 'control' && pw.ctrl === pod;
      run(m, 1.0, () => { idle(k); k.input.aimX = a.x; k.input.aimY = a.y; });
      const slip = a.status.has('slipstream');
      // spread: b stands next to a for > 2 s
      place(b, 41, 34.5); run(m, 2.4, () => { idle(k); k.input.aimX = a.x; k.input.aimY = a.y; });
      const spread = b.status.has('slipstream');
      // lock cooldown is over (3 s) → lock again then LMB teleports to the pod
      run(m, 1.6, () => { idle(k); k.input.aimX = a.x; k.input.aimY = a.y; });
      run(m, 0.05, () => { idle(k); k.input.aimX = a.x; k.input.aimY = a.y; k.input.lmbP = true; });
      run(m, 0.6, () => idle(k));
      const tp = dist(k.x, k.y, pod.x, pod.y) < 3 * M, oc = pw.overclockT > 0;
      // EMP from a survivor: clears Slipstream in 10 m and disables the pod
      a.emp = true; delete k.input.aimX; delete k.input.aimY; place(k, 10, 10);
      a.startAction('useEmp', null, m); run(m, 2.7, () => idle(k));
      const disabled = (pod.data.disabledUntil || 0) > m.time, cleared = !a.status.has('slipstream') && !b.status.has('slipstream');
      // disabled pod: can be destroyed from inside (hold LMB 0.75 s)
      run(m, 0.1, () => { idle(k); k.input.aimX = pod.x; k.input.aimY = pod.y; k.input.eP = true; });
      run(m, 1.0, () => { idle(k); k.input.lmb = true; });
      const destroyed = pod.dead;
      const pass = pods1 === 1 && pods2 === 1 && inCtl && slip && spread && tp && oc && disabled && cleared && destroyed;
      return { pass, detail: `wall pod ${pods1}, miss kept ${pods2}, control ${inCtl}, lock→slip ${slip}, spread ${spread}, teleport ${tp}, overclock ${oc}, EMP disabled ${disabled} & cleared ${cleared}, destroyed ${destroyed}` };
    },
  },
  {
    id: 'D2', name: 'Singularity: Overclock pallet stun → pallet breaks + Overheat; printers fill to 97%',
    run() {
      const m = setup({ killer: 'singularity', survivors: 1, map: { tiles: [{ key: 'short_wall', ox: 30, oy: 22 }] } }); still(m);
      const k = m.killer, pw = k.power, s = m.survivors[0], p = m.map.pallets[0];
      place(s, p.x / M + p.nx * 1.2, p.y / M + p.ny * 1.2); place(k, p.x / M - p.nx * 0.4, p.y / M - p.ny * 0.4);
      pw.overclockT = 5; s.startAction('dropPallet', p, m); run(m, 1.2, () => idle(k));
      const ok1 = k.stunT <= 0 && p.state === 'broken' && pw.overheatT > 0;
      const pr = m.devices.find((d) => d.kind === 'printer'); pr.data.charge = 90; run(m, 10, () => idle(k));
      const capped = Math.abs(pr.data.charge - 97) < 0.01;
      return { pass: ok1 && capped, detail: `stunned=${k.stunT > 0}, pallet ${p.state}, overheat ${pw.overheatT.toFixed(1)} s, printer passive cap ${pr.data.charge.toFixed(1)}%` };
    },
  },
  // ------------------------------------------------------------------ E: Cannibal
  {
    id: 'E1', name: 'Cannibal: rev, sweep ramp, multi-down, charges, cooldowns',
    run() {
      const m = setup({ killer: 'cannibal', survivors: 3 }); still(m);
      const k = m.killer, pw = k.power, [a, b, c] = m.survivors; place(k, 20, 25); place(a, 28, 24.6); place(b, 28, 25.6); place(c, 60, 10);
      // early release cancels for free
      run(m, 1.0, () => { idle(k); k.input.aim = 0; k.input.rmb = true; }); run(m, 0.1, () => idle(k));
      const cancel = pw.state === 'idle' && Math.floor(pw.charges) === 3;
      run(m, 2.05, () => { idle(k); k.input.aim = 0; k.input.rmb = true; }); run(m, 0.02, () => { idle(k); k.input.aim = 0; });
      const swept = pw.state === 'sweep', charges = Math.floor(pw.charges + 1e-6);
      let v0 = null, v1 = null; run(m, 2.55, (mm, t) => { idle(k); k.input.aim = 0; if (t < 0.05) v0 = pw.speedNow; v1 = pw.speedNow; });
      const multi = a.health === 'dying' && b.health === 'dying';
      run(m, 0.2, () => idle(k));
      const cd = pw.state === 'cooldown' ? pw.cdT : 0;
      return { pass: cancel && swept && charges === 2 && v0 < 4 && v1 > 5.2 && multi && cd > 1.5, detail: `cancel free ${cancel}, sweep ${swept} (charges ${charges}), speed ${v0?.toFixed(2)}→${v1?.toFixed(2)} m/s, multi-down ${multi}, cooldown ${cd.toFixed(1)} s` };
    },
  },
  {
    id: 'E2', name: 'Cannibal: wall ram and over-rev cause a tantrum; dropped pallet is sawn',
    run() {
      const m = setup({ killer: 'cannibal', survivors: 1, map: { tiles: [{ key: 'short_wall', ox: 30, oy: 22 }] } }); still(m);
      const k = m.killer, pw = k.power, s = m.survivors[0]; place(s, 60, 45);
      place(k, 6, 25); run(m, 2.05, () => { idle(k); k.input.aim = Math.PI; k.input.rmb = true; }); run(m, 1.5, () => { idle(k); k.input.aim = Math.PI; });
      const wall = pw.state === 'tantrum' && k.status.has('hindered') && pw.charges === 0;
      run(m, 9, () => idle(k)); pw.charges = 3; pw.state = 'idle';
      // over-rev: hold the rev when it can't start (sim: block the sweep start)
      run(m, 3.2, () => { idle(k); k.input.aim = 0; k.input.rmb = true; });
      const overrev = pw.state === 'tantrum';
      run(m, 9, () => idle(k)); pw.charges = 3; pw.state = 'idle'; k.status.remove('hindered');
      const p = m.map.pallets[0]; p.state = 'down';
      place(k, p.x / M - p.nx * 7, p.y / M - p.ny * 7); const a = Math.atan2(p.ny, p.nx);
      run(m, 2.05, () => { idle(k); k.input.aim = a; k.input.rmb = true; }); run(m, 2.5, () => { idle(k); k.input.aim = a; });
      return { pass: wall && overrev && p.state === 'broken', detail: `wall tantrum ${wall}, over-rev tantrum ${overrev}, pallet ${p.state}, last end ${pw.lastEnd?.why}` };
    },
  },
  // ------------------------------------------------------------------ F: six new killers
  {
    id: 'F1', name: 'Skull Merchant: drone scan, lock-ons → claw trap, crouch avoids, hack disables',
    run() {
      const m = setup({ killer: 'skull_merchant', survivors: 2 }); still(m);
      const k = m.killer, pw = k.power, [a, b] = m.survivors; place(k, 10, 10); place(a, 34, 25); place(b, 37, 28);
      k.facing = Math.atan2(25 * M - k.y, 34 * M - k.x);
      // deploy a drone 8 m ahead (hold 0.5 s)
      place(k, 28, 25); run(m, 0.6, () => { idle(k); k.input.aim = 0; k.input.aimDist = 6 * M; k.input.rmb = true; });
      const d = pw.drones[0]; const deployed = !!d && dist(d.x, d.y, 34 * M, 25 * M) < 1.5 * M;
      // a moves around inside the zone: detected 3 times → claw trap (injured)
      run(m, 12, (mm, t) => { idle(k); a.moveTo = { x: d.x + Math.cos(-t) * 5 * M, y: d.y + Math.sin(-t) * 5 * M }; a.moveMode = 'run'; b.moveMode = 'crouch'; b.moveTo = { x: d.x + Math.cos(-t + 2) * 4 * M, y: d.y + Math.sin(-t + 2) * 4 * M }; });
      const clawed = a.status.has('clawTrap') && a.health === 'injured', crouchSafe = !b.status.has('lockOn') && !b.status.has('clawTrap');
      // hack: a uses the drone (3 s) → disabled + claw trap removed (force a clean hack)
      a.moveTo = null; place(a, d.x / M + 1, d.y / M); const rnd = Math.random; Math.random = () => 0.99;
      a.startAction('device', d, m); run(m, 3.3, () => idle(k)); Math.random = rnd;
      const hacked = (d.data.disabledUntil || 0) > m.time && !a.status.has('clawTrap');
      // recall: Undetectable
      run(m, 0.1, () => { idle(k); k.input.aim = 0; k.input.aimDist = 6 * M; k.input.eP = true; }); run(m, 1.2, () => idle(k));
      const recall = k.status.has('undetectable') && pw.drones.length === 0;
      return { pass: deployed && clawed && crouchSafe && hacked && recall, detail: `deployed ${deployed}, moving survivor claw-trapped ${clawed}, crouching survivor safe ${crouchSafe}, hack disables+removes trap ${hacked}, recall → undetectable ${recall}` };
    },
  },
  {
    id: 'F2', name: 'Blight: rush, slam → chain window, lethal rush special attack, fatigue, tokens',
    run() {
      const m = setup({ killer: 'blight', survivors: 1 }); still(m);
      const k = m.killer, pw = k.power, s = m.survivors[0]; place(s, 60, 45);
      place(k, 10, 25); run(m, 0.05, () => { idle(k); k.input.aim = Math.PI; k.input.rmbP = true; });
      const rushing = pw.state === 'rush' && pw.tokens === 4;
      let maxV = 0; run(m, 1.2, () => { idle(k); k.input.aim = Math.PI; maxV = Math.max(maxV, Math.hypot(k.vx, k.vy) / M); });
      const slam = pw.state === 'window';
      // chain → lethal rush toward the survivor placed ahead, special attack on contact
      place(s, k.x / M + 6, k.y / M); s.moveTo = null;
      run(m, 0.05, () => { idle(k); k.input.aim = 0; k.input.rmbP = true; });
      const lethal = pw.state === 'rush' && pw.lethal;
      run(m, 1.2, () => { idle(k); k.input.aim = Math.atan2(s.y - k.y, s.x - k.x); });
      const hurt = s.health === 'injured';
      const fat = pw.state === 'fatigue';
      run(m, 3, () => idle(k)); const recovered = pw.state === 'idle';
      return { pass: rushing && maxV > 8.5 && slam && lethal && hurt && fat && recovered, detail: `rush ${rushing} (${maxV.toFixed(1)} m/s), slam→window ${slam}, lethal ${lethal}, special hit ${hurt}, fatigue ${fat}, recovered ${recovered}` };
    },
  },
  {
    id: 'F3', name: 'Nurse: blink through a wall, chain, attack out of blink, fatigue, no vaulting',
    run() {
      const m = setup({ killer: 'nurse', survivors: 1, map: { tiles: [{ key: 'long_wall', ox: 30, oy: 25 }] } }); still(m);
      const k = m.killer, pw = k.power, s = m.survivors[0];
      // find the wall and stand on one side of it
      const w = m.map.solids.find((q) => q.kind !== 'border' && q.blocksLOS && q.w * q.h > 4 * M * M) || { x: 30 * M, y: 25 * M, w: M, h: 4 * M };
      const horiz = w.w > w.h; const cx = w.x + w.w / 2, cy = w.y + w.h / 2;
      const off = (horiz ? w.h : w.w) / 2 + 3 * M;
      if (horiz) { k.x = cx; k.y = cy - off; k.facing = Math.PI / 2; s.x = cx; s.y = cy + off + 0.5 * M; } else { k.x = cx - off; k.y = cy; k.facing = 0; s.x = cx + off + 0.5 * M; s.y = cy; }
      const a = k.facing, start = { x: k.x, y: k.y };
      const blocked = !m.world.losClear(k.x, k.y, s.x, s.y);
      run(m, 0.75, () => { idle(k); k.input.aim = a; k.input.rmb = true; }); run(m, 0.05, () => { idle(k); k.input.aim = a; });
      const crossed = horiz ? Math.sign(k.y - cy) !== Math.sign(start.y - cy) : Math.sign(k.x - cx) !== Math.sign(start.x - cx);
      const chain = pw.state === 'chain' && pw.tokens === 1;
      run(m, 0.05, () => { idle(k); k.input.aim = Math.atan2(s.y - k.y, s.x - k.x); k.input.lmbP = true; k.input.lmb = true; }); run(m, 0.4, () => { idle(k); k.input.aim = Math.atan2(s.y - k.y, s.x - k.x); k.input.lmb = true; });
      const hit = s.health === 'injured';
      run(m, 0.6, () => idle(k)); const fat = pw.state === 'fatigue' && pw.fatT > 2.2;
      const noVault = !m.map.windows.length || m.killerContext(k)?.type !== 'vault';
      return { pass: blocked && crossed && chain && hit && fat && noVault, detail: `wall between ${blocked}, blinked through ${crossed}, chain window ${chain}, blink attack ${hit}, fatigue ${fat ? pw.fatT.toFixed(1) + ' s' : pw.state}` };
    },
  },
  {
    id: 'F4', name: 'Unknown: UVX weakens then hurts, gaze clears Weakened, hallucination dispel & teleport',
    run() {
      const m = setup({ killer: 'unknown', survivors: 2 }); still(m);
      const k = m.killer, pw = k.power, [a, b] = m.survivors; place(k, 20, 25); place(a, 30, 25); place(b, 60, 10); k.facing = 0;
      const shoot = () => { pw.setCd('uvx', 0); run(m, 1.05, () => { idle(k); k.input.aim = Math.atan2(a.y - k.y, a.x - k.x); k.input.rmb = true; }); run(m, 0.8, () => idle(k)); };
      shoot(); const weak = a.status.has('weakened') && a.health === 'healthy';
      shoot(); const hurt = a.health === 'injured';
      shoot(); // weakened again
      a.facing = Math.PI; a.lookTarget = { x: k.x, y: k.y }; run(m, 10.5, () => { idle(k); a.facing = Math.atan2(k.y - a.y, k.x - a.x); });
      const cleared = !a.status.has('weakened');
      // hallucination: place, b dispels by staring 4 s
      place(k, 50, 10); run(m, 0.05, () => { idle(k); k.input.eP = true; }); const h1 = pw.hallucinations[0];
      place(k, 20, 40); place(b, 50, 18); run(m, 4.3, () => { idle(k); b.facing = Math.atan2(h1.y - b.y, h1.x - b.x); });
      const dispelled = h1.dead;
      // teleport: place another, walk away, F
      place(k, 40, 40); run(m, 0.05, () => { idle(k); k.input.eP = true; }); place(k, 10, 10);
      run(m, 0.05, () => { idle(k); k.input.aim = Math.atan2(40 * M - k.y, 40 * M - k.x); k.input.aimDist = 30 * M; k.input.cycleP = true; }); run(m, 1.7, () => idle(k));
      const tp = dist(k.x, k.y, 40 * M, 40 * M) < 1.5 * M && pw.cd('tp') > 20;
      return { pass: weak && hurt && cleared && dispelled && tp, detail: `burst → Weakened ${weak}, burst on Weakened → hurt ${hurt}, 10 s gaze clears ${cleared}, hallucination dispelled ${dispelled}, teleport ${tp}` };
    },
  },
  {
    id: 'F5', name: 'Nemesis: tentacle contaminates then hurts, MR 2 smashes pallets, zombies, vaccine cures',
    run() {
      const m = setup({ killer: 'nemesis', survivors: 1, map: { tiles: [{ key: 'short_wall', ox: 30, oy: 22 }] } }); still(m);
      const k = m.killer, pw = k.power, s = m.survivors[0]; for (const z of pw.zombies) m.removeMinion(z); pw.zombies = []; pw.respawn = [];
      place(k, 15, 40); place(s, 19, 40);
      const strike = () => { pw.setCd('tentacle', 0); run(m, 0.4, () => { idle(k); k.input.aim = Math.atan2(s.y - k.y, s.x - k.x); k.input.rmb = true; }); run(m, 0.9, () => idle(k)); place(s, k.x / M + 4, k.y / M); };
      strike(); const cont = s.status.has('contaminated') && s.health === 'healthy' && pw.mr === 2;
      strike(); const hurt = s.health === 'injured' && !s.status.has('contaminated');
      // MR 2: tentacle through a dropped pallet breaks it
      const p = m.map.pallets[0]; p.state = 'down'; place(k, p.x / M - p.nx * 2.5, p.y / M - p.ny * 2.5); place(s, 60, 45);
      pw.setCd('tentacle', 0); run(m, 0.4, () => { idle(k); k.input.aim = Math.atan2(p.ny, p.nx); k.input.rmb = true; }); run(m, 0.5, () => idle(k));
      const smash = p.state === 'broken';
      // zombie sees and hits a survivor in front of it
      pw.spawnZombie(m); const z = pw.zombies[0]; place(z, 40, 10); z.facing = 0; place(s, 44, 10); s.health = 'healthy';
      run(m, 4, () => idle(k));
      const zhit = s.health === 'injured' && s.status.has('contaminated');
      // vaccine: take one from a case, inject (3 s)
      const vc = m.devices.find((d) => d.kind === 'vaccine'); m.removeMinion(z); place(s, vc.x / M + 1, vc.y / M);
      s.startAction('device', vc, m); run(m, 1.2, () => idle(k)); const got = s.vaccines === 1;
      s.startAction('vaccinate', null, m); run(m, 3.2, () => idle(k));
      const cured = !s.status.has('contaminated') && s.vaccines === 0;
      return { pass: cont && hurt && smash && zhit && got && cured, detail: `1st hit contaminates (MR ${pw.mr}) ${cont}, 2nd hurts ${hurt}, MR2 smashes pallet ${smash}, zombie hit+contaminate ${zhit}, vaccine taken ${got} & cures ${cured}` };
    },
  },
  {
    id: 'F6', name: 'Ghoul: leap latches, second leap grab attack + Kagune Mark, Enraged, mend clears mark',
    run() {
      const m = setup({ killer: 'ghoul', survivors: 1 }); still(m);
      const k = m.killer, pw = k.power, s = m.survivors[0]; place(k, 20, 25); place(s, 28, 25);
      run(m, 0.05, () => { idle(k); k.input.aim = 0; k.input.rmbP = true; }); run(m, 0.5, () => idle(k));
      const latched = pw.state === 'latch' && s.health === 'healthy' && s.status.has('latched');
      place(s, k.x / M + 5, k.y / M);
      run(m, 0.05, () => { idle(k); k.input.aim = Math.atan2(s.y - k.y, s.x - k.x); k.input.rmbP = true; }); run(m, 0.4, () => idle(k));
      const grabbed = s.health === 'injured' && s.status.has('deepWound') && s.status.has('kaguneMark');
      const enraged = pw.enraged && pw.maxTokens === 3;
      s.startAction('mend', null, m); run(m, 8.5, () => idle(k));
      const cleared = !s.status.has('kaguneMark') && !pw.enraged;
      // wall cling: leap into the border
      place(k, 5, 25); run(m, 3, () => idle(k)); pw.tokens = 2;
      run(m, 0.05, () => { idle(k); k.input.aim = Math.PI; k.input.rmbP = true; }); run(m, 0.4, () => idle(k));
      const cling = pw.state === 'cling';
      return { pass: latched && grabbed && enraged && cleared && cling, detail: `latch (no damage) ${latched}, grab attack ${grabbed}, enraged ${enraged}, mend clears mark ${cleared}, wall cling ${cling}` };
    },
  },
  {
    id: 'F7', name: 'New killers: survivor bots use killer-specific counterplay in real matches',
    run() {
      const want = { skull_merchant: /Crouched under the drone|hacking a drone|Hacked a drone/, blight: /Side-stepped the (lethal )?rush|fatigued — running/, nurse: /Doubled back as the Nurse|She is fatigued/,
        unknown: /Side-stepped the UVX|Dispelling a hallucination|Staring at the Unknown/, nemesis: /Side-stepped the tentacle|Walking away from a zombie|Injecting a vaccine|pallet on the zombie/i, ghoul: /Breaking away from the latch|Mending|Dodged the Kagune/ };
      const got = [];
      for (const [id, re] of Object.entries(want)) {
        const m = new Match({ playerRole: 'spectate', killerId: id, killerDifficulty: 7, difficulty: 8, mapId: 'rotwood', seed: 11, killerPerks: [] });
        const seen = new Set(); m.events.on('*', () => {});
        while (m.state !== 'RESULTS' && m.time < 240) { m.update(1 / 60); }
        for (const l of m.aiLog || []) if (re.test(l.text)) seen.add(l.text);
        got.push(`${id}: ${seen.size ? [...seen].slice(0, 2).join(' / ') : 'NONE'}`);
      }
      return { pass: got.every((g) => !/NONE$/.test(g)), detail: got.join(' · ') };
    },
  },
];

export function runMech(log = () => {}, only = null) {
  const out = [];
  for (const t of MECH_TESTS) {
    if (only && !only.includes(t.id[0]) && !only.includes(t.id)) continue;
    let r; try { r = t.run(); } catch (e) { r = { pass: false, detail: 'error: ' + e.message + '\n' + e.stack.split('\n').slice(1, 4).join('\n') }; }
    out.push(r); log(t, r);
  }
  return out;
}
