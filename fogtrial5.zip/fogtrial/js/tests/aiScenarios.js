// AI scenario tests (spec §44). Each builds a small hand-made map, scripts the killer,
// steps the real simulation and checks the survivor's decision. Runs headless (node)
// and in the in-game AI Lab.
import { M, dist } from '../core/util.js';
import { Match } from '../core/game.js';
import { GameMap } from '../maps/map.js';
import { MAPS } from '../maps/maps.js';
import { Generator, Hook, Hatch, Trap } from '../entities/objects.js';
import { evaluateGoals } from '../ai/utilityAI.js';
import { Device } from '../killers/framework.js';

export function testMap({ size = [70, 50], tiles = [], gens = [], hooks = [[5, 5]] } = {}) {
  const def = { ...MAPS.rotwood, size, gens: 0, hooks: 0 };
  return new GameMap(def, {
    seed: 7, gens: 0, hooks: 0, gates: 0,
    custom: (map) => {
      map.customObjects = true; map.border = 2;
      const W = map.w, H = map.h, B = 2 * M;
      map.solids.push({ x: 0, y: 0, w: W, h: B, kind: 'border', blocksMove: true, blocksLOS: true }, { x: 0, y: H - B, w: W, h: B, kind: 'border', blocksMove: true, blocksLOS: true },
        { x: 0, y: 0, w: B, h: H, kind: 'border', blocksMove: true, blocksLOS: true }, { x: W - B, y: 0, w: B, h: H, kind: 'border', blocksMove: true, blocksLOS: true });
      for (const t of tiles) map.placeTemplate(t.key, t.ox, t.oy, t.rot || 0);
      for (const [x, y] of gens) map.gens.push(new Generator(x * M, y * M, String.fromCharCode(65 + map.gens.length)));
      for (const [x, y] of hooks) map.hooks.push(new Hook(x * M, y * M));
      map.hatch = new Hatch(3 * M, 3 * M); map.trapSpawns = [];
      map.spawn = { killer: { x: 10 * M, y: 10 * M }, survivors: [{ x: 20 * M, y: 20 * M }, { x: 22 * M, y: 20 * M }, { x: 20 * M, y: 22 * M }, { x: 22 * M, y: 22 * M }] };
    },
  });
}
export function setup(opts) {
  const map = testMap(opts.map);
  const m = new Match({ killerId: opts.killer || 'trapper', difficulty: opts.difficulty ?? 8, survivorCount: opts.survivors ?? 1, perkMode: 'none', itemMode: 'none', gensRequired: opts.gensRequired ?? 5, seed: 99 }, { map });
  m.setState('NORMAL_MATCH');
  m.traps.length = 0;
  return m;
}
function makeLocker(m, x, y) {
  const d = m.addDevice(new Device({ kind: 'locker', x, y, r: 0.7 * M, label: 'Locker', seenRange: 22 * M, useTime: 1.5, survivorUsable: true, data: { locked: false } }));
  d.usable = () => !d.data.locked; d.onUse = () => { d.data.locked = true; };
  return d;
}
export function place(e, x, y) { e.x = x * M; e.y = y * M; }
export function run(m, secs, script) { const dt = 1 / 60; for (let t = 0; t < secs; t += dt) { script?.(m, t); m.update(dt); } }
function driveKiller(m, tx, ty, speedScale = 1) {
  const k = m.killer; const dx = tx - k.x, dy = ty - k.y, l = Math.hypot(dx, dy) || 1;
  k.input.mx = dx / l * speedScale; k.input.my = dy / l * speedScale; k.input.aim = Math.atan2(dy, dx);
}

export const SCENARIOS = [
  {
    id: 1, name: 'Pallet decision', expect: 'Survivor evaluates the pallet when the killer closes in from the far side (drops it, or greeds it with a note).',
    run() {
      const m = setup({ map: { tiles: [{ key: 'short_wall', ox: 30, oy: 22 }] }, difficulty: 8 });
      const s = m.survivors[0], p = m.map.pallets[0];
      place(s, p.x / M, p.y / M + 1.4); place(m.killer, p.x / M, p.y / M - 5.5);
      s.ai.inChase = true; s.ai.belief.observe(m.killer, m); s.ai.computeThreat = () => { s.ai.inChase = true; s.ai.threat = 1; };
      run(m, 2.5, (mm) => driveKiller(mm, s.x, s.y));
      const greed = m.aiLog.some((l) => /Greed/.test(l.text));
      return { pass: p.state !== 'up' || greed, detail: `pallet=${p.state}${greed ? ' (greeded)' : ''}, decision=${s.ai.chase.debug.decision || '-'}` };
    },
  },
  {
    id: 2, name: 'Avoid dead zone', expect: 'Chased in the open, the survivor heads for a real tile instead of the empty field.',
    run() {
      const m = setup({ map: { size: [80, 60], tiles: [{ key: 'jungle_gym', ox: 46, oy: 10 }] }, difficulty: 8 });
      const s = m.survivors[0]; const jg = m.map.tiles[0];
      place(s, 30, 34); place(m.killer, 20, 36);
      s.ai.belief.observe(m.killer, m);
      const d0 = dist(s.x, s.y, jg.x, jg.y);
      run(m, 3.5, (mm) => driveKiller(mm, s.x, s.y, 0.9));
      const d1 = dist(s.x, s.y, jg.x, jg.y);
      return { pass: d1 < d0 - 4 * M && s.ai.chase.nextTile === jg, detail: `distance to jungle gym ${(d0 / M).toFixed(1)}m → ${(d1 / M).toFixed(1)}m, next tile=${s.ai.chase.debug.nextTile}` };
    },
  },
  {
    id: 3, name: 'Killer far → generators', expect: 'With the killer far away, survivors go to generators.',
    run() {
      const m = setup({ map: { size: [90, 60], gens: [[30, 15], [60, 20], [40, 45], [75, 45]] }, survivors: 4, difficulty: 6 });
      place(m.killer, 85, 55); m.killer.input.mx = 0;
      run(m, 6);
      const n = m.survivors.filter((s) => s.ai.goal?.type === 'REPAIR').length;
      const spread = new Set(m.survivors.map((s) => s.ai.goal?.target?.id)).size;
      return { pass: n >= 3, detail: `${n}/4 chose REPAIR across ${spread} different generators` };
    },
  },
  {
    id: 4, name: 'Hook stage urgency', expect: 'A teammate in the second hook stage raises rescue priority.',
    run() {
      const m = setup({ map: { gens: [[40, 25]], hooks: [[20, 30]] }, survivors: 2, difficulty: 7 });
      const [a, b] = m.survivors; place(a, 30, 30); place(m.killer, 65, 45);
      const h = m.map.hooks[0]; b.health = 'hooked'; b.hook = h; h.survivor = b; place(b, 20, 30);
      const score = (stage) => { b.hookStage = stage; b.hookTimer = 30; return evaluateGoals(a.ai).find((o) => o.type === 'RESCUE')?.score || 0; };
      const s1 = score(1), s2 = score(2);
      return { pass: s2 > s1 * 1.2, detail: `rescue utility stage 1 = ${s1.toFixed(0)}, stage 2 = ${s2.toFixed(0)}` };
    },
  },
  {
    id: 5, name: '3-gen awareness', expect: 'Skilled survivors prefer clustered generators so no 3-gen is left behind.',
    run() {
      const m = setup({ map: { size: [100, 70], gens: [[20, 20], [30, 26], [22, 32], [80, 20], [80, 55]] }, survivors: 1, difficulty: 9, gensRequired: 2 });
      const s = m.survivors[0]; place(s, 50, 20); place(m.killer, 50, 66);
      const opts = evaluateGoals(s.ai).filter((o) => o.type === 'REPAIR');
      const cluster = opts.find((o) => o.target === m.map.gens[1]), lone = opts.find((o) => o.target === m.map.gens[3]);
      return { pass: cluster.score > lone.score, detail: `cluster gen ${cluster.score.toFixed(0)} (${cluster.why.join(', ')}) vs isolated gen ${lone.score.toFixed(0)}` };
    },
  },
  {
    id: 6, name: 'Remember trap at vault', expect: 'A survivor that sees a trap at a window remembers it, refuses that vault and considers disarming.',
    run() {
      const m = setup({ map: { tiles: [{ key: 'long_wall', ox: 25, oy: 20 }] }, difficulty: 7 });
      const s = m.survivors[0]; const w = m.map.windows[0];
      const side = w.sides(1.2 * M)[0]; const t = new Trap(side.x, side.y, 'set'); m.traps.push(t);
      place(s, side.x / M + 2, side.y / M - 2.5); place(m.killer, 60, 45);
      run(m, 1.2);
      const known = s.ai.memory.traps.has(t.id);
      const cost = s.ai.chase.survivorLinkCost()(w.navLink);
      const disarm = evaluateGoals(s.ai).some((o) => o.type === 'DISARM');
      return { pass: known && !isFinite(cost) && disarm, detail: `remembered=${known}, vault cost=${cost}, disarm option=${disarm}` };
    },
  },
  {
    id: 7, name: 'Chainsaw counterplay', expect: 'When the Hillbilly revs with line of sight, the survivor breaks line of sight or side-steps.',
    run() {
      const m = setup({ map: { tiles: [{ key: 'rocks', ox: 33, oy: 21 }, { key: 'l_wall', ox: 40, oy: 12 }] }, killer: 'hillbilly', difficulty: 9 });
      const s = m.survivors[0]; place(s, 36, 30); place(m.killer, 24, 32);
      s.ai.belief.observe(m.killer, m);
      let blocked = 0, frames = 0; const start = { x: s.x, y: s.y };
      run(m, 3, (mm, t) => { const k = mm.killer; k.input.rmb = true; if (t < 0.02) k.input.rmbP = true; driveKiller(mm, s.x, s.y, t < 2.5 ? 0.6 : 1); frames++; if (!mm.world.losClear(k.x, k.y, s.x, s.y)) blocked++; });
      const downed = s.health === 'dying';
      const lateral = Math.abs(s.y - start.y) / M;
      return { pass: !downed && (blocked / frames > 0.15 || lateral > 2), detail: `LOS blocked ${(blocked / frames * 100).toFixed(0)}% of the time, lateral move ${lateral.toFixed(1)}m, ${downed ? 'got sawed' : 'not sawed'}` };
    },
  },
  {
    id: 8, name: 'Wraith warning', expect: 'A repairing survivor reacts to the Wraith\'s uncloak bell close by.',
    run() {
      const m = setup({ map: { gens: [[35, 25]] }, killer: 'wraith', difficulty: 8 });
      const s = m.survivors[0]; const g = m.map.gens[0]; place(s, 35, 26.3); place(m.killer, 55, 25);
      const k = m.killer; k.power.state = 'cloaked'; k.status.add('undetectable', { source: 'cloak' });
      run(m, 2.5); const repairingBefore = s.action?.type === 'repair';
      let reacted = -1;
      run(m, 5, (mm, t) => { driveKiller(mm, s.x, s.y, 1); if (dist(k.x, k.y, s.x, s.y) < 11 * M && k.power.state === 'cloaked') k.input.rmbP = true; if (reacted < 0 && s.action?.type !== 'repair' && k.power.state !== 'cloaked') reacted = t; });
      return { pass: repairingBefore && reacted >= 0, detail: `repairing first=${repairingBefore}, left the gen ${reacted >= 0 ? reacted.toFixed(1) + 's into the approach' : 'never'}, state=${s.ai.state}` };
    },
  },
  // ---------------- expansion killers ----------------
  {
    id: 9, name: 'Ghost Face: reveal or break LOS', expect: 'A skilled survivor being stalked by a shrouded Ghost Face stares him down (reveal) or breaks line of sight, and is not Marked.',
    run() {
      const m = setup({ map: { tiles: [{ key: 'rocks', ox: 40, oy: 18 }, { key: 'l_wall', ox: 28, oy: 30 }] }, killer: 'ghostface', difficulty: 9 });
      const s = m.survivors[0], k = m.killer; place(s, 36, 25); place(k, 25, 25);
      k.power.state = 'shrouded'; k.status.add('undetectable', { source: 'shroud' });
      let blocked = 0, frames = 0;
      run(m, 5, (mm) => { k.input.mx = 0; k.input.my = 0; k.input.aim = Math.atan2(s.y - k.y, s.x - k.x); k.input.rmb = k.power.shrouded; frames++; if (!mm.world.losClear(k.x, k.y, s.x, s.y)) blocked++; });
      const revealed = k.power.state === 'cooldown'; const marked = s.status.has('marked');
      return { pass: !marked && (revealed || blocked / frames > 0.3), detail: `revealed=${revealed}, LOS blocked ${(blocked / frames * 100).toFixed(0)}%, stalk ${(s.stalk * 100 | 0)}%, marked=${marked}` };
    },
  },
  {
    id: 10, name: 'Clown: leave the gas', expect: 'A survivor repairing a generator that gets gassed leaves the cloud quickly and does not path back through it.',
    run() {
      const m = setup({ map: { gens: [[35, 25]], tiles: [{ key: 'jungle_gym', ox: 46, oy: 10 }] }, killer: 'clown', difficulty: 8 });
      const s = m.survivors[0], g = m.map.gens[0]; place(s, 35, 26.3); place(m.killer, 12, 40);
      run(m, 2.5);
      const was = s.action?.type === 'repair';
      m.killer.power.burst(m, g.x, g.y + 0.6 * M, 'tonic');
      let inside = 0;
      run(m, 7, (mm) => { if (mm.zonesAt(s.x, s.y).some((z) => z.kind === 'tonic')) inside += 1 / 60; });
      return { pass: was && inside < 2.6, detail: `repairing first=${was}, ${inside.toFixed(1)} s spent inside the tonic cloud (8 s cloud), final state ${s.ai.state}` };
    },
  },
  {
    id: 11, name: 'Executioner: side-step the wave', expect: 'Facing a telegraphed Punishment wave, a skilled survivor moves out of its corridor (walls do not protect).',
    run() {
      const m = setup({ map: { tiles: [{ key: 'long_wall', ox: 30, oy: 22 }] }, killer: 'executioner', difficulty: 9 });
      const s = m.survivors[0], k = m.killer; place(s, 38, 25); place(k, 26, 25);
      s.ai.belief.observe(k, m);
      k.power.state = 'punish';
      let hit = false; const h0 = s.health;
      run(m, 3.5, (mm, t) => { k.input.mx = 0; k.input.my = 0; k.input.aim = 0; k.facing = 0; k.input.lmbP = t > 0.2 && t < 0.24; if (s.health !== h0) hit = true; });
      const lateral = Math.abs(s.y - 25 * M) / M;
      return { pass: !hit, detail: `${hit ? 'hit by the wave' : 'avoided the wave'}, lateral offset ${lateral.toFixed(1)} m, tormented=${s.status.has('tormented')}` };
    },
  },
  {
    id: 12, name: 'Singularity: EMP the pods', expect: 'A survivor carrying an EMP near several biopods watching its generator uses the EMP.',
    run() {
      const m = setup({ map: { gens: [[35, 25]] }, killer: 'singularity', difficulty: 8 });
      const s = m.survivors[0], k = m.killer, g = m.map.gens[0]; place(s, 35, 26.3); place(k, 62, 40);
      for (const [x, y] of [[29, 22], [41, 22], [35, 31]]) k.power.attachPod(m, x * M, y * M);
      place(k, 62, 40); s.emp = true;
      run(m, 8);
      const left = m.devices.filter((d) => d.kind === 'biopod' && (d.data.disabledUntil || 0) <= m.time).length;
      return { pass: left === 0 && !s.emp, detail: `${3 - left}/3 pods disabled, EMP ${s.emp ? 'still held' : 'used'}, state ${s.ai.state}` };
    },
  },
  {
    id: 13, name: 'Huntress: dodge depends on skill', expect: 'Skilled survivors dodge more long-range hatchets than beginners, but nobody dodges everything.',
    run() {
      const trial = (diff, n) => {
        let hits = 0;
        for (let i = 0; i < n; i++) {
          const m = setup({ map: { gens: [[40, 25]] }, killer: 'huntress', difficulty: diff });
          const s = m.survivors[0], k = m.killer; place(s, 40, 26.3); place(k, 20 + (i % 3) * 2, 26.3 + (i % 2));
          run(m, 1.2); s.ai.belief.observe(k, m);
          const h0 = s.health; k.facing = Math.atan2(s.y - k.y, s.x - k.x); k.power.charge = k.power.maxWind * (0.6 + 0.4 * ((i * 7) % 5) / 4); k.power.throw(m);
          run(m, 1.6, () => { k.input.mx = 0; k.input.my = 0; k.input.aim = null; });
          if (s.health !== h0) hits++;
        }
        return hits;
      };
      const n = 30, lo = trial(2, n), hi = trial(10, n);
      return { pass: hi < lo && hi > 0, detail: `hits at difficulty 2: ${lo}/${n}, at difficulty 10: ${hi}/${n}` };
    },
  },
  // ---------------- expansion II: ten more killers ----------------
  {
    id: 14, name: 'Legion: spread out vs Frenzy', expect: 'Four skilled survivors bunched on a generator scatter when the Legion starts a Frenzy nearby.',
    run() {
      const m = setup({ map: { gens: [[38, 25]] }, killer: 'legion', difficulty: 9, survivors: 4 });
      const g = m.map.gens[0]; const k = m.killer; m.survivors.forEach((s, i) => place(s, 38 + [1.4, -1.4, 0, 0][i], 25 + [0, 0, 1.4, -1.4][i]));
      place(k, 18, 25); run(m, 2);
      const spread = () => { let t = 0, n = 0; const L = m.survivors.filter((q) => q.standing); for (let i = 0; i < L.length; i++) for (let j = i + 1; j < L.length; j++) { t += dist(L[i].x, L[i].y, L[j].x, L[j].y); n++; } return n ? t / n / M : 0; };
      const before = spread();
      k.power.state = 'frenzy'; k.power.gauge = 1; for (const s of m.survivors) s.ai.belief.observe(k, m);
      run(m, 3.5, (mm) => { driveKiller(mm, g.x - 6 * M, g.y, 0.6); k.power.gauge = 1; });
      const after = spread(); const off = m.survivors.filter((q) => q.action?.type !== 'repair').length;
      return { pass: after > before + 3, detail: `mean distance between survivors ${before.toFixed(1)} m → ${after.toFixed(1)} m, ${off}/4 left the generator` };
    },
  },
  {
    id: 15, name: 'Hag: known trap on the route', expect: 'A survivor who knows a Phantasm trap lies on its path routes around or crouches over it instead of triggering it.',
    run() {
      const m = setup({ map: { gens: [[52, 25]] }, killer: 'hag', difficulty: 8 });
      const s = m.survivors[0], k = m.killer; place(s, 20, 25); place(k, 8, 45);
      k.power.placeTrap(m, 36 * M, 25 * M); const trap = m.devices.find((d) => d.kind === 'phantasm'); trap.data.t0 = -10;
      s.ai.memory.devices.set(trap.id, trap); s.ai._zoneV++;
      run(m, 14);
      const triggered = trap.dead; const repairing = s.action?.type === 'repair';
      return { pass: !triggered && repairing, detail: `trap ${triggered ? 'TRIGGERED' : 'avoided'}, reached the generator=${repairing}` };
    },
  },
  {
    id: 16, name: 'Cannibal: tight pallet loop', expect: 'With Bubba revving close by at a tight pallet, a skilled survivor pre-drops the pallet or makes distance and is not sawed.',
    run() {
      let safe = 0, dropped = 0; const n = 6;
      for (let i = 0; i < n; i++) {
        const m = setup({ map: { tiles: [{ key: 't_wall', ox: 30, oy: 20 }] }, killer: 'cannibal', difficulty: 9 });
        const s = m.survivors[0], k = m.killer; const p = m.map.pallets[0];
        place(s, p.x / M + p.nx * 1.2, p.y / M + p.ny * 1.2); place(k, p.x / M + p.nx * (7 + i * 0.3), p.y / M + p.ny * (7 + i * 0.3));
        s.ai.belief.observe(k, m);
        run(m, 4, (mm, t) => { driveKiller(mm, s.x, s.y, 1); k.input.rmb = true; });
        if (s.standing) safe++; if (p.state !== 'up') dropped++;
      }
      return { pass: safe >= n * 0.66, detail: `not sawed in ${safe}/${n} runs, pallet used in ${dropped}/${n}` };
    },
  },
  {
    id: 17, name: 'Deathslinger: harpoon dodging', expect: 'Skilled survivors avoid more harpoon shots than beginners, but they do not dodge every shot.',
    run() {
      const trial = (diff, n) => {
        let hits = 0;
        for (let i = 0; i < n; i++) {
          const m = setup({ map: { gens: [[40, 25]] }, killer: 'deathslinger', difficulty: diff });
          const s = m.survivors[0], k = m.killer; place(s, 40, 26.3); place(k, 28 + (i % 3), 26.3 + (i % 2));
          run(m, 1.0); s.ai.belief.observe(k, m);
          // he aims down sights for ~1 s, tracking the survivor with a human-like 0.25 s lag, then fires
          const hist = [];
          run(m, 1.1, (mm, t) => { hist.push({ x: s.x, y: s.y }); const lag = hist[Math.max(0, hist.length - 15)]; k.input.mx = 0; k.input.my = 0; k.input.aim = Math.atan2(lag.y - k.y, lag.x - k.x); k.input.rmb = true; if (t > 1.05 && k.power.state === 'aiming') k.input.lmbP = true; });
          run(m, 0.8, () => { k.input.mx = 0; k.input.my = 0; k.input.aim = null; k.input.rmb = false; });
          if (k.power.speared === s || s.health !== 'healthy') hits++;
        }
        return hits;
      };
      const n = 24, lo = trial(2, n), hi = trial(10, n);
      return { pass: hi < lo && hi > 0, detail: `speared at difficulty 2: ${lo}/${n}, at difficulty 10: ${hi}/${n}` };
    },
  },
  {
    id: 18, name: 'Dredge: lock the locker', expect: 'A skilled survivor working a generator with an unlocked locker next to it locks the locker.',
    run() {
      const m = setup({ map: { gens: [[35, 25]] }, killer: 'dredge', difficulty: 8 });
      const s = m.survivors[0], k = m.killer, g = m.map.gens[0]; place(s, 35, 26.3); place(k, 62, 44);
      g.charges = 30; for (const d of m.devices.filter((q) => q.kind === 'locker')) m.removeDevice(d);
      const locker = makeLocker(m, 40 * M, 25 * M);
      run(m, 18);
      return { pass: locker.data.locked, detail: `locker ${locker.data.locked ? 'locked' : 'left unlocked'}, state ${s.ai.state}` };
    },
  },
  {
    id: 19, name: 'Knight: grab the Standard', expect: 'A survivor hunted by a guard goes for the Standard (or escapes) instead of being caught.',
    run() {
      const m = setup({ map: { gens: [[35, 25]] }, killer: 'knight', difficulty: 9 });
      const s = m.survivors[0], k = m.killer; place(s, 34, 30); place(k, 62, 44);
      const pw = k.power; pw.drawn = [{ x: 30 * M, y: 30 * M }, { x: 30 * M, y: 40 * M }];
      k.x = 62 * M; pw.order = 0; pw.summon(m); const g = pw.guard;
      g.x = 30 * M; g.y = 31 * M; g.facing = 0;
      run(m, 14, (mm) => { mm.killer.input.mx = 0; mm.killer.input.my = 0; });
      const grabbed = m.aiLog.some((l) => /Standard — hunt over/.test(l.text));
      return { pass: s.health === 'healthy' || grabbed, detail: `standard grabbed=${grabbed}, survivor ${s.health}, guard ${pw.guard ? pw.guard.state : 'gone'}` };
    },
  },
  {
    id: 20, name: 'Cenobite: solve the box', expect: 'During a Chain Hunt a survivor fetches the Lament Configuration and solves it once it is safe.',
    run() {
      const m = setup({ map: { gens: [[50, 25]] }, killer: 'cenobite', difficulty: 8, survivors: 2 });
      const k = m.killer, pw = k.power; place(k, 64, 45);
      m.survivors.forEach((s, i) => place(s, 20 + i * 3, 25));
      pw.box.x = 26 * M; pw.box.y = 32 * M; pw.boxCharge = pw.huntCharge; 
      let solved = false; m.events.on('boxSolved', () => { solved = true; });
      run(m, 30, (mm) => { mm.killer.input.mx = 0; mm.killer.input.my = 0; });
      return { pass: solved, detail: `box ${solved ? 'solved' : 'not solved'}; holder=${m.survivors.find((q) => q.box)?.name || '-'}, chained=${m.survivors.filter((q) => q.status.has('chained')).length}` };
    },
  },
  {
    id: 21, name: 'Mastermind: leave the bound lane', expect: 'Skilled survivors side-step out of Virulent Bound lanes more often than beginners.',
    run() {
      const trial = (diff, n) => {
        let hits = 0;
        for (let i = 0; i < n; i++) {
          const m = setup({ map: { gens: [[40, 25]], tiles: [{ key: 'jungle_gym', ox: 44, oy: 20 }, { key: 'rocks', ox: 40, oy: 32 }] }, killer: 'mastermind', difficulty: diff });
          const s = m.survivors[0], k = m.killer; place(s, 40, 26.3); place(k, 35 + (i % 2) * 0.5, 26.3);
          run(m, 0.5); s.ai.belief.observe(k, m);
          // he charges while tracking the survivor (0.25 s lag) and releases at full charge
          const hist = [];
          run(m, 3.6, (mm, t) => {
            hist.push({ x: s.x, y: s.y }); const lag = hist[Math.max(0, hist.length - 15)]; const a = Math.atan2(lag.y - k.y, lag.x - k.x); const st = k.power.state;
            // walks after the survivor while charging, then chains the second (longer) bound
            k.input.mx = st === 'charging' ? Math.cos(a) : 0; k.input.my = st === 'charging' ? Math.sin(a) : 0;
            if (st === 'charging' || st === 'between' || t < 0.1) k.input.aim = a;
            k.input.rmb = st === 'idle' ? t < 0.1 : st === 'charging' ? k.power.charge < 1 : false;
            k.input.rmbP = st === 'between' && k.power.chainWin < 1.7;
          });
          if (s.health !== 'healthy' || s.status.has('grabbed')) hits++;
        }
        return hits;
      };
      const n = 16, lo = trial(2, n), hi = trial(10, n);
      return { pass: hi < lo, detail: `bound hits at difficulty 2: ${lo}/${n}, at difficulty 10: ${hi}/${n}` };
    },
  },
  {
    id: 22, name: 'Houndmaster: the dog is a separate threat', expect: 'A survivor tracks the dog separately and side-steps its Chase Command; skilled survivors get grabbed less.',
    run() {
      const trial = (diff, n) => {
        let grabs = 0;
        for (let i = 0; i < n; i++) {
          const m = setup({ map: { gens: [[40, 25]] }, killer: 'houndmaster', difficulty: diff });
          const s = m.survivors[0], k = m.killer, dog = k.power.dog; place(s, 40, 26.3); place(k, 26, 26.3 + (i % 2)); dog.x = k.x; dog.y = k.y;
          run(m, 1.0); s.ai.belief.observe(k, m);
          k.facing = Math.atan2(s.y - k.y, s.x - k.x); k.power.plot = 1; k.power.sendChase(m);
          run(m, 2.5, () => { k.input.mx = 0; k.input.my = 0; k.input.aim = null; });
          if (dog.grabbed === s || s.status.has('grabbed') || dog.state === 'grab') grabs++;
        }
        return grabs;
      };
      const n = 16, lo = trial(2, n), hi = trial(10, n);
      return { pass: hi < lo, detail: `grabbed by the dog at difficulty 2: ${lo}/${n}, at difficulty 10: ${hi}/${n}` };
    },
  },
  {
    id: 23, name: 'Lich: crouch under Flight of the Damned', expect: 'Skilled survivors crouch (or dodge) under Flight of the Damned more often than beginners.',
    run() {
      const trial = (diff, n) => {
        let hits = 0;
        for (let i = 0; i < n; i++) {
          const m = setup({ map: { gens: [[40, 25]] }, killer: 'lich', difficulty: diff });
          const s = m.survivors[0], k = m.killer; place(s, 40, 26.3); place(k, 30, 26.3 + (i % 3) * 0.5);
          run(m, 1.0); s.ai.belief.observe(k, m);
          k.facing = Math.atan2(s.y - k.y, s.x - k.x); k.power.flightOfTheDamned(m);
          run(m, 2.2, () => { k.input.mx = 0; k.input.my = 0; k.input.aim = null; });
          if (s.health !== 'healthy') hits++;
        }
        return hits;
      };
      const n = 16, lo = trial(2, n), hi = trial(10, n);
      return { pass: hi < lo && hi < n, detail: `hit at difficulty 2: ${lo}/${n}, at difficulty 10: ${hi}/${n}` };
    },
  },
];

export function runAll(log = () => {}) {
  const out = [];
  for (const sc of SCENARIOS) {
    let r; try { r = sc.run(); } catch (e) { r = { pass: false, detail: 'error: ' + e.message }; console.error(e); }
    out.push({ ...sc, ...r }); log(sc, r);
  }
  return out;
}
