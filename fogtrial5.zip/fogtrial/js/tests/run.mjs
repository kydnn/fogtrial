import { runAll } from './aiScenarios.js';
const res = runAll((sc, r) => console.log(`${r.pass ? 'PASS' : 'FAIL'}  #${sc.id} ${sc.name}: ${r.detail}`));
console.log(`${res.filter((r) => r.pass).length}/${res.length} passed`);
