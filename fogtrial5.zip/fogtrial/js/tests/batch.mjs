// Batch balance check: node js/tests/batch.mjs [difficulty] [killer] [runs]
import { Match } from '../core/game.js';
import { KillerBot } from './killerBot.js';
import { KILLER_PERK_IDS } from '../perks/killerPerks.js';
const withPerks = process.argv[5] === 'perks';
const pick = (r) => { const a = [...KILLER_PERK_IDS]; const o = []; let x = r * 7 + 3; while (o.length < 4) { x = (x * 1103515245 + 12345) % 2147483648; o.push(a.splice(x % a.length, 1)[0]); } return o; };
const diff = +(process.argv[2] || 5), killerId = process.argv[3] || 'trapper', runs = +(process.argv[4] || 6);
const maps = process.argv[6] ? process.argv[6].split(',') : ['rotwood', 'ashfarm', 'ironworks', 'hollowmarsh'];
const st = {};
const agg = { kills: 0, gens: 0, time: 0, unhooks: 0, pallets: 0, stuns: 0, vaults: 0, heals: 0, hooks: 0, escapes: 0, repair: 0 };
for (let r = 0; r < runs; r++) {
  const m = new Match({ difficulty: diff, killerId, mapId: maps[r % maps.length], seed: 500 + r * 37, killerPerks: withPerks ? pick(r) : [] });
  const bot = new KillerBot(m); let fr = 0, rep = 0;
  while (m.state !== 'MATCH_END' && m.state !== 'RESULTS' && m.time < 720) { bot.update(); m.update(1 / 60); fr++; for (const s of m.survivors) { if (s.action?.type === 'repair') rep++; if (s.standing) { const k = s.ai.state + (s.ai.state === 'REPAIRING_GENERATOR' ? (s.action?.type === 'repair' ? '(on)' : '(travel)') : ''); st[k] = (st[k] || 0) + 1; } } }
  const res = m.results();
  agg.kills += res.kills; agg.escapes += res.escapes; agg.gens += m.gensDone; agg.time += m.time; agg.hooks += m.killer.stats.hooks; agg.repair += rep / fr / 4;
  for (const s of m.survivors) { agg.unhooks += s.stats.unhooks; agg.pallets += s.stats.pallets; agg.stuns += s.stats.stuns; agg.vaults += s.stats.vaults; agg.heals += s.stats.heals; }
}
const f = (k) => (agg[k] / runs).toFixed(1);
console.log(`d${diff} ${killerId}: kills ${f('kills')} esc ${f('escapes')} gens ${f('gens')} time ${f('time')}s hooks ${f('hooks')} unhooks ${f('unhooks')} heals ${f('heals')} pallets ${f('pallets')} stuns ${f('stuns')} vaults ${f('vaults')} repairShare ${(agg.repair / runs).toFixed(2)}`);
const tot = Object.values(st).reduce((a, b) => a + b, 0);
console.log('  standing-time:', Object.entries(st).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} ${(v / tot * 100).toFixed(0)}%`).join(', '));
