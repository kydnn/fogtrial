// Network sync test (no sockets): a NetHost runs the match, a NetClient mirror applies its
// serialized snapshots. Every killer is checked: no errors, the mirror tracks the server.
// node js/tests/net.mjs [seconds per killer]
globalThis.localStorage ??= { getItem: () => null, setItem: () => {} };
globalThis.performance ??= { now: () => Date.now() };
const { NetHost } = await import('../net/host.js');
const { NetClient } = await import('../net/client.js');
const { KILLER_LIST } = await import('../killers/index.js');
const { config2v8 } = await import('../modes/twoVeight.js');
const secs = +(process.argv[2] || 90);
let fails = 0, bytes = 0, snaps = 0;
function run(name, cfg, humans, role, index) {
  const host = new NetHost(cfg, humans);
  const c = new NetClient({}); c.send = () => {};
  c.startMatch({ cfg, role, index });
  let maxErr = 0, err = null;
  try {
    for (let i = 0; i < secs * 60 && !host.over; i++) {
      host.step(1 / 60);
      if (i % 3 === 0) { host.buildFrame(); const txt = NetHost.serialize(host.snapshotFor('p1')); bytes += txt.length; snaps++; c.applySnap(JSON.parse(txt)); }
      if (i % 3 === 0) {
        const all = [...host.m.survivors.map((s, j) => [s, c.m.survivors[j]]), ...host.m.killers.map((k, j) => [k, c.m.killers[j]])];
        for (const [a, b] of all) maxErr = Math.max(maxErr, Math.hypot(a.x - b._nx, a.y - b._ny) / 32);
      }
    }
    const hm = host.m, cm = c.m;
    const same = hm.survivors.every((s, i) => s.health === cm.survivors[i].health) && hm.gensDone === cm.gensDone && hm.devices.length === cm.devices.length && hm.minions.length === cm.minions.length
      && hm.killers.every((k, i) => k.power.state === cm.killers[i].power.state);
    if (!same || maxErr > 0.05) err = `mirror diverged (pos err ${maxErr.toFixed(2)} m, devices ${hm.devices.length}/${cm.devices.length}, minions ${hm.minions.length}/${cm.minions.length})`;
    // the HUDs read the mirror's power & survivor state
    for (const k of cm.killers) k.power.hud(cm);
  } catch (e) { err = e.stack.split('\n').slice(0, 3).join(' | '); }
  if (err) fails++;
  console.log(`${err ? 'FAIL' : 'PASS'}  ${name}${err ? ': ' + err : ''}`);
}
for (const k of KILLER_LIST) {
  run(`1v4 ${k.id} (bot) · human survivor`, { mode: '1v4', mapId: 'rotwood', seed: 7, playerRole: 'net', killers: [{ killerId: k.id, perks: k.signature.slice(0, 3), difficulty: 7 }], survivors: [{ human: true, name: 'P1', perks: ['sprint_burst'], item: 'flashlight' }, {}, {}, {}], survivorCount: 4 }, [{ pid: 'p1', role: 'survivor', index: 0 }], 'survivor', 0);
}
const c8 = config2v8({ role: 'spectate', killerA: 'singularity', killerB: 'nemesis', mapId: 'docks', seed: 3 }); c8.playerRole = 'net'; c8.killers[1].human = true;
run('2v8 singularity (bot) + nemesis (human)', c8, [{ pid: 'p1', role: 'killer', index: 1 }], 'killer', 1);
console.log(`${fails ? fails + ' FAILED' : 'all passed'} · average snapshot ${(bytes / snaps / 1024).toFixed(2)} KB (${(bytes / snaps * 20 / 1024).toFixed(1)} KB/s per player)`);
process.exit(fails ? 1 : 0);
