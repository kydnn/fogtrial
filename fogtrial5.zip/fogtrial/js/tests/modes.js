// Mode tests (spec §23 A, B, C, I): a full Play-as-Survivor match driven through the real
// player controller, killer-bot difficulty comparison, both 2v8 configurations with killer
// coordination, and a regression pass over every killer in the classic mode.
import { M, dist } from '../core/util.js';
import { EV } from '../core/events.js';
import { Match } from '../core/game.js';
import { SurvivorController } from '../player/survivorController.js';
import { config2v8 } from '../modes/twoVeight.js';
import { KILLER_LIST } from '../killers/index.js';

// A scripted "human": paths to objectives with the nav grid, holds E, hits skill checks,
// runs from the killer when seen, wiggles when carried, struggles on the hook.
function scriptedPlayer(m, ctl) {
  const s = ctl.s; const st = { path: null, goal: null, repath: 0, checks: 0, great: 0 };
  return () => {
    const I = { mx: 0, my: 0, e: false, aimX: s.x + 10, aimY: s.y };
    if (s.skillCheck) { const c = s.skillCheck, pos = (m.time - c.t0 - c.warn) / c.dur; if (pos > c.zone + c.great * 0.4) { ctl.in.spaceP = true; st.checks++; } }
    if (s.health === 'carried') ctl.in[(Math.floor(m.time * 6) % 2) ? 'leftP' : 'rightP'] = true;
    else if (s.standing) {
      const k = m.nearestKiller(s.x, s.y), kd = dist(k.x, k.y, s.x, s.y);
      let goal = null;
      const hooked = m.survivors.find((o) => o !== s && o.health === 'hooked');
      if (m.gatesPowered) goal = m.map.gates.slice().sort((a, b) => dist(a.x, a.y, s.x, s.y) - dist(b.x, b.y, s.x, s.y))[0];
      else if (hooked && dist(hooked.x, hooked.y, s.x, s.y) < 30 * M && kd > 16 * M) goal = hooked;
      else goal = m.map.gens.filter((q) => !q.done).sort((a, b) => dist(a.x, a.y, s.x, s.y) - dist(b.x, b.y, s.x, s.y))[0];
      if (kd < 10 * M && m.world.losClear(k.x, k.y, s.x, s.y)) { const l = kd || 1; I.mx = (s.x - k.x) / l; I.my = (s.y - k.y) / l; st.path = null; }
      else if (goal) {
        let tx = goal.x, ty = goal.y;
        if (goal.open && goal.exitRect) { tx = goal.exitRect.x + goal.exitRect.w / 2; ty = goal.exitRect.y + goal.exitRect.h / 2; }
        const d = dist(tx, ty, s.x, s.y);
        if (d < (goal.open ? 0.3 : 1.5) * M) I.e = !goal.open;
        else {
          if (!st.path || st.goal !== goal || (st.repath -= 1 / 60) <= 0) { const r = m.map.nav.findPath(s.x, s.y, tx, ty, {}); st.path = r ? m.map.nav.smooth(m.world, r.pts, s.r) : [{ x: tx, y: ty }]; st.i = 1; st.goal = goal; st.repath = 2; }
          let p = st.path[Math.min(st.i, st.path.length - 1)]; if (dist(p.x, p.y, s.x, s.y) < 0.6 * M && st.i < st.path.length - 1) { st.i++; p = st.path[st.i]; }
          const l = dist(p.x, p.y, s.x, s.y) || 1; I.mx = (p.x - s.x) / l; I.my = (p.y - s.y) / l;
        }
      }
    }
    ctl.setInput(I);
    return st;
  };
}

export const MODE_TESTS = [
  {
    id: 'A1', name: 'Play as Survivor: full match through the player controller',
    run() {
      const m = new Match({ playerRole: 'survivor', killerId: 'trapper', killerDifficulty: 4, difficulty: 6, mapId: 'rotwood', seed: 77, killerPerks: [] });
      const s = m.player, ctl = new SurvivorController(m, s); const step = scriptedPlayer(m, ctl);
      const seen = new Set(); for (const e of [EV.GENERATOR_REPAIRED, EV.SURVIVOR_HOOKED, EV.SURVIVOR_UNHOOKED, EV.SKILL_CHECK_SUCCESS, EV.SURVIVOR_ESCAPED, EV.SURVIVOR_KILLED, EV.CHASE_START]) m.events.on(e, (d) => { if (d.survivor === s || d.rescuer === s) seen.add(e); });
      let st = null, ai = 0, botHelp = 0;
      m.events.on(EV.SURVIVOR_UNHOOKED, (d) => { if (d.survivor === s && d.rescuer && d.rescuer !== s) botHelp++; });
      while (m.state !== 'RESULTS' && m.time < 900) { st = step(); m.update(1 / 60); if (m.killer.bot?.per.belief(s).visible) ai++; }
      const r = m.results();
      const ok = m.state === 'RESULTS' && !s.ai && s.stats.gens > 0.2 && st.checks > 0 && ai > 0;
      return { pass: ok, detail: `ended ${m.state} at ${m.time.toFixed(0)} s · player ${s.outcome || s.health} · player repaired ${s.stats.gens.toFixed(2)} gens, ${st.checks} skill checks · killer bot saw the player ${(ai / 60).toFixed(0)} s · rescued by bots ${botHelp}× · team: ${r.kills} killed / ${r.escapes} escaped · events: ${[...seen].map((e) => e.replace(/^on/, '')).join(', ')}` };
    },
  },
  {
    id: 'B1', name: 'Killer bot difficulty 1 / 5 / 10 changes decisions, not stats',
    run() {
      const out = {};
      for (const d of [1, 5, 10]) {
        let kills = 0, hits = 0, react = 0, n = 0, chase = 0, frames = 0, swings = 0, miss = 0;
        for (const seed of [3, 4]) {
          const m = new Match({ playerRole: 'spectate', killerId: 'trapper', killerDifficulty: d, difficulty: 5, mapId: 'rotwood', seed, killerPerks: [] });
          const speed0 = m.killer.def.speed;
          while (m.state !== 'RESULTS' && m.time < 600) { m.update(1 / 60); frames++; if (m.killer.bot.state === 'CHASING') chase++; }
          const r = m.results(); kills += r.kills; hits += m.killer.stats.hits; miss += m.killer.stats.missed; react += m.killer.bot.P.reaction; n++;
          if (m.killer.def.speed !== speed0) return { pass: false, detail: 'killer speed changed with difficulty' };
        }
        out[d] = { kills: kills / n, hits: hits / n, miss: miss / n, reaction: react / n, chase: chase / frames };
      }
      const P1 = out[1], P10 = out[10];
      const pass = P10.kills >= P1.kills && P10.reaction < P1.reaction && (P10.kills > P1.kills || P10.hits > P1.hits);
      return { pass, detail: Object.entries(out).map(([d, o]) => `d${d}: ${o.kills.toFixed(1)} kills, ${o.hits.toFixed(0)} hits, ${o.miss.toFixed(0)} misses, reaction ${o.reaction.toFixed(2)} s, chasing ${(o.chase * 100).toFixed(0)}%`).join(' · ') };
    },
  },
  {
    id: 'C1', name: '2v8 config A: player Killer A + bot Killer B + 8 bot survivors',
    run() {
      const m = new Match(config2v8({ role: 'killer', killerA: 'trapper', killerB: 'huntress', killerDifficulty: 5, survivorDifficulty: 5, mapId: 'ironworks', seed: 21 }));
      const [A, B] = m.killers; let cages = 0, bHooks = 0;
      m.events.on(EV.SURVIVOR_HOOKED, (d) => { if (d.hook.cage) cages++; if (d.killer === B) bHooks++; });
      while (m.state !== 'RESULTS' && m.time < 600) m.update(1 / 60); // the player killer stands still
      const ok = !A.bot && !!B.bot && m.survivors.length === 8 && m.map.gens.length === 13 && m.gensNeeded === 8 && m.map.gates.length === 3 && bHooks > 0 && cages === bHooks && A.cls && B.cls;
      return { pass: ok, detail: `A player=${!A.bot} (${A.cls}), B bot=${!!B.bot} (${B.cls}) hooked ${bHooks} into cages ${cages}; 8 survivors, ${m.map.gens.length} gens / ${m.gensNeeded} needed, ${m.map.gates.length} gates; result ${m.results().kills} killed / ${m.results().escapes} escaped` };
    },
  },
  {
    id: 'C2', name: '2v8 config B: player survivor + 7 bot survivors vs 2 killer bots; classes & rules',
    run() {
      const m = new Match(config2v8({ role: 'survivor', killerA: 'wraith', killerB: 'cannibal', killerDifficulty: 5, teammateDifficulty: 6, survivorClass: 'medic', mapId: 'rotwood', seed: 9 }));
      const s = m.player, ctl = new SurvivorController(m, s); const step = scriptedPlayer(m, ctl);
      const selfHealBlocked = !m.survivors.find((o) => o.cls !== 'medic').canStart('healSelf', null, m) && true;
      let revealed = 0; const t0 = m.reveals.length; m.events.on(EV.CHASE_START, () => { revealed++; });
      while (m.state !== 'RESULTS' && m.time < 900) { step(); m.update(1 / 60); }
      const ok = s.isPlayer && s.cls === 'medic' && m.killers.every((k) => k.bot) && m.survivors.length === 8 && m.state === 'RESULTS' && revealed > 0 && m.cfg.modifiers.noHatch;
      return { pass: ok, detail: `player ${s.name} (${s.cls}) ${s.outcome || s.health}, both killers bots, chases (Revealed) ${revealed}, self-heal blocked for non-medics ${selfHealBlocked}, result ${m.results().kills} killed / ${m.results().escapes} escaped in ${m.time.toFixed(0)} s` };
    },
  },
  {
    id: 'C3', name: '2v8 killer coordination: shared sightings, split targets, regions',
    run() {
      let both = 0, same = 0, frames = 0, shares = 0, regionsOk = 0;
      for (const seed of [5, 6]) {
        const m = new Match(config2v8({ role: 'spectate', killerA: 'trapper', killerB: 'wraith', killerDifficulty: 7, survivorDifficulty: 6, mapId: 'rotwood', seed }));
        const team = m.killers[0].bot.team;
        while (m.state !== 'RESULTS' && m.time < 420) {
          m.update(1 / 60); frames++;
          const [a, b] = m.killers;
          if (a.bot.goal?.type === 'CHASE' && b.bot.goal?.type === 'CHASE') { both++; if (a.bot.goal.target === b.bot.goal.target) same++; }
        }
        shares += team.sightings.size; if (team.regions.size === m.map.gens.length) regionsOk++;
      }
      const pass = shares > 0 && regionsOk === 2 && (both === 0 || same / both < 0.35);
      return { pass, detail: `both chasing ${(both / frames * 100).toFixed(1)}% of the time, same target ${both ? (same / both * 100).toFixed(0) : 0}% of that, shared sightings ${shares}, gen regions split ${regionsOk}/2` };
    },
  },
  {
    id: 'I1', name: 'Regression: every killer plays a full classic match as a bot without errors',
    run() {
      const bad = []; let total = 0;
      for (const k of KILLER_LIST) {
        try {
          const m = new Match({ playerRole: 'spectate', killerId: k.id, killerDifficulty: 6, difficulty: 5, mapId: 'rotwood', seed: 31, killerPerks: k.signature.slice(0, 3) });
          let used = 0; m.events.on(EV.POWER_USED, () => used++); m.events.on(EV.TRAP_SET, () => used++);
          m.killer.power.hud(m); // the HUD reads every power field from the first frame
          let t = 0; while (m.state !== 'RESULTS' && m.time < 300) { m.update(1 / 60); if ((t += 1) % 30 === 0) m.killer.power.hud(m); }
          total++; if (!used && !['wraith'].includes(k.id)) bad.push(k.id + ' (power never used)');
        } catch (e) { bad.push(k.id + ': ' + e.message); }
      }
      return { pass: !bad.length, detail: `${total}/${KILLER_LIST.length} killers ran 300 s; ${bad.length ? 'problems: ' + bad.join(', ') : 'every bot used its power'}` };
    },
  },
];

export function runModes(log = () => {}, only = null) {
  const out = [];
  for (const t of MODE_TESTS) {
    if (only && !only.includes(t.id[0]) && !only.includes(t.id)) continue;
    let r; try { r = t.run(); } catch (e) { r = { pass: false, detail: 'error: ' + e.message + '\n' + e.stack.split('\n').slice(1, 4).join('\n') }; }
    out.push(r); log(t, r);
  }
  return out;
}
