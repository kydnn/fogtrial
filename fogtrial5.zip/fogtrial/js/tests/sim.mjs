// Headless match simulation: node js/tests/sim.mjs [difficulty] [killer] [seconds]
import { Match } from '../core/game.js';
import { KillerBot } from './killerBot.js';
const diff = +(process.argv[2] || 5), killerId = process.argv[3] || 'trapper', secs = +(process.argv[4] || 420), mapId = process.argv[5] || 'rotwood';
const m = new Match({ difficulty: diff, killerId, mapId, seed: 1234 + diff, killerPerks: (process.argv[6] || 'bbq,pop').split(',') });
const bot = new KillerBot(m);
const t0 = performance.now(); let frames = 0; const states = {};
let lastLog = 0;
let rep = 0;
while (m.state !== 'RESULTS' && m.state !== 'MATCH_END' && m.time < secs) {
  bot.update(); m.update(1 / 60); frames++;
  for (const s of m.survivors) { states[s.ai.state] = (states[s.ai.state] || 0) + 1; if (s.action?.type === 'repair') rep++; }
  if (m.time - lastLog > 60) { lastLog = m.time; console.log(`t=${m.time.toFixed(0)} gens=${m.gensDone} ` + m.survivors.map((s) => `${s.name}:${s.health}/${s.ai.state}/${s.ai.goal?.type || '-'}`).join(' ')); }
}
const ms = performance.now() - t0;
console.log(`sim ${m.time.toFixed(0)}s in ${ms.toFixed(0)}ms (${(ms / frames).toFixed(2)} ms/frame) state=${m.state}`);
console.log('gen progress', m.map.gens.map((g) => g.progress.toFixed(2)).join(' '));
console.log('repair-action share', (rep / frames / m.survivors.length).toFixed(2), 'gens', m.gensDone, 'killer', JSON.stringify(m.killer.stats));
console.log('survivors', m.survivors.map((s) => `${s.name} ${s.health} ${JSON.stringify(s.stats)}`).join('\n'));
const tot = Object.values(states).reduce((a, b) => a + b, 0);
console.log('state share', Object.entries(states).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} ${(v / tot * 100).toFixed(1)}%`).join(', '));
console.log('AI log:\n' + m.aiLog.slice(-25).map((l) => `${l.t.toFixed(0)} ${l.who}: ${l.text}`).join('\n'));
