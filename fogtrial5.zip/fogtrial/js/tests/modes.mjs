import { runModes } from './modes.js';
const res = runModes((t, r) => console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${t.id} ${t.name}: ${r.detail}`), process.argv[2] ? process.argv[2].split(',') : null);
console.log(`${res.filter((r) => r.pass).length}/${res.length} mode tests passed`);
