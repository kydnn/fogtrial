// Simple scripted killer used for headless simulations and the AI Lab (not the player).
// It is deliberately straightforward: patrol gens, chase what it sees, hook, kick.
import { M, dist } from '../core/util.js';

export class KillerBot {
  constructor(m) { this.m = m; this.path = null; this.idx = 0; this.target = null; this.repathT = 0; this.goal = null; this.patrolGen = null; }
  steerTo(x, y) {
    const m = this.m, k = m.killer;
    this.repathT -= 1 / 60;
    if (!this.path || this.repathT <= 0 || !this.goal || dist(this.goal.x, this.goal.y, x, y) > 2 * M) {
      const r = m.map.nav.findPath(k.x, k.y, x, y, { linkCost: (L) => L.kind === 'window' ? 8 : Infinity });
      this.path = r ? m.map.nav.smooth(m.world, r.pts, k.r) : [{ x, y }]; this.idx = 1; this.repathT = 0.6; this.goal = { x, y };
    }
    let p = this.path[Math.min(this.idx, this.path.length - 1)];
    if (p && p.viaLink && p.viaLink.kind === 'window' && dist(k.x, k.y, p.viaLink.ref.x, p.viaLink.ref.y) < 1.6 * M) { k.input.spaceP = true; this.idx++; }
    if (p && dist(k.x, k.y, p.x, p.y) < 0.6 * M) this.idx++;
    p = this.path[Math.min(this.idx, this.path.length - 1)] || { x, y };
    const dx = p.x - k.x, dy = p.y - k.y, l = Math.hypot(dx, dy) || 1;
    k.input.mx = dx / l; k.input.my = dy / l; k.input.aim = Math.atan2(dy, dx);
  }
  // Simple, readable power use per killer so spectator matches and tests exercise every power.
  usePower(t, bd) {
    const m = this.m, k = m.killer, inp = k.input, pw = k.power, id = pw.id;
    const lead = (tt) => ({ x: t.x + t.vx * tt, y: t.y + t.vy * tt });
    const aimAt = (p) => { inp.aim = Math.atan2(p.y - k.y, p.x - k.x); inp.aimDist = dist(k.x, k.y, p.x, p.y); };
    const clear = m.world.losClear(k.x, k.y, t.x, t.y);
    if (id === 'hatchets') {
      if (pw.state === 'winding') { aimAt(lead(bd / (30 * M))); this.windT = (this.windT || 0) + 1 / 60; inp.rmb = this.windT < 0.75; if (!inp.rmb) this.windT = 0; return true; }
      if (pw.count > 0 && bd > 4 * M && bd < 22 * M && clear && Math.random() < 0.05) { inp.rmb = true; this.windT = 0; aimAt(t); return true; }
    } else if (id === 'tonic') {
      if (pw.state === 'aiming') { aimAt(lead(0.6)); this.windT = (this.windT || 0) + 1 / 60; inp.rmb = this.windT < 0.35; if (!inp.rmb) this.windT = 0; return false; }
      if (pw.bottles > 0 && bd > 4 * M && bd < 14 * M && Math.random() < 0.03) { inp.rmb = true; this.windT = 0; }
    } else if (id === 'judgement') {
      if (pw.state === 'normal' && bd < 15 * M && bd > 4 * M && clear) inp.rmbP = true;
      else if (pw.state === 'punish' && bd < 3 * M) inp.rmbP = true;
      else if (pw.state === 'punish' && bd < 15 * M && pw.cd('wave') <= 0 && Math.random() < 0.08) { aimAt(lead(0.9)); inp.lmbP = true; }
      if (pw.state === 'windup') { aimAt(lead(0.9)); return true; }
    } else if (id === 'shroud') {
      if (pw.state === 'visible') inp.rmbP = true;
      else if (pw.shrouded && bd > 7 * M && !t.status.has('marked')) { inp.rmb = true; aimAt(t); return true; }
    } else if (id === 'chainsaw') {
      if (bd > 6 * M && bd < 20 * M && m.world.sweepClear(k.x, k.y, t.x, t.y, k.r) && pw.overheatT <= 0) { inp.rmb = true; aimAt(t); if (pw.state === 'sprint') return false; }
    } else if (id === 'cloak') {
      if (pw.state === 'cloaked' && bd < 8 * M) inp.rmbP = true;
    } else if (id === 'quantum') {
      if (Math.random() < 0.004 && pw.podsCarried > 0) inp.rmbP = true;
    } else if (id === 'frenzy') {
      if (pw.state === 'ready' && bd < 14 * M) inp.rmbP = true;
      if (pw.state === 'frenzy') { if (bd < 2.2 * M && pw.slashT <= 0 && t !== pw.lastHit) { aimAt(t); inp.lmbP = true; } if (t === pw.lastHit) { const o = m.survivors.find((q) => q.standing && q !== t && dist(q.x, q.y, k.x, k.y) < 20 * M); if (o) this.steerTo(o.x, o.y); } const c = m.killerContext(); if (c?.type === 'vault' && bd < 6 * M) inp.spaceP = true; return true; }
    } else if (id === 'phantasm') {
      if (pw.teleportTarget(m)) inp.eP = true;
    } else if (id === 'bubba') {
      if (pw.state === 'sweep') { aimAt(t); inp.rmb = true; return true; }
      if (pw.state === 'revving') { aimAt(t); inp.rmb = pw.rev < Math.min(pw.charges, 1.2); return true; }
      if (bd < 6.5 * M && bd > 1.6 * M && pw.charges >= 1 && clear) { inp.rmb = true; aimAt(t); return true; }
    } else if (id === 'redeemer') {
      if (pw.state === 'aiming') { aimAt(lead(bd / (55 * M))); inp.rmb = true; this.aimT = (this.aimT || 0) + 1 / 60; if (this.aimT > 0.45 && clear) { inp.lmbP = true; this.aimT = 0; } return true; }
      if (pw.state === 'reel') { if (bd < 2.4 * M) { inp.lmbP = true; inp.lmb = true; } return true; }
      if (pw.loaded && pw.state === 'idle' && bd > 3 * M && bd < 16 * M && clear) { inp.rmb = true; aimAt(t); return true; }
    } else if (id === 'nightfall') {
      if (pw.state === 'gloaming') inp.eP = true;
    } else if (id === 'guardia') {
      if (pw.state === 'idle' && !pw.guard && pw.cd('power') <= 0 && bd > 6 * M && bd < 18 * M) { inp.rmbP = true; aimAt(t); this.knightDraw = 0; }
      else if (pw.state === 'drawing') { this.knightDraw = (this.knightDraw || 0) + 1 / 60; if (this.knightDraw > 1.2) inp.rmbP = true; }
    } else if (id === 'lament') {
      if (pw.chain) { aimAt(t); inp.rmb = true; return true; }
      if (pw.state === 'idle' && pw.cd('chain') <= 0 && bd > 3 * M && bd < 20 * M && clear) { inp.rmb = true; aimAt(t); return true; }
    } else if (id === 'virulent') {
      if (pw.state === 'charging') { aimAt(lead(0.4)); inp.rmb = pw.charge < 1.02; return true; }
      if (pw.state === 'between' && bd < 13 * M && clear) { aimAt(lead(0.5)); inp.rmbP = true; return true; }
      if (pw.state === 'idle' && pw.tokens > 0 && bd > 3 * M && bd < 11 * M && clear) { inp.rmb = true; aimAt(t); return true; }
    } else if (id === 'hound') {
      const d = pw.dog;
      if (pw.state === 'plotting') { aimAt(lead(0.8)); inp.rmb = pw.plot < 0.9; return true; }
      if (d?.state === 'follow' && pw.cd('dog') <= 0 && bd > 4 * M && bd < 18 * M && clear && Math.random() < 0.08) { inp.rmb = true; aimAt(t); return true; }
    } else if (id === 'vecna') {
      const pick = (i) => { inp.slot = i + 1; };
      if (pw.state !== 'idle') return false;
      if (pw.ready('fotd') && bd < 16 * M && bd > 4 * M) { pick(0); if (pw.sel === 0) { aimAt(t); inp.rmbP = true; } return false; }
      if (pw.ready('magehand') && t.vault == null) { const p = m.map.pallets.find((q) => q.state === 'down' && dist(q.x, q.y, k.x, k.y) < 6 * M); if (p) { pick(2); if (pw.sel === 2) { aimAt(p); inp.rmbP = true; } return false; } }
      if (pw.ready('fly') && bd > 10 * M && bd < 26 * M) { pick(1); if (pw.sel === 1) inp.rmbP = true; }
    }
    return false;
  }
  idlePower() {
    const m = this.m, k = m.killer, inp = k.input, pw = k.power;
    if (pw.id === 'cloak' && pw.state === 'visible' && Math.random() < 0.02) inp.rmbP = true;
    if (pw.id === 'shroud' && pw.state === 'visible') inp.rmbP = true;
    if (pw.id === 'judgement' && pw.state === 'punish') inp.rmbP = true;
    if (pw.id === 'quantum') {
      if (pw.podsCarried > 0 && Math.random() < 0.006) inp.rmbP = true;
      if (pw.cd('tp') <= 0 && pw.teleportTarget(m, k.facing) && Math.random() < 0.05) inp.eP = true;
    }
    if (pw.id === 'phantasm' && pw.traps.length < pw.maxTraps && Math.random() < 0.01) { this.hagDraw = 1.6; }
    if (pw.id === 'phantasm' && this.hagDraw > 0) { this.hagDraw -= 1 / 60; inp.rmb = true; }
    if (pw.id === 'phantasm' && pw.teleportTarget(m)) inp.eP = true;
    if (pw.id === 'nightfall' && pw.state === 'idle' && pw.tokens > 0 && pw.cd('tp') <= 0 && Math.random() < 0.004) inp.rmbP = true;
    if (pw.id === 'nightfall' && pw.state === 'gloaming') { const g = m.map.gens.filter((q) => !q.done && q.repairers.size).sort((a, b) => b.charges - a.charges)[0]; const l = g && pw.lockers.sort((a, b) => dist(a.x, a.y, g.x, g.y) - dist(b.x, b.y, g.x, g.y))[0]; if (l) { inp.aim = Math.atan2(l.y - k.y, l.x - k.x); inp.aimDist = dist(l.x, l.y, k.x, k.y) / 2.2; inp.rmbP = pw.target === l; } if (pw.gloamT > 2) inp.eP = true; }
    if (pw.id === 'hound' && pw.dog?.state === 'follow' && pw.cd('dog') <= 0 && Math.random() < 0.01) { const g = m.map.gens.filter((q) => !q.done).sort((a, b) => dist(a.x, a.y, k.x, k.y) - dist(b.x, b.y, k.x, k.y))[0]; if (g && dist(g.x, g.y, k.x, k.y) < 40 * M) { inp.aim = Math.atan2(g.y - k.y, g.x - k.x); inp.aimDist = dist(g.x, g.y, k.x, k.y); inp.eP = true; } }
    if (pw.id === 'guardia' && pw.state === 'idle' && !pw.guard && pw.cd('power') <= 0 && Math.random() < 0.004) { inp.rmbP = true; this.knightDraw = 0; }
    if (pw.id === 'guardia' && pw.state === 'drawing') { this.knightDraw = (this.knightDraw || 0) + 1 / 60; if (this.knightDraw > 3) inp.rmbP = true; }
    if (pw.id === 'lament') { if (pw.box && dist(pw.box.x, pw.box.y, k.x, k.y) < 1.7 * M) inp.spaceP = true; if (m.survivors.some((s) => s.action?.type === 'solveBox')) inp.eP = true; }
    if (pw.id === 'vecna' && pw.state === 'idle' && pw.ready('sphere') && Math.random() < 0.01) { inp.slot = 4; if (pw.sel === 3) inp.rmbP = true; }
    if (pw.id === 'hatchets' && pw.count < 2) {
      const l = m.devices.filter((d) => d.kind === 'locker').sort((a, b) => dist(a.x, a.y, k.x, k.y) - dist(b.x, b.y, k.x, k.y))[0];
      if (l) { if (dist(l.x, l.y, k.x, k.y) < 1.7 * M) inp.eP = true; else this.patrolGen = l; }
    }
  }
  update() {
    const m = this.m, k = m.killer, inp = k.input;
    inp.lmb = false; inp.rmb = false;
    if (k.action || k.stunT > 0) return;
    // carrying → nearest hook
    if (k.carrying) {
      const h = m.map.hooks.filter((h) => !h.survivor).sort((a, b) => dist(a.x, a.y, k.x, k.y) - dist(b.x, b.y, k.x, k.y))[0];
      if (h) { if (dist(h.x, h.y, k.x, k.y) < 1.8 * M) inp.spaceP = true; else this.steerTo(h.x, h.y); }
      return;
    }
    const downed = m.survivors.find((s) => s.health === 'dying' && dist(s.x, s.y, k.x, k.y) < 20 * M);
    if (downed) { if (dist(downed.x, downed.y, k.x, k.y) < 1.6 * M) inp.spaceP = true; else this.steerTo(downed.x, downed.y); return; }
    // visible survivors
    let tgt = null, bd = 1e9;
    // A fair bot: it only sees what fits on a player's screen (about 34 x 20 m) with line of sight,
    // and it tracks scratch marks and loud noises like a player would.
    for (const s of m.survivors) {
      if (!s.standing) continue; const d = dist(s.x, s.y, k.x, k.y);
      if (Math.abs(s.x - k.x) > 17 * M || Math.abs(s.y - k.y) > 10.5 * M) continue;
      if (s.moveMode === 'crouch' && m.map.isGrass(s.x, s.y) && d > 5 * M) continue;
      if (m.world.losClear(k.x, k.y, s.x, s.y) && d < bd) { bd = d; tgt = s; }
    }
    if (!tgt) {
      const sc = m.scratches.filter((q) => m.time - q.t < 3 && dist(q.x, q.y, k.x, k.y) < 16 * M).sort((a, b) => b.t - a.t)[0];
      if (sc) this.lastSeen = { x: sc.x, y: sc.y, t: m.time - 2 };
      const ln = m.loudNoises.filter((q) => m.time - q.t < 0.2)[0];
      if (ln && (!this.lastSeen || m.time - this.lastSeen.t > 3)) this.patrolGen = { x: ln.x, y: ln.y, done: false };
    }
    if (tgt) {
      this.lastSeen = { x: tgt.x, y: tgt.y, t: m.time };
      const ctx = m.killerContext(); if (ctx && ctx.type === 'break' && bd < 5 * M) { inp.spaceP = true; return; }
      if (bd < 9 * M && m.world.sweepClear(k.x, k.y, tgt.x, tgt.y, k.r)) { const dx = tgt.x - k.x, dy = tgt.y - k.y, l = Math.hypot(dx, dy); inp.mx = dx / l; inp.my = dy / l; inp.aim = Math.atan2(dy, dx); }
      else this.steerTo(tgt.x, tgt.y);
      if (this.usePower(tgt, bd)) return;
      if (bd < 2.6 * M && k.power.canAttack(m)) { inp.lmbP = true; inp.lmb = true; }
      if (k.power.id === 'traps' && k.power.carried > 0 && Math.random() < 0.002) inp.rmbP = true;
      return;
    }
    this.idlePower();
    if (this.lastSeen && m.time - this.lastSeen.t < 4) { this.steerTo(this.lastSeen.x, this.lastSeen.y); return; }
    // patrol: go to a gen, kick it
    if (!this.patrolGen || this.patrolGen.done || dist(this.patrolGen.x, this.patrolGen.y, k.x, k.y) < 2 * M) {
      const ctx = m.killerContext(); if (ctx && ctx.type === 'kick') inp.spaceP = true;
      const gens = m.map.gens.filter((g) => !g.done && g !== this.patrolGen);
      this.patrolGen = gens.sort((a, b) => dist(a.x, a.y, k.x, k.y) - dist(b.x, b.y, k.x, k.y) + (Math.random() - 0.5) * 1600)[0] || m.map.gates[0];
    }
    const tgt2 = this.patrolGen || m.survivors.find((s) => s.standing);
    if (tgt2) this.steerTo(tgt2.x, tgt2.y);
  }
}
