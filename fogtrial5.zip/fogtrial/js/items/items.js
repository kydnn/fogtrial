// Survivor items and item add-ons (data-driven). Charges are seconds of use.
export const ITEMS = {
  medkit: { id: 'medkit', name: 'Med-Kit', icon: '✚', charges: 24, desc: 'Self-heal (16 s of charges). Heals others 25% faster.', healSelf: true, healOthersMult: 1.25 },
  toolbox: { id: 'toolbox', name: 'Toolbox', icon: '⚒', charges: 32, desc: 'Repair generators 50% faster while charges last.', repairMult: 1.5 },
  flashlight: { id: 'flashlight', name: 'Flashlight', icon: '☀', charges: 10, desc: 'Blind the killer; shining during a carry forces a drop.', blind: true },
  key: { id: 'key', name: 'Key', icon: '⚷', charges: 1, desc: 'Open the closed hatch when two or fewer survivors remain.', hatch: true },
};
export const ITEM_ADDONS = {
  gauze: { id: 'gauze', item: 'medkit', name: 'Gauze Roll', desc: '+8 charges', apply: (it) => { it.charges += 8; } },
  syringe: { id: 'syringe', item: 'medkit', name: 'Anti-Haemorrhagic Syringe', desc: 'Self-heals 30% faster', apply: (it) => { it.healSpeed = 1.3; } },
  wire: { id: 'wire', item: 'toolbox', name: 'Wire Spool', desc: '+10 charges', apply: (it) => { it.charges += 10; } },
  socket: { id: 'socket', item: 'toolbox', name: 'Socket Swivels', desc: 'Repair bonus 65%', apply: (it) => { it.repairMult = 1.65; } },
  battery: { id: 'battery', item: 'flashlight', name: 'Battery', desc: '+5 charges', apply: (it) => { it.charges += 5; } },
  lens: { id: 'lens', item: 'flashlight', name: 'Wide Lens', desc: 'Wider beam', apply: (it) => { it.beam = 1.4; } },
  amber: { id: 'amber', item: 'key', name: 'Blood Amber', desc: 'Open hatch faster', apply: (it) => { it.hatchSpeed = 1.5; } },
};
export function makeItem(id, addons = []) {
  if (!id || !ITEMS[id]) return null;
  const d = ITEMS[id];
  const it = { id, name: d.name, icon: d.icon, charges: d.charges, maxCharges: d.charges, repairMult: d.repairMult || 1, healSpeed: 1, beam: 1, hatchSpeed: 1, addons: [] };
  for (const a of addons) { const ad = ITEM_ADDONS[a]; if (ad && ad.item === id) { ad.apply(it); it.addons.push(a); } }
  it.maxCharges = it.charges;
  return it;
}
export const ITEM_POOL = ['medkit', 'medkit', 'toolbox', 'toolbox', 'flashlight', 'key', null, null];
