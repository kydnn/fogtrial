// Survivor HUD (DOM overlay) for the player-survivor mode. Shows only what a survivor would
// know: their own state, the team's health/hook states, generators left, item, perks,
// statuses, interaction prompts, skill checks, chase/terror radius cues and endgame info.
import { fmtTime } from '../core/util.js';
import { STATE_ICON } from './hud.js';
import { STATUS_DEFS } from '../core/status.js';

const M = 32;
export class SurvivorHUD {
  constructor(root) { this.root = root; this.t = 0; this.built = null; }
  build(m) {
    const s = m.player;
    this.root.innerHTML = `
      <div class="hud-top"><div class="obj" id="sh-obj"></div><div class="collapse" id="sh-collapse" hidden><div class="bar"><i id="sh-collapse-bar"></i></div><span id="sh-collapse-t"></span></div>
        <div class="sh-warn" id="sh-warn"></div></div>
      <div class="hud-notify" id="sh-notify"></div>
      <div class="hud-bl">
        <div class="gens"><span class="gen-ico" aria-hidden="true"></span><b id="sh-gens">5</b><small>generators left</small></div>
        <ul class="survs ${m.survivors.length > 5 ? 'many' : ''}" id="sh-survs">${m.survivors.map((o, i) => `
          <li id="sh-s${i}" class="ok ${o === s ? 'me' : ''}"><span class="port" style="--c:${o.color}">${o.name[0]}</span><span class="st"></span>
          <span class="pips"><i></i><i></i></span><span class="hbar"><i></i></span><span class="nm">${o === s ? 'You' : o.name}${o.cls ? ` <em>${o.cls}</em>` : ''}</span></li>`).join('')}</ul>
      </div>
      <div class="hud-br sh-br">
        <div class="sh-item" id="sh-item"></div>
        <div class="perks" id="sh-perks">${[0, 1, 2, 3].map((i) => { const p = s.perks[i]; return `<div class="pd p${i} ${p ? '' : 'empty'}" title="${p ? p.def.name + ' — ' + p.def.description : 'Empty perk slot'}"><span>${p ? p.def.icon : ''}</span><em></em></div>`; }).join('')}</div>
        <div class="sh-status" id="sh-status"></div>
        <div class="keys"><span><kbd>WASD</kbd>Move</span><span><kbd>Shift</kbd>Walk</span><span><kbd>C</kbd>Crouch</span><span><kbd>Space</kbd>Vault · pallet · skill check</span><span><kbd>E</kbd>Interact (hold)</span><span><kbd>Q / RMB</kbd>Item</span><span><kbd>F</kbd>Active perk</span></div>
      </div>
      <div class="sh-me" id="sh-me"></div>
      <div class="sh-prompts" id="sh-prompts"></div>
      <canvas class="sh-check" id="sh-check" width="150" height="150" hidden></canvas>
      <div class="sh-chase" id="sh-chase" hidden>Chased</div>
      <div class="sh-dead" id="sh-dead" hidden></div>
      <div class="hud-intro" id="sh-intro"></div>`;
    this.el = (id) => this.root.querySelector('#' + id);
    this.built = m;
  }
  update(m, dt) {
    if (this.built !== m) this.build(m);
    const s = m.player, el = this.el, ctl = m.playerCtl;
    // every frame: prompts + skill check
    const pr = ctl ? ctl.prompts() : [];
    el('sh-prompts').innerHTML = pr.map((p) => `<div class="pr">${p.key ? `<kbd>${p.key}</kbd>` : ''}<span>${p.label}</span>${p.prog !== null && p.prog !== undefined ? `<div class="pbar"><i style="width:${Math.min(100, p.prog * 100)}%"></i></div>` : ''}</div>`).join('');
    this.drawCheck(m, s);
    const intro = el('sh-intro');
    if (m.state === 'MATCH_START') { intro.hidden = false; intro.innerHTML = `<b>${m.map.name}</b><span>Repair ${m.gensNeeded} generators and escape · ${m.killers.map((k) => k.def.name).join(' & ')}</span>`; }
    else intro.hidden = true;
    this.t -= dt; if (this.t > 0) return; this.t = 0.1;
    const left = Math.max(0, m.gensNeeded - m.gensDone);
    el('sh-gens').textContent = m.gatesPowered ? '0' : left;
    let obj = `Repair ${left} more generator${left === 1 ? '' : 's'}`;
    if (m.collapse) obj = 'Endgame Collapse — get out!'; else if (m.gatesPowered) obj = 'The exit gates are powered — open one and escape';
    if (m.hatch.state === 'open') obj += ' · the hatch is open';
    el('sh-obj').textContent = obj;
    el('sh-collapse').hidden = !m.collapse;
    if (m.collapse) { el('sh-collapse-bar').style.width = (m.collapseT / 120 * 100) + '%'; el('sh-collapse-t').textContent = fmtTime(m.collapseT); }
    m.survivors.forEach((o, i) => {
      const li = el('sh-s' + i); if (!li) return; const st = STATE_ICON[o.health] || STATE_ICON.healthy;
      li.className = st.cls + (o.trap ? ' trapped' : '') + (o === s ? ' me' : '') + (m.inChase(o) ? ' chased' : '');
      li.querySelector('.st').textContent = o.trap ? '⊗' : st.icon;
      const pips = li.querySelectorAll('.pips i'); pips[0].className = o.hookStage >= 1 ? 'on' : ''; pips[1].className = o.hookStage >= 2 ? 'on' : '';
      const hb = li.querySelector('.hbar'); hb.hidden = o.health !== 'hooked';
      if (o.health === 'hooked') hb.firstElementChild.style.width = (100 - o.hookTimer / m.hookStageTime * 100) + '%';
    });
    // item
    const it = s.item;
    el('sh-item').innerHTML = it ? `<span class="ii">${it.icon || '◆'}</span><div><b>${it.name}</b><div class="pbar"><i style="width:${Math.max(0, Math.min(100, it.charges / (it.maxCharges || it.charges || 1) * 100))}%"></i></div></div>` : (s.emp ? '<span class="ii">⚡</span><div><b>EMP</b><small>Q to use</small></div>' : '<small>No item</small>');
    // perks: cooldown / tokens / charges
    s.perks.forEach((p, i) => { const d = this.root.querySelector('#sh-perks .pd.p' + i); if (!d) return; d.classList.toggle('active', m.time - p.lastProc < 2 || !!p.active); d.classList.toggle('cd', p.cooldownT > 0); d.querySelector('em').textContent = p.cooldownT > 0 ? Math.ceil(p.cooldownT) : p.tokens ? p.tokens : p.charges === 0 ? '✕' : ''; });
    // statuses
    const ex = s.status.get('exhausted');
    el('sh-status').innerHTML = s.status.list.filter((q) => STATUS_DEFS[q.id] && q.id !== 'repairSpeed' && q.id !== 'actionSpeed').map((q) => `<span class="${STATUS_DEFS[q.id].kind}">${STATUS_DEFS[q.id].name}${isFinite(q.expiration) && q.expiration < 900 ? ' ' + Math.ceil(q.expiration) + 's' : ''}</span>`).join('') + (s.status.has('exhausted') && ex ? '' : '');
    // own state line
    let me = '';
    if (s.health === 'hooked') me = `Hooked · ${s.hookStage === 2 ? 'struggle phase' : 'stage 1'} · ${Math.ceil(m.hookStageTime - s.hookTimer)}s`;
    else if (s.health === 'dying') me = `Downed · bleeding out ${Math.ceil(s.bleed)}s`;
    else if (s.health === 'carried') me = 'Carried — wiggle!';
    else if (s.status.has('deepWound')) me = `Deep Wound · mend within ${Math.ceil(s.status.timeLeft('deepWound'))}s`;
    el('sh-me').textContent = me;
    el('sh-chase').hidden = !m.inChase(s);
    // warnings (Spine Chill, Premonition, power cues)
    const ws = (s.warnings || []).filter((w) => m.time - w.t < 3);
    el('sh-warn').innerHTML = ws.map((w) => `<div>${w.text}</div>`).join('');
    const dead = el('sh-dead');
    if (!s.alive) { dead.hidden = false; dead.innerHTML = `<b>${s.outcome || (s.health === 'escaped' ? 'Escaped' : 'Dead')}</b><span>Spectating your team · press <kbd>Enter</kbd> to skip to the results</span>`; }
    else dead.hidden = true;
    el('sh-notify').innerHTML = m.notify.filter((n) => m.time - n.t < 5).map((n) => `<div style="color:${n.color};opacity:${Math.min(1, 5 - (m.time - n.t))}">${n.text}</div>`).join('');
  }
  // Skill check: needle sweeping a dial with a good zone and a thin great zone
  drawCheck(m, s) {
    const cv = this.el('sh-check'); const c = s.skillCheck;
    cv.hidden = !c; if (!c) return;
    const g = cv.getContext('2d'); const W = 150, R = 54, cx = W / 2, cy = W / 2;
    g.clearRect(0, 0, W, W);
    const pos = (m.time - c.t0 - c.warn) / c.dur; const a0 = -Math.PI / 2;
    g.lineWidth = 6; g.strokeStyle = 'rgba(255,255,255,0.18)'; g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.stroke();
    g.strokeStyle = 'rgba(240,235,220,0.95)'; g.beginPath(); g.arc(cx, cy, R, a0 + c.zone * Math.PI * 2, a0 + (c.zone + c.good) * Math.PI * 2); g.stroke();
    g.strokeStyle = '#ffffff'; g.lineWidth = 9; g.beginPath(); g.arc(cx, cy, R, a0 + c.zone * Math.PI * 2, a0 + (c.zone + c.great) * Math.PI * 2); g.stroke();
    if (pos > 0) { const a = a0 + Math.min(1.05, pos) * Math.PI * 2; g.strokeStyle = '#e8434f'; g.lineWidth = 3; g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + Math.cos(a) * (R + 6), cy + Math.sin(a) * (R + 6)); g.stroke(); }
    g.fillStyle = '#d9d2c3'; g.font = '600 13px "Saira Condensed", sans-serif'; g.textAlign = 'center'; g.fillText(pos < 0 ? 'SKILL CHECK' : 'SPACE', cx, cy + 5);
    g.fillStyle = 'rgba(255,255,255,0.7)'; g.font = '600 11px "Saira Condensed", sans-serif'; g.fillText(c.kind === 'repair' ? 'Generator' : c.kind === 'heal' ? 'Healing' : c.kind === 'struggle' ? 'Struggle' : '', cx, cy + 20);
  }
}
