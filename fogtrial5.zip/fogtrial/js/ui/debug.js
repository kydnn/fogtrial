// AI debug panel: per-survivor state, goal, utilities, belief, threat, BT node, chase
// reasoning — plus controls to pause AI, force states, change difficulty and toggle layers.
import { M, dist } from '../core/util.js';

const esc = (s) => String(s).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));

export class DebugPanel {
  constructor(root, renderer) { this.root = root; this.r = renderer; this.t = 0; this.m = null; }
  build(m) {
    this.m = m; const d = this.r.debug;
    this.root.innerHTML = `<div class="dbg-head"><b>AI debug</b><span>\` to hide</span></div>
      <div class="dbg-ctl">
        <label><input type="checkbox" id="d-pause" ${m.aiPaused ? 'checked' : ''}> Pause AI</label>
        <label><input type="checkbox" id="d-nav" ${d.nav ? 'checked' : ''}> Navigation</label>
        <label><input type="checkbox" id="d-graph" ${d.graph ? 'checked' : ''}> Chase graph</label>
        <label><input type="checkbox" id="d-belief" ${d.belief ? 'checked' : ''}> Killer belief</label>
        <label><input type="checkbox" id="d-paths" ${d.paths ? 'checked' : ''}> Paths</label>
        <label><input type="checkbox" id="d-xray" ${d.xray ? 'checked' : ''}> X-ray survivors</label>
      </div>
      <section class="dcard dprof"><header><b>Counterplay vs ${esc(m.killers.map((k) => k.def.name).join(' & '))}</b></header><div class="dbody">${(() => { const P = m.survivors.find((q) => q.ai)?.ai?.profile; if (!P) return ''; const kn = P.knobs;
        return `<div class="kv"><span>Power</span><b>${esc(P.power)}</b><span>Strengths</span><b>${esc(P.strengths.join(', '))}</b><span>Weaknesses</span><b>${esc(P.weaknesses.join(', '))}</b>
        <span>Avoid</span><b>${esc(P.avoid.join(', '))}</b><span>Exploit</span><b>${esc(P.exploit.join(', '))}</b>
        <span>Knobs</span><b>${Object.entries(kn).filter(([k, v]) => typeof v === 'number' && Math.abs(v - (['hideBias', 'preDrop', 'unknownParanoia', 'losValue'].includes(k) ? 0 : 1)) > 0.01).map(([k, v]) => `${k} ${v.toFixed(2)}`).join(' · ') || 'neutral'}</b>
        <span>Known perks</span><b id="dbg-kperks">—</b></div>`; })()}</div></section>
      <div id="dbg-kcards">${m.killers.filter((k) => k.bot).map((k, i) => `<section class="dcard kcard-dbg" id="dk-${m.killers.indexOf(k)}" style="--c:${k.def.accent}">
        <header><b>${esc(k.def.short)} bot</b><select data-kdiff="${m.killers.indexOf(k)}">${[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((v) => `<option ${v === k.botDifficulty ? 'selected' : ''}>${v}</option>`).join('')}</select></header>
        <div class="dbody"></div></section>`).join('')}</div>
      <div id="dbg-cards">${m.survivors.map((s, i) => `<section class="dcard" id="dc-${i}" style="--c:${s.color}">
        <header><b>${esc(s.name)}</b><select data-diff="${i}">${[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((v) => `<option ${v === s.difficulty ? 'selected' : ''}>${v}</option>`).join('')}</select>
        <select data-force="${i}"><option value="">force…</option><option>IDLE</option><option>HIDING</option><option>CHASE</option><option>REPAIRING_GENERATOR</option></select></header>
        <div class="dbody"></div></section>`).join('')}</div>
      <div class="dbg-log" id="dbg-log"></div>`;
    const q = (id) => this.root.querySelector('#' + id);
    q('d-pause').addEventListener('change', (e) => (m.aiPaused = e.target.checked));
    for (const k of ['nav', 'graph', 'belief', 'paths', 'xray']) q('d-' + k).addEventListener('change', (e) => (d[k] = e.target.checked));
    this.root.querySelectorAll('[data-kdiff]').forEach((sel) => sel.addEventListener('change', () => m.killers[+sel.dataset.kdiff].bot.setDifficulty(+sel.value)));
    this.root.querySelectorAll('[data-diff]').forEach((sel) => sel.addEventListener('change', () => m.survivors[+sel.dataset.diff].ai.setDifficulty(+sel.value)));
    this.root.querySelectorAll('[data-force]').forEach((sel) => sel.addEventListener('change', () => { const s = m.survivors[+sel.dataset.force]; if (sel.value) s.ai.forced = { state: sel.value, until: m.time + 8 }; sel.value = ''; }));
  }
  update(m, dt) {
    if (this.root.hidden) return;
    if (this.m !== m) this.build(m);
    this.t -= dt; if (this.t > 0) return; this.t = 0.2;
    // killer bots: state machine, chosen goal + alternatives, perception, power controller
    m.killers.forEach((k, i) => {
      const card = this.root.querySelector('#dk-' + i + ' .dbody'); if (!card || !k.bot) return;
      const ai = k.bot, g = ai.goal; const known = ai.per.known(0.4);
      const vis = known.filter((b) => b.visible).length; const lead = ai.per.bestLead?.();
      card.innerHTML = `<div class="kv"><span>State</span><b>${ai.state}</b><span>Difficulty</span><b>${ai.difficulty} · reaction ${ai.P.reaction.toFixed(2)} s · power IQ ${ai.P.powerIQ.toFixed(2)}</b>
        <span>Goal</span><b>${g ? g.type + ' → ' + esc(g.target?.name || g.target?.kind || (g.target?.x ? Math.round(g.target.x / M) + ',' + Math.round(g.target.y / M) : '')) + ' (' + g.score.toFixed(0) + ')' : '-'}${m.time < ai.commitUntil ? ' · committed' : ''}</b>
        <span>Perceives</span><b>${vis} in sight · ${known.length} tracked${lead ? ' · lead: ' + esc(lead.src || lead.kind || '') : ''}</b>
        <span>Power</span><b>${esc(k.power.name)} · ${esc(k.power.state || '')}${ai.powerCtl ? '' : ' (no controller)'}</b>
        ${ai.team ? `<span>Team</span><b>role ${ai.role} · ${ai.team.sightings.size} shared sightings</b>` : ''}
        <span>Chase</span><b>${g?.type === 'CHASE' ? `${(ai.chase.elapsed).toFixed(0)} s · hits ${ai.chase.hits}` : '-'}</b></div>
        <ol class="util">${(ai.options || []).slice(0, 5).map((o) => `<li class="${g && o.key === g.key ? 'cur' : ''}"><b>${o.type}</b> ${esc(o.target?.name || '')} <i>${o.score.toFixed(0)}</i><small>${esc(o.why || '')}</small></li>`).join('')}</ol>
        <div class="klog">${ai.log.slice(-4).reverse().map((l) => `<div>${l.t.toFixed(0)}s ${esc(l.text)}</div>`).join('')}</div>`;
    });
    m.survivors.forEach((s, i) => {
      const card = this.root.querySelector('#dc-' + i + ' .dbody'); if (!card) return;
      if (!s.ai) { card.innerHTML = `<div class="kv"><span>Player</span><b>${s.health}${s.action ? ' · ' + s.action.label : ''}</b></div>`; return; }
      const ai = s.ai, B = ai.belief, ch = ai.chase.debug || {};
      const nearP = m.map.pallets.filter((p) => p.state === 'up' && dist(p.x, p.y, s.x, s.y) < 15 * M).length;
      const nearW = m.map.windows.filter((w) => w.blockedUntil <= m.time && dist(w.x, w.y, s.x, s.y) < 15 * M).length;
      const top = [...ai.options].sort((a, b) => b.score - a.score).slice(0, 5);
      card.innerHTML = `<div class="kv"><span>State</span><b>${ai.state}</b><span>Health</span><b>${s.health}${s.trap ? ' · trapped' : ''}</b>
        <span>Persona</span><b>${s.personality.label} · D${s.difficulty}</b><span>BT node</span><b>${ai.trace.slice(1).join(' › ') || '-'}</b>
        <span>Goal</span><b>${ai.goal ? ai.goal.type + ' → ' + (ai.goal.target?.name || ai.goal.target?.kind || '') + ' (' + ai.goal.score.toFixed(0) + ')' : '-'}</b>
        <span>Threat</span><b>${ai.threat.toFixed(2)}${ai.inChase ? ' · IN CHASE' : ''}</b>
        <span>Killer belief</span><b>${B.state} ${(B.conf * 100) | 0}% · ${(dist(B.pos().x, B.pos().y, s.x, s.y) / M).toFixed(0)}m${B.heartbeat ? ' · ♥' + (B.heartbeat * 100 | 0) : ''}</b>
        <span>Tile</span><b>${ch.tile || m.map.tileAt(s.x, s.y)?.label || 'open'} → ${ch.nextTile || '-'}</b>
        <span>Chase</span><b>${ai.inChase ? `margin ${ch.margin} · ${ch.decision || ''}${ch.mindgame ? ' · mindgame!' : ''}` : '-'}</b>
        <span>Nearby</span><b>${nearP} pallets · ${nearW} windows · path ${ai.path ? ai.path.length - ai.pathIdx : 0}</b>
        <span>Perk plan</span><b>${esc(ai.perkBrain.describe() || 'neutral')}</b>
        <span>Perks</span><b>${s.perks.map((p) => p.def.name + (p.tokens ? ' ×' + p.tokens : '') + (p.cooldownT > 0 ? ' (' + Math.ceil(p.cooldownT) + 's)' : '') + (p.charges === 0 ? ' (used)' : '')).join(', ') || '—'}${s.item ? ' · ' + s.item.name + ' ' + Math.ceil(s.item.charges) : ''}</b></div>
        <ol class="util">${top.map((o) => `<li class="${ai.goal && o.key === ai.goal.key ? 'cur' : ''}"><b>${o.type}</b> ${o.target?.name || ''} <i>${o.score.toFixed(0)}</i><small>${esc(o.why.filter(Boolean).join(' · '))}</small></li>`).join('')}</ol>`;
    });
    const kp = this.root.querySelector('#dbg-kperks'); if (kp) kp.textContent = [...(m.bb.killerPerksKnown?.keys() || [])].join(', ') || 'none revealed yet';
    const log = this.root.querySelector('#dbg-log');
    log.innerHTML = m.aiLog.slice(-8).reverse().map((l) => `<div><b style="color:${l.color}">${esc(l.who)}</b> ${esc(l.text)}</div>`).join('');
  }
}
