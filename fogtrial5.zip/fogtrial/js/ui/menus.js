// Menu screens: main menu, story chapters, loadout, custom match, results, pause,
// controls and the AI Lab. Plain DOM; main.js wires the callbacks.
import { KILLERS, KILLER_LIST } from '../killers/index.js';
import { KILLER_PERKS, KILLER_PERK_IDS, KILLER_PERK_CATEGORIES } from '../perks/killerPerks.js';
import { SURVIVOR_PERKS, BUILD_THEMES } from '../perks/survivorPerks.js';
import { MAP_LIST } from '../maps/maps.js';
import { STORY_LEVELS, loadProgress, AI_BANDS, DIFF_TIERS, PERK_MODE_LABEL, randomScenario } from '../story/levels.js';
import { KILLER_PROFILES } from '../ai/killerProfiles.js';
import { ARCHETYPES, SURVIVOR_ROSTER } from '../ai/personality.js';
import { DIFFICULTY_LABELS } from '../ai/difficulty.js';
import { ITEMS, ITEM_ADDONS } from '../items/items.js';
import { KILLER_DIFFICULTY_LABELS } from '../ai/killer/params.js';
import { SURVIVOR_CLASSES, KILLER_CLASSES, config2v8, TWO_V_EIGHT } from '../modes/twoVeight.js';

const $ = (sel, root = document) => root.querySelector(sel);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

export class Menus {
  constructor(root, api) {
    this.root = root; this.api = api;
    this.loadout = { killer: 'trapper', perks: ['bbq', 'pop', 'sloppy', 'brutal_strength'], addons: [] };
    this.storyFilter = { killer: 'all', tier: 'all', band: 'all', map: 'all' }; this.perkCat = 'all';
    this.custom = { surv: Array.from({ length: 5 }, () => ({ difficulty: '', archetype: '', build: '', item: '', addon: '', perks: [] })), mapId: 'rotwood', survivorCount: 4, difficulty: 5, perDiff: [null, null, null, null, null], perkMode: 'random', itemMode: 'random', itemAddons: 'none', gensRequired: 5, hookCount: 12, gateCount: 2, modifiers: {} };
    try { const s = JSON.parse(localStorage.getItem('fogtrial.loadout') || 'null'); if (s && s.killer) this.loadout = s; } catch (e) { /* ignore */ }
    // survivor-side loadout (Play as Survivor) and per-mode match setups
    this.sload = { character: 0, perks: ['sprint_burst', 'kindred', 'self_care', 'adrenaline'].filter((p) => SURVIVOR_PERKS[p]), item: 'toolbox', addon: '' };
    try { const s = JSON.parse(localStorage.getItem('fogtrial.sload') || 'null'); if (s && Array.isArray(s.perks)) this.sload = { ...this.sload, ...s }; } catch (e) { /* ignore */ }
    this.kmatch = { mapId: 'random', survivorDifficulty: 5, survivorCount: 4 };
    this.smatch = { mapId: 'random', killer: 'random', killerDifficulty: 5, teammateDifficulty: 5, killerPerks: 'random' };
    this.v8 = { role: 'killer', killerA: 'trapper', killerB: 'wraith', killerAClass: 'brute', killerBClass: 'enforcer', survivorClass: 'escapist', mapId: 'rotwood', killerDifficulty: 5, killerBDifficulty: 5, survivorDifficulty: 5, teammateDifficulty: 5, allowPerks: false };
    this.spCat = 'all';
  }
  saveLoadout() { try { localStorage.setItem('fogtrial.loadout', JSON.stringify(this.loadout)); localStorage.setItem('fogtrial.sload', JSON.stringify(this.sload)); } catch (e) { /* ignore */ } }
  show(html, cls = '') { this.root.hidden = false; this.root.className = 'screen ' + cls; this.root.innerHTML = html; this.root.scrollTop = 0; }
  hide() { this.root.hidden = true; this.root.innerHTML = ''; }
  click(sel, fn) { this.root.querySelectorAll(sel).forEach((b) => b.addEventListener('click', (e) => { this.api.sfx('ui'); fn(e, b); })); }

  // ------------------------------------------------------------- main
  main() {
    this.show(`
      <div class="title-wrap">
        <p class="kicker">A top-down asymmetric trial</p>
        <h1 class="title">Fog Trial</h1>
        <p class="sub">Hunt as one of ${KILLER_LIST.length} killers, or survive against a killer bot with three bot teammates. Generators, hooks, loops — and bots that read each other.</p>
        <nav class="main-nav">
          <button class="btn primary" data-go="killer">Play as Killer <small>you hunt · bot survivors</small></button>
          <button class="btn primary" data-go="survivor">Play as Survivor <small>you + 3 bot teammates vs a killer bot</small></button>
          <button class="btn primary" data-go="mp">Multiplayer <small>custom matches online · humans and bots in any slot</small></button>
          <button class="btn" data-go="v8">2v8 Mode <small>two killers · eight survivors · classes</small></button>
          <button class="btn" data-go="story">Story Mode <small>${STORY_LEVELS.length} killer scenarios</small></button>
          <button class="btn" data-go="custom">Custom Match <small>configure every survivor bot</small></button>
          <div class="nav-row">
            <button class="btn ghost" data-go="kselect">Killer Selection</button>
            <button class="btn ghost" data-go="sload">Survivor Loadout</button>
            <button class="btn ghost" data-go="settings">Settings</button>
            <button class="btn ghost" data-go="controls">Controls</button>
            <button class="btn ghost" data-go="lab">AI Lab</button>
          </div>
        </nav>
        <p class="foot">An original fan-made tribute to asymmetric horror. No assets from any existing game.</p>
      </div>`, 'menu');
    this.click('[data-go]', (e, b) => {
      const g = b.dataset.go;
      if (g === 'story') this.story(); else if (g === 'custom') this.customScreen(); else if (g === 'lab') this.lab(); else if (g === 'controls') this.controls();
      else if (g === 'mp') this.mpConnect(); else if (g === 'killer') this.loadoutScreen({ match: true }); else if (g === 'survivor') this.survivorSetup(); else if (g === 'v8') this.v8Setup();
      else if (g === 'kselect') this.loadoutScreen({ onDone: () => this.main(), browse: true }); else if (g === 'sload') this.survivorLoadout({ onDone: () => this.main() }); else if (g === 'settings') this.settingsScreen();
    });
  }

  // ------------------------------------------------------------- shared bits
  mapPicker(cur, name, withRandom = true) {
    return `<div class="maprow">${withRandom ? `<label class="mapopt ${cur === 'random' ? 'sel' : ''}"><input type="radio" name="${name}" value="random" ${cur === 'random' ? 'checked' : ''}><b>Random map</b><small>any of ${MAP_LIST.length}</small></label>` : ''}${MAP_LIST.map((mp) => `<label class="mapopt ${cur === mp.id ? 'sel' : ''}"><input type="radio" name="${name}" value="${mp.id}" ${cur === mp.id ? 'checked' : ''}><b>${esc(mp.name)}</b><small>${esc(mp.blurb)}</small></label>`).join('')}</div>`;
  }
  diffSlider(id, val, labels, title) { return `<label class="fld">${esc(title)} <output id="${id}-lab">${val} · ${esc(labels[val])}</output><input type="range" id="${id}" min="1" max="10" value="${val}"></label>`; }
  bindSlider(id, labels, set) { const r = this.root; $('#' + id, r)?.addEventListener('input', (e) => { const v = +e.target.value; set(v); $('#' + id + '-lab', r).textContent = `${v} · ${labels[v]}`; }); }
  pickMap(id) { return id === 'random' ? MAP_LIST[Math.floor(Math.random() * MAP_LIST.length)].id : id; }

  // ------------------------------------------------------------- Play as Survivor
  survivorSetup() {
    const S = this.smatch, L = this.sload; const opt = (v, cur, label) => `<option value="${v}" ${String(v) === String(cur) ? 'selected' : ''}>${esc(label)}</option>`;
    const ch = SURVIVOR_ROSTER[L.character] || SURVIVOR_ROSTER[0];
    const kd = S.killer === 'random' ? null : KILLERS[S.killer];
    this.show(`<div class="panel wide ssetup"><div class="row-head"><h2>Play as Survivor</h2><div class="row-actions"><button class="btn small" data-back>Back</button><button class="btn primary" data-go>Enter the trial</button></div></div>
      <div class="cgrid">
        <fieldset><legend>You</legend>
          <div class="kband" style="--kc:${ch.color}"><span class="sport" style="--c:${ch.color}">${esc(ch.name[0])}</span><div><b>${esc(ch.name)}</b><small>${L.perks.map((p) => SURVIVOR_PERKS[p]?.name).filter(Boolean).join(' · ') || 'No perks'}<br>${L.item ? esc(ITEMS[L.item]?.name || L.item) : 'No item'}${L.addon ? ' + ' + esc(ITEM_ADDONS[L.addon]?.name || L.addon) : ''}</small></div></div>
          <button class="btn small" data-sload>Change character, perks &amp; item…</button>
        </fieldset>
        <fieldset><legend>Killer</legend>
          <label class="fld">Killer<select id="ss-killer">${opt('random', S.killer, 'Random killer')}${KILLER_LIST.map((k) => opt(k.id, S.killer, k.name)).join('')}</select></label>
          ${kd ? `<div class="kband" style="--kc:${kd.accent}">${portrait(kd)}<div><b>${esc(kd.name)}</b><small>${esc(kd.power)} — ${esc(kd.powerDesc)}</small></div></div>` : '<p class="note">A random killer is rolled when the trial starts.</p>'}
          <label class="fld">Killer perks<select id="ss-kperks">${opt('random', S.killerPerks, 'Random')}${opt('signature', S.killerPerks, 'Signature perks')}${opt('none', S.killerPerks, 'No perks')}</select></label>
          ${this.diffSlider('ss-kd', S.killerDifficulty, KILLER_DIFFICULTY_LABELS, 'Killer bot difficulty')}
        </fieldset>
        <fieldset><legend>Teammates</legend>
          ${this.diffSlider('ss-td', S.teammateDifficulty, DIFFICULTY_LABELS, 'Teammate bot difficulty')}
          <p class="note">Three bot teammates. They repair, heal you, come for you when you're hooked and follow your lead.</p>
        </fieldset>
      </div>
      <fieldset><legend>Map</legend>${this.mapPicker(S.mapId, 'ss-map')}</fieldset></div>`, 'menu');
    const r = this.root;
    r.querySelectorAll('input[name=ss-map]').forEach((i) => i.addEventListener('change', () => { S.mapId = i.value; this.survivorSetup(); }));
    $('#ss-killer', r).addEventListener('change', (e) => { S.killer = e.target.value; this.survivorSetup(); });
    $('#ss-kperks', r).addEventListener('change', (e) => (S.killerPerks = e.target.value));
    this.bindSlider('ss-kd', KILLER_DIFFICULTY_LABELS, (v) => (S.killerDifficulty = v));
    this.bindSlider('ss-td', DIFFICULTY_LABELS, (v) => (S.teammateDifficulty = v));
    this.click('[data-back]', () => this.main());
    this.click('[data-sload]', () => this.survivorLoadout({ onDone: () => this.survivorSetup() }));
    this.click('[data-go]', () => { this.saveLoadout(); this.api.start(this.survivorMatchConfig()); });
  }
  survivorMatchConfig() {
    const S = this.smatch, L = this.sload;
    const pool = KILLER_LIST.filter((k) => k.unlocked); const kd = S.killer === 'random' ? pool[Math.floor(Math.random() * pool.length)] : KILLERS[S.killer];
    let kperks = [];
    if (S.killerPerks === 'signature') kperks = kd.signature.filter((p) => KILLER_PERKS[p]).slice(0, 3);
    else if (S.killerPerks === 'random') { const ids = KILLER_PERK_IDS.filter((p) => !KILLER_PERKS[p].hex || Math.random() < 0.5); while (kperks.length < 4) { const p = ids[Math.floor(Math.random() * ids.length)]; if (!kperks.includes(p)) kperks.push(p); } }
    const ch = SURVIVOR_ROSTER[L.character] || SURVIVOR_ROSTER[0];
    const me = { difficulty: 5, perks: L.perks.slice(0, 4), item: L.item || null, itemAddons: L.addon ? [L.addon] : [], name: ch.name };
    return { playerRole: 'survivor', mapId: this.pickMap(S.mapId), killerId: kd.id, killerPerks: kperks, killerAddons: [], killerDifficulty: S.killerDifficulty,
      survivorCount: 4, difficulty: S.teammateDifficulty, perkMode: 'random', itemMode: 'random', playerName: ch.name,
      survivors: [me, ...[1, 2, 3].map(() => ({ difficulty: S.teammateDifficulty }))] };
  }

  // ------------------------------------------------------------- Survivor Loadout
  survivorLoadout({ onDone } = {}) {
    const L = this.sload; const cat = this.spCat;
    const cats = ['all', ...[...new Set(Object.values(SURVIVOR_PERKS).map((p) => p.cat))]];
    const ids = Object.keys(SURVIVOR_PERKS).filter((id) => cat === 'all' || SURVIVOR_PERKS[id].cat === cat).sort((a, b) => SURVIVOR_PERKS[a].name.localeCompare(SURVIVOR_PERKS[b].name));
    const perks = ids.map((id) => { const p = SURVIVOR_PERKS[id]; return `<button class="perk ${L.perks.includes(id) ? 'sel' : ''}" data-p="${id}" title="${esc(p.description)}"><span class="pd"><span>${p.icon || '◆'}</span></span><b>${esc(p.name)}</b><small>${esc(p.description)}</small></button>`; }).join('');
    const items = [['', 'No item'], ...Object.values(ITEMS).map((it) => [it.id, it.name])];
    const addons = L.item ? Object.values(ITEM_ADDONS).filter((a) => a.item === L.item) : [];
    this.show(`<div class="panel wide loadout"><div class="row-head"><h2>Survivor Loadout</h2><div class="row-actions"><button class="btn primary" data-done>Done</button></div></div>
      <h3>Character</h3><div class="chars">${SURVIVOR_ROSTER.map((c, i) => `<button class="char ${i === L.character ? 'sel' : ''}" data-c="${i}" style="--c:${c.color}"><span class="sport" style="--c:${c.color}">${esc(c.name[0])}</span><b>${esc(c.name)}</b></button>`).join('')}</div>
      <h3>Item <small>Q / RMB to use in a trial</small></h3><div class="addons">${items.map(([id, n]) => `<button class="addon ${String(L.item || '') === id ? 'sel' : ''}" data-it="${id}"><b>${esc(n)}</b><small>${id ? esc(ITEMS[id].desc || '') : 'Bring nothing'}</small></button>`).join('')}</div>
      ${addons.length ? `<h3>Item add-on</h3><div class="addons">${[['', { name: 'None', desc: '' }], ...addons.map((a) => [a.id, a])].map(([id, a]) => `<button class="addon ${String(L.addon || '') === id ? 'sel' : ''}" data-ad="${id}"><b>${esc(a.name)}</b><small>${esc(a.desc || '')}</small></button>`).join('')}</div>` : ''}
      <h3>Perks <small>${L.perks.length}/4 equipped · F activates active perks in a trial</small></h3>
      <div class="tabs">${cats.map((c) => `<button class="tab ${cat === c ? 'on' : ''}" data-cat="${c}">${esc(c === 'all' ? 'All' : c)}</button>`).join('')}</div>
      <div class="perkgrid">${perks}</div></div>`, 'menu');
    const again = () => this.survivorLoadout({ onDone });
    this.click('[data-c]', (e, b) => { L.character = +b.dataset.c; again(); });
    this.click('[data-it]', (e, b) => { L.item = b.dataset.it || null; L.addon = ''; again(); });
    this.click('[data-ad]', (e, b) => { L.addon = b.dataset.ad; again(); });
    this.click('[data-cat]', (e, b) => { this.spCat = b.dataset.cat; again(); });
    this.click('[data-p]', (e, b) => { const id = b.dataset.p; const i = L.perks.indexOf(id); if (i >= 0) L.perks.splice(i, 1); else if (L.perks.length < 4) L.perks.push(id); again(); });
    this.click('[data-done]', () => { this.saveLoadout(); (onDone || (() => this.main()))(); });
  }

  // ------------------------------------------------------------- 2v8
  v8Setup() {
    const V = this.v8; const opt = (v, cur, label) => `<option value="${v}" ${String(v) === String(cur) ? 'selected' : ''}>${esc(label)}</option>`;
    const kA = KILLERS[V.killerA], kB = KILLERS[V.killerB];
    const roles = [['killer', 'Killer A (you) + bot Killer B vs 8 bot survivors'], ['survivor', 'Survivor (you) + 7 bot survivors vs 2 killer bots'], ['spectate', 'Spectate: all bots']];
    const kopts = (cur) => KILLER_LIST.map((k) => opt(k.id, cur, k.name)).join('');
    const kcls = (cur) => Object.entries(KILLER_CLASSES).map(([id, c]) => opt(id, cur, `${c.name} — ${c.blurb}`)).join('');
    this.show(`<div class="panel wide v8"><div class="row-head"><h2>2v8 Mode</h2><div class="row-actions"><button class="btn small" data-back>Back</button><button class="btn primary" data-go>Enter the trial</button></div></div>
      <p class="note">Two killers against eight survivors on a larger map: ${TWO_V_EIGHT.generators} generators, ${TWO_V_EIGHT.gensRequired} to power ${TWO_V_EIGHT.gates} exit gates. Hooked survivors are sent to cages elsewhere on the map. No self-healing (Medic excepted), no hatch, and survivors are Revealed when a chase starts, near a kicked generator or when they finish one. Everyone plays a class instead of perks and items.</p>
      <fieldset><legend>Your role</legend>${roles.map(([id, l]) => `<label class="chk"><input type="radio" name="v8-role" value="${id}" ${V.role === id ? 'checked' : ''}> ${esc(l)}</label>`).join('')}</fieldset>
      <div class="cgrid">
        <fieldset><legend>Killer A ${V.role === 'killer' ? '(you)' : '(bot)'}</legend><div class="kband" style="--kc:${kA.accent}">${portrait(kA)}<div><b>${esc(kA.name)}</b><small>${esc(kA.power)}</small></div></div>
          <label class="fld">Killer<select id="v8-ka">${kopts(V.killerA)}</select></label><label class="fld">Class<select id="v8-kac">${kcls(V.killerAClass)}</select></label>
          ${V.role !== 'killer' ? this.diffSlider('v8-kad', V.killerDifficulty, KILLER_DIFFICULTY_LABELS, 'Killer A bot difficulty') : ''}</fieldset>
        <fieldset><legend>Killer B (bot)</legend><div class="kband" style="--kc:${kB.accent}">${portrait(kB)}<div><b>${esc(kB.name)}</b><small>${esc(kB.power)}</small></div></div>
          <label class="fld">Killer<select id="v8-kb">${kopts(V.killerB)}</select></label><label class="fld">Class<select id="v8-kbc">${kcls(V.killerBClass)}</select></label>
          ${this.diffSlider('v8-kbd', V.killerBDifficulty, KILLER_DIFFICULTY_LABELS, 'Killer B bot difficulty')}</fieldset>
        <fieldset><legend>Survivors</legend>
          ${V.role === 'survivor' ? `<label class="fld">Your class<select id="v8-sc">${Object.entries(SURVIVOR_CLASSES).map(([id, c]) => opt(id, V.survivorClass, `${c.name} — ${c.blurb}`)).join('')}</select></label>${this.diffSlider('v8-td', V.teammateDifficulty, DIFFICULTY_LABELS, 'Teammate bot difficulty')}`
            : this.diffSlider('v8-sd', V.survivorDifficulty, DIFFICULTY_LABELS, 'Survivor bot difficulty')}
          <p class="note">Bot survivors take the four classes in turn: ${Object.values(SURVIVOR_CLASSES).map((c) => `<b>${esc(c.name)}</b>`).join(', ')}.</p>
          <label class="chk"><input type="checkbox" id="v8-perks" ${V.allowPerks ? 'checked' : ''}> House rule: allow random items (and up to two extra perks)</label>
        </fieldset>
      </div>
      <fieldset><legend>Map (enlarged for 2v8)</legend>${this.mapPicker(V.mapId, 'v8-map')}</fieldset></div>`, 'menu');
    const r = this.root, again = () => this.v8Setup();
    r.querySelectorAll('input[name=v8-role]').forEach((i) => i.addEventListener('change', () => { V.role = i.value; again(); }));
    r.querySelectorAll('input[name=v8-map]').forEach((i) => i.addEventListener('change', () => { V.mapId = i.value; again(); }));
    for (const [id, key, re] of [['v8-ka', 'killerA', 1], ['v8-kb', 'killerB', 1], ['v8-kac', 'killerAClass'], ['v8-kbc', 'killerBClass'], ['v8-sc', 'survivorClass']]) $('#' + id, r)?.addEventListener('change', (e) => { V[key] = e.target.value; if (re) again(); });
    this.bindSlider('v8-kad', KILLER_DIFFICULTY_LABELS, (v) => (V.killerDifficulty = v));
    this.bindSlider('v8-kbd', KILLER_DIFFICULTY_LABELS, (v) => (V.killerBDifficulty = v));
    this.bindSlider('v8-sd', DIFFICULTY_LABELS, (v) => (V.survivorDifficulty = v));
    this.bindSlider('v8-td', DIFFICULTY_LABELS, (v) => (V.teammateDifficulty = v));
    $('#v8-perks', r).addEventListener('change', (e) => (V.allowPerks = e.target.checked));
    this.click('[data-back]', () => this.main());
    this.click('[data-go]', () => {
      const cfg = config2v8({ ...V, mapId: this.pickMap(V.mapId), killerPerks: V.allowPerks ? this.loadout.perks : null, survivorPerks: V.allowPerks ? this.sload.perks : null });
      if (V.role === 'survivor') { const ch = SURVIVOR_ROSTER[this.sload.character] || SURVIVOR_ROSTER[0]; cfg.playerName = ch.name; cfg.survivors[0].name = ch.name; }
      this.api.start(cfg);
    });
  }

  // ------------------------------------------------------------- multiplayer
  mpLoadout() {
    const L = this.loadout, S = this.sload;
    return { killer: L.killer, kperks: L.perks, addons: L.addons, sperks: S.perks, item: S.item || null, addon: S.addon || '', character: S.character };
  }
  mpConnect(msg = '', code = '') {
    const net = this.api.net();
    const url = this.mpUrl ?? net.constructor.defaultUrl(); const name = this.mpName || (() => { try { return localStorage.getItem('fogtrial.name') || ''; } catch (e) { return ''; } })();
    const sameOrigin = /^https?:$/.test(location.protocol) && url === location.origin;
    this.show(`<div class="panel narrow mp"><h2>Multiplayer</h2>
      <p class="note">Custom matches like Dead by Daylight's: one player creates a room and shares the code. Everyone picks a killer or survivor slot; empty slots are played by bots.</p>
      ${msg ? `<p class="mp-msg">${esc(msg)}</p>` : ''}
      <label class="fld">Your name<input id="mp-name" maxlength="16" value="${esc(name)}" placeholder="Player"></label>
      <label class="fld ${sameOrigin ? 'mp-adv' : ''}">Server address<input id="mp-url" value="${esc(url)}" placeholder="https://your-game.onrender.com"></label>
      ${sameOrigin ? '<p class="note small">Connected to this site’s server.</p>' : '<p class="note small">The address of your Fog Trial server (for example your Render web service).</p>'}
      <div class="row-actions left"><button class="btn primary" data-create>Create room</button></div>
      <div class="mp-join"><label class="fld">Room code<input id="mp-code" maxlength="4" value="${esc(code || this.mpCode || '')}" placeholder="ABCD" style="text-transform:uppercase"></label><button class="btn" data-join>Join</button></div>
      <div class="row-actions"><button class="btn small" data-back>Back</button></div></div>`, 'menu');
    const r = this.root;
    const go = async (what) => {
      this.mpName = $('#mp-name', r).value.trim() || 'Player'; this.mpUrl = $('#mp-url', r).value.trim(); this.mpCode = $('#mp-code', r).value.trim().toUpperCase();
      try { localStorage.setItem('fogtrial.name', this.mpName); } catch (e) { /* ignore */ }
      if (!this.mpUrl) { this.mpConnect('Enter the server address first.'); return; }
      if (what === 'join' && this.mpCode.length !== 4) { this.mpConnect('Enter the 4-letter room code.'); return; }
      $('.mp', r).classList.add('busy'); r.querySelectorAll('button').forEach((b) => (b.disabled = true));
      const note = document.createElement('p'); note.className = 'mp-msg'; note.textContent = 'Connecting… a sleeping Render server takes up to a minute to wake up.'; $('.mp', r).appendChild(note);
      try {
        if (!net.connected) await net.connect(this.mpUrl, this.mpName);
        net.send(what === 'create' ? { t: 'create', loadout: this.mpLoadout() } : { t: 'join', code: this.mpCode, loadout: this.mpLoadout() });
        this.mpWaiting = true;
      } catch (e) { this.mpConnect(e.message || String(e)); }
    };
    this.click('[data-create]', () => go('create')); this.click('[data-join]', () => go('join'));
    $('#mp-code', r).addEventListener('keydown', (e) => { if (e.key === 'Enter') go('join'); });
    this.click('[data-back]', () => this.main());
  }
  mpRoom(state = null) {
    const net = this.api.net(); const R = state || net.room; if (!R) { this.mpConnect(); return; }
    this.mpWaiting = false; this.inRoom = true;
    const me = R.players.find((p) => p.id === R.you) || {}; const host = R.hostId === R.you;
    const pl = (id) => R.players.find((p) => p.id === id);
    const opt = (v, cur, label) => `<option value="${v}" ${String(v) === String(cur) ? 'selected' : ''}>${esc(label)}</option>`;
    const v8 = R.mode === '2v8';
    const row = (s) => {
      const p = s.pid ? pl(s.pid) : null; const mine = s.pid === R.you; const L = p?.loadout || {};
      const label = s.role === 'killer' ? (v8 ? `Killer ${'AB'[s.idx]}` : 'Killer') : `Survivor ${s.idx + 1}`;
      let who;
      if (p) {
        const what = s.role === 'killer' ? (KILLERS[L.killer]?.name || 'The Trapper') : (SURVIVOR_ROSTER[L.character]?.name || '') + (v8 ? '' : (L.sperks?.length ? ' · ' + L.sperks.map((x) => SURVIVOR_PERKS[x]?.name).filter(Boolean).join(', ') : ''));
        who = `<b>${esc(p.name)}</b>${mine ? ' <em>(you)</em>' : ''}${p.id === R.hostId ? ' <em>host</em>' : ''} <span class="rd ${p.ready || p.id === R.hostId ? 'on' : ''}">${p.ready || p.id === R.hostId ? 'ready' : 'not ready'}</span><small>${esc(what)}</small>`;
      } else {
        who = `<b class="bot">Bot</b>${s.role === 'killer' ? (host ? ` <select data-bk="${s.i}">${KILLER_LIST.map((k) => opt(k.id, s.botKiller, k.name)).join('')}</select>` : ` <small>${esc(KILLERS[s.botKiller]?.name || '')}</small>`) : ''}
          ${host ? `<select data-bd="${s.i}" title="Bot difficulty">${[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((d) => opt(d, s.botDiff, `${d} · ${(s.role === 'killer' ? KILLER_DIFFICULTY_LABELS : DIFFICULTY_LABELS)[d]}`)).join('')}</select>` : `<small>difficulty ${s.botDiff}</small>`}`;
      }
      const cls = v8 ? (s.role === 'killer' ? KILLER_CLASSES : SURVIVOR_CLASSES) : null;
      const clsSel = cls ? ((host || mine) ? `<select data-cls="${s.i}">${Object.entries(cls).map(([id, c]) => opt(id, s.cls, c.name)).join('')}</select>` : `<small>${esc(cls[s.cls]?.name || '')}</small>`) : '';
      const act = mine ? `<button class="btn small" data-unslot>Leave slot</button>` : !p && !R.playing ? `<button class="btn small" data-take="${s.i}">Take</button>` : host && p && !R.playing ? `<button class="btn small ghost" data-kick="${s.i}">Move to spectators</button>` : '';
      return `<li class="slot ${s.role} ${p ? 'human' : 'botslot'} ${mine ? 'mine' : ''}"><span class="sl">${label}</span><span class="who">${who}</span>${clsSel ? `<span class="cls">${clsSel}</span>` : ''}<span class="act">${act}</span></li>`;
    };
    const specs = R.players.filter((p) => p.slot < 0);
    const mySlot = R.slots.find((s) => s.pid === R.you);
    const chatVal = $('#mp-chat', this.root)?.value || ''; const chatFocus = document.activeElement?.id === 'mp-chat';
    this.show(`<div class="panel wide mproom"><div class="row-head"><div><p class="kicker">Room</p><h2 class="code">${esc(R.code)}</h2></div>
        <div class="row-actions"><button class="btn small" data-copy>Copy invite link</button><button class="btn small" data-leave>Leave room</button></div></div>
      ${R.playing ? '<p class="mp-msg">A match is in progress — you are in the lobby until it ends.</p>' : ''}
      <div class="cgrid mpset">
        <fieldset><legend>Match</legend>
          <label class="fld">Mode<select id="mp-mode" ${host && !R.playing ? '' : 'disabled'}>${opt('1v4', R.mode, '1v4 — one killer, four survivors')}${opt('2v8', R.mode, '2v8 — two killers, eight survivors')}</select></label>
          <label class="fld">Map<select id="mp-map" ${host && !R.playing ? '' : 'disabled'}>${opt('random', R.mapId, 'Random map')}${MAP_LIST.map((mp) => opt(mp.id, R.mapId, mp.name)).join('')}</select></label>
          ${host ? '' : '<p class="note small">The host sets the mode, map and bots.</p>'}
        </fieldset>
        <fieldset><legend>Your loadout</legend>
          ${mySlot ? (mySlot.role === 'killer' ? `<p>${esc(KILLERS[this.loadout.killer]?.name || '')} · ${this.loadout.perks.map((x) => KILLER_PERKS[x]?.name).filter(Boolean).join(', ') || 'no perks'}</p><button class="btn small" data-kload>Choose killer &amp; perks…</button>`
            : `<p>${esc(SURVIVOR_ROSTER[this.sload.character]?.name || '')} · ${v8 ? 'class: ' + esc(SURVIVOR_CLASSES[mySlot.cls]?.name || '') : (this.sload.perks.map((x) => SURVIVOR_PERKS[x]?.name).filter(Boolean).join(', ') || 'no perks') + ' · ' + (this.sload.item ? esc(ITEMS[this.sload.item]?.name) : 'no item')}</p><button class="btn small" data-sload>Choose character, perks &amp; item…</button>`)
            : '<p class="note">You are spectating. Take a slot to play.</p>'}
          ${v8 ? '<p class="note small">2v8 uses classes instead of perks and items.</p>' : ''}
        </fieldset>
      </div>
      <h3>Killers</h3><ul class="slots">${R.slots.filter((s) => s.role === 'killer').map(row).join('')}</ul>
      <h3>Survivors</h3><ul class="slots">${R.slots.filter((s) => s.role === 'survivor').map(row).join('')}</ul>
      ${specs.length ? `<p class="note">Spectating: ${specs.map((p) => esc(p.name)).join(', ')}</p>` : ''}
      <div class="row-actions">${!host && mySlot ? `<button class="btn ${me.ready ? '' : 'primary'}" data-ready>${me.ready ? 'Not ready' : 'Ready'}</button>` : ''}${host ? `<button class="btn primary" data-start ${R.playing ? 'disabled' : ''}>Start match</button>` : ''}</div>
      <div class="mpchat"><div class="msgs">${R.chat.map((c) => `<div>${c.who ? `<b>${esc(c.who)}</b> ` : '<i>'}${esc(c.text)}${c.who ? '' : '</i>'}</div>`).join('')}</div>
        <input id="mp-chat" maxlength="200" placeholder="Say something… (Enter)" value="${esc(chatVal)}"></div></div>`, 'menu');
    const r = this.root, send = (o) => net.send(o);
    const msgs = $('.mpchat .msgs', r); msgs.scrollTop = msgs.scrollHeight;
    const chat = $('#mp-chat', r); if (chatFocus) { chat.focus(); chat.setSelectionRange(chat.value.length, chat.value.length); }
    chat.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter' && chat.value.trim()) { send({ t: 'chat', text: chat.value.trim() }); chat.value = ''; } });
    $('#mp-mode', r).addEventListener('change', (e) => send({ t: 'settings', mode: e.target.value }));
    $('#mp-map', r).addEventListener('change', (e) => send({ t: 'settings', mapId: e.target.value }));
    r.querySelectorAll('[data-bk]').forEach((el) => el.addEventListener('change', () => send({ t: 'slot', i: +el.dataset.bk, botKiller: el.value })));
    r.querySelectorAll('[data-bd]').forEach((el) => el.addEventListener('change', () => send({ t: 'slot', i: +el.dataset.bd, botDiff: +el.value })));
    r.querySelectorAll('[data-cls]').forEach((el) => el.addEventListener('change', () => send({ t: 'slot', i: +el.dataset.cls, cls: el.value })));
    this.click('[data-take]', (e, b) => send({ t: 'take', i: +b.dataset.take }));
    this.click('[data-kick]', (e, b) => send({ t: 'slot', i: +b.dataset.kick, kick: true }));
    this.click('[data-unslot]', () => send({ t: 'unslot' }));
    this.click('[data-ready]', () => send({ t: 'ready', v: !me.ready }));
    this.click('[data-start]', () => send({ t: 'start' }));
    this.click('[data-leave]', () => { send({ t: 'leave' }); net.room = null; this.inRoom = false; this.mpConnect(); });
    this.click('[data-copy]', () => { const link = `${location.origin}${location.pathname}?room=${R.code}`; try { navigator.clipboard.writeText(link); } catch (e) { /* ignore */ } this.toast('Invite link copied: ' + link); });
    this.click('[data-kload]', () => { this.inRoom = false; this.loadoutScreen({ browse: true, onDone: () => { this.saveLoadout(); send({ t: 'loadout', ...this.mpLoadout() }); this.mpRoom(); } }); });
    this.click('[data-sload]', () => { this.inRoom = false; this.survivorLoadout({ onDone: () => { this.saveLoadout(); send({ t: 'loadout', ...this.mpLoadout() }); this.mpRoom(); } }); });
  }
  toast(text) {
    const t = document.createElement('div'); t.className = 'toast'; t.textContent = text; document.body.appendChild(t);
    setTimeout(() => t.classList.add('out'), 3500); setTimeout(() => t.remove(), 4200);
  }

  // ------------------------------------------------------------- settings
  settingsScreen() {
    const S = this.api.settings(); const opt = (v, cur, label) => `<option value="${v}" ${String(v) === String(cur) ? 'selected' : ''}>${esc(label)}</option>`;
    this.show(`<div class="panel narrow settings"><h2>Settings</h2>
      <label class="fld">Volume<input type="range" id="st-vol" min="0" max="1" step="0.05" value="${S.volume}"></label>
      <label class="fld">Camera zoom<input type="range" id="st-zoom" min="0.7" max="1.5" step="0.05" value="${S.zoom}"></label>
      <label class="fld">Mouse wheel<select id="st-wheel">${opt('auto', S.wheel || 'auto', 'Auto (ability select when the killer has one)')}${opt('zoom', S.wheel, 'Always zoom')}${opt('ability', S.wheel, 'Always select ability')}</select></label>
      <label class="fld">Simulation detail<select id="st-perf">${opt('high', S.perf || 'high', 'High (bots think at full rate)')}${opt('balanced', S.perf, 'Balanced (2v8 bots think less often)')}${opt('low', S.perf, 'Low (all bots think less often)')}</select></label>
      <label class="chk"><input type="checkbox" id="st-dbg" ${S.debug ? 'checked' : ''}> AI debug overlay in matches (also: \` / F3)</label>
      <label class="chk"><input type="checkbox" id="st-hints" ${S.hints !== false ? 'checked' : ''}> Show control hints on the HUD</label>
      <div class="row-actions"><button class="btn primary" data-back>Done</button></div></div>`, 'menu');
    const r = this.root, set = (k, v) => this.api.setSetting(k, v);
    $('#st-vol', r).addEventListener('input', (e) => set('volume', +e.target.value));
    $('#st-zoom', r).addEventListener('input', (e) => set('zoom', +e.target.value));
    $('#st-wheel', r).addEventListener('change', (e) => set('wheel', e.target.value));
    $('#st-perf', r).addEventListener('change', (e) => set('perf', e.target.value));
    $('#st-dbg', r).addEventListener('change', (e) => set('debug', e.target.checked));
    $('#st-hints', r).addEventListener('change', (e) => set('hints', e.target.checked));
    this.click('[data-back]', () => this.main());
  }

  controls() {
    this.show(`<div class="panel narrow"><h2>Controls</h2>
      <h3>As the killer</h3>
      <dl class="controls">
        <dt><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd></dt><dd>Move</dd>
        <dt><kbd>Mouse</kbd></dt><dd>Aim / face (pod view: the reticle)</dd>
        <dt><kbd>LMB</kbd></dt><dd>Attack (hold for a longer lunge) · power follow-ups (blink attack, lethal rush, teleport from a pod)</dd>
        <dt><kbd>RMB</kbd> / <kbd>Q</kbd></dt><dd>Killer power. While carrying: drop the survivor</dd>
        <dt><kbd>E</kbd></dt><dd>Secondary ability (pick up traps, pod view, recall drones, hallucinations…)</dd>
        <dt><kbd>F</kbd> / <kbd>Wheel</kbd></dt><dd>Cycle (Lich spells, next biopod, Unknown teleport)</dd>
        <dt><kbd>SPACE</kbd></dt><dd>Hook, pick up, break pallet, vault, damage generator, close hatch</dd>
      </dl>
      <h3>As a survivor</h3>
      <dl class="controls">
        <dt><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd></dt><dd>Run · <kbd>Shift</kbd> walk · <kbd>C</kbd> crouch</dd>
        <dt><kbd>SPACE</kbd></dt><dd>Vault, drop a pallet, hit skill checks</dd>
        <dt><kbd>E</kbd> (hold)</dt><dd>Repair, heal, unhook, open gates, search chests, cleanse totems, hack drones, print EMPs…</dd>
        <dt><kbd>Q</kbd> / <kbd>RMB</kbd></dt><dd>Use your item (flashlight, med-kit) · EMP · spray · vaccine</dd>
        <dt><kbd>F</kbd></dt><dd>Active perk (Dead Hard, …)</dd>
        <dt><kbd>A</kbd>/<kbd>D</kbd></dt><dd>Wiggle while carried</dd>
        <dt><kbd>Enter</kbd> · <kbd>Tab</kbd></dt><dd>When dead: skip to the results · spectate the next teammate</dd>
      </dl>
      <h3>Everywhere</h3>
      <dl class="controls"><dt><kbd>Esc</kbd></dt><dd>Pause</dd><dt><kbd>\`</kbd> / <kbd>F3</kbd></dt><dd>AI debug overlay</dd></dl>
      <h3>Reading the trial</h3>
      <ul class="tips"><li>Red streaks are scratch marks left by running survivors (killer only).</li><li>Yellow pings are loud noises: fast vaults, pallets, failed skill checks, traps, finished generators.</li><li>Aura reveals appear as arrows pointing to the target, never as x-ray.</li><li>Everyone only sees what their line of sight allows; walls cast shadows. As a survivor you get the heartbeat, not the killer's position.</li></ul>
      <button class="btn" data-back>Back</button></div>`, 'menu');
    this.click('[data-back]', () => this.main());
  }

  // ------------------------------------------------------------- story
  // Free selection: every scenario is playable. Filter by killer, difficulty tier,
  // survivor AI band and map; the detail panel shows the full setup.
  story(sel = null) {
    const prog = loadProgress(); const F = this.storyFilter;
    const list = STORY_LEVELS.filter((l) => (F.killer === 'all' || l.killer === F.killer) && (F.tier === 'all' || l.tier === F.tier) && (F.band === 'all' || l.band === +F.band) && (F.map === 'all' || l.map === F.map));
    const cur = sel || this._storySel || list[0] || STORY_LEVELS[0]; this._storySel = cur;
    const opt = (v, curv, label) => `<option value="${v}" ${String(v) === String(curv) ? 'selected' : ''}>${esc(label)}</option>`;
    const stars = (n) => '★'.repeat(n) + '<i>' + '★'.repeat(5 - n) + '</i>';
    const cards = list.map((l) => { const k = KILLERS[l.killer]; const best = prog.best[l.id]; const won = best !== undefined && best >= l.requiredKills;
      return `<button class="scard ${cur.id === l.id ? 'sel' : ''} ${won ? 'won' : ''}" data-lv="${l.id}" style="--kc:${k.accent}">
        <span class="sid">[${String(l.id).padStart(2, '0')}]</span><b>${esc(l.name)}</b>
        <span class="smeta">${esc(k.short)} · ${esc(MAP_LIST.find((m) => m.id === l.map)?.name.split(' ')[0] || '')}</span>
        <span class="sstars">${stars(l.stars)}</span><span class="stier t${DIFF_TIERS.indexOf(l.tier)}">${esc(l.tier)}</span>${won ? '<span class="sdone">✓</span>' : ''}</button>`; }).join('');
    const k = KILLERS[cur.killer]; const mp = MAP_LIST.find((x) => x.id === cur.map);
    const d = cur.survivorDifficulty; const best = prog.best[cur.id];
    const rules = Object.keys(cur.specialRules);
    this.show(`<div class="story-layout">
      <div class="story-list"><div class="row-head"><h2>Story Mode <small>${STORY_LEVELS.length} scenarios · all unlocked</small></h2><div class="row-actions"><button class="btn small primary" data-random title="Rolls killer, map, survivor skill, builds, items and rules (respects the killer, map and AI filters) and starts at once">Random scenario</button><button class="btn small" data-back>Back</button></div></div>
        <div class="filters">
          <label class="fld">Killer<select id="f-killer">${opt('all', F.killer, 'All killers')}${KILLER_LIST.map((x) => opt(x.id, F.killer, x.name)).join('')}</select></label>
          <label class="fld">Difficulty<select id="f-tier">${opt('all', F.tier, 'All')}${DIFF_TIERS.map((t) => opt(t, F.tier, t)).join('')}</select></label>
          <label class="fld">Survivor AI<select id="f-band">${opt('all', F.band, 'All')}${AI_BANDS.map((b, i) => opt(i, F.band, `${b[0]}–${b[1]} · ${DIFFICULTY_LABELS[b[1]]}`)).join('')}</select></label>
          <label class="fld">Map<select id="f-map">${opt('all', F.map, 'All maps')}${MAP_LIST.map((m) => opt(m.id, F.map, m.name)).join('')}</select></label>
          <span class="fcount">${list.length} shown</span>
        </div>
        <div class="sgrid">${cards || '<p class="note">No scenarios match these filters.</p>'}</div></div>
      <aside class="brief">
        <span class="cn">Scenario ${String(cur.id).padStart(2, '0')} · ${esc(cur.group)}</span><h2>${esc(cur.name)}</h2>
        <div class="kband" style="--kc:${k.accent}">${portrait(k)}<div><b>${esc(k.name)}</b><small>${esc(k.power)}</small></div></div>
        <p class="intro">${esc(cur.intro)}</p>
        <dl class="facts"><dt>Map</dt><dd>${esc(mp.name)}</dd>
          <dt>Survivors</dt><dd>${cur.survivorBots} bots</dd>
          <dt>Survivor AI</dt><dd>${d[0] === d[1] ? d[0] : d.join('–')} · ${DIFFICULTY_LABELS[d[1]]}</dd>
          ${cur.archetypes ? `<dt>Squad</dt><dd>${cur.archetypes.map((a) => ARCHETYPES[a]?.label || a).join(', ')}</dd>` : ''}
          <dt>Survivor perks</dt><dd>${PERK_MODE_LABEL[cur.survivorPerks] || cur.survivorPerks}</dd>
          <dt>Items</dt><dd>${cur.survivorItems === 'random' ? 'Random' : cur.survivorItems === 'none' ? 'None' : ITEMS[cur.survivorItems]?.name}</dd>
          <dt>Generators</dt><dd>${cur.generatorCount}</dd>
          <dt>Special rules</dt><dd>${rules.length ? rules.map(ruleName).join(', ') : 'None'}</dd>
          <dt>Goal</dt><dd>Kill at least ${cur.requiredKills}</dd>
          <dt>Recommended</dt><dd class="stars">${stars(cur.stars)} <small>${esc(cur.tier)}</small></dd>
          ${best !== undefined ? `<dt>Your best</dt><dd>${best} kill${best === 1 ? '' : 's'}${best >= cur.requiredKills ? ' · cleared' : ''}</dd>` : ''}</dl>
        <button class="btn primary" data-play="${cur.id}">Play scenario</button>
      </aside></div>`, 'menu story');
    this.click('[data-back]', () => this.main());
    this.click('[data-lv]', (e, b) => this.story(STORY_LEVELS.find((l) => l.id === +b.dataset.lv)));
    this.click('[data-play]', () => this.loadoutScreen({ story: cur }));
    this.click('[data-random]', () => {
      const ks = KILLER_LIST.filter((x) => x.unlocked && (F.killer === 'all' || x.id === F.killer)); const ms = MAP_LIST.filter((x) => F.map === 'all' || x.id === F.map);
      const lvl = randomScenario(ks, ms, F.band === 'all' ? null : AI_BANDS[+F.band]);
      const L = this.loadout; const perks = L.perks.filter((p) => KILLER_PERKS[p]);
      this.api.startStory(lvl, { perks, addons: [] });
    });
    for (const [id, key] of [['f-killer', 'killer'], ['f-tier', 'tier'], ['f-band', 'band'], ['f-map', 'map']]) $('#' + id, this.root).addEventListener('change', (e) => { F[key] = e.target.value; this._storySel = null; this.story(); });
  }

  // ------------------------------------------------------------- loadout
  loadoutScreen({ story = null, onDone = null, match = false, browse = false } = {}) {
    const L = this.loadout; if (story) L.killer = story.killer; const KM = this.kmatch;
    const kdef = KILLERS[L.killer];
    L.addons = L.addons.filter((a) => kdef.addons[a]); L.perks = L.perks.filter((p) => KILLER_PERKS[p]);
    const kcards = KILLER_LIST.map((k) => `<button class="kcard ${k.id === L.killer ? 'sel' : ''}" data-k="${k.id}" ${(story && story.killer !== k.id) || !k.unlocked ? 'disabled' : ''} style="--kc:${k.accent}">
      ${portrait(k)}<b>${esc(k.name)}</b><span class="pw">${esc(k.power)}</span><span class="cost">${k.unlocked ? (k.cost ? k.cost + ' ◈' : 'Unlocked · free') : 'Locked'}</span></button>`).join('');
    const cat = this.perkCat;
    const ids = KILLER_PERK_IDS.filter((id) => cat === 'all' || (cat === 'signature' ? kdef.signature.includes(id) : KILLER_PERKS[id].cat === cat));
    const perks = ids.map((id) => { const p = KILLER_PERKS[id]; const i = L.perks.indexOf(id); return `<button class="perk ${i >= 0 ? 'sel' : ''}" data-p="${id}" title="${esc(p.description)}"><span class="pd"><span>${p.icon}</span></span><b>${esc(p.name)}${kdef.signature.includes(id) ? ' <em>signature</em>' : ''}</b><small>${esc(p.description)}</small></button>`; }).join('');
    const addons = Object.entries(kdef.addons).map(([id, a]) => `<button class="addon ${L.addons.includes(id) ? 'sel' : ''}" data-a="${id}"><b>${esc(a.name)}</b><small>${esc(a.desc)}</small></button>`).join('');
    const prof = KILLER_PROFILES[kdef.id];
    const cats = [['all', 'All'], ['signature', 'Signature'], ...Object.entries(KILLER_PERK_CATEGORIES)];
    this.show(`<div class="panel wide loadout"><div class="row-head"><h2>${match ? 'Play as Killer' : browse ? 'Killer Selection' : 'Loadout'}</h2><div class="row-actions"><button class="btn small" data-back>Back</button><button class="btn primary" data-go>${browse ? 'Save' : 'Enter the trial'}</button></div></div>
      ${match ? `<div class="cgrid kmatch"><fieldset><legend>Survivor bots</legend><label class="fld">Survivors<select id="km-n">${[1, 2, 3, 4, 5].map((n) => `<option value="${n}" ${n === KM.survivorCount ? 'selected' : ''}>${n}</option>`).join('')}</select></label>${this.diffSlider('km-d', KM.survivorDifficulty, DIFFICULTY_LABELS, 'Survivor difficulty')}</fieldset>
        <fieldset class="span2"><legend>Map</legend>${this.mapPicker(KM.mapId, 'km-map')}</fieldset></div>` : ''}
      <h3>Killer <small>${KILLER_LIST.length} killers</small></h3><div class="kcards">${kcards}</div>
      <div class="kdetail" style="--kc:${kdef.accent}">${portrait(kdef, 'big')}<div>
        <h3>${esc(kdef.name)} <small>${esc(kdef.difficulty)} · speed ${kdef.speed} m/s · terror ${kdef.terror} m</small></h3>
        <p><b>${esc(kdef.power)}</b> — ${esc(kdef.powerDesc)}</p>
        <p class="sig">Signature perks: ${kdef.signature.map((p) => `<button class="chip ${L.perks.includes(p) ? 'on' : ''}" data-p="${p}">${esc(KILLER_PERKS[p].name)}</button>`).join(' ')}</p>
        ${kdef.powerData ? `<div class="pdata"><ul>${kdef.powerData.abilities.map((a) => `<li><kbd>${esc(a.key)}</kbd> <b>${esc(a.name)}</b> — ${esc(a.desc)}</li>`).join('')}</ul><p class="note">${Object.entries(kdef.powerData.cooldowns).map(([k, v]) => `${esc(k)}: ${esc(v)}`).join(' · ')}${kdef.powerData.statuses.length ? ' · statuses: ' + esc(kdef.powerData.statuses.join(', ')) : ''}</p></div>` : ''}
        ${prof ? `<p class="note">How survivors play against you: avoid ${esc(prof.avoid.join(', '))}; exploit ${esc(prof.exploit.join(', '))}.</p>` : ''}
      </div></div>
      <h3>Perks <small>${L.perks.length}/4 equipped · ${KILLER_PERK_IDS.length} in pool</small></h3>
      <div class="tabs">${cats.map(([c, l]) => `<button class="tab ${cat === c ? 'on' : ''}" data-cat="${c}">${esc(l)}</button>`).join('')}</div>
      <div class="perkgrid">${perks}</div>
      <h3>Add-ons <small>${L.addons.length}/2</small></h3><div class="addons">${addons}</div></div>`, 'menu');
    const again = () => this.loadoutScreen({ story, onDone, match, browse });
    if (match) {
      this.root.querySelectorAll('input[name=km-map]').forEach((i) => i.addEventListener('change', () => { KM.mapId = i.value; again(); }));
      $('#km-n', this.root).addEventListener('change', (e) => (KM.survivorCount = +e.target.value));
      this.bindSlider('km-d', DIFFICULTY_LABELS, (v) => (KM.survivorDifficulty = v));
    }
    this.click('[data-back]', () => (story ? this.story(story) : browse && onDone ? onDone(L) : match || browse ? this.main() : this.customScreen()));
    this.click('[data-k]', (e, b) => { L.killer = b.dataset.k; L.addons = []; again(); });
    this.click('[data-cat]', (e, b) => { this.perkCat = b.dataset.cat; again(); });
    this.click('[data-p]', (e, b) => { const id = b.dataset.p; const i = L.perks.indexOf(id); if (i >= 0) L.perks.splice(i, 1); else if (L.perks.length < 4) L.perks.push(id); again(); });
    this.click('[data-a]', (e, b) => { const id = b.dataset.a; const i = L.addons.indexOf(id); if (i >= 0) L.addons.splice(i, 1); else if (L.addons.length < 2) L.addons.push(id); again(); });
    this.click('[data-go]', () => {
      this.saveLoadout();
      if (story) this.api.startStory(story, L);
      else if (match) this.api.start({ playerRole: 'killer', mapId: this.pickMap(KM.mapId), killerId: L.killer, killerPerks: L.perks, killerAddons: L.addons, survivorCount: KM.survivorCount, difficulty: KM.survivorDifficulty });
      else if (onDone) onDone(L);
    });
  }

  // ------------------------------------------------------------- custom
  customScreen() {
    const C = this.custom, L = this.loadout;
    const opt = (v, cur, label) => `<option value="${v}" ${String(v) === String(cur ?? '') ? 'selected' : ''}>${esc(label)}</option>`;
    const mods = [['hardcoreHooks', 'Short hooks (40 s stages)'], ['bloodMoon', 'Blood Moon (faster bloodlust)'], ['heavyFog', 'Heavy fog (shorter sight)'], ['noHatch', 'No hatch'], ['startInjured', 'Survivors start injured']];
    const buildModes = [['', 'Team setting'], ['random', 'Random (weighted)'], ['basic', 'Basic'], ['strong', 'Strong'], ['meta', 'Meta build'], ...Object.keys(BUILD_THEMES).map((t) => [t, PERK_MODE_LABEL[t]]), ['none', 'No perks'], ['pick', 'Pick 4 perks…']];
    const spIds = Object.keys(SURVIVOR_PERKS).sort((a, b) => SURVIVOR_PERKS[a].name.localeCompare(SURVIVOR_PERKS[b].name));
    const rows = Array.from({ length: C.survivorCount }, (_, i) => {
      const S = C.surv[i]; const roster = SURVIVOR_ROSTER[i];
      const itemAddons = S.item && S.item !== 'none' && S.item !== 'random' ? Object.values(ITEM_ADDONS).filter((a) => a.item === S.item) : [];
      return `<div class="srow" data-i="${i}"><span class="sname"><span class="dot" style="--c:${roster.color}"></span>${esc(roster.name)}</span>
        <label class="fld mini">AI<select data-f="difficulty">${opt('', S.difficulty, 'team')}${[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((d) => opt(d, S.difficulty, d)).join('')}</select></label>
        <label class="fld mini">Personality<select data-f="archetype">${opt('', S.archetype, 'Random')}${Object.entries(ARCHETYPES).map(([k, a]) => opt(k, S.archetype, a.label)).join('')}</select></label>
        <label class="fld mini">Perks<select data-f="build">${buildModes.map(([v, l]) => opt(v, S.build, l)).join('')}</select></label>
        <label class="fld mini">Item<select data-f="item">${opt('', S.item, 'team')}${opt('random', S.item, 'Random')}${opt('none', S.item, 'None')}${Object.values(ITEMS).map((it) => opt(it.id, S.item, it.name)).join('')}</select></label>
        <label class="fld mini">Add-on<select data-f="addon" ${itemAddons.length ? '' : 'disabled'}>${opt('', S.addon, itemAddons.length ? 'None' : '—')}${itemAddons.map((a) => opt(a.id, S.addon, a.name)).join('')}</select></label>
        ${S.build === 'pick' ? `<div class="pick4">${[0, 1, 2, 3].map((j) => `<select data-pk="${j}">${opt('', S.perks[j], '— empty —')}${spIds.map((id) => opt(id, S.perks[j], `${SURVIVOR_PERKS[id].name} (${SURVIVOR_PERKS[id].cat})`)).join('')}</select>`).join('')}</div>` : ''}
      </div>`; }).join('');
    this.show(`<div class="panel wide custom"><div class="row-head"><h2>Custom Match</h2><div class="row-actions"><button class="btn small" data-back>Back</button><button class="btn primary" data-go>Loadout &amp; start</button></div></div>
      <div class="cgrid">
        <fieldset><legend>Map</legend>${MAP_LIST.map((mp) => `<label class="mapopt ${C.mapId === mp.id ? 'sel' : ''}"><input type="radio" name="map" id="map-${mp.id}" value="${mp.id}" ${C.mapId === mp.id ? 'checked' : ''}><b>${esc(mp.name)}</b><small>${esc(mp.blurb)}</small></label>`).join('')}</fieldset>
        <fieldset><legend>Team defaults</legend>
          <label class="fld">Survivor bots<select id="c-count">${[1, 2, 3, 4, 5].map((n) => opt(n, C.survivorCount, n)).join('')}</select></label>
          <label class="fld">Difficulty <output id="c-dlab">${C.difficulty} · ${DIFFICULTY_LABELS[C.difficulty]}</output><input type="range" id="c-diff" min="1" max="10" value="${C.difficulty}"></label>
          <label class="fld">Survivor perks<select id="c-perks">${buildModes.filter(([v]) => v && v !== 'pick').map(([v, l]) => opt(v, C.perkMode, l)).join('')}</select></label>
          <label class="fld">Survivor items<select id="c-items">${opt('random', C.itemMode, 'Random')}${opt('none', C.itemMode, 'None')}${Object.values(ITEMS).map((it) => opt(it.id, C.itemMode, 'All: ' + it.name)).join('')}</select></label>
          <label class="fld">Item add-ons<select id="c-addons">${opt('none', C.itemAddons, 'None')}${opt('random', C.itemAddons, 'Random add-on per item')}</select></label>
        </fieldset>
        <fieldset><legend>Rules</legend>
          <label class="fld">Generators to repair<select id="c-gens">${[1, 2, 3, 4, 5, 6, 7].map((n) => opt(n, C.gensRequired, n)).join('')}</select></label>
          <label class="fld">Hooks on map<select id="c-hooks">${[6, 9, 12, 15].map((n) => opt(n, C.hookCount, n)).join('')}</select></label>
          <label class="fld">Exit gates<select id="c-gates">${[1, 2, 3].map((n) => opt(n, C.gateCount, n)).join('')}</select></label>
          ${mods.map(([id, l]) => `<label class="chk"><input type="checkbox" id="m-${id}" ${C.modifiers[id] ? 'checked' : ''}> ${l}</label>`).join('')}
        </fieldset>
        <fieldset><legend>Killer</legend><div class="kband" style="--kc:${KILLERS[L.killer].accent}">${portrait(KILLERS[L.killer])}<div><b>${esc(KILLERS[L.killer].name)}</b><small>${L.perks.map((p) => KILLER_PERKS[p]?.name).filter(Boolean).join(' · ') || 'No perks'}</small></div></div><p class="note">Pick any killer, perks and add-ons on the next screen.</p></fieldset>
      </div>
      <fieldset class="survs"><legend>Survivors — set each bot individually (blank = team default)</legend>${rows}</fieldset></div>`, 'menu');
    const r = this.root;
    r.querySelectorAll('input[name=map]').forEach((i) => i.addEventListener('change', () => { C.mapId = i.value; this.customScreen(); }));
    $('#c-count', r).addEventListener('change', (e) => { C.survivorCount = +e.target.value; this.customScreen(); });
    $('#c-diff', r).addEventListener('input', (e) => { C.difficulty = +e.target.value; $('#c-dlab', r).textContent = `${C.difficulty} · ${DIFFICULTY_LABELS[C.difficulty]}`; });
    $('#c-perks', r).addEventListener('change', (e) => (C.perkMode = e.target.value));
    $('#c-items', r).addEventListener('change', (e) => (C.itemMode = e.target.value));
    $('#c-addons', r).addEventListener('change', (e) => (C.itemAddons = e.target.value));
    $('#c-gens', r).addEventListener('change', (e) => (C.gensRequired = +e.target.value));
    $('#c-hooks', r).addEventListener('change', (e) => (C.hookCount = +e.target.value));
    $('#c-gates', r).addEventListener('change', (e) => (C.gateCount = +e.target.value));
    for (const [id] of mods) $('#m-' + id, r).addEventListener('change', (e) => (C.modifiers[id] = e.target.checked));
    r.querySelectorAll('.srow').forEach((row) => {
      const S = C.surv[+row.dataset.i];
      row.querySelectorAll('[data-f]').forEach((sel) => sel.addEventListener('change', () => { const f = sel.dataset.f; S[f] = f === 'difficulty' ? (sel.value ? +sel.value : '') : sel.value; if (f === 'item') S.addon = ''; if (f === 'build' || f === 'item') this.customScreen(); }));
      row.querySelectorAll('[data-pk]').forEach((sel) => sel.addEventListener('change', () => { S.perks[+sel.dataset.pk] = sel.value; }));
    });
    this.click('[data-back]', () => this.main());
    this.click('[data-go]', () => this.loadoutScreen({ onDone: (Ld) => this.api.start({
      mapId: C.mapId, killerId: Ld.killer, killerPerks: Ld.perks, killerAddons: Ld.addons, survivorCount: C.survivorCount, difficulty: C.difficulty,
      perkMode: C.perkMode, itemMode: C.itemMode, itemAddons: C.itemAddons,
      survivors: Array.from({ length: C.survivorCount }, (_, i) => this.survivorCfg(C.surv[i])),
      gensRequired: C.gensRequired, gensOnMap: Math.min(9, C.gensRequired + 2), hookCount: C.hookCount, gateCount: C.gateCount, modifiers: { ...C.modifiers },
    }) }));
  }
  survivorCfg(S) {
    const C = this.custom; const out = { difficulty: S.difficulty || C.difficulty };
    if (S.archetype) out.archetype = S.archetype;
    if (S.build === 'pick') { const ps = [...new Set(S.perks.filter(Boolean))].slice(0, 4); out.perks = ps; } else if (S.build) out.perkMode = S.build;
    if (S.item) { out.item = S.item === 'none' ? null : S.item; if (S.addon) out.itemAddons = [S.addon]; }
    return out;
  }

  // ------------------------------------------------------------- results
  results(res, { story = null, passed = false, nextLevel = null } = {}) {
    const surv = res.playerRole === 'survivor', v8 = res.mode === '2v8';
    const rows = res.survivors.map((s) => `<tr class="${(s.isYou ?? s.isPlayer) ? 'me' : ''}"><td><span class="dot" style="--c:${s.color}"></span>${esc(s.name)}${(s.isYou ?? s.isPlayer) ? ' <em>(you)</em>' : ''}${s.cls ? ` <small>${esc(SURVIVOR_CLASSES[s.cls]?.name || s.cls)}</small>` : ''}</td><td class="${s.outcome.startsWith('Escaped') ? 'esc' : 'dead'}">${esc(s.outcome)}</td><td>${s.isPlayer ? 'Player' : `D${s.difficulty} · ${esc(s.archetype)}`}</td><td>${(s.stats.gens).toFixed(1)}</td><td>${s.stats.pallets}/${s.stats.stuns}</td><td>${s.stats.vaults}</td><td>${s.stats.unhooks}</td><td>${s.stats.heals}</td><td class="pk">${s.perks.map(esc).join(', ') || '—'}<br><small>${esc(s.item)}</small></td></tr>`).join('');
    const krows = res.killers.map((k) => `<tr><td><span class="dot" style="--c:${k.accent}"></span>${esc(k.name)}${k.cls ? ` <small>${esc(KILLER_CLASSES[k.cls]?.name || k.cls)}</small>` : ''}</td><td>${k.bot ? `Bot · ${k.difficulty} ${esc(KILLER_DIFFICULTY_LABELS[k.difficulty] || '')}` : 'Player'}</td><td>${k.stats.hits}</td><td>${k.stats.downs}</td><td>${k.stats.hooks}</td><td>${k.stats.kicks}</td><td>${k.stats.palletsBroken}</td><td>${k.stats.stuns}</td></tr>`).join('');
    const total = Object.values(res.score).reduce((a, b) => a + b, 0);
    const log = res.log.filter((l) => !/questionable/.test(l.text)).slice(-14).map((l) => `<li><time>${Math.floor(l.t / 60)}:${String(Math.floor(l.t % 60)).padStart(2, '0')}</time><b style="color:${l.color}">${esc(l.who)}</b> ${esc(l.text)}</li>`).join('');
    const me = res.player;
    const grade = surv ? (me && /Escaped/.test(me.outcome) ? 'You Escaped' : me && /Sacrificed|Killed|Fog/.test(me.outcome) ? (me.outcome === 'Sacrificed' ? 'Sacrificed' : 'Killed') : 'Trial over')
      : v8 ? (res.kills > res.total / 2 ? 'The Killers Win' : res.escapes > res.total / 2 ? 'The Survivors Win' : 'A Draw in the Fog') : res.grade;
    const tag = res.net ? `Multiplayer ${v8 ? '2v8' : '1v4'} · ${surv ? 'Survivor' : res.playerRole === 'killer' ? 'Killer' : 'Spectator'}` : v8 ? '2v8 · ' + (surv ? 'Survivor' : res.playerRole === 'killer' ? 'Killer A' : 'Spectator') : surv ? 'Play as Survivor' : story ? (story.random ? '' : 'Scenario ' + story.id + ' · ') + esc(story.name) : 'Custom trial';
    this.show(`<div class="panel wide results"><p class="kicker">${tag}</p>
      <h2 class="grade">${esc(grade)}</h2>
      <p class="tally"><b>${res.kills}</b> killed · <b>${res.escapes}</b> escaped of ${res.total} · ${Math.floor(res.time / 60)}:${String(Math.floor(res.time % 60)).padStart(2, '0')}${story ? ` · <span class="${passed ? 'pass' : 'fail'}">${passed ? 'Trial passed' : `Needed ${story.requiredKills} kills`}</span>` : ''}</p>
      ${surv ? '' : `<div class="scores">${Object.entries(res.score).map(([k, v]) => `<div class="sc ${k}"><span>${k}</span><b>${Math.round(v)}</b></div>`).join('')}<div class="sc total"><span>Bloodpoints</span><b>${Math.round(total)}</b></div></div>`}
      <h3>${res.killers.length > 1 ? 'Killers' : 'Killer'}</h3><div class="tblwrap"><table><thead><tr><th>Killer</th><th>Control</th><th>Hits</th><th>Downs</th><th>Hooks</th><th>Kicks</th><th>Pallets broken</th><th>Stunned</th></tr></thead><tbody>${krows}</tbody></table></div>
      <h3>Survivors</h3><div class="tblwrap"><table><thead><tr><th>Survivor</th><th>Outcome</th><th>Control</th><th>Gens</th><th>Pallets/stuns</th><th>Vaults</th><th>Rescues</th><th>Heals</th><th>Build</th></tr></thead><tbody>${rows}</tbody></table></div>
      <h3>${surv ? 'What your team was thinking' : 'What the survivors were thinking'}</h3><ul class="ailog">${log || '<li>No notable plays recorded.</li>'}</ul>
      <div class="row-actions">${res.net ? '<button class="btn primary" data-lobby>Back to the lobby</button>' : `<button class="btn" data-menu>Main menu</button><button class="btn" data-retry>Play again</button>`}${nextLevel ? `<button class="btn primary" data-next>Next trial</button>` : ''}</div></div>`, 'menu');
    this.click('[data-lobby]', () => this.mpRoom());
    this.click('[data-menu]', () => (story ? this.story(story) : this.main()));
    this.click('[data-retry]', () => this.api.retry());
    this.click('[data-next]', () => this.story(nextLevel));
  }

  pause(onResume, onQuit, settings) {
    this.show(`<div class="panel narrow pause"><h2>Paused</h2>
      <label class="fld">Zoom<input type="range" id="p-zoom" min="0.7" max="1.5" step="0.05" value="${settings.zoom}"></label>
      <label class="fld">Volume<input type="range" id="p-vol" min="0" max="1" step="0.05" value="${settings.volume}"></label>
      <label class="fld">Mouse wheel<select id="p-wheel"><option value="auto" ${settings.wheel === 'auto' ? 'selected' : ''}>Auto (spell select for the Lich, zoom otherwise)</option><option value="zoom" ${settings.wheel === 'zoom' ? 'selected' : ''}>Always zoom</option><option value="ability" ${settings.wheel === 'ability' ? 'selected' : ''}>Always select ability</option></select></label>
      <label class="chk"><input type="checkbox" id="p-dbg" ${settings.debug ? 'checked' : ''}> AI debug overlay</label>
      <div class="row-actions"><button class="btn" data-quit>Abandon trial</button><button class="btn primary" data-resume>Resume</button></div></div>`, 'menu overlay');
    $('#p-zoom', this.root).addEventListener('input', (e) => settings.onZoom(+e.target.value));
    $('#p-vol', this.root).addEventListener('input', (e) => settings.onVolume(+e.target.value));
    $('#p-dbg', this.root).addEventListener('change', (e) => settings.onDebug(e.target.checked));
    $('#p-wheel', this.root).addEventListener('change', (e) => settings.onWheel(e.target.value));
    this.click('[data-resume]', onResume); this.click('[data-quit]', onQuit);
  }

  lab() {
    this.show(`<div class="panel wide lab"><div class="row-head"><h2>AI Lab</h2><div class="row-actions"><button class="btn small" data-back>Back</button><button class="btn primary" data-run="ai">Survivor AI scenarios</button><button class="btn" data-run="mech">Killer power checks</button><button class="btn" data-run="modes">Mode checks (slow)</button></div></div>
      <p>Each check builds a real match (or a small test map), scripts the inputs and runs the real simulation. <b>Survivor AI scenarios</b>: the design-brief survivor decisions plus one per killer. <b>Killer power checks</b>: Trapper haste, the Cenobite chain regression, the Singularity and Cannibal reworks and the six new killers. <b>Mode checks</b>: a full Play-as-Survivor match through the player controller, killer-bot difficulty 1/5/10, both 2v8 configurations and killer coordination (takes a few minutes).</p>
      <ol class="labres" id="labres"></ol>
      <h3>Watch it live</h3><p>Start a spectator match (all bots) with the debug overlay: killer bot cards show its state, goal and alternatives.</p>
      <div class="row-actions"><button class="btn" data-spec="3">Spectate difficulty 3</button><button class="btn" data-spec="10">Spectate difficulty 10</button><button class="btn" data-spec2v8>Spectate 2v8</button></div></div>`, 'menu');
    this.click('[data-back]', () => this.main());
    this.click('[data-spec]', (e, b) => this.api.spectate(+b.dataset.spec));
    this.click('[data-spec2v8]', () => this.api.start(config2v8({ role: 'spectate', killerA: this.v8.killerA, killerB: this.v8.killerB, mapId: this.pickMap(this.v8.mapId) })));
    this.click('[data-run]', async (e, b) => {
      const ol = $('#labres', this.root); ol.innerHTML = '<li>Running…</li>';
      const which = b.dataset.run;
      const list = which === 'ai' ? (await import('../tests/aiScenarios.js')).SCENARIOS : which === 'mech' ? (await import('../tests/mechanics.js')).MECH_TESTS : (await import('../tests/modes.js')).MODE_TESTS.filter((t) => t.id !== 'I1');
      ol.innerHTML = '';
      for (const sc of list) {
        ol.insertAdjacentHTML('beforeend', `<li class="run"><b>…</b> <span>${esc(sc.name)}</span></li>`); await new Promise((r) => setTimeout(r, 40));
        let r; try { r = sc.run(); } catch (err) { r = { pass: false, detail: 'error: ' + err.message }; }
        ol.lastElementChild.outerHTML = `<li class="${r.pass ? 'pass' : 'fail'}"><b>${r.pass ? 'PASS' : 'FAIL'}</b> <span>${esc(sc.name)}</span><small>${sc.expect ? 'Expected: ' + esc(sc.expect) + '<br>' : ''}Result: ${esc(r.detail)}</small></li>`;
      }
    });
  }
}
// Killer portrait: an original emblem built from the killer's colours and a power glyph.
const GLYPH = { trapper: '⨯', hillbilly: '⚙', wraith: '♪', ghostface: '☾', clown: '⚗', executioner: '⚖', singularity: '◈', huntress: '⟋', legion: '✂', hag: '☊', cannibal: '⚒', deathslinger: '➶', dredge: '▥', knight: '⚑', cenobite: '⛓', mastermind: '☣', houndmaster: '❦', lich: '✋', skull_merchant: '⌖', blight: '☄', nurse: '✚', unknown: '◉', nemesis: '☢', ghoul: '❖' };
export function portrait(k, cls = '') {
  return `<span class="kport ${cls}" style="--kc:${k.accent};--kb:${k.color}" aria-hidden="true"><span class="kp-hood"></span><span class="kp-eyes"></span><span class="kp-glyph">${GLYPH[k.id] || k.short[0]}</span></span>`;
}
export function ruleName(id) { return { hardcoreHooks: 'Short hooks', bloodMoon: 'Blood Moon', heavyFog: 'Heavy fog', noHatch: 'No hatch', startInjured: 'Start injured' }[id] || id; }
