// Killer HUD (DOM overlay). Layout follows the original game's structure:
// survivor status column + generators bottom-left, power and perk diamond bottom-right,
// score events on the left, objective text at the top.
import { fmtTime } from '../core/util.js';
import { ALL_PERKS } from '../perks/perkSystem.js';
import { STATUS_DEFS } from '../core/status.js';

const STATE_ICON = {
  healthy: { icon: '◯', label: 'Alive', cls: 'ok' }, injured: { icon: '◐', label: 'Injured', cls: 'inj' }, dying: { icon: '✚', label: 'Dying', cls: 'dying' },
  carried: { icon: '⇡', label: 'Carried', cls: 'dying' }, hooked: { icon: '⚓', label: 'Hooked', cls: 'hook' }, dead: { icon: '✕', label: 'Dead', cls: 'dead' }, escaped: { icon: '⇥', label: 'Escaped', cls: 'esc' },
};

export class HUD {
  constructor(root) { this.root = root; this.t = 0; this.built = null; }
  build(m) {
    const k = m.killer;
    this.root.innerHTML = `
      <div class="hud-top"><div class="obj" id="hud-obj"></div><div class="collapse" id="hud-collapse" hidden><div class="bar"><i id="hud-collapse-bar"></i></div><span id="hud-collapse-t"></span></div></div>
      <div class="hud-feed" id="hud-feed"></div>
      <div class="hud-notify" id="hud-notify"></div>
      <div class="hud-bl">
        <div class="gens"><span class="gen-ico" aria-hidden="true"></span><b id="hud-gens">5</b><small>generators</small></div>
        ${m.killers.length > 1 ? `<div class="partner" id="hud-partner"></div>` : ''}
        <ul class="survs ${m.survivors.length > 5 ? 'many' : ''}" id="hud-survs">${m.survivors.map((s, i) => `
          <li id="hs-${i}" class="ok"><span class="port" style="--c:${s.color}">${s.name[0]}</span><span class="st"></span>
          <span class="pips"><i></i><i></i></span><span class="hbar"><i></i></span><span class="nm">${s.name}${s.cls ? ` <em>${s.cls}</em>` : ''}</span></li>`).join('')}</ul>
      </div>
      <div class="hud-br">
        <div class="power"><div class="ring"><svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="27" class="bg"/><circle id="hud-ring" cx="32" cy="32" r="27" class="fg" pathLength="100" stroke-dasharray="100 100" stroke-dashoffset="0"/></svg><b id="hud-pv"></b></div>
          <div class="pinfo"><span class="ptitle" id="hud-pt"></span><span class="pstate" id="hud-ps"></span><span class="bl" id="hud-bl"></span></div></div>
        <div class="perks" id="hud-perks">${[0, 1, 2, 3].map((i) => { const p = k.perks[i]; return `<div class="pd p${i} ${p ? '' : 'empty'}" title="${p ? p.def.name + ' — ' + p.def.description : 'Empty perk slot'}"><span>${p ? p.def.icon : ''}</span></div>`; }).join('')}</div>
        <div class="spells" id="hud-spells" hidden></div>
        <div class="kstat" id="hud-kstat"></div>
        <div class="keys" id="hud-keys"></div>
      </div>
      <div class="hud-prompt" id="hud-prompt" hidden><kbd id="hud-pk">SPACE</kbd><span id="hud-pl"></span><div class="pbar"><i id="hud-pb"></i></div></div>
      <div class="hud-carry" id="hud-carry" hidden><span>Wiggle</span><div class="pbar"><i id="hud-cb"></i></div></div>
      <div class="hud-whispers" id="hud-wh" hidden>≋</div>
      <div class="hud-intro" id="hud-intro"></div>`;
    this.el = (id) => this.root.querySelector('#' + id);
    const keys = k.power.hud(m).hints.map(([a, b]) => `<span><kbd>${a}</kbd>${b}</span>`).join('');
    this.el('hud-keys').innerHTML = `<span><kbd>LMB</kbd>Attack</span>${keys}<span><kbd>SPACE</kbd>Interact</span>`;
    this.built = m;
  }
  update(m, dt, ctx) {
    if (this.built !== m) this.build(m);
    const k = m.killer, el = this.el;
    // prompt every frame
    const pr = el('hud-prompt');
    let prompt = null;
    if (k.action) prompt = { key: '', label: k.action.label, prog: k.action.t / k.action.dur };
    else if (k.power.setting) prompt = { key: 'Q', label: 'Setting trap', prog: k.power.setting.t / k.power.setTime };
    else if (k.power.picking) prompt = { key: 'E', label: 'Picking up trap', prog: k.power.picking.t };
    else if (ctx) prompt = { key: 'SPACE', label: ctx.label, prog: null };
    else { const pp = k.power.prompt?.(m); if (pp) prompt = { key: pp.key, label: pp.label, prog: null }; else if (k.carrying) prompt = { key: 'Q', label: 'Drop survivor', prog: null }; }
    pr.hidden = !prompt;
    if (prompt) { el('hud-pk').textContent = prompt.key; el('hud-pk').hidden = !prompt.key; el('hud-pl').textContent = prompt.label; el('hud-pb').parentElement.hidden = prompt.prog === null; if (prompt.prog !== null) el('hud-pb').style.width = Math.min(100, prompt.prog * 100) + '%'; }
    const car = el('hud-carry'); car.hidden = !k.carrying; if (k.carrying) el('hud-cb').style.width = Math.min(100, k.carrying.wiggle * 100) + '%';
    // intro banner
    const intro = el('hud-intro');
    if (m.state === 'MATCH_START') { intro.hidden = false; intro.innerHTML = `<b>${m.map.name}</b><span>${m.survivors.length} survivors · ${m.gensNeeded} generators to stop</span>`; }
    else intro.hidden = true;
    this.t -= dt; if (this.t > 0) return; this.t = 0.1;
    // objective
    const left = Math.max(0, m.gensNeeded - m.gensDone);
    el('hud-gens').textContent = m.gatesPowered ? '0' : left;
    let obj = 'Hook the survivors before the generators are repaired';
    if (m.collapse) obj = 'Endgame Collapse — stop them from leaving';
    else if (m.gatesPowered) obj = 'The exit gates are powered';
    else if (m.hatch.state === 'open') obj = 'The hatch is open';
    el('hud-obj').textContent = obj;
    const col = el('hud-collapse'); col.hidden = !m.collapse;
    if (m.collapse) { el('hud-collapse-bar').style.width = (m.collapseT / 120 * 100) + '%'; el('hud-collapse-t').textContent = fmtTime(m.collapseT); }
    // survivors
    m.survivors.forEach((s, i) => {
      const li = el('hs-' + i); const st = STATE_ICON[s.health] || STATE_ICON.healthy;
      li.className = st.cls + (s.trap ? ' trapped' : '') + (m.inChase(s) ? ' chased' : '');
      li.querySelector('.st').textContent = s.trap ? '⊗' : st.icon; li.querySelector('.st').title = s.trap ? 'Trapped' : st.label;
      const pips = li.querySelectorAll('.pips i'); pips[0].className = s.hookStage >= 1 ? 'on' : ''; pips[1].className = s.hookStage >= 2 ? 'on' : '';
      const hb = li.querySelector('.hbar'); hb.hidden = s.health !== 'hooked';
      if (s.health === 'hooked') hb.firstElementChild.style.width = (100 - s.hookTimer / m.hookStageTime * 100) + '%';
    });
    // 2v8 partner killer (bot): what it is doing, shared through the killer team
    const pe = el('hud-partner');
    if (pe) { const o = m.killers.find((q) => q !== k); const st = o.bot ? o.bot.state.toLowerCase().replace(/_/g, ' ') : ''; const tg = o.bot?.goal?.target; pe.innerHTML = `<b style="color:${o.def.accent}">${o.def.short}</b>${o.cls ? ` <em>${o.cls}</em>` : ''} · ${o.carrying ? 'carrying ' + o.carrying.name : st}${tg?.name && o.bot?.goal?.type === 'CHASE' ? ' ' + tg.name : ''}`; }
    // power
    const ph = k.power.hud(m);
    const hk = ph.hints.map((h) => h.join(':')).join('|');
    if (hk !== this._hk) { this._hk = hk; el('hud-keys').innerHTML = `<span><kbd>LMB</kbd>Attack</span>${ph.hints.map(([a, b]) => `<span><kbd>${a}</kbd>${b}</span>`).join('')}<span><kbd>SPACE</kbd>Interact</span>`; }
    el('hud-pt').textContent = ph.title; el('hud-pv').textContent = ph.value; el('hud-ps').textContent = ph.state;
    el('hud-ring').setAttribute('stroke-dashoffset', String(100 - Math.max(0, Math.min(1, ph.meter)) * 100));
    const sp = el('hud-spells'); sp.hidden = !ph.spells;
    if (ph.spells) sp.innerHTML = `<div class="sw">${ph.spells.map((q, i) => `<div class="sp s${i} ${i === ph.sel ? 'on' : ''} ${q.cd > 0 ? 'cd' : ''}" title="${q.name}"><span class="si">${q.icon}</span><kbd>${i + 1}</kbd>${q.cd > 0 ? `<em>${Math.ceil(q.cd)}</em>` : ''}</div>`).join('')}<div class="sc">${ph.spells[ph.sel].name}</div></div>`;
    el('hud-bl').textContent = k.bloodlust ? 'Bloodlust ' + 'I'.repeat(k.bloodlust) : k.stunT > 0 ? 'Stunned' : k.attack.state === 'hit' ? 'Wiping blade' : k.attack.state === 'miss' ? 'Missed' : '';
    // statuses on the killer (Haste from Trapper's traps, Undetectable, Blindness…)
    el('hud-kstat').innerHTML = k.status.list.filter((q) => STATUS_DEFS[q.id]).map((q) => `<span class="${STATUS_DEFS[q.id].kind}">${STATUS_DEFS[q.id].name}${isFinite(q.expiration) && q.expiration < 900 ? ' ' + Math.ceil(q.expiration) + 's' : ''}</span>`).join('');
    // perks: active glow
    k.perks.forEach((p, i) => { const d = this.root.querySelector('.pd.p' + i); if (!d) return; d.classList.toggle('active', !!p.active || m.time - p.lastProc < 2); });
    el('hud-wh').hidden = !(k.hasPerk('whispers') && m.survivors.some((s) => s.standing && Math.hypot(s.x - k.x, s.y - k.y) < 48 * 32));
    // feed
    el('hud-feed').innerHTML = m.feed.filter((f) => m.time - f.t < 4).map((f) => `<div class="fe ${f.cat}" style="opacity:${Math.min(1, 4 - (m.time - f.t))}"><b>+${f.pts}</b><span>${f.label}</span><em>${f.cat}</em></div>`).join('');
    el('hud-notify').innerHTML = m.notify.filter((n) => m.time - n.t < 5).map((n) => `<div style="color:${n.color};opacity:${Math.min(1, 5 - (m.time - n.t))}">${n.text}</div>`).join('');
  }
}
export { STATE_ICON };
