// Top-down canvas renderer. The killer sees what a killer could see: line-of-sight
// shadows from walls, scratch marks, blood, grunts, loud-noise pings, and aura reveals
// drawn as arrows (never as x-ray silhouettes through the map).
import { M, dist, clamp, mulberry32, angleDiff } from '../core/util.js';

const CHUNK = 512;
const TAU = Math.PI * 2;

export class Renderer {
  constructor(canvas) {
    this.canvas = canvas; this.ctx = canvas.getContext('2d');
    this.chunks = new Map(); this.grassChunks = new Map(); this.map = null; this.dpr = 1; this.t = 0;
    this.debug = { on: false, nav: false, graph: false, belief: true, paths: true, xray: false, fields: false };
  }
  resize(w, h) {
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    this.canvas.width = Math.floor(w * this.dpr); this.canvas.height = Math.floor(h * this.dpr);
    this.canvas.style.width = w + 'px'; this.canvas.style.height = h + 'px';
    this.w = w; this.h = h;
  }
  setMap(map) { this.map = map; this.chunks.clear(); this.grassChunks.clear(); }

  // ---------------------------------------------------------------- static layers
  chunk(cx, cy) {
    const key = cx + ',' + cy; let c = this.chunks.get(key); if (c) return c;
    const map = this.map, th = map.theme;
    c = document.createElement('canvas'); c.width = CHUNK; c.height = CHUNK; const g = c.getContext('2d');
    const ox = cx * CHUNK, oy = cy * CHUNK;
    g.fillStyle = th.ground; g.fillRect(0, 0, CHUNK, CHUNK);
    const rng = mulberry32((cx * 73856093) ^ (cy * 19349663) ^ map.seed);
    // soil patches
    for (let i = 0; i < 26; i++) { g.fillStyle = th.ground2; g.globalAlpha = 0.5; g.beginPath(); g.ellipse(rng() * CHUNK, rng() * CHUNK, 20 + rng() * 70, 14 + rng() * 40, rng() * 3, 0, TAU); g.fill(); }
    g.globalAlpha = 1;
    for (let i = 0; i < 520; i++) { g.fillStyle = rng() < 0.5 ? th.speck : th.ground2; g.fillRect(rng() * CHUNK, rng() * CHUNK, 1 + rng() * 2.5, 1 + rng() * 2.5); }
    // tiny pebbles / leaves
    for (let i = 0; i < 40; i++) { g.fillStyle = 'rgba(255,255,255,0.03)'; g.beginPath(); g.arc(rng() * CHUNK, rng() * CHUNK, 1.5 + rng() * 3, 0, TAU); g.fill(); }
    // grass base tint under tufts
    g.fillStyle = th.grass; g.globalAlpha = 0.35;
    for (const gc of map.grassCells) { const x = gc.x * M - ox, y = gc.y * M - oy; if (x < -M || y < -M || x > CHUNK + M || y > CHUNK + M) continue; g.fillRect(x - M / 2, y - M / 2, M, M); }
    g.globalAlpha = 1;
    this.chunks.set(key, c); return c;
  }
  grassChunk(cx, cy) {
    const key = cx + ',' + cy; let c = this.grassChunks.get(key); if (c !== undefined) return c;
    const map = this.map, th = map.theme; const ox = cx * CHUNK, oy = cy * CHUNK;
    const cells = map.grassCells.filter((gc) => { const x = gc.x * M - ox, y = gc.y * M - oy; return x > -M && y > -M && x < CHUNK + M && y < CHUNK + M; });
    if (!cells.length) { this.grassChunks.set(key, null); return null; }
    c = document.createElement('canvas'); c.width = CHUNK; c.height = CHUNK; const g = c.getContext('2d');
    const rng = mulberry32((cx * 92821) ^ (cy * 68917) ^ 7);
    g.lineCap = 'round';
    for (const gc of cells) {
      const x = gc.x * M - ox, y = gc.y * M - oy;
      for (let k = 0; k < 7; k++) {
        const bx = x + (rng() - 0.5) * M, by = y + (rng() - 0.5) * M; const a = -Math.PI / 2 + (rng() - 0.5) * 1.2, l = 7 + rng() * 10;
        g.strokeStyle = rng() < 0.5 ? th.grass : shade(th.grass, 1.35); g.lineWidth = 2 + rng() * 1.5;
        g.beginPath(); g.moveTo(bx, by + 4); g.lineTo(bx + Math.cos(a) * l, by + Math.sin(a) * l); g.stroke();
      }
    }
    this.grassChunks.set(key, c); return c;
  }

  // ---------------------------------------------------------------- frame
  // The renderer always draws from one "eye": the player's killer, the player's survivor or a
  // spectated entity. Visibility, shadows, fog and HUD-like indicators follow that eye.
  draw(m, cam, opts = {}) {
    const ctx = this.ctx, map = m.map, th = map.theme; this.t += 1 / 60;
    let eye = opts.viewer || m.player || m.killer; this.eyeK = eye.kind === 'killer';
    // remote viewpoints (Singularity biopod control, …): sight lines start at the device
    const vp = this.eyeK && eye.power?.viewPoint?.(m); if (vp) { eye = Object.create(eye); eye.x = vp.x; eye.y = vp.y; }
    this.eye = eye;
    if (this.map !== map) this.setMap(map);
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.fillStyle = th.border; ctx.fillRect(0, 0, this.w, this.h);
    ctx.save();
    ctx.translate(this.w / 2 + cam.shakeX, this.h / 2 + cam.shakeY); ctx.scale(cam.zoom, cam.zoom); ctx.translate(-cam.x, -cam.y);
    // ground chunks
    const c0 = Math.max(0, Math.floor(cam.left / CHUNK)), c1 = Math.floor(cam.right / CHUNK), r0 = Math.max(0, Math.floor(cam.top / CHUNK)), r1 = Math.floor(cam.bottom / CHUNK);
    for (let cy = r0; cy <= r1; cy++) for (let cx = c0; cx <= c1; cx++) { if (cx * CHUNK >= map.w || cy * CHUNK >= map.h) continue; ctx.drawImage(this.chunk(cx, cy), cx * CHUNK, cy * CHUNK); }
    this.drawDecals(m, cam);
    this.drawObjects(m, cam);
    if (this.debug.on && this.debug.nav) this.drawNav(m, cam);
    // visibility
    const vis = this.visibleSet(m);
    this.drawSurvivors(m, cam, vis, true);
    for (const k of m.killers) { if (vis.killers.has(k)) this.drawKiller(m, k); else k.power.drawOver?.(ctx, m, this); } // telegraphs (chains, waves…) stay visible
    for (const n of m.minions) {
      if (!cam.inView(n.x, n.y, 60)) continue;
      if (!this.eyeK && !(this.debug.on && this.debug.xray) && (dist(n.x, n.y, eye.x, eye.y) > 24 * M || !m.world.losClear(eye.x, eye.y, n.x, n.y))) continue;
      const owner = m.killers.find((k) => k === n.owner) || m.killer;
      if (!owner.power.drawMinion?.(ctx, n, m, this)) drawMinionDefault(ctx, n);
    }
    this.drawSurvivors(m, cam, vis, false);
    // grass overlay hides crouched survivors a bit
    ctx.globalAlpha = 0.85;
    for (let cy = r0; cy <= r1; cy++) for (let cx = c0; cx <= c1; cx++) { if (cx * CHUNK >= map.w || cy * CHUNK >= map.h) continue; const gch = this.grassChunk(cx, cy); if (gch) ctx.drawImage(gch, cx * CHUNK, cy * CHUNK); }
    ctx.globalAlpha = 1;
    this.drawShadows(m, cam);
    this.drawWalls(m, cam);
    this.drawCanopies(m, cam);
    this.drawFX(m);
    if (this.debug.on) this.drawDebugWorld(m, cam);
    ctx.restore();
    this.drawFog(m, cam);
    this.drawScreenFX(m, cam);
    this.drawIndicators(m, cam, vis);
  }

  visibleSet(m) {
    const e = this.eye, set = new Set(); set.killers = new Set();
    const xray = this.debug.on && this.debug.xray;
    let range = (m.cfg.modifiers.heavyFog ? 18 : 30) * M;
    if (!this.eyeK && m.nightfallFor?.(e)) range = 7 * M;
    for (const s of m.survivors) {
      if (!s.alive) continue;
      if (s === e || xray) { set.add(s); continue; }
      if (s.health === 'carried' || s.health === 'hooked') { set.add(s); continue; }
      const d = dist(e.x, e.y, s.x, s.y);
      if (d < 2.2 * M) { set.add(s); continue; }
      if (d > range) continue;
      if (!m.world.losClear(e.x, e.y, s.x, s.y)) continue;
      if (this.eyeK && e.blindT > 0 && d > 4 * M) continue;
      if (this.eyeK && s.moveMode === 'crouch' && m.map.isGrass(s.x, s.y) && d > 5 * M && !s.action) continue;
      set.add(s);
    }
    for (const k of m.killers) {
      if (k === e || this.eyeK || xray) { set.killers.add(k); continue; }
      const d = dist(e.x, e.y, k.x, k.y); const vis = k.power.visibilityTo?.(e, m) ?? 1;
      if (d < 2.2 * M || (d < range * Math.max(0.25, vis) && m.world.losClear(e.x, e.y, k.x, k.y))) set.killers.add(k);
    }
    return set;
  }

  drawDecals(m, cam) {
    const ctx = this.ctx, t = m.time;
    // blood
    if (this.eyeK || this.debug.xray) for (const b of m.blood) { if (!cam.inView(b.x, b.y)) continue; const a = 1 - (t - b.t) / 12; ctx.fillStyle = `rgba(110,8,16,${0.8 * a})`; ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, TAU); ctx.fill(); }
    // scratch marks (killer-only tracking information)
    ctx.lineCap = 'round';
    for (const s of (this.eyeK || this.debug.xray ? m.scratches : [])) {
      if (!cam.inView(s.x, s.y)) continue; const a = clamp(1 - (t - s.t) / 7, 0, 1);
      ctx.strokeStyle = `rgba(214,74,40,${0.75 * a})`; ctx.lineWidth = 2.2;
      const c = Math.cos(s.a), sn = Math.sin(s.a);
      ctx.beginPath(); ctx.moveTo(s.x - c * 7, s.y - sn * 7); ctx.lineTo(s.x + c * 7, s.y + sn * 7); ctx.moveTo(s.x - c * 4 + sn * 4, s.y - sn * 4 - c * 4); ctx.lineTo(s.x + c * 5 + sn * 4, s.y + sn * 5 - c * 4); ctx.stroke();
    }
    // traps
    for (const tr of m.traps) {
      if (!cam.inView(tr.x, tr.y)) continue;
      drawTrap(ctx, tr.x, tr.y, tr.state, this.t);
    }
    // area zones (gas, torment trails…)
    for (const z of m.zones) {
      if (!cam.inView(z.x, z.y, z.r + 20)) continue;
      const life = Math.min(1, (z.until - m.time) / 1.5), armed = z.armed(m);
      ctx.globalAlpha = life * (armed ? 1 : 0.45); ctx.fillStyle = z.color;
      if (z.kind === 'tonic' || z.kind === 'antidote') {
        for (let i = 0; i < 6; i++) { const a = i * 1.05 + m.time * 0.4 + z.x; ctx.beginPath(); ctx.arc(z.x + Math.cos(a) * z.r * 0.4, z.y + Math.sin(a) * z.r * 0.4, z.r * 0.62, 0, TAU); ctx.fill(); }
      } else { ctx.beginPath(); ctx.arc(z.x, z.y, z.r, 0, TAU); ctx.fill(); }
      ctx.globalAlpha = 1;
    }
    // devices (pods, lockers, printers)
    for (const d of m.devices) {
      if (!cam.inView(d.x, d.y, 40)) continue;
      if (d.kind === 'biopod' || d.kind === 'printer') { for (const k of m.killers) k.power.drawDevice?.(ctx, d, m, this); }
      else if (d.kind === 'locker') {
        ctx.fillStyle = '#3d4248'; ctx.fillRect(d.x - 12, d.y - 16, 24, 32); ctx.strokeStyle = '#6a7078'; ctx.lineWidth = 2; ctx.strokeRect(d.x - 12, d.y - 16, 24, 32);
        ctx.beginPath(); ctx.moveTo(d.x, d.y - 16); ctx.lineTo(d.x, d.y + 16); ctx.stroke();
      } else {
        // survivors only notice hidden devices (Phantasm traps…) up close
        if (!this.eyeK && d.hiddenFromSurvivors && dist(d.x, d.y, this.eye.x, this.eye.y) > (d.seenRange || 6 * M)) continue;
        for (const k of m.killers) k.power.drawDevice?.(ctx, d, m, this);
      }
    }
    for (const k of m.killers) k.power.drawGround?.(ctx, m, this);
  }

  drawObjects(m, cam) {
    const ctx = this.ctx, map = m.map, k = this.eye;
    // exit gates
    for (const g of map.gates) {
      const d = g.doorRect, e = g.exitRect;
      ctx.fillStyle = g.open ? 'rgba(230,220,180,0.10)' : 'rgba(0,0,0,0.3)'; ctx.fillRect(e.x, e.y, e.w, e.h);
      if (!g.open) { ctx.fillStyle = g.powered ? '#7a6a40' : '#3b3d40'; ctx.fillRect(d.x, d.y, d.w, d.h); }
      // switch box
      ctx.fillStyle = '#2c2e31'; ctx.fillRect(g.x - 9, g.y - 9, 18, 18); ctx.strokeStyle = g.powered ? '#e3a14a' : '#55585c'; ctx.lineWidth = 2; ctx.strokeRect(g.x - 9, g.y - 9, 18, 18);
      if (g.powered) { const lights = Math.floor(g.progress / 20 * 3 + (g.open ? 3 : 0)); for (let i = 0; i < 3; i++) { ctx.fillStyle = i < lights ? '#ff3b30' : '#401010'; ctx.fillRect(g.x - 7 + i * 5.5, g.y - 15, 4, 4); } }
      if (g.open) { ctx.fillStyle = 'rgba(255,240,200,0.12)'; ctx.beginPath(); ctx.arc(e.x + e.w / 2, e.y + e.h / 2, 60, 0, TAU); ctx.fill(); }
    }
    // hatch
    const h = map.hatch;
    if (h.state === 'open' || h.state === 'closed' || h.state === 'shut') {
      ctx.fillStyle = '#16171a'; ctx.fillRect(h.x - 14, h.y - 14, 28, 28); ctx.strokeStyle = h.state === 'open' ? '#9fd0d0' : '#4a4f55'; ctx.lineWidth = 3; ctx.strokeRect(h.x - 14, h.y - 14, 28, 28);
      if (h.state === 'open') { ctx.fillStyle = 'rgba(160,210,210,0.25)'; ctx.beginPath(); ctx.arc(h.x, h.y, 26 + Math.sin(this.t * 3) * 3, 0, TAU); ctx.fill(); }
    }
    // totems
    for (const t of map.totems) {
      if (!cam.inView(t.x, t.y) || t.cleansed) { if (t.cleansed && cam.inView(t.x, t.y)) { ctx.fillStyle = '#3a3530'; ctx.beginPath(); ctx.arc(t.x, t.y, 6, 0, TAU); ctx.fill(); } continue; }
      ctx.fillStyle = '#5b5248'; ctx.beginPath(); ctx.arc(t.x, t.y, 9, 0, TAU); ctx.fill();
      ctx.fillStyle = '#d8d0c0'; ctx.beginPath(); ctx.arc(t.x, t.y - 2, 5, 0, TAU); ctx.fill();
      ctx.fillStyle = '#1a1714'; ctx.fillRect(t.x - 3, t.y - 3, 2, 2); ctx.fillRect(t.x + 1, t.y - 3, 2, 2);
      if (t.hex) { for (let i = 0; i < 3; i++) { const a = i * 2.1 + this.t; const fx = t.x + Math.cos(a) * 12, fy = t.y + Math.sin(a) * 12; ctx.fillStyle = `rgba(255,${150 + Math.random() * 60 | 0},60,0.9)`; ctx.beginPath(); ctx.arc(fx, fy, 2.5 + Math.random(), 0, TAU); ctx.fill(); } }
    }
    // chests
    for (const c of map.chests) {
      if (!cam.inView(c.x, c.y)) continue;
      ctx.fillStyle = c.opened ? '#3e3226' : '#6a4f2e'; ctx.fillRect(c.x - 13, c.y - 9, 26, 18); ctx.strokeStyle = '#2a2016'; ctx.lineWidth = 2; ctx.strokeRect(c.x - 13, c.y - 9, 26, 18);
      ctx.fillStyle = '#b39352'; ctx.fillRect(c.x - 2, c.y - 3, 4, 6);
    }
    // hooks
    for (const hk of map.hooks) {
      if (!cam.inView(hk.x, hk.y)) continue;
      ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(hk.x + 4, hk.y + 6, 13, 8, 0, 0, TAU); ctx.fill();
      ctx.strokeStyle = '#8d8f93'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(hk.x, hk.y + 10); ctx.lineTo(hk.x, hk.y - 12); ctx.stroke();
      ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(hk.x + 6, hk.y - 12, 6, Math.PI, Math.PI * 2.2); ctx.stroke();
      ctx.fillStyle = '#4a3a2c'; ctx.beginPath(); ctx.arc(hk.x, hk.y + 10, 6, 0, TAU); ctx.fill();
      if (hk.cage && hk.survivor) { ctx.strokeStyle = '#e2683c'; ctx.lineWidth = 2; ctx.strokeRect(hk.x - 16, hk.y - 18, 32, 34); for (let x = -10; x <= 10; x += 7) { ctx.beginPath(); ctx.moveTo(hk.x + x, hk.y - 18); ctx.lineTo(hk.x + x, hk.y + 16); ctx.stroke(); } }
    }
    // pallets
    for (const p of map.pallets) { if (!cam.inView(p.x, p.y)) continue; drawPallet(ctx, p); }
    // generators
    for (const g of map.gens) {
      if (!cam.inView(g.x, g.y)) continue;
      const s = 1.4 * M; const shake = g.repairers.size ? (Math.random() - 0.5) * 1.6 : 0;
      ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.fillRect(g.x - s / 2 + 5, g.y - s / 2 + 6, s, s);
      ctx.fillStyle = g.done ? '#4a4a3a' : '#3d4146'; ctx.fillRect(g.x - s / 2 + shake, g.y - s / 2, s, s);
      ctx.strokeStyle = g.done ? '#e3c068' : g.blockedUntil > m.time ? '#c0392b' : '#6b7178'; ctx.lineWidth = 2; ctx.strokeRect(g.x - s / 2 + shake, g.y - s / 2, s, s);
      // pistons
      for (let i = 0; i < 3; i++) { const ph = g.repairers.size ? Math.sin(this.t * 14 + i * 2) * 3 : 0; ctx.fillStyle = '#8a8f96'; ctx.fillRect(g.x - 12 + i * 9 + shake, g.y - 6 + ph, 6, 12); }
      if (g.done) { const r = 60 + Math.sin(this.t * 2) * 6; const gr = ctx.createRadialGradient(g.x, g.y, 4, g.x, g.y, r); gr.addColorStop(0, 'rgba(255,220,140,0.35)'); gr.addColorStop(1, 'rgba(255,220,140,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(g.x, g.y, r, 0, TAU); ctx.fill(); }
      if (g.regressing && !g.done) { ctx.fillStyle = `rgba(255,200,90,${0.5 + Math.random() * 0.5})`; ctx.fillRect(g.x - 3 + (Math.random() - 0.5) * 18, g.y - 18 - Math.random() * 6, 2, 2); }
      if (g.ruin) { ctx.strokeStyle = 'rgba(255,90,40,0.5)'; ctx.lineWidth = 1; ctx.strokeRect(g.x - s / 2 - 3, g.y - s / 2 - 3, s + 6, s + 6); }
      // up close the killer can read progress from the pistons
      if (!g.done && dist(k.x, k.y, g.x, g.y) < 4 * M && g.charges > 0) { ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(g.x - 20, g.y + s / 2 + 5, 40, 4); ctx.fillStyle = '#e3a14a'; ctx.fillRect(g.x - 20, g.y + s / 2 + 5, 40 * g.progress, 4); }
    }
  }

  drawWalls(m, cam) {
    const ctx = this.ctx, th = m.map.theme;
    // water channels / tar pits first: they sit below everything else
    for (const s of m.map.solids) {
      if (s.kind !== 'water' || s.x > cam.right + 40 || s.x + s.w < cam.left - 40 || s.y > cam.bottom + 40 || s.y + s.h < cam.top - 40) continue;
      ctx.fillStyle = th.water || '#14262e'; ctx.fillRect(s.x, s.y, s.w, s.h);
      if (th.waterGlow) { ctx.fillStyle = th.waterGlow; ctx.fillRect(s.x, s.y, s.w, s.h); }
      ctx.strokeStyle = 'rgba(255,255,255,0.07)'; ctx.lineWidth = 1; ctx.beginPath();
      for (let y = s.y + 8; y < s.y + s.h; y += 14) for (let x = s.x + ((y * 7) % 23); x < s.x + s.w - 10; x += 46) { const o = Math.sin(this.t * 1.5 + x * 0.05 + y) * 3; ctx.moveTo(x + o, y); ctx.lineTo(x + 12 + o, y); }
      ctx.stroke();
    }
    for (const s of m.map.solids) {
      if (s.kind === 'water') continue;
      if (s.x > cam.right + 40 || s.x + s.w < cam.left - 40 || s.y > cam.bottom + 40 || s.y + s.h < cam.top - 40) continue;
      if (s.kind === 'metal') {
        // shipping containers / metal crates: corrugated tops
        ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(s.x + 5, s.y + 7, s.w, s.h);
        ctx.fillStyle = th.metal || '#3c5566'; ctx.fillRect(s.x, s.y + 4, s.w, s.h);
        ctx.fillStyle = th.metalTop || '#55798f'; ctx.fillRect(s.x, s.y, s.w, s.h - 1);
        ctx.strokeStyle = 'rgba(0,0,0,0.22)'; ctx.lineWidth = 1; ctx.beginPath();
        if (s.w >= s.h) for (let x = s.x + 6; x < s.x + s.w; x += 6) { ctx.moveTo(x, s.y + 2); ctx.lineTo(x, s.y + s.h - 3); } else for (let y = s.y + 6; y < s.y + s.h; y += 6) { ctx.moveTo(s.x + 2, y); ctx.lineTo(s.x + s.w - 3, y); }
        ctx.stroke(); continue;
      }
      if (s.kind === 'tree') { ctx.fillStyle = shade(th.tree, 0.8); ctx.beginPath(); ctx.arc(s.x + s.w / 2, s.y + s.h / 2, s.w * 0.42, 0, TAU); ctx.fill(); continue; }
      const top = s.kind === 'wood' ? th.woodTop : s.kind === 'rock' ? th.rockTop : s.kind === 'border' ? '#1c1d20' : th.wallTop;
      const side = s.kind === 'wood' ? th.wood : s.kind === 'rock' ? th.rock : s.kind === 'border' ? '#121315' : th.wall;
      if (s.kind === 'rock') {
        // boulders: a lumpy cluster per meter cell, seeded by position so it never flickers
        const cells = [];
        for (let y = s.y; y < s.y + s.h - 1; y += M) for (let x = s.x; x < s.x + s.w - 1; x += M) { const h = ((x * 73 + y * 151) % 97) / 97; cells.push([x + M / 2 + (h - 0.5) * 6, y + M / 2 + (((h * 7) % 1) - 0.5) * 6, M * (0.6 + h * 0.18)]); }
        ctx.fillStyle = 'rgba(0,0,0,0.35)'; for (const [x, y, r] of cells) { ctx.beginPath(); ctx.arc(x + 5, y + 7, r, 0, TAU); ctx.fill(); }
        ctx.fillStyle = side; for (const [x, y, r] of cells) { ctx.beginPath(); ctx.arc(x, y + 2, r, 0, TAU); ctx.fill(); }
        ctx.fillStyle = top; for (const [x, y, r] of cells) { ctx.beginPath(); ctx.arc(x - 1, y - 1, r * 0.86, 0, TAU); ctx.fill(); }
        ctx.fillStyle = 'rgba(255,255,255,0.06)'; for (const [x, y, r] of cells) { ctx.beginPath(); ctx.arc(x - r * 0.3, y - r * 0.35, r * 0.35, 0, TAU); ctx.fill(); }
        continue;
      }
      ctx.fillStyle = side; ctx.fillRect(s.x, s.y + 4, s.w, s.h);
      ctx.fillStyle = top; ctx.fillRect(s.x, s.y, s.w, s.h - 1);
      if (s.kind === 'wood') { ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 1; ctx.beginPath(); if (s.w > s.h) for (let x = s.x + 10; x < s.x + s.w; x += 10) { ctx.moveTo(x, s.y); ctx.lineTo(x, s.y + s.h); } else for (let y = s.y + 10; y < s.y + s.h; y += 10) { ctx.moveTo(s.x, y); ctx.lineTo(s.x + s.w, y); } ctx.stroke(); }
      else if (s.kind === 'wall') { ctx.strokeStyle = 'rgba(0,0,0,0.18)'; ctx.lineWidth = 1; ctx.strokeRect(s.x + 0.5, s.y + 0.5, s.w - 1, s.h - 2); }
    }
    // windows (low walls you can vault)
    for (const w of m.map.windows) {
      if (!cam.inView(w.x, w.y)) continue; const r = w.rect;
      ctx.fillStyle = shade(th.wall, 0.75); ctx.fillRect(r.x, r.y + 3, r.w, r.h);
      ctx.fillStyle = w.blockedUntil > m.time ? '#5a2a3a' : shade(th.wallTop, 0.85); ctx.fillRect(r.x, r.y, r.w, r.h);
      ctx.strokeStyle = w.blockedUntil > m.time ? '#c04070' : 'rgba(230,220,200,0.55)'; ctx.lineWidth = 2; ctx.setLineDash([4, 4]);
      ctx.beginPath(); if (w.alongX) { ctx.moveTo(r.x + 3, r.y + r.h / 2); ctx.lineTo(r.x + r.w - 3, r.y + r.h / 2); } else { ctx.moveTo(r.x + r.w / 2, r.y + 3); ctx.lineTo(r.x + r.w / 2, r.y + r.h - 3); } ctx.stroke(); ctx.setLineDash([]);
    }
  }
  drawCanopies(m, cam) {
    const ctx = this.ctx, th = m.map.theme;
    for (const s of m.map.solids) {
      if (s.kind !== 'tree' || !cam.inView(s.x, s.y, 80)) continue;
      const cx = s.x + s.w / 2, cy = s.y + s.h / 2, r = 1.45 * M;
      const k = this.eye; ctx.globalAlpha = dist(k.x, k.y, cx, cy) < r + k.r + 8 ? 0.35 : m.survivors.some((v) => v.alive && dist(v.x, v.y, cx, cy) < r + 6 && dist(v.x, v.y, k.x, k.y) < 4 * M) ? 0.55 : 1;
      ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.arc(cx + 6, cy + 8, r, 0, TAU); ctx.fill();
      ctx.fillStyle = th.treeTop; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.fill();
      ctx.fillStyle = shade(th.treeTop, 1.25); ctx.beginPath(); ctx.arc(cx - r * 0.3, cy - r * 0.3, r * 0.55, 0, TAU); ctx.fill();
      ctx.globalAlpha = 1;
    }
  }

  // Shadow volumes behind every sight-blocking solid, cast from the killer.
  drawShadows(m, cam) {
    const ctx = this.ctx, k = this.eye, lx = k.x, ly = k.y, FAR = 4000;
    ctx.beginPath();
    for (const s of m.map.solids) {
      if (!s.blocksLOS) continue;
      if (s.x > cam.right + 300 || s.x + s.w < cam.left - 300 || s.y > cam.bottom + 300 || s.y + s.h < cam.top - 300) continue;
      if (lx > s.x && lx < s.x + s.w && ly > s.y && ly < s.y + s.h) continue;
      const pts = [[s.x, s.y], [s.x + s.w, s.y], [s.x + s.w, s.y + s.h], [s.x, s.y + s.h]];
      for (let i = 0; i < 4; i++) {
        const a = pts[i], b = pts[(i + 1) % 4];
        const ex = b[0] - a[0], ey = b[1] - a[1]; const nx = ey, ny = -ex; // outward normal for clockwise rect
        if ((a[0] - lx) * nx + (a[1] - ly) * ny <= 0) continue; // edge faces the light
        const pa = proj(a, lx, ly, FAR), pb = proj(b, lx, ly, FAR);
        ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.lineTo(pb[0], pb[1]); ctx.lineTo(pa[0], pa[1]); ctx.closePath();
      }
    }
    for (const g of m.map.gates) if (!g.open) { /* gate doors block sight too but are at map edge */ }
    ctx.fillStyle = 'rgba(4,5,7,0.78)'; ctx.fill('nonzero');
  }

  drawSurvivors(m, cam, vis, ground) {
    const ctx = this.ctx;
    for (const s of m.survivors) {
      if (!s.alive || !vis.has(s)) continue;
      const lying = s.health === 'dying';
      if (ground !== (lying || s.health === 'hooked')) continue;
      if (s.health === 'carried') continue;
      drawSurvivor(ctx, s, this.t, m);
    }
  }
  drawKiller(m, k = m.killer) {
    const ctx = this.ctx;
    const cloaked = k.power.id === 'cloak' && k.power.state !== 'visible';
    const alpha = k.power.alpha?.(m) ?? (cloaked ? (k.power.state === 'cloaked' ? 0.28 : 0.55) : k.power.id === 'shroud' && k.power.shrouded ? (k.power.crouched ? 0.6 : 0.8) : 1);
    if (alpha <= 0) { k.power.drawOver?.(ctx, m, this); return; }
    // red stain (the killer's light the survivors see)
    const gr = ctx.createRadialGradient(k.x, k.y, 10, k.x, k.y, 6 * M);
    gr.addColorStop(0, `rgba(200,20,30,${0.18 * alpha})`); gr.addColorStop(1, 'rgba(200,20,30,0)');
    ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.arc(k.x, k.y, 6 * M, k.facing - 0.3, k.facing + 0.3); ctx.closePath(); ctx.fill();
    ctx.save(); ctx.globalAlpha = alpha; ctx.translate(k.x, k.y);
    if (k.carrying) { ctx.save(); ctx.rotate(k.facing); ctx.fillStyle = k.carrying.color; ctx.beginPath(); ctx.ellipse(-8, 0, 10, 20, 0, 0, TAU); ctx.fill(); ctx.restore(); }
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.ellipse(5, 7, k.r + 2, k.r - 2, 0, 0, TAU); ctx.fill();
    ctx.rotate(k.facing);
    // weapon
    const id = k.def.id;
    if (k.power.drawWeapon?.(ctx, m, this)) { /* power draws its own weapon */ }
    else if (id === 'hillbilly') {
      const rev = k.power.state === 'revving' || k.power.state === 'sprint';
      ctx.fillStyle = rev ? '#e07a3a' : '#6b6e72'; ctx.fillRect(k.r - 4, -6, 26, 12); ctx.fillStyle = '#2a2b2e'; ctx.fillRect(k.r - 8, -8, 10, 16);
      if (rev) { ctx.strokeStyle = `rgba(255,${120 + Math.random() * 100 | 0},60,0.9)`; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(k.r + 22, -6); ctx.lineTo(k.r + 22, 6); ctx.stroke(); }
    } else if (id === 'trapper') {
      ctx.fillStyle = '#9da3a8'; ctx.beginPath(); ctx.moveTo(k.r - 2, 4); ctx.lineTo(k.r + 20, 10); ctx.lineTo(k.r + 22, 2); ctx.lineTo(k.r, -2); ctx.fill();
    } else if (id === 'huntress') {
      const wind = k.power.state === 'winding'; ctx.save(); if (wind) ctx.rotate(-0.9 * Math.min(1, k.power.charge / k.power.maxWind));
      ctx.strokeStyle = '#7a5a3a'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(k.r - 4, 8); ctx.lineTo(k.r + 12, 12); ctx.stroke();
      ctx.fillStyle = '#cfd3d6'; ctx.beginPath(); ctx.moveTo(k.r + 10, 8); ctx.lineTo(k.r + 20, 10); ctx.lineTo(k.r + 12, 18); ctx.closePath(); ctx.fill(); ctx.restore();
    } else if (id === 'clown') {
      const c = k.power.type === 'tonic' ? '#b07ad8' : '#e8c35a'; ctx.fillStyle = c; ctx.beginPath(); ctx.ellipse(k.r + 6, 8, 5, 7, 0, 0, TAU); ctx.fill(); ctx.fillStyle = '#ddd'; ctx.fillRect(k.r + 4, 0, 3, 3);
    } else if (id === 'executioner') {
      ctx.strokeStyle = '#4d3b2c'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(k.r - 6, 2); ctx.lineTo(k.r + 26, 2); ctx.stroke();
      ctx.fillStyle = k.power.state === 'normal' ? '#8a8f94' : '#e2683c'; ctx.beginPath(); ctx.moveTo(k.r + 14, -10); ctx.lineTo(k.r + 30, -4); ctx.lineTo(k.r + 30, 8); ctx.lineTo(k.r + 14, 6); ctx.closePath(); ctx.fill();
    } else if (id === 'singularity') {
      ctx.strokeStyle = '#5fe0e0'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(k.r + 4, 0, 6, 0, TAU); ctx.stroke();
    } else if (id === 'ghostface') {
      ctx.fillStyle = '#b9bcc0'; ctx.beginPath(); ctx.moveTo(k.r - 2, 6); ctx.lineTo(k.r + 16, 9); ctx.lineTo(k.r - 2, 10); ctx.closePath(); ctx.fill();
    } else {
      ctx.strokeStyle = '#c6c2b4'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(k.r - 4, 6); ctx.lineTo(k.r + 18, 12); ctx.stroke();
    }
    const att = k.attack.state;
    if (att === 'lunge') { ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, k.r + 28, -0.7, 0.7); ctx.stroke(); }
    // body
    ctx.fillStyle = shade(k.def.color, 0.55); ctx.beginPath(); ctx.arc(0, 0, k.r, 0, TAU); ctx.fill();
    ctx.fillStyle = shade(k.def.color, 0.85); ctx.beginPath(); ctx.ellipse(0, 0, k.r * 0.85, k.r * 1.05, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = shade(k.def.color, 1.15); ctx.beginPath(); ctx.arc(4, 0, k.r * 0.5, 0, TAU); ctx.fill();
    if (id === 'trapper') { ctx.fillStyle = '#e9e2d0'; ctx.beginPath(); ctx.arc(6, 0, 5, 0, TAU); ctx.fill(); }
    if (id === 'ghostface') { ctx.fillStyle = '#ecebe6'; ctx.beginPath(); ctx.ellipse(5, 0, 6, 5, 0, 0, TAU); ctx.fill(); ctx.fillStyle = '#111'; ctx.fillRect(7, -3, 2, 2); ctx.fillRect(7, 1, 2, 2); }
    if (id === 'huntress') { ctx.fillStyle = '#5a4a3a'; ctx.beginPath(); ctx.moveTo(-4, -k.r); ctx.lineTo(2, -k.r - 8); ctx.lineTo(6, -k.r + 2); ctx.fill(); ctx.beginPath(); ctx.moveTo(-4, k.r); ctx.lineTo(2, k.r + 8); ctx.lineTo(6, k.r - 2); ctx.fill(); }
    if (id === 'clown') { ctx.fillStyle = '#e0e0e0'; ctx.beginPath(); ctx.arc(6, 0, 5, 0, TAU); ctx.fill(); ctx.fillStyle = '#c0303a'; ctx.beginPath(); ctx.arc(10, 0, 2, 0, TAU); ctx.fill(); }
    if (id === 'executioner') { ctx.fillStyle = '#9a8a74'; ctx.beginPath(); ctx.moveTo(-2, -9); ctx.lineTo(12, 0); ctx.lineTo(-2, 9); ctx.closePath(); ctx.fill(); }
    if (id === 'singularity') { ctx.fillStyle = '#5fe0e0'; ctx.globalAlpha *= 0.8; ctx.beginPath(); ctx.arc(5, 0, 3, 0, TAU); ctx.fill(); }
    k.power.drawBody?.(ctx, m, this);
    if (id === 'wraith') { ctx.strokeStyle = '#d8d4c8'; ctx.lineWidth = 1.5; for (let i = -1; i <= 1; i++) { ctx.beginPath(); ctx.moveTo(-k.r * 0.6, i * 6); ctx.lineTo(k.r * 0.6, i * 6 + 2); ctx.stroke(); } }
    ctx.restore();
    if (cloaked && k.power.state === 'cloaked') { ctx.strokeStyle = `rgba(180,220,220,${0.15 + Math.random() * 0.1})`; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(k.x, k.y, k.r + 4 + Math.random() * 3, 0, TAU); ctx.stroke(); }
    if (k.stunT > 0) { ctx.fillStyle = '#ffd27a'; for (let i = 0; i < 3; i++) { const a = this.t * 5 + i * 2.1; ctx.beginPath(); ctx.arc(k.x + Math.cos(a) * 20, k.y - 24 + Math.sin(a) * 6, 3, 0, TAU); ctx.fill(); } }
    // power telegraphs the player needs to read
    const pw = k.power;
    if (pw.id === 'judgement' && (pw.state === 'windup' || pw.state === 'punish')) {
      const len = pw.waveLen; ctx.save(); ctx.translate(k.x, k.y); ctx.rotate(k.facing);
      ctx.fillStyle = pw.state === 'windup' ? `rgba(226,104,60,${0.15 + 0.25 * pw.windT / pw.windup})` : 'rgba(226,104,60,0.06)'; ctx.fillRect(0, -1.25 * M, len, 2.5 * M); ctx.restore();
    }
    if (pw.wave) { const w = pw.wave; const hx = w.x + Math.cos(w.dir) * w.d, hy = w.y + Math.sin(w.dir) * w.d; ctx.save(); ctx.translate(hx, hy); ctx.rotate(w.dir); ctx.fillStyle = 'rgba(255,120,60,0.8)'; ctx.fillRect(-6, -1.25 * M, 12, 2.5 * M); ctx.restore(); }
    if (pw.id === 'tonic' && pw.state === 'aiming') { const t = pw.target(k.input); ctx.strokeStyle = pw.type === 'tonic' ? 'rgba(176,122,216,0.8)' : 'rgba(232,195,90,0.8)'; ctx.setLineDash([6, 6]); ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.quadraticCurveTo((k.x + t.x) / 2, (k.y + t.y) / 2 - 40, t.x, t.y); ctx.stroke(); ctx.setLineDash([]); ctx.beginPath(); ctx.arc(t.x, t.y, pw.cloudR, 0, TAU); ctx.stroke(); }
    if (pw.id === 'hatchets' && pw.state === 'winding') { const f = Math.min(1, pw.charge / pw.maxWind); ctx.strokeStyle = `rgba(230,230,230,${0.25 + 0.4 * f})`; ctx.lineWidth = 1.5; ctx.setLineDash([4, 8]); ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.lineTo(k.x + Math.cos(k.facing) * pw.range * (0.5 + 0.5 * f), k.y + Math.sin(k.facing) * pw.range * (0.5 + 0.5 * f)); ctx.stroke(); ctx.setLineDash([]); }
    if (pw.id === 'shroud' && pw.stalking) { ctx.fillStyle = 'rgba(255,255,255,0.05)'; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.arc(k.x, k.y, 26 * M, k.facing - 0.55, k.facing + 0.55); ctx.closePath(); ctx.fill(); }
    k.power.drawOver?.(ctx, m, this);
    // trap setting ghost
    if (k.power.setting) { const p = k.power.setting.p; ctx.globalAlpha = 0.5; drawTrap(ctx, p.x, p.y, 'set', this.t); ctx.globalAlpha = 1; }
  }

  drawFX(m) {
    const ctx = this.ctx, fx = m.fx;
    for (const p of fx.particles) { const a = 1 - p.t / p.life; ctx.globalAlpha = a; ctx.fillStyle = p.color; ctx.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size); }
    ctx.globalAlpha = 1;
    for (const r of fx.rings) { const k = r.t / r.life; ctx.strokeStyle = r.color; ctx.globalAlpha = 1 - k; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(r.x, r.y, r.r * (0.3 + k), 0, TAU); ctx.stroke(); }
    ctx.globalAlpha = 1;
    ctx.font = '600 15px "Saira Condensed", "Arial Narrow", sans-serif'; ctx.textAlign = 'center';
    for (const t of fx.texts) { ctx.globalAlpha = 1 - t.t / t.life; ctx.fillStyle = '#000'; ctx.fillText(t.s, t.x + 1, t.y + 1); ctx.fillStyle = t.color; ctx.fillText(t.s, t.x, t.y); }
    ctx.globalAlpha = 1;
    // grunts of pain: a sound ripple where an unseen injured survivor is
    const k = this.eye;
    for (const g of (this.eyeK ? m.grunts : [])) {
      if (dist(g.x, g.y, k.x, k.y) > 22 * M) continue;
      const a = (m.time - g.t) / 1.2; ctx.strokeStyle = g.color ? g.color : `rgba(220,60,60,${0.6 * (1 - a)})`; ctx.globalAlpha = g.color ? 0.7 * (1 - a) : 1; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(g.x + (Math.sin(g.t * 13) * 20), g.y + (Math.cos(g.t * 7) * 20), 10 + a * 30, 0, TAU); ctx.stroke(); ctx.globalAlpha = 1;
    }
    // projectiles
    for (const p of m.projectiles) {
      if (p.kind === 'hatchet') { ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.t * 24); ctx.fillStyle = '#d6dadd'; ctx.fillRect(-7, -2, 14, 4); ctx.fillStyle = '#6a4a2a'; ctx.fillRect(-2, -6, 4, 12); ctx.restore(); }
      else { const h = (p.height || 0) * 18; ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.arc(p.x, p.y, 4, 0, TAU); ctx.fill(); ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(p.x, p.y - h, 5, 0, TAU); ctx.fill(); }
    }
  }

  drawFog(m, cam) {
    const ctx = this.ctx, k = this.eye; const p = cam.toScreen(k.x, k.y);
    let r = (m.cfg.modifiers.heavyFog ? 15 : 24) * (this.eyeK && k.hasPerk('shadowborn') ? 1.25 : 1) * M * cam.zoom;
    if (!this.eyeK && m.nightfallFor?.(k)) r = 6 * M * cam.zoom;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    const [fr, fg, fb] = m.map.theme.fog;
    const gr = ctx.createRadialGradient(p.x, p.y, r * 0.55, p.x, p.y, r * 1.35);
    gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, `rgba(6,7,9,0.82)`);
    ctx.fillStyle = gr; ctx.fillRect(0, 0, this.w, this.h);
    ctx.fillStyle = `rgba(${fr},${fg},${fb},0.05)`; ctx.fillRect(0, 0, this.w, this.h);
  }
  drawScreenFX(m, cam) {
    const ctx = this.ctx, fx = m.fx, k = this.eye;
    const chasing = this.eyeK ? !!k.chaseTarget : m.inChase(k);
    // Survivor's heartbeat: the terror radius of the nearest detectable killer pulses at the edges
    if (!this.eyeK && k.alive) {
      let hb = 0; for (const q of m.killers) { if (q.status.mods().undetectable || k.status?.has('oblivious')) continue; const d = dist(q.x, q.y, k.x, k.y); if (d < q.terrorRadius) hb = Math.max(hb, 1 - d / q.terrorRadius); }
      this.heartbeat = hb;
      if (hb > 0 && !chasing) {
        const rate = 3 + hb * 6; const pulse = Math.max(0, Math.sin(this.t * rate)) ** 6 * (0.12 + 0.3 * hb);
        const gr = ctx.createRadialGradient(this.w / 2, this.h / 2, Math.min(this.w, this.h) * 0.4, this.w / 2, this.h / 2, Math.max(this.w, this.h) * 0.75);
        gr.addColorStop(0, 'rgba(140,0,12,0)'); gr.addColorStop(1, `rgba(140,0,12,${pulse})`); ctx.fillStyle = gr; ctx.fillRect(0, 0, this.w, this.h);
      }
    }
    if (chasing) {
      const pulse = 0.25 + 0.15 * Math.sin(this.t * 6.5) + (this.eyeK ? k.bloodlust * 0.08 : 0.05);
      const gr = ctx.createRadialGradient(this.w / 2, this.h / 2, Math.min(this.w, this.h) * 0.35, this.w / 2, this.h / 2, Math.max(this.w, this.h) * 0.75);
      gr.addColorStop(0, 'rgba(120,0,10,0)'); gr.addColorStop(1, `rgba(120,0,10,${pulse})`);
      ctx.fillStyle = gr; ctx.fillRect(0, 0, this.w, this.h);
    }
    if (fx.flash > 0) { ctx.fillStyle = `rgba(${fx.flashColor},${fx.flash * 0.6})`; ctx.fillRect(0, 0, this.w, this.h); }
    if (this.eyeK && k.blindT > 0) { ctx.fillStyle = `rgba(255,252,235,${Math.min(0.92, k.blindT / 2.5)})`; ctx.fillRect(0, 0, this.w, this.h); }
  }

  // Aura reveals → arrows. Loud noises → pings. Both clamp to the screen edge.
  drawIndicators(m, cam, vis) {
    const ctx = this.ctx; ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    const k = this.eye; const kp = cam.toScreen(k.x, k.y);
    const placed = [];
    if (!this.eyeK) { this.drawSurvivorIndicators(m, cam, vis, kp); return; }
    const nudge = (x, y) => { for (let i = 0; i < 6; i++) { if (!placed.some((q) => Math.abs(q.x - x) < 120 && Math.abs(q.y - y) < 20)) break; y -= 20; } placed.push({ x, y }); return y; };
    for (const r of m.reveals) {
      const t = r.target; if (t.kind === 'survivor' && vis.has(t)) continue;
      const p = cam.toScreen(t.x, t.y); const d = dist(k.x, k.y, t.x, t.y) / M;
      const color = t.kind === 'generator' ? '#e8c35a' : '#e8434f';
      const on = p.x > 30 && p.y > 30 && p.x < this.w - 30 && p.y < this.h - 30;
      if (on) {
        // hidden but in view: soft aura glyph + arrow pointing down at it
        ctx.strokeStyle = color; ctx.globalAlpha = 0.6 + 0.3 * Math.sin(this.t * 6); ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(p.x, p.y, 14 * cam.zoom, 0, TAU); ctx.stroke(); ctx.globalAlpha = 1;
        arrow(ctx, p.x, p.y - 34, Math.PI / 2, color, 16);
        label(ctx, p.x, p.y - 56, r.label, color);
      } else {
        const a = Math.atan2(p.y - kp.y, p.x - kp.x);
        const e = edgePoint(this.w, this.h, a, 46, 130);
        arrow(ctx, e.x, e.y, a, color, 20);
        const lx = clamp(e.x - Math.cos(a) * 34, 70, this.w - 70);
        label(ctx, lx, nudge(lx, e.y - Math.sin(a) * 34 + 4), `${t.name || r.label} · ${Math.round(d)}m`, color);
      }
    }
    for (const n of m.loudNoises) {
      const p = cam.toScreen(n.x, n.y); const age = m.time - n.t; const a = 1 - age / 3;
      const on = p.x > 20 && p.y > 20 && p.x < this.w - 20 && p.y < this.h - 20;
      ctx.globalAlpha = a;
      if (on) { noisePing(ctx, p.x, p.y, age, '#f2d06b'); }
      else { const ang = Math.atan2(p.y - kp.y, p.x - kp.x); const e = edgePoint(this.w, this.h, ang, 30, 120); noisePing(ctx, e.x, e.y, age, '#f2d06b', 0.6); }
      ctx.globalAlpha = 1;
    }
  }

  // What a survivor legitimately sees beyond line of sight: hooked teammates' auras, killer
  // reveals from perks/items, generator completion lights and the powered gates.
  drawSurvivorIndicators(m, cam, vis, ep) {
    const ctx = this.ctx, e = this.eye; const placed = [];
    const nudge = (x, y) => { for (let i = 0; i < 6; i++) { if (!placed.some((q) => Math.abs(q.x - x) < 120 && Math.abs(q.y - y) < 20)) break; y -= 20; } placed.push({ x, y }); return y; };
    const mark = (x, y, color, text, glyph = true) => {
      const p = cam.toScreen(x, y); const on = p.x > 30 && p.y > 30 && p.x < this.w - 30 && p.y < this.h - 30; const d = dist(e.x, e.y, x, y) / M;
      if (on) { if (glyph) { ctx.strokeStyle = color; ctx.globalAlpha = 0.6 + 0.3 * Math.sin(this.t * 6); ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(p.x, p.y, 15 * cam.zoom, 0, TAU); ctx.stroke(); ctx.globalAlpha = 1; } label(ctx, p.x, p.y - 30 * cam.zoom, text, color); }
      else { const a = Math.atan2(p.y - ep.y, p.x - ep.x); const ed = edgePoint(this.w, this.h, a, 46, 130); arrow(ctx, ed.x, ed.y, a, color, 18); const lx = clamp(ed.x - Math.cos(a) * 34, 70, this.w - 70); label(ctx, lx, nudge(lx, ed.y - Math.sin(a) * 34 + 4), `${text} · ${Math.round(d)}m`, color); }
    };
    // hooked teammates: always visible (white), with the hook stage
    for (const s of m.survivors) if (s !== e && s.health === 'hooked') mark(s.x, s.y, '#f2efe6', `${s.name} hooked ${s.hookStage === 2 ? '(struggle)' : ''}`);
    // dying teammates nearby / teammates being carried
    for (const s of m.survivors) if (s !== e && (s.health === 'dying' || s.health === 'carried') && !vis.has(s) && dist(s.x, s.y, e.x, e.y) < 32 * M) mark(s.x, s.y, '#e8a0a8', `${s.name} ${s.health === 'carried' ? 'carried' : 'downed'}`);
    // killer reveals (Alert, Fogwise, Kindred, 2v8 classes…)
    for (const k of m.killers) if (!vis.killers.has(k) && m.killerRevealedTo(e, k)) mark(k.x, k.y, '#e8434f', k.def.short);
    // aura reveals aimed at survivors' team (e.g. Bond-style perks reveal teammates)
    for (const r of m.survivorAuras || []) if (r.to === e && r.until > m.time && !vis.has(r.target)) mark(r.target.x, r.target.y, '#9fd0e0', r.label);
    // exit gates once powered
    if (m.gatesPowered) for (const g of m.map.gates) mark(g.x, g.y, g.open ? '#9fd0a0' : '#e3a14a', g.open ? 'Exit open' : 'Exit gate', false);
    if (m.hatch.state === 'open' && dist(m.hatch.x, m.hatch.y, e.x, e.y) < 24 * M) mark(m.hatch.x, m.hatch.y, '#9fd0d0', 'Hatch');
    // generator completions and gate alarms are heard across the map
    for (const n of m.loudNoises) {
      if (n.kind !== 'gen' && n.kind !== 'gate' && dist(n.x, n.y, e.x, e.y) > 18 * M) continue;
      const p = cam.toScreen(n.x, n.y); const age = m.time - n.t; ctx.globalAlpha = 1 - age / 3;
      const on = p.x > 20 && p.y > 20 && p.x < this.w - 20 && p.y < this.h - 20;
      if (on) noisePing(ctx, p.x, p.y, age, '#f2d06b'); else { const ang = Math.atan2(p.y - ep.y, p.x - ep.x); const ed = edgePoint(this.w, this.h, ang, 30, 120); noisePing(ctx, ed.x, ed.y, age, '#f2d06b', 0.6); }
      ctx.globalAlpha = 1;
    }
  }

  // ---------------------------------------------------------------- debug
  drawNav(m, cam) {
    const ctx = this.ctx, nav = m.map.nav;
    const c0 = Math.max(0, Math.floor(cam.left / M)), c1 = Math.min(nav.cols - 1, Math.floor(cam.right / M));
    const r0 = Math.max(0, Math.floor(cam.top / M)), r1 = Math.min(nav.rows - 1, Math.floor(cam.bottom / M));
    for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) {
      const i = r * nav.cols + c;
      if (nav.isBlocked(i)) { ctx.fillStyle = 'rgba(255,60,60,0.18)'; ctx.fillRect(c * M, r * M, M, M); }
      else if (nav.deadZone[i] > 0.5) { ctx.fillStyle = `rgba(160,60,255,${nav.deadZone[i] * 0.14})`; ctx.fillRect(c * M, r * M, M, M); }
      else if (nav.tileOf[i] >= 0) { ctx.fillStyle = 'rgba(80,200,120,0.07)'; ctx.fillRect(c * M, r * M, M, M); }
    }
    ctx.strokeStyle = 'rgba(80,200,255,0.8)'; ctx.lineWidth = 2;
    for (const L of nav.links) { const a = nav.center(L.a), b = nav.center(L.b); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
  }
  drawDebugWorld(m, cam) {
    const ctx = this.ctx;
    if (this.debug.graph) {
      ctx.lineWidth = 1.5;
      for (const t of m.map.tiles) {
        if (t.filler) continue;
        for (const id of t.connected) { const o = m.map.tiles[id]; if (o.id < t.id || o.filler) continue; ctx.strokeStyle = 'rgba(120,220,160,0.25)'; ctx.beginPath(); ctx.moveTo(t.x, t.y); ctx.lineTo(o.x, o.y); ctx.stroke(); }
        ctx.fillStyle = `rgba(120,220,160,${0.3 + t.safety * 0.6})`; ctx.beginPath(); ctx.arc(t.x, t.y, 6 + t.safety * 8, 0, TAU); ctx.fill();
        if (cam.inView(t.x, t.y)) { ctx.font = '11px "IBM Plex Mono", monospace'; ctx.fillStyle = '#bff0d0'; ctx.textAlign = 'center'; ctx.fillText(`${t.label} ${(t.safety * 100) | 0}`, t.x, t.y - 16); }
      }
    }
    for (const s of m.survivors) {
      if (!s.alive || !s.ai) continue; const ai = s.ai;
      if (this.debug.paths && ai.path) { ctx.strokeStyle = s.color; ctx.globalAlpha = 0.7; ctx.lineWidth = 2; ctx.setLineDash([5, 5]); ctx.beginPath(); ctx.moveTo(s.x, s.y); for (let i = ai.pathIdx; i < ai.path.length; i++) ctx.lineTo(ai.path[i].x, ai.path[i].y); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1; }
      if (this.debug.belief && ai.belief.conf > 0.1) {
        const b = ai.belief.pos(); ctx.strokeStyle = s.color; ctx.globalAlpha = ai.belief.conf; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.arc(b.x, b.y, 10 + (1 - ai.belief.conf) * 40, 0, TAU); ctx.stroke(); ctx.beginPath(); ctx.moveTo(b.x - 6, b.y - 6); ctx.lineTo(b.x + 6, b.y + 6); ctx.moveTo(b.x + 6, b.y - 6); ctx.lineTo(b.x - 6, b.y + 6); ctx.stroke(); ctx.globalAlpha = 1;
      }
      if (ai.inChase && ai.chase.debug.best) { const p = ai.chase.debug.best; ctx.fillStyle = s.color; ctx.globalAlpha = 0.8; ctx.fillRect(p.x - 4, p.y - 4, 8, 8); ctx.globalAlpha = 1; }
      // floating label
      ctx.font = '600 11px "IBM Plex Mono", monospace'; ctx.textAlign = 'center';
      const lines = [`${s.name} D${s.difficulty} ${ai.state}`, `${ai.goal ? ai.goal.type + ' ' + ai.goal.score.toFixed(0) : '-'} · thr ${ai.threat.toFixed(2)}`, `${ai.belief.state} ${(ai.belief.conf * 100) | 0}%`];
      lines.forEach((l, i) => { const y = s.y - 30 - (lines.length - 1 - i) * 13; ctx.fillStyle = 'rgba(0,0,0,0.65)'; const w = ctx.measureText(l).width + 6; ctx.fillRect(s.x - w / 2, y - 10, w, 13); ctx.fillStyle = i === 0 ? s.color : '#ddd'; ctx.fillText(l, s.x, y); });
    }
  }
}

// ------------------------------------------------------------------ drawing helpers
function proj(p, lx, ly, far) { const dx = p[0] - lx, dy = p[1] - ly; const l = Math.hypot(dx, dy) || 1; return [p[0] + dx / l * far, p[1] + dy / l * far]; }
export function shade(hex, f) {
  const n = parseInt(hex.slice(1), 16); let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  r = clamp(Math.round(r * f), 0, 255); g = clamp(Math.round(g * f), 0, 255); b = clamp(Math.round(b * f), 0, 255);
  return `rgb(${r},${g},${b})`;
}
function roundRect(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
function drawPallet(ctx, p) {
  const r = p.rect;
  if (p.state === 'broken') { ctx.fillStyle = '#5a4428'; for (let i = 0; i < 6; i++) { const a = i * 1.7; ctx.fillRect(p.x + Math.cos(a) * 14 - 4, p.y + Math.sin(a) * 9 - 1.5, 9, 3); } return; }
  if (p.state === 'down') {
    ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.fillRect(r.x + 3, r.y + 4, r.w, r.h);
    ctx.fillStyle = '#8a6a3e'; ctx.fillRect(r.x, r.y, r.w, r.h);
    ctx.strokeStyle = '#5b4426'; ctx.lineWidth = 2; ctx.beginPath();
    if (p.alongX) for (let x = r.x + 8; x < r.x + r.w; x += 9) { ctx.moveTo(x, r.y); ctx.lineTo(x, r.y + r.h); } else for (let y = r.y + 8; y < r.y + r.h; y += 9) { ctx.moveTo(r.x, y); ctx.lineTo(r.x + r.w, y); }
    ctx.stroke(); return;
  }
  // standing pallet: tall plank leaning at one end of the gap
  const t = 8; const lean = p.dropping ? 0.5 : 1;
  ctx.fillStyle = '#9c7a48';
  if (p.alongX) { ctx.fillRect(r.x - t * 0.3, p.y - t / 2 - (1 - lean) * 10, t, t); ctx.fillStyle = '#b8935a'; ctx.fillRect(r.x - t * 0.3 + 1, p.y - t / 2 + 1, t - 2, t - 2); }
  else { ctx.fillRect(p.x - t / 2, r.y - t * 0.3, t, t); ctx.fillStyle = '#b8935a'; ctx.fillRect(p.x - t / 2 + 1, r.y - t * 0.3 + 1, t - 2, t - 2); }
  ctx.strokeStyle = 'rgba(200,160,100,0.35)'; ctx.lineWidth = 1; ctx.setLineDash([3, 4]); ctx.strokeRect(r.x, r.y, r.w, r.h); ctx.setLineDash([]);
}
function drawTrap(ctx, x, y, state, t) {
  ctx.save(); ctx.translate(x, y);
  ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(2, 3, 11, 8, 0, 0, TAU); ctx.fill();
  ctx.strokeStyle = state === 'set' ? '#b7bcc2' : '#6f7378'; ctx.lineWidth = 2.2;
  ctx.beginPath(); ctx.arc(0, 0, 9, 0, TAU); ctx.stroke();
  if (state === 'set') { ctx.beginPath(); for (let i = 0; i < 8; i++) { const a = i / 8 * TAU; ctx.moveTo(Math.cos(a) * 9, Math.sin(a) * 9); ctx.lineTo(Math.cos(a) * 5, Math.sin(a) * 5); } ctx.stroke(); ctx.fillStyle = '#7a1c1c'; ctx.beginPath(); ctx.arc(0, 0, 2.5, 0, TAU); ctx.fill(); }
  else { ctx.beginPath(); ctx.moveTo(-9, 0); ctx.lineTo(9, 0); ctx.stroke(); }
  ctx.restore();
}
function drawSurvivor(ctx, s, t, m) {
  const crouch = s.moveMode === 'crouch' && s.standing && !s.action;
  const r = s.r * (crouch ? 0.85 : 1);
  ctx.save(); ctx.translate(s.x, s.y);
  if (s.health === 'dying') {
    ctx.rotate(s.facing); ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.ellipse(3, 4, r * 1.5, r * 0.8, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = shade(s.color, 0.7); ctx.beginPath(); ctx.ellipse(0, 0, r * 1.45, r * 0.75, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#7a0f18'; ctx.beginPath(); ctx.arc(-4, 2, 5, 0, TAU); ctx.fill();
    ctx.fillStyle = '#e2c9a8'; ctx.beginPath(); ctx.arc(r * 1.1, 0, 5, 0, TAU); ctx.fill();
    ctx.restore(); return;
  }
  if (s.health === 'hooked') {
    ctx.fillStyle = shade(s.color, 0.8); ctx.beginPath(); ctx.ellipse(0, 4, r * 0.8, r * 1.05, Math.sin(t * 8) * 0.1, 0, TAU); ctx.fill();
    ctx.fillStyle = '#e2c9a8'; ctx.beginPath(); ctx.arc(0, -10, 5, 0, TAU); ctx.fill();
    ctx.restore(); return;
  }
  const bob = Math.hypot(s.vx, s.vy) > 10 ? Math.sin(t * 18) * 1.2 : 0;
  ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.ellipse(4, 6, r, r * 0.75, 0, 0, TAU); ctx.fill();
  if (s.vault) { const k = s.vault.t / s.vault.dur; ctx.scale(1 + Math.sin(k * Math.PI) * 0.25, 1 + Math.sin(k * Math.PI) * 0.25); }
  ctx.rotate(s.facing);
  // body
  ctx.fillStyle = shade(s.color, 0.75); ctx.beginPath(); ctx.ellipse(0, bob, r * 0.9, r, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = s.color; ctx.beginPath(); ctx.ellipse(-1, bob, r * 0.7, r * 0.82, 0, 0, TAU); ctx.fill();
  if (s.health === 'injured') { ctx.fillStyle = '#8c0f1c'; ctx.beginPath(); ctx.arc(-3, 4, 4, 0, TAU); ctx.arc(2, -5, 3, 0, TAU); ctx.fill(); }
  // arms when working
  if (s.action) { ctx.strokeStyle = '#e2c9a8'; ctx.lineWidth = 3; const w = Math.sin(t * 16) * 2; ctx.beginPath(); ctx.moveTo(4, -6); ctx.lineTo(r + 3, -4 + w); ctx.moveTo(4, 6); ctx.lineTo(r + 3, 4 - w); ctx.stroke(); }
  // head
  ctx.fillStyle = '#e2c9a8'; ctx.beginPath(); ctx.arc(3, bob, r * 0.45, 0, TAU); ctx.fill();
  ctx.fillStyle = shade(s.color, 0.5); ctx.beginPath(); ctx.arc(1, bob, r * 0.45, Math.PI * 0.55, Math.PI * 1.45); ctx.fill();
  if (s.item?.id === 'flashlight' && s.action?.type === 'flashlight') { const gr = ctx.createLinearGradient(0, 0, 7 * M, 0); gr.addColorStop(0, 'rgba(255,250,220,0.55)'); gr.addColorStop(1, 'rgba(255,250,220,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(8, 0); ctx.lineTo(7 * M, -1.6 * M); ctx.lineTo(7 * M, 1.6 * M); ctx.closePath(); ctx.fill(); }
  ctx.restore();
  if (s.trap) { ctx.strokeStyle = '#b7bcc2'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(s.x, s.y + 6, 10, 0, TAU); ctx.stroke(); }
  // power statuses the killer can read on survivors
  const st = s.status;
  if (st.has('marked')) { ctx.strokeStyle = 'rgba(255,75,92,0.9)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(s.x, s.y, s.r + 6, 0, TAU); ctx.stroke(); }
  if (st.has('slipstream')) { ctx.strokeStyle = 'rgba(95,224,224,0.85)'; ctx.setLineDash([3, 3]); ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(s.x, s.y, s.r + 9, 0, TAU); ctx.stroke(); ctx.setLineDash([]); }
  if (st.has('tormented')) { ctx.strokeStyle = 'rgba(226,104,60,0.9)'; ctx.lineWidth = 1.5; for (let i = -1; i <= 1; i++) { ctx.beginPath(); ctx.moveTo(s.x + i * 5, s.y - s.r - 10); ctx.lineTo(s.x + i * 5, s.y - s.r - 2); ctx.stroke(); } }
  if (st.has('intoxicated')) { ctx.fillStyle = 'rgba(176,122,216,0.5)'; ctx.beginPath(); ctx.arc(s.x + Math.sin(t * 5) * 4, s.y - s.r - 6, 4, 0, TAU); ctx.fill(); }
  if (st.has('chained')) { const n = st.get('chained').value ?? 3; ctx.strokeStyle = 'rgba(190,190,200,0.9)'; ctx.lineWidth = 1.5; for (let i = 0; i < n; i++) { const a = i * 2.1 + t; ctx.beginPath(); ctx.moveTo(s.x, s.y); ctx.lineTo(s.x + Math.cos(a) * 26, s.y + Math.sin(a) * 26); ctx.stroke(); } }
  if (st.has('infected')) { const v = Math.min(100, st.get('infected').value ?? 0); ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(s.x - 14, s.y - s.r - 12, 28, 4); ctx.fillStyle = v >= 100 ? '#e0d040' : '#7fae3a'; ctx.fillRect(s.x - 14, s.y - s.r - 12, 28 * v / 100, 4); }
  if (st.has('grabbed')) { ctx.strokeStyle = 'rgba(255,90,90,0.9)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(s.x, s.y, s.r + 4, 0, TAU); ctx.stroke(); }
  for (const k of m.killers) k.power.drawSurvivorMark?.(ctx, s, m);
  if (s.stalk > 0.05 && m.hasPower('shroud')) { ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(s.x - 14, s.y + s.r + 6, 28, 4); ctx.fillStyle = '#ff4b5c'; ctx.fillRect(s.x - 14, s.y + s.r + 6, 28 * s.stalk, 4); }
}
function drawMinionDefault(ctx, n) {
  ctx.save(); ctx.translate(n.x, n.y); ctx.rotate(n.facing);
  ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.ellipse(3, 4, n.r + 2, n.r, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = n.color; ctx.beginPath(); ctx.arc(0, 0, n.r, 0, TAU); ctx.fill();
  ctx.fillStyle = '#111'; ctx.beginPath(); ctx.arc(n.r * 0.5, 0, n.r * 0.3, 0, TAU); ctx.fill();
  ctx.restore();
  if (n.stunT > 0) { ctx.fillStyle = '#ffd27a'; ctx.beginPath(); ctx.arc(n.x, n.y - n.r - 8, 3, 0, TAU); ctx.fill(); }
}
function arrow(ctx, x, y, a, color, size) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(a);
  ctx.fillStyle = color; ctx.strokeStyle = 'rgba(0,0,0,0.6)'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(size, 0); ctx.lineTo(-size * 0.6, -size * 0.65); ctx.lineTo(-size * 0.25, 0); ctx.lineTo(-size * 0.6, size * 0.65); ctx.closePath(); ctx.stroke(); ctx.fill();
  ctx.restore();
}
function label(ctx, x, y, text, color) {
  ctx.font = '600 13px "Saira Condensed", "Arial Narrow", sans-serif'; ctx.textAlign = 'center';
  const w = ctx.measureText(text).width + 10; ctx.fillStyle = 'rgba(8,8,10,0.75)'; ctx.fillRect(x - w / 2, y - 12, w, 17);
  ctx.fillStyle = color; ctx.fillText(text.toUpperCase(), x, y + 1);
}
function edgePoint(w, h, a, pad, padBottom = pad) {
  const cx = w / 2, cy = h / 2, dx = Math.cos(a), dy = Math.sin(a);
  const tx = dx > 0 ? (w - pad - cx) / dx : dx < 0 ? (pad - cx) / dx : Infinity;
  const ty = dy > 0 ? (h - padBottom - cy) / dy : dy < 0 ? (pad + 30 - cy) / dy : Infinity;
  const t = Math.min(tx, ty); return { x: cx + dx * t, y: cy + dy * t };
}
function noisePing(ctx, x, y, age, color, scale = 1) {
  ctx.strokeStyle = color; ctx.lineWidth = 2.5;
  for (let i = 0; i < 2; i++) { const r = (10 + ((age * 40 + i * 14) % 30)) * scale; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.stroke(); }
  ctx.fillStyle = color; ctx.beginPath(); ctx.arc(x, y, 4 * scale, 0, TAU); ctx.fill();
}
