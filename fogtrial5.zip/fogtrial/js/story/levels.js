// Story mode: data-driven scenarios. Every scenario is freely selectable (filters by killer,
// difficulty tier, survivor AI band and map). The original 54 trials keep their chapters;
// the expansion adds themed scenarios for all eight killers. All use the normal match engine.
const CH = [
  { id: 1, name: 'The First Snare', killer: 'trapper', blurb: 'Learn the hunt with the Trapper.' },
  { id: 2, name: 'Chainsaw Season', killer: 'hillbilly', blurb: 'Raw speed. Learn when to rev.' },
  { id: 3, name: 'The Bell Tolls', killer: 'wraith', blurb: 'Stalk unseen. They will listen for the bell.' },
  { id: 4, name: 'Tooled Up', killer: 'mixed', blurb: 'Survivors bring items and real perks.' },
  { id: 5, name: 'Fog Veterans', killer: 'mixed', blurb: 'Experienced survivors who loop and coordinate.' },
  { id: 6, name: 'Last Light', killer: 'mixed', blurb: 'Elite survivors with meta builds and harsh rules.' },
];

// [name, teaches/intro, map, killer(or null=chapter), bots, [dmin,dmax], perkMode, itemMode, gens, kills, rules]
const L = [
  // Chapter 1 — Trapper
  ['Fresh Tracks', 'Move with WASD and aim with the mouse. Find the lone survivor — follow the red scratch marks they leave when they run. Left click to strike.', 'rotwood', null, 1, [1, 1], 'none', 'none', 2, 1, {}],
  ['On the Hook', 'Down a survivor with two hits, press SPACE to pick them up, then carry them to a hook and press SPACE again.', 'rotwood', null, 2, [1, 1], 'none', 'none', 3, 1, {}],
  ['Steel Jaws', 'Hold Q (or right mouse) to set a bear trap in front of you. Place traps in tall grass, by windows and near generators.', 'ashfarm', null, 2, [1, 2], 'none', 'none', 3, 1, {}],
  ['Pallets and Windows', 'Survivors drop pallets to block you. Press SPACE beside a dropped pallet to break it, or beside a window to vault it.', 'rotwood', null, 3, [1, 2], 'basic', 'none', 3, 2, {}],
  ['Kick the Gens', 'Generators you stop guarding get repaired. Press SPACE at a generator to damage it and make it regress.', 'ironworks', null, 3, [2, 2], 'basic', 'none', 4, 2, {}],
  ['Blood and Grunts', 'Injured survivors bleed and groan. Red ripples on screen mark grunts of pain you can hear nearby.', 'ashfarm', null, 4, [2, 2], 'basic', 'none', 4, 2, {}],
  ['The Trapper\'s Garden', 'Survivors who see a trap remember it and route around it. Hide your traps where they cannot see them coming.', 'hollowmarsh', null, 4, [2, 3], 'basic', 'none', 4, 2, {}],
  ['Rescue Party', 'Survivors rescue hooked teammates. Patrol near hooks — but camping lets them repair freely.', 'rotwood', null, 4, [3, 3], 'basic', 'random', 5, 2, {}],
  ['Snare Master', 'A full trial against four beginner survivors.', 'ironworks', null, 4, [3, 3], 'random', 'random', 5, 3, {}],
  // Chapter 2 — Hillbilly
  ['First Rev', 'Hold Q to rev the chainsaw; at full charge you sprint. A chainsaw hit downs instantly. Hitting a wall stops you hard.', 'ashfarm', null, 1, [2, 2], 'none', 'none', 2, 1, {}],
  ['Open Fields', 'Long straight runs are where the chainsaw shines. Survivors will try to break line of sight.', 'ashfarm', null, 2, [2, 3], 'basic', 'none', 3, 1, {}],
  ['Overheat', 'Revving builds heat. Overheat and the saw is out for 12 seconds. Pace your sprints.', 'rotwood', null, 3, [2, 3], 'basic', 'none', 4, 2, {}],
  ['Curve the Saw', 'Steer the sprint with the mouse. Survivors who see you revving start side-stepping.', 'ironworks', null, 3, [3, 4], 'basic', 'none', 4, 2, {}],
  ['Pallet Breakers', 'Survivors pre-drop pallets against the chainsaw. Break them quickly or saw around them.', 'rotwood', null, 4, [3, 4], 'random', 'none', 5, 2, {}],
  ['Night Shift', 'A full trial. Survivors start to read your rev.', 'hollowmarsh', null, 4, [3, 4], 'random', 'random', 5, 2, {}],
  ['Corn Maze', 'Tall crops on the farm hide crouching survivors. Look for scratch marks.', 'ashfarm', null, 4, [4, 4], 'random', 'random', 5, 3, {}],
  ['Hard Stop', 'Survivors loop tight structures where the saw collides. Use basic attacks there.', 'ironworks', null, 4, [4, 5], 'random', 'random', 5, 2, {}],
  ['Chainsaw Season', 'Average survivors with random perks and items.', 'rotwood', null, 4, [4, 5], 'random', 'random', 5, 3, {}],
  // Chapter 3 — Wraith
  ['Ring the Bell', 'Press Q to cloak. Cloaked, you are fast and undetectable but cannot attack. Uncloak rings the bell — survivors hear it.', 'rotwood', null, 2, [3, 3], 'basic', 'none', 3, 1, {}],
  ['Shimmer', 'Up close, sharp survivors spot your shimmer. Uncloak before they notice you.', 'hollowmarsh', null, 3, [3, 4], 'basic', 'none', 4, 2, {}],
  ['Ambush', 'Survivors repair near loops when they cannot track you. Catch them in the open.', 'ashfarm', null, 3, [4, 4], 'basic', 'random', 4, 2, {}],
  ['Silent Hunter', 'No heartbeat while cloaked. Survivors that predict you leave generators early.', 'rotwood', null, 4, [4, 5], 'random', 'random', 5, 2, {}],
  ['Echoes', 'Survivors share what they see. One sighting warns the whole team.', 'ironworks', null, 4, [4, 5], 'random', 'random', 5, 2, {}],
  ['Spine Chill', 'Some survivors carry Spine Chill and feel you watching even while cloaked.', 'hollowmarsh', null, 4, [5, 5], 'strong', 'random', 5, 2, {}],
  ['Whisper Woods', 'Heavy fog shrinks your sight. Trust scratch marks and the bell\'s echo.', 'rotwood', null, 4, [5, 5], 'random', 'random', 5, 2, { heavyFog: true }],
  ['The Long Night', 'A full trial against average survivors.', 'ashfarm', null, 4, [5, 6], 'random', 'random', 5, 3, {}],
  ['The Bell Tolls', 'Good survivors who understand cloaking.', 'ironworks', null, 4, [5, 6], 'random', 'random', 5, 2, {}],
  // Chapter 4 — Tooled up (mixed)
  ['Med-Kits', 'Survivors carry med-kits and heal themselves. Pressure them before they recover.', 'rotwood', 'trapper', 4, [5, 6], 'random', 'medkit', 5, 2, {}],
  ['Toolboxes', 'Toolboxes make generators fly. Prioritize patrols.', 'ironworks', 'wraith', 4, [5, 6], 'random', 'toolbox', 5, 2, {}],
  ['Strong Perks', 'Survivors bring strong perks: Dead Hard, Borrowed Time, Sprint Burst.', 'ashfarm', 'hillbilly', 4, [6, 8], 'strong', 'random', 5, 2, {}],
  ['Flashlights', 'Survivors with flashlights try to blind you during pick-ups. Face a wall when you pick up.', 'rotwood', 'trapper', 4, [6, 6], 'random', 'flashlight', 5, 2, {}],
  ['Keys', 'A survivor with a key can open the hatch early. Close it with SPACE.', 'hollowmarsh', 'wraith', 4, [6, 6], 'random', 'key', 5, 2, {}],
  ['Hex Hunters', 'Bring Hex: Ruin and watch survivors search for your totem.', 'rotwood', 'hillbilly', 4, [6, 7], 'random', 'random', 5, 2, {}],
  ['Mixed Bag', 'Five survivors, more generators.', 'ironworks', 'trapper', 5, [6, 6], 'random', 'random', 6, 3, {}],
  ['Blood Moon', 'Bloodlust builds twice as fast tonight.', 'ashfarm', 'wraith', 4, [6, 7], 'strong', 'random', 5, 2, { bloodMoon: true }],
  ['Tooled Up', 'Good survivors with good gear.', 'rotwood', 'hillbilly', 4, [7, 7], 'strong', 'random', 5, 3, {}],
  // Chapter 5 — Veterans
  ['Loopers', 'Very strong loopers: they greed pallets and chain tiles.', 'ironworks', 'trapper', 4, [7, 8], 'strong', 'random', 5, 2, {}],
  ['Coordinated', 'They call out your position and take protection hits.', 'rotwood', 'wraith', 4, [7, 8], 'strong', 'random', 5, 2, {}],
  ['Short Hooks', 'Hook stages last 40 seconds. Rescues come faster.', 'ashfarm', 'hillbilly', 4, [7, 8], 'strong', 'random', 5, 2, { hardcoreHooks: true }],
  ['Marsh Lights', 'Weak tiles, long dead zones. Make them pay for every mistake.', 'hollowmarsh', 'hillbilly', 4, [8, 8], 'strong', 'random', 5, 3, {}],
  ['Patient Rescuers', 'Survivors wait for you to leave the hook before saving.', 'rotwood', 'trapper', 4, [8, 8], 'meta', 'random', 5, 2, {}],
  ['3-Gen', 'Strong survivors avoid leaving a 3-gen. Can you build one anyway?', 'ironworks', 'wraith', 4, [8, 9], 'meta', 'random', 5, 2, {}],
  ['Started Hurt', 'Survivors start injured — and they will heal fast.', 'ashfarm', 'trapper', 4, [8, 9], 'meta', 'medkit', 5, 3, { startInjured: true }],
  ['Fog Veterans I', 'Very strong survivors.', 'rotwood', 'hillbilly', 4, [8, 9], 'meta', 'random', 5, 2, {}],
  ['Fog Veterans II', 'Very strong survivors on a strong map.', 'ironworks', 'trapper', 4, [9, 9], 'meta', 'random', 5, 2, {}],
  // Chapter 6 — Last Light
  ['No Hatch', 'There is no hatch. Every survivor must leave through a gate.', 'hollowmarsh', 'wraith', 4, [9, 9], 'meta', 'random', 5, 2, { noHatch: true }],
  ['Six Gens', 'Six generators to stop.', 'rotwood', 'hillbilly', 4, [9, 9], 'meta', 'toolbox', 6, 2, {}],
  ['Heavy Fog', 'Your sight is short and they are elite.', 'ashfarm', 'trapper', 4, [9, 10], 'meta', 'random', 5, 2, { heavyFog: true }],
  ['Iron Will', 'Elite survivors on the industrial yard.', 'ironworks', 'wraith', 4, [9, 10], 'meta', 'random', 5, 2, {}],
  ['Short Fuse', 'Hook stages last 40 s and bloodlust builds fast.', 'rotwood', 'hillbilly', 4, [10, 10], 'meta', 'random', 5, 2, { hardcoreHooks: true, bloodMoon: true }],
  ['Five Against One', 'Five elite survivors.', 'hollowmarsh', 'trapper', 5, [10, 10], 'meta', 'random', 6, 3, {}],
  ['The Entity\'s Favourites', 'Elite survivors with full meta builds.', 'ashfarm', 'wraith', 4, [10, 10], 'meta', 'random', 5, 3, {}],
  ['Merciless', 'Kill all four elite survivors.', 'ironworks', 'hillbilly', 4, [10, 10], 'meta', 'random', 5, 4, {}],
  ['Last Light', 'The final trial. Heavy fog, short hooks, elite survivors.', 'rotwood', 'trapper', 4, [10, 10], 'meta', 'random', 5, 3, { heavyFog: true, hardcoreHooks: true }],
];

// Expansion scenarios (object form: lets a scenario pin per-survivor archetypes / builds).
// arch: archetype per survivor · perks: random-build theme (see survivorPerks BUILD_THEMES)
const X = [
  // Ghost Face
  { name: 'Stalker', killer: 'ghostface', map: 'ashfarm', bots: 2, diff: [2, 3], perks: 'basic', items: 'none', gens: 3, kills: 1, intro: 'Press RMB to don the Night Shroud: no heartbeat, hard to see. Hold RMB with a survivor in view to stalk them until they are Marked — then a single hit puts them down.' },
  { name: 'Stealth Test', killer: 'ghostface', map: 'rotwood', bots: 4, diff: [4, 5], perks: 'stealth', items: 'random', gens: 4, kills: 2, intro: 'Survivors who look straight at you for a moment reveal you and break your shroud. Approach from behind cover and from their blind side.' },
  { name: 'Peekaboo', killer: 'ghostface', map: 'hollowmarsh', bots: 4, diff: [6, 6], perks: 'awareness', items: 'random', gens: 5, kills: 2, intro: 'These survivors break line of sight the moment they feel watched. Stalk in short bursts and keep corners between you.' },
  { name: 'Silent Night', killer: 'ghostface', map: 'rotwood', bots: 4, diff: [7, 8], perks: 'stealth', items: 'random', gens: 5, kills: 2, rules: { heavyFog: true }, intro: 'Heavy fog for everyone. Your shroud is strong here — but so is their hiding.' },
  { name: 'Marked for Death', killer: 'ghostface', map: 'ashfarm', bots: 5, diff: [8, 8], perks: 'chase', items: 'random', gens: 6, kills: 3, intro: 'Five strong survivors. Mark them before the chase starts so you never need two hits.' },
  { name: 'The Watchers', killer: 'ghostface', map: 'ironworks', bots: 4, diff: [9, 10], perks: 'awareness', items: 'random', gens: 5, kills: 2, intro: 'Elite survivors call out every glimpse of you and stare you down. Can you still get a Mark?' },
  // Clown
  { name: 'Toxic Chase', killer: 'clown', map: 'rotwood', bots: 2, diff: [2, 3], perks: 'basic', items: 'none', gens: 3, kills: 1, intro: 'Hold RMB to aim a bottle and release to throw. Purple tonic slows and intoxicates anyone inside. Throw it where they will be, not where they are.' },
  { name: 'Gas Station', killer: 'clown', map: 'ironworks', bots: 4, diff: [4, 5], perks: 'objective', items: 'random', gens: 5, kills: 2, intro: 'Lob tonic onto generators to drive survivors off them. Clouds deny an area for eight seconds.' },
  { name: 'Fumes in the Corn', killer: 'clown', map: 'ashfarm', bots: 4, diff: [6, 6], perks: 'random', items: 'random', gens: 5, kills: 2, intro: 'Press E to switch to the yellow antidote: it speeds up everyone inside — you included. Use it to catch up across open fields.' },
  { name: 'Antidote Rush', killer: 'clown', map: 'hollowmarsh', bots: 4, diff: [7, 8], perks: 'chase', items: 'random', gens: 5, kills: 2, intro: 'Chase specialists who route around your clouds. Block loops with gas so they have to run into the open.' },
  { name: 'Carnival of Pain', killer: 'clown', map: 'rotwood', bots: 4, diff: [9, 10], perks: 'meta', items: 'random', gens: 5, kills: 3, intro: 'Elite survivors read every bottle arc. Out-think their routes.' },
  // Executioner
  { name: 'Rites of Judgement', killer: 'executioner', map: 'ashfarm', bots: 2, diff: [2, 3], perks: 'basic', items: 'none', gens: 3, kills: 1, intro: 'RMB toggles Punishment mode: you move slower and leave Torment Trails. In this mode, LMB fires a ground wave that passes through walls.' },
  { name: 'Cage of Atonement', killer: 'executioner', map: 'rotwood', bots: 4, diff: [4, 5], perks: 'random', items: 'random', gens: 4, kills: 2, intro: 'Downed survivors who are Tormented can be sent to a Cage (SPACE) far from you — no need to carry them.' },
  { name: 'No Safe Loop', killer: 'executioner', map: 'ironworks', bots: 4, diff: [6, 7], perks: 'chase', items: 'random', gens: 5, kills: 2, arch: ['looper', 'looper', 'looper', 'wildcard'], intro: 'Strong loopers on strong tiles. Your wave goes through walls — punish them for holding a loop.' },
  { name: 'Torment Trail', killer: 'executioner', map: 'hollowmarsh', bots: 4, diff: [7, 8], perks: 'rescue', items: 'random', gens: 5, kills: 2, intro: 'A rescue-focused team. Lay trails around hooks: anyone who steps on them can be caged.' },
  { name: 'Judgement Day', killer: 'executioner', map: 'ironworks', bots: 4, diff: [10, 10], perks: 'meta', items: 'random', gens: 5, kills: 3, rules: { hardcoreHooks: true }, intro: 'Elite survivors side-step every telegraphed wave. Short hooks.' },
  // Singularity
  { name: 'Surveillance', killer: 'singularity', map: 'rotwood', bots: 3, diff: [3, 3], perks: 'basic', items: 'none', gens: 4, kills: 1, intro: 'Hold and release RMB to shoot a biopod onto a wall. Press E to look through a pod and hold the reticle on a survivor for 0.8 s to Slipstream them.' },
  { name: 'Quantum Leap', killer: 'singularity', map: 'ashfarm', bots: 4, diff: [5, 5], perks: 'random', items: 'random', gens: 5, kills: 2, intro: 'In a pod, lock onto a Slipstreamed survivor and press LMB to teleport to that pod — or shoot a Slipstreamed survivor directly. Each teleport Overclocks you: pallets can\'t stun you.' },
  { name: 'Slipstream', killer: 'singularity', map: 'hollowmarsh', bots: 5, diff: [7, 7], perks: 'random', items: 'random', gens: 6, kills: 3, intro: 'Five survivors across a wide marsh. Keep the pod network up and keep teleporting.' },
  { name: 'EMP Storm', killer: 'singularity', map: 'ironworks', bots: 4, diff: [8, 8], perks: 'objective', items: 'toolbox', gens: 5, kills: 2, intro: 'A disciplined team that prints EMPs to wipe your pods. Guard the printers — or spread out.' },
  { name: 'Overclocked', killer: 'singularity', map: 'rotwood', bots: 4, diff: [9, 10], perks: 'meta', items: 'random', gens: 5, kills: 3, intro: 'Elite survivors avoid pod sightlines and EMP your network early.' },
  // Huntress
  { name: 'First Throw', killer: 'huntress', map: 'ashfarm', bots: 2, diff: [2, 2], perks: 'none', items: 'none', gens: 3, kills: 1, intro: 'Hold RMB to wind up a hatchet, release to throw. A longer wind-up flies faster and further. Reload at lockers with E.' },
  { name: 'Open Season', killer: 'huntress', map: 'ashfarm', bots: 4, diff: [5, 5], perks: 'random', items: 'random', gens: 5, kills: 2, intro: 'Wide fields and few walls. Survivors who stay in the open will eat hatchets.' },
  { name: 'Line of Sight', killer: 'huntress', map: 'rotwood', bots: 4, diff: [7, 7], perks: 'chase', items: 'random', gens: 5, kills: 2, intro: 'Survivors here break line of sight and juke your wind-ups. Throw when they commit to a direction.' },
  { name: 'Lullaby', killer: 'huntress', map: 'hollowmarsh', bots: 4, diff: [8, 8], perks: 'stealth', items: 'random', gens: 5, kills: 2, arch: ['stealth', 'stealth', 'genrusher', 'stealth'], intro: 'Your humming carries far. These survivors hide early — find them before the gens pop.' },
  { name: 'Headhunter', killer: 'huntress', map: 'ironworks', bots: 4, diff: [10, 10], perks: 'meta', items: 'random', gens: 5, kills: 3, intro: 'Elite survivors dodge hatchets at range. Close the distance before you throw.' },
  // Themed mixed scenarios
  { name: 'Rookie Hunt', killer: 'trapper', map: 'rotwood', bots: 4, diff: [1, 1], perks: 'none', items: 'none', gens: 4, kills: 3, intro: 'Four brand-new survivors. A relaxed warm-up.' },
  { name: 'The Loopers', killer: 'hillbilly', map: 'ironworks', bots: 4, diff: [7, 8], perks: 'chase', items: 'random', gens: 5, kills: 2, arch: ['looper', 'looper', 'looper', 'looper'], intro: 'Four loop specialists with chase builds. Learn when to abandon a chase.' },
  { name: 'Generator War', killer: 'clown', map: 'hollowmarsh', bots: 4, diff: [6, 7], perks: 'objective', items: 'toolbox', gens: 5, kills: 2, arch: ['genrusher', 'genrusher', 'genrusher', 'genrusher'], intro: 'A team that only cares about generators. Every second you spend chasing, three gens move.' },
  { name: 'Field Hospital', killer: 'wraith', map: 'ashfarm', bots: 4, diff: [6, 6], perks: 'healing', items: 'medkit', gens: 5, kills: 2, arch: ['medic', 'medic', 'altruist', 'medic'], intro: 'Medics with healing builds. Interrupt heals before they undo your hits.' },
  { name: 'Hero Squad', killer: 'singularity', map: 'rotwood', bots: 4, diff: [7, 7], perks: 'rescue', items: 'random', gens: 5, kills: 2, arch: ['altruist', 'altruist', 'altruist', 'looper'], intro: 'Altruists who come for every hook. Turn their bravery against them.' },
  { name: 'Ghosts in the Fog', killer: 'huntress', map: 'hollowmarsh', bots: 4, diff: [8, 8], perks: 'stealth', items: 'random', gens: 5, kills: 2, rules: { heavyFog: true }, arch: ['stealth', 'stealth', 'stealth', 'stealth'], intro: 'Survivors who would rather hide than run, in heavy fog.' },
  { name: 'Endgame Specialists', killer: 'executioner', map: 'ashfarm', bots: 4, diff: [8, 9], perks: 'endgame', items: 'random', gens: 5, kills: 2, intro: 'They save their perks for the gates. Get your kills before the end.' },
  { name: 'The Final Exam', killer: 'ghostface', map: 'ironworks', bots: 5, diff: [10, 10], perks: 'meta', items: 'random', gens: 6, kills: 3, rules: { hardcoreHooks: true }, intro: 'Five elite survivors with meta builds and short hooks.' },
  // ---------------- Roster expansion: the ten newer killers and five new maps ----------------
  // Legion
  { name: 'Legion Frenzy', killer: 'legion', map: 'rotwood', bots: 3, diff: [2, 3], perks: 'basic', items: 'none', gens: 4, kills: 1, intro: 'Press RMB when the gauge is full to enter Feral Frenzy: you run fast, vault windows and dropped pallets, and every slash on a healthy survivor inflicts Deep Wound and refills the gauge. Chain from survivor to survivor.' },
  { name: 'Mend or Bleed', killer: 'legion', map: 'asylum', bots: 4, diff: [5, 5], perks: 'healing', items: 'medkit', gens: 5, kills: 2, intro: 'Deep Wound bleeds a survivor out unless they mend in time. Medics will try to patch everyone up — keep the pressure on.' },
  { name: 'Spread Thin', killer: 'legion', map: 'grove', bots: 4, diff: [8, 9], perks: 'objective', items: 'random', gens: 5, kills: 2, intro: 'Skilled survivors refuse to group up so you never get an easy chain. Find them one at a time.' },
  // Hag
  { name: "Hag's Web", killer: 'hag', map: 'asylum', bots: 3, diff: [3, 3], perks: 'basic', items: 'none', gens: 4, kills: 1, intro: 'Hold RMB to draw a Phantasm Trap. A survivor walking over it triggers it — press E within 40 m to teleport to the phantom. Crouching survivors pass safely.' },
  { name: 'Mud and Bones', killer: 'hag', map: 'hollowmarsh', bots: 4, diff: [6, 6], perks: 'stealth', items: 'random', gens: 5, kills: 2, intro: 'Trap the hooks and the generators that matter. These survivors crouch through anything they have seen.' },
  { name: 'The Witch Hunt', killer: 'hag', map: 'quarry', bots: 4, diff: [9, 10], perks: 'counter', items: 'random', gens: 5, kills: 3, intro: 'Elite survivors remember every trap and wipe the ones that guard their objectives.' },
  // Cannibal
  { name: "Bubba's Chainsaw", killer: 'cannibal', map: 'ironworks', bots: 3, diff: [2, 3], perks: 'basic', items: 'none', gens: 4, kills: 1, intro: 'Hold RMB for 2 s to rev and release to sweep: you speed up as you carve, and everyone the saw touches goes down. LMB mid-sweep dashes. Hold the rev too long or saw into a wall and you throw a Tantrum.' },
  { name: 'Family Dinner', killer: 'cannibal', map: 'lodge', bots: 4, diff: [5, 6], perks: 'rescue', items: 'random', gens: 5, kills: 3, intro: 'An altruistic group that crowds the hook. Bring the saw to the rescue.' },
  { name: 'Tight Quarters', killer: 'cannibal', map: 'asylum', bots: 4, diff: [8, 8], perks: 'chase', items: 'random', gens: 5, kills: 2, arch: ['looper', 'looper', 'stealth', 'wildcard'], intro: 'Loopers who know your saw is deadly in tight spaces: they pre-drop pallets and take you to the windows.' },
  // Deathslinger
  { name: 'Harpoon Hunt', killer: 'deathslinger', map: 'docks', bots: 3, diff: [3, 3], perks: 'basic', items: 'none', gens: 4, kills: 1, intro: 'Hold RMB to aim down sights and LMB to fire the Redeemer. A speared survivor is reeled in — hit them before the chain snaps on an obstacle. Reload after every shot.' },
  { name: 'Across the Water', killer: 'deathslinger', map: 'docks', bots: 4, diff: [6, 6], perks: 'random', items: 'random', gens: 5, kills: 2, intro: 'The harbour channels give long sightlines. Survivors on bridges are easy targets — if they do not break your aim.' },
  { name: 'Quick Draw', killer: 'deathslinger', map: 'rotwood', bots: 4, diff: [9, 10], perks: 'counter', items: 'random', gens: 5, kills: 2, intro: 'Elite survivors juke your sights and hug cover. Shoot only when they commit.' },
  // Dredge
  { name: 'Darkness Falls', killer: 'dredge', map: 'grove', bots: 3, diff: [3, 4], perks: 'basic', items: 'none', gens: 4, kills: 1, intro: 'Hold RMB to enter the Gloaming and teleport into a locker; LMB returns you to your Remnant. When the gauge fills, Nightfall drowns the map in darkness for 60 s.' },
  { name: 'Locked Out', killer: 'dredge', map: 'lodge', bots: 4, diff: [6, 7], perks: 'objective', items: 'toolbox', gens: 5, kills: 2, intro: 'Survivors lock the lockers next to their generators. Find the ones they forgot.' },
  { name: 'Endless Night', killer: 'dredge', map: 'hollowmarsh', bots: 4, diff: [9, 9], perks: 'stealth', items: 'random', gens: 5, kills: 2, rules: { heavyFog: true }, intro: 'Heavy fog and Nightfall together. Stealthy survivors go quiet when the dark comes.' },
  // Knight
  { name: "The Knight's Guard", killer: 'knight', map: 'ashfarm', bots: 3, diff: [3, 3], perks: 'basic', items: 'none', gens: 4, kills: 1, intro: 'Hold RMB to draw a patrol path, release to summon a Guard; press E to choose Carnifex, Assassin or Jailer. A guard that spots a survivor hunts them down.' },
  { name: 'Patrol Routes', killer: 'knight', map: 'quarry', bots: 4, diff: [6, 6], perks: 'random', items: 'random', gens: 5, kills: 2, intro: 'Send Jailers across generators and Carnifex through pallet loops. Survivors leave the area when they see a patrol.' },
  { name: 'Grab the Standard', killer: 'knight', map: 'ironworks', bots: 4, diff: [9, 10], perks: 'chase', items: 'random', gens: 5, kills: 2, intro: 'Elite survivors run to the guard\'s Standard to end hunts and lead guards through pallets. Use guards to cut off loops, not to chase.' },
  // Cenobite
  { name: 'Chain Hunt', killer: 'cenobite', map: 'asylum', bots: 3, diff: [3, 3], perks: 'basic', items: 'none', gens: 4, kills: 1, intro: 'Steer Possessed Chains with RMB to bind survivors. The Lament Configuration starts a Chain Hunt if nobody solves it — teleport to anyone who tries.' },
  { name: 'Puzzle Box', killer: 'cenobite', map: 'grove', bots: 4, diff: [6, 7], perks: 'objective', items: 'random', gens: 5, kills: 2, intro: 'A team that will solve the box quickly. Interrupt the solver and let the hunt run.' },
  { name: 'Such Sights', killer: 'cenobite', map: 'docks', bots: 4, diff: [9, 10], perks: 'counter', items: 'random', gens: 5, kills: 2, intro: 'Elite survivors break chains on cover and solve the box only where it is safe.' },
  // Mastermind
  { name: 'Virulent Bound', killer: 'mastermind', map: 'lodge', bots: 3, diff: [3, 3], perks: 'basic', items: 'none', gens: 4, kills: 1, intro: 'Hold RMB to charge a bound, release to leap; chain a second, longer bound. Grab survivors and slam them into walls. Bounds spread Uroboros — fully infected survivors go down in one hit.' },
  { name: 'Outbreak', killer: 'mastermind', map: 'ashfarm', bots: 4, diff: [6, 6], perks: 'healing', items: 'random', gens: 5, kills: 2, intro: 'Infected survivors queue at the supply cases for First Aid Spray. Catch them on the way.' },
  { name: 'Dash Lanes', killer: 'mastermind', map: 'docks', bots: 4, diff: [9, 10], perks: 'chase', items: 'random', gens: 5, kills: 2, intro: 'Elite survivors keep obstacles between you and them so no lane is ever clear.' },
  // Houndmaster
  { name: 'Hound Hunt', killer: 'houndmaster', map: 'grove', bots: 3, diff: [3, 3], perks: 'basic', items: 'none', gens: 4, kills: 1, intro: 'Hold RMB to plot a path and LMB to send the dog on a Chase Command; E switches to Search Command. Snug grabs survivors and drags them back to you. Pallets stun the dog.' },
  { name: 'Good Dog', killer: 'houndmaster', map: 'quarry', bots: 4, diff: [6, 6], perks: 'random', items: 'random', gens: 5, kills: 2, intro: 'Search Command reveals survivors along a path. Use it to find who is working on generators.' },
  { name: 'Leash Law', killer: 'houndmaster', map: 'asylum', bots: 4, diff: [9, 10], perks: 'counter', items: 'random', gens: 5, kills: 3, intro: 'Elite survivors track the dog separately from you and stun it with pallets.' },
  // Lich
  { name: 'The Four Spells', killer: 'lich', map: 'grove', bots: 3, diff: [3, 4], perks: 'basic', items: 'none', gens: 4, kills: 1, intro: 'Mouse wheel or 1–4 selects a spell; RMB casts it. Flight of the Damned, Fly, Mage Hand and Dispelling Sphere — survivors loot Magic Items that each counter one.' },
  { name: 'Mage Hand', killer: 'lich', map: 'lodge', bots: 4, diff: [6, 6], perks: 'chase', items: 'random', gens: 5, kills: 2, intro: 'Lift dropped pallets back up and block standing ones. Loopers lose their safety.' },
  { name: 'Vile Darkness', killer: 'lich', map: 'quarry', bots: 4, diff: [9, 10], perks: 'meta', items: 'random', gens: 5, kills: 3, intro: 'Elite survivors watch which spell you hold and play around it.' },
  // Mixed: old killers on new maps, new killers in themed squads
  { name: 'Asylum Snare', killer: 'trapper', map: 'asylum', bots: 4, diff: [5, 5], perks: 'random', items: 'random', gens: 5, kills: 2, intro: 'Doorways are perfect for traps. Survivors learn where you hide them.' },
  { name: 'Harbour Hatchets', killer: 'huntress', map: 'docks', bots: 4, diff: [7, 7], perks: 'chase', items: 'random', gens: 5, kills: 2, intro: 'Long sightlines across the water favour the Huntress — survivors stay behind containers.' },
  { name: 'Tar Pit Saw', killer: 'hillbilly', map: 'quarry', bots: 4, diff: [7, 8], perks: 'random', items: 'random', gens: 5, kills: 2, intro: 'Open lanes across the pit make the chainsaw deadly; the rock ridges stop it cold.' },
  { name: 'Cathedral Bells', killer: 'wraith', map: 'grove', bots: 4, diff: [6, 7], perks: 'stealth', items: 'random', gens: 5, kills: 2, intro: 'Deep woods to sneak through, and survivors who hide in them.' },
  { name: 'Snowblind', killer: 'ghostface', map: 'lodge', bots: 4, diff: [7, 8], perks: 'awareness', items: 'random', gens: 5, kills: 2, rules: { heavyFog: true }, intro: 'The snowfields leave nowhere to stalk from — use the cabins.' },
  { name: 'Container Gas', killer: 'clown', map: 'docks', bots: 4, diff: [6, 6], perks: 'objective', items: 'random', gens: 5, kills: 2, intro: 'Gas the container yards and herd survivors onto the bridges.' },
  { name: 'Pit of Torment', killer: 'executioner', map: 'quarry', bots: 4, diff: [8, 8], perks: 'rescue', items: 'random', gens: 5, kills: 2, intro: 'Trails around the pit cut off every route. The wave crosses the tar.' },
  { name: 'Frozen Pods', killer: 'singularity', map: 'lodge', bots: 4, diff: [8, 9], perks: 'counter', items: 'random', gens: 5, kills: 2, intro: 'Survivors with anti-power builds go straight for the EMP printers.' },
  { name: 'Counter-Squad', killer: 'knight', map: 'asylum', bots: 4, diff: [10, 10], perks: 'counter', items: 'random', gens: 5, kills: 2, arch: ['looper', 'altruist', 'genrusher', 'stealth'], intro: 'Four specialists with anti-power builds. Every guard you send, they will try to exploit.' },
  { name: 'Nightmare Gauntlet', killer: 'dredge', map: 'quarry', bots: 5, diff: [10, 10], perks: 'meta', items: 'random', gens: 6, kills: 3, rules: { hardcoreHooks: true, bloodMoon: true }, intro: 'Five elite survivors, short hooks and Blood Moon. The final exam for the new roster.' },
];

const Y = [
  // Skull Merchant
  { name: 'Eyes in the Sky', killer: 'skull_merchant', map: 'rotwood', bots: 3, diff: [2, 3], perks: 'basic', items: 'none', gens: 4, kills: 1, intro: 'Hold RMB to deploy a drone. Its scan line detects survivors who run through it; three lock-ons attach a claw trap. E recalls a drone and makes you Undetectable.' },
  { name: 'Claw Traps', killer: 'skull_merchant', map: 'ironworks', bots: 4, diff: [5, 6], perks: 'random', items: 'random', gens: 5, kills: 2, intro: 'Claw-trapped survivors show up on your radar whenever a drone scans them. Survivors hack drones to remove them.' },
  { name: 'Dead Zone', killer: 'skull_merchant', map: 'asylum', bots: 4, diff: [9, 10], perks: 'counter', items: 'random', gens: 5, kills: 2, intro: 'Elite survivors crouch under every scan line and hack your network apart.' },
  // Blight
  { name: 'Blighted Rush', killer: 'blight', map: 'quarry', bots: 3, diff: [2, 3], perks: 'basic', items: 'none', gens: 4, kills: 1, intro: 'Press RMB to rush. Slam a wall head-on and press RMB again within 1.25 s for a lethal rush — then LMB to strike.' },
  { name: 'Bounce House', killer: 'blight', map: 'asylum', bots: 4, diff: [5, 6], perks: 'chase', items: 'random', gens: 5, kills: 2, intro: 'Tight corridors are full of walls to slam. Chain rushes through the building.' },
  { name: 'Serum Overdose', killer: 'blight', map: 'docks', bots: 4, diff: [9, 10], perks: 'meta', items: 'random', gens: 5, kills: 3, intro: 'Elite survivors side-step at the last moment and punish every fatigue.' },
  // Nurse
  { name: "Spencer's Last Breath", killer: 'nurse', map: 'lodge', bots: 3, diff: [2, 3], perks: 'basic', items: 'none', gens: 4, kills: 1, intro: 'Hold RMB to charge a blink, release to teleport through walls. Blink again within 1.5 s or attack out of the blink. You are slow and cannot vault.' },
  { name: 'Through the Walls', killer: 'nurse', map: 'ironworks', bots: 4, diff: [5, 6], perks: 'random', items: 'random', gens: 5, kills: 2, intro: 'Pallets and windows mean nothing to you. Predict where they will run.' },
  { name: 'Mind Games', killer: 'nurse', map: 'grove', bots: 4, diff: [9, 10], perks: 'chase', items: 'random', gens: 5, kills: 2, intro: 'Elite survivors double back as your charge ends. Out-guess them.' },
  // Unknown
  { name: 'UVX', killer: 'unknown', map: 'hollowmarsh', bots: 3, diff: [2, 3], perks: 'basic', items: 'none', gens: 4, kills: 1, intro: 'Hold RMB 1 s and release to fire UVX — it bounces once off walls. The burst Weakens; a burst on a Weakened survivor hurts.' },
  { name: 'Hallucinations', killer: 'unknown', map: 'rotwood', bots: 4, diff: [5, 6], perks: 'random', items: 'random', gens: 5, kills: 2, intro: 'E leaves a hallucination; F teleports to it. Survivors stare them down to dispel them.' },
  { name: 'Stare Down', killer: 'unknown', map: 'quarry', bots: 4, diff: [9, 10], perks: 'awareness', items: 'random', gens: 5, kills: 2, intro: 'Elite survivors turn to face you to shake off Weakened — and dodge every bounce.' },
  // Nemesis
  { name: 'T-Virus', killer: 'nemesis', map: 'ironworks', bots: 3, diff: [2, 3], perks: 'basic', items: 'none', gens: 4, kills: 1, intro: 'Hold RMB briefly and release: the tentacle contaminates, and hurts the contaminated. Contaminations raise your Mutation Rate.' },
  { name: 'Outbreak II', killer: 'nemesis', map: 'docks', bots: 4, diff: [5, 6], perks: 'healing', items: 'random', gens: 5, kills: 2, intro: 'Two zombies roam the docks. Survivors queue at the vaccine cases.' },
  { name: 'Mutation Rate 3', killer: 'nemesis', map: 'asylum', bots: 4, diff: [9, 10], perks: 'counter', items: 'random', gens: 5, kills: 3, intro: 'Elite survivors respect the 6.5 m tentacle and pallet-stun your zombies.' },
  // Ghoul
  { name: 'Kagune Leap', killer: 'ghoul', map: 'grove', bots: 3, diff: [2, 3], perks: 'basic', items: 'none', gens: 4, kills: 1, intro: 'Press RMB to leap. Land on a survivor to latch on, then leap again for a grab attack that marks them. Marked survivors make you Enraged.' },
  { name: 'Enraged', killer: 'ghoul', map: 'lodge', bots: 4, diff: [5, 6], perks: 'random', items: 'random', gens: 5, kills: 2, intro: 'While anyone carries the Kagune Mark you have 3 leaps and grab marked survivors instantly. They will mend to remove it.' },
  { name: 'One-Eyed', killer: 'ghoul', map: 'hollowmarsh', bots: 4, diff: [9, 10], perks: 'chase', items: 'random', gens: 5, kills: 3, intro: 'Elite survivors break away after every latch and mend fast. Chain your leaps off the walls.' },
];

const TIERS = ['Easy', 'Normal', 'Hard', 'Very Hard', 'Extreme'];
function rate(maxD, bots, rules, kills) {
  let r = maxD <= 2 ? 0 : maxD <= 4 ? 1 : maxD <= 6 ? 2 : maxD <= 8 ? 3 : 4;
  const extra = (bots >= 5 ? 1 : 0) + Object.keys(rules).length * 0.5 + (kills >= 4 ? 1 : 0) + (maxD >= 9 && kills >= 3 ? 0.5 : 0);
  const stars = Math.min(5, Math.max(1, Math.round(r + 1 + extra * 0.6)));
  return { tier: TIERS[Math.min(4, Math.round(r + extra * 0.4))], stars };
}
export const AI_BANDS = [[1, 2], [3, 4], [5, 6], [7, 8], [9, 10]];
export const DIFF_TIERS = TIERS;

export const STORY_LEVELS = [
  ...L.map((row, i) => {
    const [name, intro, map, killer, bots, diff, perks, items, gens, kills, rules] = row;
    const chapter = CH[Math.min(5, Math.floor(i / 9))];
    const k = killer || chapter.killer;
    return { id: i + 1, chapter: chapter.id, group: chapter.name, name, intro, map, killer: k, survivorBots: bots, survivorDifficulty: diff,
      survivorPerks: perks, survivorItems: items, generatorCount: gens, requiredKills: Math.min(kills, bots), specialRules: rules, ...rate(diff[1], bots, rules, kills) };
  }),
  ...X.map((x, j) => ({ id: L.length + j + 1, chapter: 7, group: 'New Blood', name: x.name, intro: x.intro, map: x.map, killer: x.killer, survivorBots: x.bots, survivorDifficulty: x.diff,
    survivorPerks: x.perks, survivorItems: x.items, generatorCount: x.gens, requiredKills: Math.min(x.kills, x.bots), specialRules: x.rules || {}, archetypes: x.arch || null, ...rate(x.diff[1], x.bots, x.rules || {}, x.kills) })).map((l) => (l.id > L.length + 34 ? { ...l, chapter: 8, group: 'Expanded Roster' } : l)),
  ...Y.map((x, j) => ({ id: L.length + X.length + j + 1, chapter: 9, group: 'Fog Breakers', name: x.name, intro: x.intro, map: x.map, killer: x.killer, survivorBots: x.bots, survivorDifficulty: x.diff,
    survivorPerks: x.perks, survivorItems: x.items, generatorCount: x.gens, requiredKills: Math.min(x.kills, x.bots), specialRules: x.rules || {}, archetypes: x.arch || null, ...rate(x.diff[1], x.bots, x.rules || {}, x.kills) })),
];
for (const l of STORY_LEVELS) l.band = AI_BANDS.findIndex(([a, b]) => l.survivorDifficulty[1] >= a && l.survivorDifficulty[1] <= b);
export const CHAPTERS = [...CH, { id: 9, name: 'Fog Breakers', killer: 'mixed', blurb: 'The Skull Merchant, Blight, Nurse, Unknown, Nemesis and Ghoul.' }, { id: 8, name: 'Expanded Roster', killer: 'mixed', blurb: 'Legion, Hag, Cannibal, Deathslinger, Dredge, Knight, Cenobite, Mastermind, Houndmaster and the Lich, across the five new maps.' }, { id: 7, name: 'New Blood', killer: 'mixed', blurb: 'Scenarios for the Ghost Face, Clown, Executioner, Singularity and Huntress, plus themed survivor squads.' }];

const KEY = 'fogtrial.story.v1';
export function loadProgress() {
  try { const v = JSON.parse(localStorage.getItem(KEY) || 'null'); if (v && typeof v.unlocked === 'number') return v; } catch (e) { /* storage unavailable */ }
  return { unlocked: STORY_LEVELS.length, best: {} };
}
export function saveProgress(p) { try { localStorage.setItem(KEY, JSON.stringify(p)); } catch (e) { /* ignore */ } }
export const PERK_MODE_LABEL = { none: 'None', basic: 'Basic', random: 'Random', strong: 'Strong', meta: 'Meta builds', chase: 'Chase builds', objective: 'Objective builds', stealth: 'Stealth builds', rescue: 'Rescue builds', healing: 'Healing builds', awareness: 'Awareness builds', counter: 'Anti-power builds', endgame: 'Endgame builds' };

// Build a match config from a scenario — the same config format Custom Match uses.
export function levelConfig(level, loadout) {
  const [a, b] = level.survivorDifficulty;
  const diffs = Array.from({ length: level.survivorBots }, (_, i) => Math.round(a + (b - a) * (level.survivorBots === 1 ? 0.5 : i / (level.survivorBots - 1))));
  return {
    mapId: level.map, killerId: level.killer, killerPerks: loadout.perks || [], killerAddons: loadout.addons || [],
    survivorCount: level.survivorBots, difficulties: diffs, perkMode: level.survivorPerks, itemMode: level.survivorItems === 'random' ? 'random' : level.survivorItems === 'none' ? 'none' : level.survivorItems,
    survivors: level.archetypes ? diffs.map((d, i) => ({ difficulty: d, archetype: level.archetypes[i] || null })) : null,
    gensRequired: level.generatorCount, gensOnMap: level.generatorCount + 2, modifiers: level.specialRules, story: level.id,
  };
}

// Random Scenario: a valid combination of killer, map, survivor difficulties, builds, items
// and rules. Difficulty can be pinned to a band; everything else is rolled.
export function randomScenario(killers, maps, band = null) {
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  const k = pick(killers), mp = pick(maps);
  const [lo, hi] = band ?? pick(AI_BANDS);
  const bots = Math.random() < 0.12 ? 5 : Math.random() < 0.15 ? 3 : 4;
  const d0 = lo + Math.floor(Math.random() * (hi - lo + 1)), d1 = Math.min(10, d0 + (Math.random() < 0.5 ? 1 : 0));
  const perks = pick(['random', 'random', 'basic', 'strong', 'meta', 'chase', 'objective', 'stealth', 'rescue', 'healing', 'awareness', 'endgame', 'counter']);
  const items = pick(['random', 'random', 'none', 'medkit', 'toolbox', 'flashlight']);
  const rules = {}; for (const r of ['hardcoreHooks', 'bloodMoon', 'heavyFog', 'noHatch', 'startInjured']) if (Math.random() < 0.12) rules[r] = true;
  const gens = Math.random() < 0.15 ? 6 : Math.random() < 0.2 ? 4 : 5;
  const kills = Math.max(1, Math.min(bots, Math.round(bots * (0.4 + 0.1 * (5 - Math.min(4, Math.floor(d1 / 2.5)))))));
  const arch = Math.random() < 0.3 ? Array.from({ length: bots }, () => pick(['altruist', 'genrusher', 'looper', 'stealth', 'medic', 'wildcard'])) : null;
  const l = { id: 0, chapter: 0, group: 'Random', name: `Random: ${k.short} on ${mp.name}`, intro: 'A randomly generated trial.', map: mp.id, killer: k.id, survivorBots: bots, survivorDifficulty: [d0, d1],
    survivorPerks: perks, survivorItems: items, generatorCount: gens, requiredKills: kills, specialRules: rules, archetypes: arch, random: true, ...rate(d1, bots, rules, kills) };
  l.band = AI_BANDS.findIndex(([a, b]) => d1 >= a && d1 <= b);
  return l;
}
