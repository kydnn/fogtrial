// Game-feel container: particles, floating text, screen shake, flashes. Pure data;
// the renderer draws it. Works headless for tests.
import { M } from './util.js';

export class FX {
  constructor() { this.particles = []; this.texts = []; this.shakeAmt = 0; this.flash = 0; this.flashColor = '255,255,255'; this.hitStop = 0; this.rings = []; }
  update(dt) {
    for (const p of this.particles) { p.t += dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 1 - dt * p.drag; p.vy *= 1 - dt * p.drag; }
    this.particles = this.particles.filter((p) => p.t < p.life);
    for (const t of this.texts) { t.t += dt; t.y -= 18 * dt; }
    this.texts = this.texts.filter((t) => t.t < t.life);
    for (const r of this.rings) r.t += dt; this.rings = this.rings.filter((r) => r.t < r.life);
    this.shakeAmt = Math.max(0, this.shakeAmt - dt * 40);
    this.flash = Math.max(0, this.flash - dt * 2.5);
  }
  burst(x, y, n, color, speed = 120, life = 0.7, size = 3, drag = 3) {
    if (this.particles.length > 900) return;
    for (let i = 0; i < n; i++) { const a = Math.random() * Math.PI * 2, s = speed * (0.3 + Math.random() * 0.7); this.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, t: 0, life: life * (0.6 + Math.random() * 0.6), color, size: size * (0.6 + Math.random() * 0.8), drag }); }
  }
  ring(x, y, color, r = 60, life = 0.6) { this.rings.push({ x, y, color, r, life, t: 0 }); }
  text(x, y, s, color = '#fff', life = 1.3) { this.texts.push({ x, y, s, color, t: 0, life }); }
  shake(a) { this.shakeAmt = Math.max(this.shakeAmt, a); }
  swing(k) { this.ring(k.x + Math.cos(k.facing) * 30, k.y + Math.sin(k.facing) * 30, 'rgba(220,220,220,0.5)', 26, 0.25); }
  hit(s, res) { this.burst(s.x, s.y, res === 'downed' ? 34 : 20, '#a3101e', 190, 0.9, 3.5); this.shake(res === 'downed' ? 9 : 6); this.hitStop = 0.06; this.flash = 0.25; this.flashColor = '160,10,20'; }
  sparks(x, y) { this.burst(x, y, 26, '#ffcf6a', 260, 0.5, 2.2, 5); }
  splinters(x, y) { this.burst(x, y, 30, '#9a7448', 200, 0.8, 3, 4); }
  gen(x, y) { this.burst(x, y, 40, '#ffe7a3', 160, 1.2, 2.5, 2); this.ring(x, y, 'rgba(255,220,140,0.8)', 3 * M, 1.2); }
}
