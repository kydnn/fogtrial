// Central event bus. Perks, scoring, audio, AI memory and UI all subscribe here.
export const EV = {
  GENERATOR_START: 'onGeneratorStart',
  GENERATOR_PROGRESS: 'onGeneratorProgress',
  GENERATOR_REPAIRED: 'onGeneratorComplete',
  GENERATOR_DAMAGED: 'onGeneratorDamaged',
  SKILL_CHECK: 'onSkillCheck',
  SKILL_CHECK_SUCCESS: 'onSkillCheckSuccess',
  SKILL_CHECK_FAILURE: 'onSkillCheckFailure',
  SURVIVOR_INJURED: 'onSurvivorInjured',
  SURVIVOR_DOWNED: 'onSurvivorDowned',
  SURVIVOR_PICKED_UP: 'onSurvivorPickedUp',
  SURVIVOR_DROPPED: 'onSurvivorDropped',
  SURVIVOR_HOOKED: 'onSurvivorHooked',
  SURVIVOR_UNHOOKED: 'onSurvivorUnhooked',
  SURVIVOR_HEALED: 'onSurvivorHealed',
  SURVIVOR_KILLED: 'onSurvivorKilled',
  SURVIVOR_ESCAPED: 'onSurvivorEscaped',
  HOOK_STAGE: 'onHookStage',
  PALLET_DROPPED: 'onPalletDropped',
  PALLET_DESTROYED: 'onPalletDestroyed',
  KILLER_STUNNED: 'onKillerStunned',
  VAULT_PERFORMED: 'onVault',
  KILLER_HIT: 'onKillerHit',
  KILLER_MISS: 'onKillerMiss',
  EXIT_GATES_POWERED: 'onExitGatesPowered',
  EXIT_GATE_OPENED: 'onExitGateOpened',
  ENDGAME_COLLAPSE: 'onEndgameCollapse',
  HATCH_OPENED: 'onHatchOpened',
  HATCH_CLOSED: 'onHatchClosed',
  TRAP_SET: 'onTrapSet',
  TRAP_TRIGGERED: 'onTrapTriggered',
  TRAP_DISARMED: 'onTrapDisarmed',
  TOTEM_CLEANSED: 'onTotemCleansed',
  CHEST_OPENED: 'onChestOpened',
  CHASE_START: 'onChaseStart',
  CHASE_END: 'onChaseEnd',
  LOUD_NOISE: 'onLoudNoise',
  SOUND: 'onSound', // generic world sound survivors may hear
  POWER_USED: 'onPowerUsed',
  SCORE: 'onScore',
};

export class EventBus {
  constructor() { this.map = new Map(); this.log = []; }
  on(name, fn, owner = null) {
    if (!this.map.has(name)) this.map.set(name, []);
    this.map.get(name).push({ fn, owner });
    return () => this.off(name, fn);
  }
  off(name, fn) {
    const l = this.map.get(name); if (!l) return;
    const i = l.findIndex((h) => h.fn === fn); if (i >= 0) l.splice(i, 1);
  }
  offOwner(owner) { for (const l of this.map.values()) for (let i = l.length - 1; i >= 0; i--) if (l[i].owner === owner) l.splice(i, 1); }
  emit(name, data = {}) {
    const l = this.map.get(name);
    if (l) for (const h of [...l]) { try { h.fn(data); } catch (e) { console.error('event handler', name, e); } }
    const any = this.map.get('*');
    if (any) for (const h of [...any]) h.fn({ name, ...data });
  }
}
