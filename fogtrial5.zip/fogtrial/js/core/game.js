// Match: the rules engine and match state machine. DOM-free so it runs headless in tests.
// States: MAP_LOADING → MATCH_START → NORMAL_MATCH → ENDGAME_COLLAPSE → MATCH_END → RESULTS
import { M, dist, clamp, mulberry32, angleDiff, uid } from './util.js';
import { EventBus, EV } from './events.js';
import { FX } from './fx.js';
import { GameMap } from '../maps/map.js';
import { MAPS } from '../maps/maps.js';
import { KILLERS } from '../killers/index.js';
import { Killer } from '../entities/killer.js';
import { Survivor, HOOK_STAGE_TIME } from '../entities/survivor.js';
import { GEN_CHARGES } from '../entities/objects.js';
import { PerkSystem } from '../perks/perkSystem.js';
import { randomSurvivorPerks } from '../perks/survivorPerks.js';
import { ITEM_POOL, ITEM_ADDONS, makeItem } from '../items/items.js';
import { SurvivorAI } from '../ai/survivorAI.js';
import { KillerAI } from '../ai/killer/killerAI.js';
import { Blackboard } from '../ai/blackboard.js';
import { rollPersonality, SURVIVOR_ROSTER } from '../ai/personality.js';
import { install2v8, scaleMapDef, pickCage } from '../modes/twoVeight.js';

export const MATCH_STATES = ['LOBBY', 'LOADOUT', 'MAP_LOADING', 'MATCH_START', 'NORMAL_MATCH', 'ENDGAME_COLLAPSE', 'EXIT', 'MATCH_END', 'RESULTS'];
const COLLAPSE_TIME = 120;

export const DEFAULT_CONFIG = {
  mapId: 'rotwood', seed: null, killerId: 'trapper', killerPerks: [], killerAddons: [],
  survivorCount: 4, difficulty: 5, difficulties: null, perkMode: 'random', itemMode: 'random', survivors: null,
  gensRequired: 5, gensOnMap: 7, hookCount: null, gateCount: 2, modifiers: {},
  // Roles: 'killer' (player controls killers[0]), 'survivor' (player controls survivors[0]),
  // 'spectate' (everyone is a bot). killers: optional [{ killerId, perks, addons, difficulty }].
  playerRole: 'killer', killers: null, killerDifficulty: 5, mode: '1v4',
};

export class Match {
  constructor(config = {}, deps = {}) {
    this.cfg = { ...DEFAULT_CONFIG, ...config, modifiers: { ...(config.modifiers || {}) } };
    this.audio = deps.audio || null;
    this.state = 'MAP_LOADING'; this.stateT = 0; this.time = 0; this.realTime = 0;
    this.events = new EventBus(); this.fx = new FX();
    this.rng = mulberry32(this.cfg.seed ?? Math.floor(Math.random() * 1e9));
    const def0 = MAPS[this.cfg.mapId] || MAPS.rotwood;
    const def = this.cfg.mode === '2v8' ? scaleMapDef(def0) : def0;
    this.map = deps.map || new GameMap(def, { seed: this.cfg.seed ?? Math.floor(this.rng() * 1e9), gens: this.cfg.gensOnMap, hooks: this.cfg.hookCount ?? undefined, gates: this.cfg.gateCount });
    this.world = this.map.world;
    this.gensNeeded = Math.min(this.cfg.gensRequired, this.map.gens.length); this.gensDone = 0; this.gatesPowered = false;
    this.collapse = false; this.collapseT = COLLAPSE_TIME;
    this.hookStageTime = this.cfg.modifiers.hardcoreHooks ? 40 : HOOK_STAGE_TIME;
    this.traps = []; this.projectiles = []; this.zones = []; this.devices = []; this.minions = []; this.scratches = []; this.blood = []; this.grunts = []; this.sounds = []; this.loudNoises = [];
    this.reveals = []; this.killerReveals = []; this.aiLog = []; this.feed = []; this.notify = [];
    this.score = { brutality: 0, deviousness: 0, hunter: 0, sacrifice: 0 };
    this.pathBudget = 6; this.aiPaused = false; this.camping = 0;
    // bot think-rate scale (Settings → Simulation detail): lower = cheaper on big matches
    const perf = this.cfg.perf || 'high'; this.thinkScale = perf === 'low' ? 0.6 : perf === 'balanced' && this.cfg.mode === '2v8' ? 0.75 : 1;
    this.perks = new PerkSystem(this);
    this.bb = new Blackboard(this);
    this.hatch = this.map.hatch;
    // Killers. killers[0] is the primary killer (the player's in killer mode); 2v8 adds a second.
    const kcfg = this.cfg.killers || [{ killerId: this.cfg.killerId, perks: this.cfg.killerPerks, addons: this.cfg.killerAddons, difficulty: this.cfg.killerDifficulty }];
    this.killers = kcfg.map((c, i) => {
      const kd = KILLERS[c.killerId] || KILLERS.trapper;
      const k = new Killer(kd, kd.Power, { addons: c.addons || [] }); k.index = i; k.team = i;
      const sp = i === 0 ? this.map.spawn.killer : this.map.spawn.killer2 || this.farSpawn(this.map.spawn.killer);
      k.x = sp.x; k.y = sp.y;
      this.perks.register(k, (c.perks || []).slice(0, 4));
      k.botDifficulty = c.difficulty ?? this.cfg.killerDifficulty;
      k.isPlayer = !!c.human || (i === 0 && this.cfg.playerRole === 'killer');
      return k;
    });
    this.killer = this.killers[0];
    // Survivors
    this.survivors = [];
    let roster = [...SURVIVOR_ROSTER].sort(() => this.rng() - 0.5);
    // the player's chosen character comes first; bots never share their name
    const pn = this.cfg.playerRole === 'survivor' ? (this.cfg.playerName || this.cfg.survivors?.[0]?.name) : null;
    if (pn) { const me = roster.find((r) => r.name === pn); if (me) roster = [me, ...roster.filter((r) => r !== me)]; }
    const n = this.cfg.survivors ? this.cfg.survivors.length : this.cfg.survivorCount;
    for (let i = 0; i < n; i++) {
      const sc = this.cfg.survivors?.[i] || {};
      const diff = sc.difficulty ?? this.cfg.difficulties?.[i] ?? this.cfg.difficulty;
      const pers = rollPersonality(this.rng, sc.archetype || null);
      const item = sc.item === 'random' ? ITEM_POOL[Math.floor(this.rng() * ITEM_POOL.length)] : sc.item !== undefined ? sc.item : this.cfg.itemMode === 'none' ? null : this.cfg.itemMode === 'random' ? ITEM_POOL[Math.floor(this.rng() * ITEM_POOL.length)] : this.cfg.itemMode;
      let addons = sc.itemAddons || [];
      if (!sc.itemAddons && this.cfg.itemAddons === 'random' && item) { const pool = Object.values(ITEM_ADDONS).filter((a) => a.item === item); if (pool.length) addons = [pool[Math.floor(this.rng() * pool.length)].id]; }
      const sv = new Survivor({ name: (i === 0 && pn) || sc.name || roster[i % roster.length].name, color: roster[i % roster.length].color, difficulty: diff, personality: pers, item, itemAddons: addons });
      const sp = this.map.spawn.survivors[i % this.map.spawn.survivors.length];
      sv.x = sp.x + (i >= 4 ? 20 : 0); sv.y = sp.y;
      const perkIds = sc.perks || randomSurvivorPerks(this.rng, sc.perkMode || this.cfg.perkMode, i);
      this.perks.register(sv, perkIds);
      if (sc.human || (i === 0 && this.cfg.playerRole === 'survivor')) { sv.isPlayer = true; if (!sc.human) sv.name = this.cfg.playerName || sv.name; } else new SurvivorAI(sv, this, diff, pers);
      if (this.cfg.modifiers.startInjured) sv.health = 'injured';
      this.survivors.push(sv);
    }
    if (this.cfg.mode === '2v8') install2v8(this);
    for (const k of this.killers) k.power.onInit?.(this);
    // Killer bots: every killer the player does not control gets the killer AI.
    for (const k of this.killers) if (!k.isPlayer) k.bot = new KillerAI(k, this, k.botDifficulty);
    this.perks.init();
    this.wireEvents();
    this.setState('MATCH_START');
  }

  setState(s) { this.state = s; this.stateT = 0; this.events.emit('state', { state: s }); }

  // ------------------------------------------------------------ event wiring
  wireEvents() {
    const E = this.events, sc = (cat, pts, label) => this.addScore(cat, pts, label);
    E.on(EV.KILLER_HIT, (d) => { sc('brutality', d.result === 'downed' ? 500 : 300, d.result === 'downed' ? 'Down' : 'Hit'); this.endChaseOn(d.survivor, d.killer); if (this.time - d.survivor.unhookedAt < 30) this.bb.model.tunnels++; if (!d.survivor.hasPerk('calm_spirit')) this.audio?.play('scream'); });
    E.on(EV.SURVIVOR_DOWNED, (d) => { (d.killer || this.nearestKiller(d.survivor.x, d.survivor.y)).stats.downs++; this.notifyK(`${d.survivor.name} is down`); });
    E.on(EV.GENERATOR_REPAIRED, (d) => { this.loudNoise(d.gen.x, d.gen.y, 'gen'); this.notifyK(`Generator ${d.gen.name} repaired`); });
    E.on(EV.PALLET_DESTROYED, () => sc('brutality', 100, 'Break'));
    E.on(EV.GENERATOR_DAMAGED, () => sc('brutality', 100, 'Damage'));
    E.on(EV.SURVIVOR_HOOKED, () => sc('sacrifice', 500, 'Hooked'));
    E.on(EV.SURVIVOR_KILLED, (d) => sc('sacrifice', 1000, d.how === 'hook' ? 'Sacrificed' : 'Killed'));
    E.on(EV.TRAP_TRIGGERED, (d) => { sc('deviousness', 400, 'Trap catch'); if (d.survivor) E.emit('powerTriggered', { survivor: d.survivor, x: d.survivor.x, y: d.survivor.y, trap: d.trap }); });
    E.on(EV.KILLER_STUNNED, (d) => { this.endBloodlust(d.killer); });
    E.on(EV.CHASE_START, () => { sc('hunter', 100, 'Chase'); });
    E.on(EV.POWER_USED, (d) => { if (d.power === 'uncloaked' || d.power === 'sprint') sc('deviousness', 50, d.power === 'sprint' ? 'Rev' : 'Ambush'); });
  }
  addScore(cat, pts, label) { this.score[cat] += pts; this.feed.push({ t: this.time, cat, pts, label }); if (this.feed.length > 8) this.feed.shift(); }
  notifyK(text, color = '#e8e2d6') { this.notify.push({ t: this.time, text, color }); if (this.notify.length > 4) this.notify.shift(); }

  // ------------------------------------------------------------ helpers
  aliveCount() { return this.survivors.filter((s) => s.alive).length; }
  // --- multi-killer helpers ---
  nearestKiller(x, y) { let best = this.killers[0], bd = Infinity; for (const k of this.killers) { const d = dist(k.x, k.y, x, y); if (d < bd) { bd = d; best = k; } } return best; }
  killerDist(x, y) { const k = this.nearestKiller(x, y); return dist(k.x, k.y, x, y); }
  killerWith(method) { return this.killers.find((k) => typeof k.power[method] === 'function') || this.killer; }
  hasPower(id) { return this.killers.some((k) => k.power.id === id); }
  carrier(s) { return this.killers.find((k) => k.carrying === s) || null; }
  inChase(s) { return this.killers.some((k) => k.chaseTarget === s); }
  get chaseTarget() { return this.killer.chaseTarget || null; }
  get player() { return this.cfg.playerRole === 'survivor' ? this.survivors.find((s) => s.isPlayer) : this.cfg.playerRole === 'killer' ? this.killer : null; }
  farSpawn(from) {
    const spots = this.map.openSpots(10, 6, []); let best = null, bd = -1;
    for (const p of spots) { const d = dist(p.x, p.y, from.x, from.y); if (d > bd) { bd = d; best = p; } }
    return best || { x: this.map.w - from.x, y: this.map.h - from.y };
  }
  // Sounds are attributed to the killer that made them (or the nearest one) so each survivor
  // belief only reacts to its own killer's cues.
  sound(type, x, y, radius, data = {}) { this.sounds.push({ type, x, y, radius, t: this.time, data, src: data.killer || (this.killers ? this.nearestKiller(x, y) : null) }); }
  quiet(s) { const p = s.perks?.find((q) => q.id === 'quick_and_quiet'); if (!p || p.cooldownT > 0) return false; p.cooldownT = 20; this.perks.proc(p, 'Quick & Quiet'); return true; }
  loudNoise(x, y, kind) { this.loudNoises.push({ x, y, t: this.time, kind }); if (this.loudNoises.length > 20) this.loudNoises.shift(); }
  reveal(target, dur, label, silent = false) {
    if (target && target.perks && target.ai && this.auraShield(target, label)) return;
    const r = this.reveals.find((q) => q.target === target && q.label === label);
    if (r) r.until = Math.max(r.until, this.time + dur); else this.reveals.push({ target, until: this.time + dur, label, silent });
  }
  // Distortion / Sole Survivor: a survivor's aura reveal can be blocked by tokens.
  auraShield(s, label) {
    const key = label + ':' + Math.floor(this.time); if (s._lastShield === key) return true;
    const d = s.perks.find((p) => p.id === 'distortion' && p.charges > 0) || (this.aliveCount() === 1 && s.perks.find((p) => p.id === 'sole_survivor' && p.tokens > 0));
    if (!d) return false;
    if (d.id === 'distortion') d.charges--; else d.tokens--;
    s._lastShield = key; s.noScratchUntil = this.time + 10; this.perks.proc(d, d.def.name); s.ai?.note(`${d.def.name} hid my aura`, 'aurashield'); return true;
  }
  // Directional warnings for the human survivor (Spine Chill, Premonition, hums, …).
  warn(s, text, dir = null) { if (!s.isPlayer) return; (s.warnings ||= []).push({ t: this.time, text, dir }); if (s.warnings.length > 4) s.warnings.shift(); }
  revealKillerTo(s, dur, label, k = null) { this.killerReveals.push({ to: s, until: this.time + dur, label, killer: k }); }
  killerRevealedTo(s, k = null) { return this.killerReveals.some((r) => r.to === s && r.until > this.time && (!k || !r.killer || r.killer === k)); }
  lightHex(id) {
    const free = this.map.totems.filter((t) => !t.hex && !t.cleansed); if (!free.length) return null;
    const t = free[Math.floor(this.rng() * free.length)]; t.hex = id; return t;
  }
  addScratch(s) { if ((s.noScratchUntil || 0) > this.time) return; if (s.hasPerk('low_profile') && this.aliveCount() === 1) return; const life = 7 * this.perks.killerProduct('scratchLife') * (s.hasPerk('lightweight') ? 0.55 : 1); const a = Math.random() * Math.PI * 2, r = Math.random() * 0.8 * M; this.scratches.push({ life, x: s.x + Math.cos(a) * r, y: s.y + Math.sin(a) * r, t: this.time, a: Math.random() * Math.PI, sv: s }); }
  addBlood(s) { if ((s.silentUntil || 0) > this.time || (s.hasPerk('low_profile') && this.aliveCount() === 1)) return; const lb = s.perks?.find((q) => q.id === 'lucky_break'); if (lb && s.health === 'injured' && (lb.data.used || 0) < 180) return; this.blood.push({ life: 12 * this.perks.killerProduct('bloodLife'), x: s.x + (Math.random() - 0.5) * 12, y: s.y + (Math.random() - 0.5) * 12, t: this.time, r: 2 + Math.random() * 3 }); }
  addGrunt(s, color = null) { this.grunts.push({ x: s.x, y: s.y, t: this.time, sv: s, color }); }
  // --- power framework hooks (see killers/framework.js) ---
  spawnProjectile(p) { this.projectiles.push(p); return p; }
  addMinion(n) { this.minions.push(n); return n; }
  removeMinion(n) { n.dead = true; this.minions = this.minions.filter((q) => q !== n); }
  updateMinions(dt) { for (const n of this.minions) { if (n.stunT > 0) { n.stunT -= dt; n.vx = n.vy = 0; continue; } n.update?.(dt, this); } this.minions = this.minions.filter((n) => !n.dead); }
  addZone(z) { this.zones.push(z); if (this.zones.length > 320) this.zones.splice(0, this.zones.length - 320); return z; }
  addDevice(d) { this.devices.push(d); return d; }
  removeDevice(d) { d.dead = true; this.devices = this.devices.filter((q) => q !== d); }
  updateProjectiles(dt) { for (const p of this.projectiles) p.update(dt, this); this.projectiles = this.projectiles.filter((p) => !p.dead); }
  updateZones(dt) {
    const t = this.time; this.zones = this.zones.filter((z) => z.until > t);
    for (const z of this.zones) {
      if (!z.armed(this)) continue;
      if (z.effect) for (const s of this.survivors) if (s.standing && z.contains(s.x, s.y)) z.effect(s, dt, this, z);
      if (z.killerEffect) for (const k of this.killers) if (z.contains(k.x, k.y) && (!z.owner || z.owner === k)) z.killerEffect(k, dt, this, z);
    }
  }
  zonesAt(x, y, pad = 0) { return this.zones.filter((z) => z.armed(this) && z.contains(x, y, pad)); }
  // Send a dying survivor straight to a hook (Executioner's cage). Prefers a far hook.
  cageSurvivor(s, minDist = 24 * M, k = this.carrier(s) || this.killer) { const free = this.map.hooks.filter((h) => !h.survivor && !h.broken);
    if (!free.length || s.health !== 'dying') return false;
    const far = free.filter((h) => dist(h.x, h.y, k.x, k.y) > minDist);
    const pool = far.length ? far : free; const h = pool[Math.floor(this.rng() * pool.length)];
    h.cage = true; k.carrying = s; s.health = 'carried'; this.hookSurvivor(h, true, k); return true;
  }

  // ------------------------------------------------------------ main update
  update(dt) {
    this.realTime += dt; this.stateT += dt;
    if (this.fx.hitStop > 0) { this.fx.hitStop -= dt; dt *= 0.15; }
    this.fx.update(dt);
    if (this.state === 'MATCH_START') { if (this.stateT > 2.6) { this.setState('NORMAL_MATCH'); this.events.emit('matchStart', {}); } return; }
    if (this.state === 'MATCH_END') { if (this.stateT > 2.5) this.setState('RESULTS'); return; }
    if (this.state === 'RESULTS') return;
    this.time += dt;
    this.pathBudget = 6;
    for (const k of this.killers) {
      if (k.bot && !this.aiPaused) k.bot.update(dt);
      k.update(dt, this);
      k.power.tick?.(dt, this);
    }
    if (this.playerCtls) for (const c of this.playerCtls) c.update(dt); else this.playerCtl?.update(dt);
    this.updateMinions(dt);
    this.updateProjectiles(dt); this.updateZones(dt);
    for (const s of this.survivors) { if (s.ai) s.ai.update(dt); s.update(dt, this); }
    this.separateSurvivors();
    this.perks.update(dt);
    this.updateCarry(dt); this.updateHooks(dt); this.updateGens(dt); this.updateTraps(dt);
    this.updateChase(dt); this.updateGates(dt); this.updatePallets();
    // decay lists
    const t = this.time;
    if (this.scratches.length > 400) this.scratches.splice(0, this.scratches.length - 400);
    this.scratches = this.scratches.filter((q) => t - q.t < q.life);
    this.blood = this.blood.filter((q) => t - q.t < q.life);
    this.grunts = this.grunts.filter((q) => t - q.t < 1.2);
    this.sounds = this.sounds.filter((q) => t - q.t < 1.5);
    this.loudNoises = this.loudNoises.filter((q) => t - q.t < 3);
    this.reveals = this.reveals.filter((q) => q.until > t && (q.target.kind !== 'survivor' || q.target.alive));
    this.killerReveals = this.killerReveals.filter((q) => q.until > t);
    this.map.refreshTileSafety(t);
    // end check
    if (this.survivors.every((s) => !s.alive)) { this.setState('MATCH_END'); this.events.emit('matchEnd', {}); }
  }

  // ------------------------------------------------------------ killer interactions
  killerContext(k = this.killer) {
    if (k.action || k.stunT > 0) return null;
    const pc = k.power.context?.(this); if (pc) return pc;
    if (k.power.noContext?.(this)) return null;
    const cloaked = k.power.id === 'cloak' && k.power.state !== 'visible';
    const near = (o, r) => dist(k.x, k.y, o.x, o.y) < r * M;
    if (k.carrying) {
      let best = null, bd = 2.2 * M;
      for (const h of this.map.hooks) { if (h.survivor || h.broken) continue; const d = dist(k.x, k.y, h.x, h.y); if (d < bd) { bd = d; best = h; } }
      return best ? { type: 'hook', target: best, label: 'Hook survivor' } : null;
    }
    if (!cloaked) for (const s of this.survivors) if (s.health === 'dying' && near(s, 1.9) && !this.killers.some((q) => q !== k && q.action?.type === 'pickup' && q.action.target === s)) return { type: 'pickup', target: s, label: `Pick up ${s.name}` };
    if (!cloaked) for (const p of this.map.pallets) if (p.state === 'down' && dist(k.x, k.y, p.x, p.y) < Math.max(p.len / 2, 1.2 * M) + 0.8 * M && Math.abs((k.x - p.x) * p.nx + (k.y - p.y) * p.ny) < 1.5 * M) return { type: 'break', target: p, label: 'Break pallet' };
    if (!k.power.noVault?.()) for (const w of this.map.windows) if (near(w, 1.7) && w.killerBlockedUntil <= this.time && Math.abs((k.x - w.x) * w.nx + (k.y - w.y) * w.ny) > 0.4 * M) return { type: 'vault', target: w, label: 'Vault' };
    if (!cloaked) for (const g of this.map.gens) if (!g.done && g.charges > 0 && !g.regressing && g.repairers.size === 0 && near(g, 2.3)) return { type: 'kick', target: g, label: 'Damage generator' };
    if (!cloaked && this.hatch.state === 'open' && near(this.hatch, 1.8)) return { type: 'closeHatch', target: this.hatch, label: 'Close hatch' };
    return null;
  }
  separateKiller(k = this.killer) {
    for (const s of this.survivors) {
      if (!s.standing || s.vault) continue;
      const d = dist(k.x, k.y, s.x, s.y), r = k.r + s.r - 2;
      if (d < r && d > 0.01) { const p = (r - d); k.x += (k.x - s.x) / d * p; k.y += (k.y - s.y) / d * p; }
    }
  }
  separateSurvivors() {
    const L = this.survivors.filter((s) => s.standing && !s.vault);
    for (let i = 0; i < L.length; i++) for (let j = i + 1; j < L.length; j++) {
      const a = L[i], b = L[j]; const d = dist(a.x, a.y, b.x, b.y), r = a.r + b.r;
      if (d < r && d > 0.01) { const p = (r - d) / 2; const nx = (a.x - b.x) / d, ny = (a.y - b.y) / d; a.x += nx * p; a.y += ny * p; b.x -= nx * p; b.y -= ny * p; }
    }
  }

  kickGenerator(g, k = this.killer) {
    if (g.done) return;
    g.charges = Math.max(0, g.charges - GEN_CHARGES * 0.025); g.regressing = g.charges > 0; g.kickT = this.time;
    k.stats.kicks++;
    this.sound('killer_action', g.x, g.y, 30 * M, { what: 'kick' });
    this.events.emit(EV.GENERATOR_DAMAGED, { gen: g, killer: k }); this.audio?.play('kick'); this.fx.sparks(g.x, g.y);
  }
  breakPallet(p, k = this.killer) {
    if (p.state !== 'down') return;
    p.state = 'broken'; this.world.remove(p.solid); k.stats.palletsBroken++;
    this.bb.model.palletBreaks++; p.breakCounted = true;
    this.sound('killer_action', p.x, p.y, 36 * M, { what: 'break' });
    this.events.emit(EV.PALLET_DESTROYED, { pallet: p, killer: k }); this.fx.splinters(p.x, p.y); this.fx.shake(5); this.audio?.play('break');
    this.endBloodlust(k);
  }
  pickUp(s, k = this.killer) {
    if (s.health !== 'dying' || this.carrier(s)) return;
    // Decisive Strike: anti-tunnel escape with a skill check
    if (s.hasPerk('decisive_strike') && this.time - s.unhookedAt < 40 && !s.dsUsed) {
      s.dsUsed = true;
      const p = 0.45 + 0.5 * (s.ai ? s.ai.params.dodge : 0.5);
      if (Math.random() < p) { s.health = 'injured'; s.status.add('deepWound', { duration: 20 }); k.stun(this, 4, 'ds'); this.fx.text(s.x, s.y - 30, 'DECISIVE STRIKE', '#ffd27a'); s.ai?.note('Hit Decisive Strike', 'ds'); this.notifyK(`${s.name} used Decisive Strike`); return; }
    }
    s.health = 'carried'; s.wiggle = 0; s.carriedSince = this.time; s.stopAction(this); s.healers.clear();
    k.carrying = s;
    this.events.emit(EV.SURVIVOR_PICKED_UP, { survivor: s, killer: k });
    this.audio?.play('pickup');
  }
  dropCarried(reason, k = this.killer) {
    const s = k.carrying; if (!s) return;
    k.carrying = null;
    const a = k.facing + Math.PI; s.x = k.x + Math.cos(a) * 0.9 * M; s.y = k.y + Math.sin(a) * 0.9 * M;
    this.world.resolve(s, s.r);
    if (reason === 'drop') { s.health = 'dying'; }
    else { s.health = 'injured'; s.status.add('haste', { duration: 3, value: 0.3, source: 'escape' }); this.fx.text(s.x, s.y - 30, reason === 'wiggle' ? 'WIGGLED FREE' : 'SAVED', '#ffd27a'); s.ai?.note(reason === 'wiggle' ? 'Wiggled free' : 'Got saved from the carry', 'wiggle'); }
    this.events.emit(EV.SURVIVOR_DROPPED, { survivor: s, reason, killer: k });
    if (reason === 'wiggle') k.stun(this, 3, 'wiggle');
  }
  updateCarry(dt) { for (const k of this.killers) this.updateCarryFor(dt, k); }
  updateCarryFor(dt, k) {
    const s = k.carrying; if (!s) return;
    s.x = k.x - Math.cos(k.facing) * 0.4 * M; s.y = k.y - Math.sin(k.facing) * 0.4 * M;
    const breakout = this.survivors.some((o) => o !== s && o.standing && o.hasPerk('breakout') && dist(o.x, o.y, k.x, k.y) < 6 * M);
    // Bots wiggle automatically; the human survivor's controller adds wiggle by alternating keys.
    if (!s.isPlayer) s.wiggle += dt / (16 * this.perks.killerProduct('wiggleMult', k)) * (breakout ? 1.2 : 1) * (s.hasPerk('boil_over') ? 1.25 : 1);
    else s.wiggleMult = (breakout ? 1.2 : 1) * (s.hasPerk('boil_over') ? 1.25 : 1) / this.perks.killerProduct('wiggleMult', k);
    if (s.wiggle >= 1) this.dropCarried('wiggle', k);
  }
  hookSurvivor(h, caged = false, k = this.killer) {
    const s = k.carrying; if (!s || h.survivor) return;
    // 2v8: hooking sends the survivor to a cage somewhere else on the map
    if (this.is2v8 && !caged) { const c = pickCage(this, h); if (c && c !== h) { c.cage = true; return this.hookSurvivor(c, true, k); } }
    if (!caged) h.cage = false;
    k.carrying = null; k.stats.hooks++;
    s.health = 'hooked'; s.hook = h; h.survivor = s; s.x = h.x; s.y = h.y + 0.5 * M; s.hookCount++; s.hookedAt = this.time; s.unhookAttempts = 0;
    this.bb.model.hooks++; this.lastHook = { s, t: this.time, h, campT: 0 };
    if (s.hookStage >= 2) { this.events.emit(EV.SURVIVOR_HOOKED, { survivor: s, hook: h, killer: k }); this.killSurvivor(s, 'hook'); return; }
    s.hookStage++; s.hookTimer = 0;
    this.events.emit(EV.SURVIVOR_HOOKED, { survivor: s, hook: h, killer: k });
    this.fx.burst(h.x, h.y, 30, '#c9a46a', 120, 1.5, 2.5, 1); this.audio?.play('hook');
    this.notifyK(`${s.name} ${caged ? 'caged' : 'hooked'} (${s.hookStage === 1 ? 'first' : 'second'} stage)`);
  }
  updateHooks(dt) {
    for (const s of this.survivors) {
      if (s.health !== 'hooked') continue;
      if ((s.hookPauseUntil || 0) > this.time) continue;
      s.hookTimer += dt;
      if (s.hookStage >= 2) {
        // Struggle phase: skill checks; failures cost time
        s._strT = (s._strT ?? 4) - dt;
        if (s._strT <= 0) { s._strT = 3 + Math.random() * 4; if (s.isPlayer) this.startPlayerCheck(s, 'struggle', s.hook); else { const fail = s.ai ? s.ai.params.scFail * 0.6 : 0.1; if (Math.random() < fail) s.hookTimer += 8; } }
      }
      if (s.hookTimer >= this.hookStageTime) {
        if (s.hookStage === 1) { s.hookStage = 2; s.hookTimer = 0; this.events.emit(EV.HOOK_STAGE, { survivor: s, stage: 2 }); this.notifyK(`${s.name} entered struggle phase`); }
        else this.killSurvivor(s, 'hook');
      }
    }
    // camping tracker (survivors infer it from the killer lingering by the hook)
    if (this.lastHook && this.lastHook.s.health === 'hooked' && this.killerDist(this.lastHook.h.x, this.lastHook.h.y) < 12 * M) {
      this.lastHook.campT += dt; if (this.lastHook.campT > 15 && !this.lastHook.counted) { this.lastHook.counted = true; this.bb.model.camping++; }
    }
  }
  unhook(s, rescuer) {
    if (s.health !== 'hooked') return;
    const h = s.hook; h.survivor = null; s.hook = null;
    s.health = 'injured'; s.healProgress = 0; s.unhookedAt = this.time;
    if (rescuer) { const a = Math.atan2(rescuer.y - h.y, rescuer.x - h.x); s.x = h.x + Math.cos(a) * 0.9 * M; s.y = h.y + Math.sin(a) * 0.9 * M; rescuer.stats.unhooks++; }
    else { s.x = h.x; s.y = h.y + 0.9 * M; }
    this.world.resolve(s, s.r);
    s.status.add('endurance', { duration: 10, source: 'unhook' }); s.status.add('haste', { duration: 10, value: 0.07, source: 'unhook' });
    this.events.emit(EV.SURVIVOR_UNHOOKED, { survivor: s, rescuer });
    this.notifyK(rescuer ? `${rescuer.name} unhooked ${s.name}` : `${s.name} escaped the hook`, '#cfe3e3');
    this.audio?.play('unhook');
  }
  selfUnhook(s) { this.unhook(s, null); }
  selfUnhookAttempt(s) {
    s.unhookAttempts++;
    if (Math.random() < (s.hasPerk('slippery_meat') ? 0.12 : 0.04)) { this.unhook(s, null); s.ai?.note('Lucky self-unhook!', 'luck'); }
    else s.hookTimer += 20;
  }
  killSurvivor(s, how) {
    if (s.health === 'dead') return;
    if (s.hook) { s.hook.survivor = null; s.hook = null; }
    for (const k of this.killers) if (k.carrying === s) k.carrying = null;
    if (s.trap) { s.trap.victim = null; s.trap.state = 'unset'; s.trap = null; }
    s.stopAction(this); s.health = 'dead'; s.outcome = how === 'hook' ? 'Sacrificed' : how === 'collapse' ? 'Killed by the Fog' : 'Killed';
    this.bb.release(s);
    this.events.emit(EV.SURVIVOR_KILLED, { survivor: s, how });
    this.fx.burst(s.x, s.y, 50, '#6b0b14', 90, 2, 3, 1); this.fx.shake(6);
    this.notifyK(`${s.name} ${s.outcome.toLowerCase()}`, '#e05a5a');
    this.checkHatch();
  }
  healed(t, healer) {
    if (t.health === 'dying') t.health = 'injured';
    else if (t.health === 'injured') { t.health = 'healthy'; t.status.remove('deepWound'); t.status.remove('mangled'); t.status.remove('hemorrhage'); }
    t.healProgress = 0; t.recovery = 0;
    if (healer && healer !== t) healer.stats.heals++;
    this.events.emit(EV.SURVIVOR_HEALED, { survivor: t, healer });
  }

  // ------------------------------------------------------------ generators
  // Skill checks. Bots roll against their difficulty; the human survivor gets a real timed
  // check (needle + good/great zones) that the controller resolves. Both go through
  // resolveSkillCheck so perks and penalties are identical.
  skillCheck(s, g, kind = 'repair') {
    this.events.emit(EV.SKILL_CHECK, { survivor: s, gen: g, kind });
    const mod = this.perks.skillCheckMods(s, g);
    if (s.isPlayer) { this.startPlayerCheck(s, kind, g, mod); return; }
    const P = s.ai ? s.ai.params : { scFail: 0.1, scGreat: 0.3 };
    const fail = mod.forceGreat ? 0 : Math.min(0.9, P.scFail + mod.fail), great = mod.forceGreat ? 1 : Math.max(0, P.scGreat + mod.great);
    const r = Math.random();
    this.resolveSkillCheck(s, g, r < fail ? 'fail' : (mod.forceGreat || r < fail + great) ? 'great' : 'good', mod, kind);
  }
  startPlayerCheck(s, kind, target, mod = { fail: 0, great: 0, failExtra: 0, forceGreat: false }) {
    if (s.skillCheck) return;
    // harder checks from killer perks shrink the zones; Stake Out style tokens make any success great
    const shrink = Math.max(0.35, 1 - mod.fail * 2.2);
    s.skillCheck = { kind, target, mod, t0: this.time, warn: 0.55, dur: 1.15, zone: 0.55 + Math.random() * 0.3, good: 0.13 * shrink, great: 0.04 * shrink };
    this.audio?.play('ui');
  }
  // Called by the player controller when SPACE is pressed (or the needle runs out).
  // forced: a result judged on a network client (its needle is what the player saw)
  answerPlayerCheck(s, pressed, forced = null) {
    const c = s.skillCheck; if (!c) return null;
    const pos = (this.time - c.t0 - c.warn) / c.dur;
    let res = 'fail';
    if (forced) res = forced === 'great' || forced === 'good' ? (c.mod.forceGreat ? 'great' : forced) : 'fail';
    else if (pressed && pos >= c.zone && pos <= c.zone + c.good) res = c.mod.forceGreat || pos <= c.zone + c.great ? 'great' : 'good';
    s.skillCheck = null; s.lastCheck = { res, t: this.time };
    if (c.kind === 'repair') this.resolveSkillCheck(s, c.target, res, c.mod, 'repair');
    else if (c.kind === 'heal') { if (res === 'fail') { const t = c.target; t.healProgress = Math.max(0, t.healProgress - 0.1); this.addGrunt(t); this.loudNoise(s.x, s.y, 'skillcheck'); this.audio?.play('genfail'); } else if (res === 'great') c.target.healProgress = Math.min(0.999, c.target.healProgress + 0.02); }
    else if (c.kind === 'struggle') { if (res === 'fail') { s.hookTimer += 8; this.audio?.play('genfail'); } }
    else if (c.kind === 'wiggle') { if (res !== 'fail') s.wiggle += 0.05; }
    else if (c.kind === 'device') c.target.owner?.power?.onPlayerCheck?.(this, s, c.target, res);
    this.events.emit(res === 'fail' ? EV.SKILL_CHECK_FAILURE : EV.SKILL_CHECK_SUCCESS, { survivor: s, gen: c.kind === 'repair' ? c.target : null, great: res === 'great', kind: c.kind });
    return res;
  }
  resolveSkillCheck(s, g, res, mod, kind = 'repair') {
    const tech = s.hasPerk('technician');
    if (res === 'fail') {
      g.charges = Math.max(0, g.charges - GEN_CHARGES * ((tech ? 0.05 : 0.1) + mod.failExtra));
      if (!tech) this.loudNoise(g.x, g.y, 'skillcheck'); this.fx.sparks(g.x, g.y); this.audio?.play('genfail', { x: g.x, y: g.y });
      if (!s.isPlayer) this.events.emit(EV.SKILL_CHECK_FAILURE, { survivor: s, gen: g });
      s.stopAction(this); if (s.ai) s.ai.tT = 0.6;
    } else {
      const isGreat = res === 'great';
      if (isGreat) g.charges += GEN_CHARGES * 0.01;
      if (!s.isPlayer) this.events.emit(EV.SKILL_CHECK_SUCCESS, { survivor: s, gen: g, great: isGreat });
    }
  }
  completeGenerator(g) {
    if (g.done) return;
    g.done = true; g.charges = GEN_CHARGES; g.regressing = false;
    for (const s of [...g.repairers]) s.stopAction(this);
    this.gensDone++;
    this.events.emit(EV.GENERATOR_REPAIRED, { gen: g });
    this.fx.gen(g.x, g.y); this.audio?.play('gendone');
    if (this.gensDone >= this.gensNeeded && !this.gatesPowered) this.powerGates();
  }
  powerGates() {
    this.gatesPowered = true;
    for (const g of this.map.gates) g.powered = true;
    for (const g of this.map.gens) if (!g.done) { g.blockedUntil = Infinity; }
    this.events.emit(EV.EXIT_GATES_POWERED, {});
    this.notifyK('The exit gates are powered', '#ffd27a'); this.audio?.play('gates');
  }
  updateGens(dt) {
    for (const g of this.map.gens) {
      if (g.done) continue;
      if (g.repairers.size) { g.regressing = false; for (const s of g.repairers) if (s.action?.target !== g) g.repairers.delete(s); }
      else if (g.regressing) { g.charges -= dt * 0.25; if (g.charges <= 0) { g.charges = 0; g.regressing = false; } }
    }
  }

  // ------------------------------------------------------------ pallets & vaults
  dropPallet(p, s) {
    p.dropping = false; if (p.state !== 'up') return;
    p.state = 'down'; p.dropT = this.time; p.dropper = s; s.stats.pallets++;
    this.world.add(p.solid);
    // who stands in the stun zone is decided before anyone is pushed out of the footprint
    const inZone = new Set(this.killers.filter((k) => p.stunZone(k)));
    // push entities out of the pallet footprint toward their side
    for (const e of [...this.killers, ...this.survivors.filter((q) => q.standing)]) {
      if (e.x > p.rect.x - e.r && e.x < p.rect.x + p.rect.w + e.r && e.y > p.rect.y - e.r && e.y < p.rect.y + p.rect.h + e.r) {
        const side = e === s ? p.sideOf(s) : 1 - p.sideOf(s);
        const sp = p.sides(0.75 * M + e.r)[side]; e.x = sp.x + (e.x - p.x) * (p.alongX ? 1 : 0) * 0.5; e.y = sp.y + (e.y - p.y) * (p.alongX ? 0 : 1) * 0.5;
      }
    }
    for (const n of this.minions) if (n.stunnable && p.stunZone(n) && n.stunT <= 0) { n.stunT = n.stunTime ?? 3; n.onStun?.(this, s); this.fx.text(n.x, n.y - 30, 'STUNNED', '#ffd27a'); s.ai?.note(`Stunned the ${n.label} with a pallet`, 'mstun'); }
    for (const k of this.killers) if (inZone.has(k) && !k.action && k.stunT <= 0 && k.power.stunImmune?.(this)) { inZone.delete(k); k.power.onStunImmune?.(this, p, s); s.ai?.note('Pallet broke on the Overclocked killer', 'oc'); }
    for (const k of this.killers) if (inZone.has(k) && !k.action && k.stunT <= 0 && !k.power.stunImmune?.(this)) {
      const sf = k.perks.find((q) => q.id === 'spirit_fury' && q.data.ready);
      this.lastStunner = s; k.stun(this, sf ? 1.2 : 2, 'pallet');
      if (sf) { sf.data.ready = false; sf.tokens = 0; sf.active = false; this.perks.proc(sf, 'Spirit Fury'); k.stunT = Math.min(k.stunT, 0.8); this._sfBreak = p; } s.stats.stuns++; this.fx.shake(10); this.fx.text(k.x, k.y - 40, 'STUNNED', '#ffd27a');
      this.bb.model.palletBreaks += 0; s.ai?.note('Pallet stun!', 'stunok');
    }
    if (!this.quiet(s)) this.loudNoise(p.x, p.y, 'pallet');
    this.events.emit(EV.PALLET_DROPPED, { pallet: p, survivor: s }); this.fx.splinters(p.x, p.y); this.audio?.play('pallet');
  }
  updatePallets() {
    if (this._sfBreak && this.killers.every((k) => k.stunT < 0.4)) { const p = this._sfBreak; this._sfBreak = null; if (p.state === 'down') { this.breakPallet(p); this.fx.text(p.x, p.y - 30, 'SPIRIT FURY', '#e05a5a'); } }
    for (const p of this.map.pallets) if (p.state === 'down' && !p.respectCounted && this.time - p.dropT > 8) { p.respectCounted = true; this.bb.model.palletRespects++; }
  }
  onVault(s, obj, quality) {
    s.stats.vaults++;
    if (quality === 'fast' && !this.quiet(s)) this.loudNoise(obj.x, obj.y, 'vault');
    if (obj.kind === 'window') {
      obj.vaultLog = (obj.vaultLog || []).filter((v) => this.time - v.t < 60);
      obj.vaultLog.push({ t: this.time, s });
      if (obj.vaultLog.filter((v) => v.s === s).length >= 3 && this.inChase(s)) { obj.blockedUntil = this.time + 16; obj.vaultLog = []; s.ai?.note('Window got blocked after 3 vaults', 'winblock'); }
    }
    this.events.emit(EV.VAULT_PERFORMED, { who: s, obj, quality });
    if (quality === 'fast') this.audio?.play('vault');
  }

  // ------------------------------------------------------------ traps
  updateTraps(dt) {
    for (const t of this.traps) {
      if (t.state !== 'set') continue;
      for (const s of this.survivors) {
        if (!s.standing || s.vault || s.trap) continue;
        if (dist(s.x, s.y, t.x, t.y) < 0.55 * M) { this.trapSurvivor(t, s); break; }
      }
    }
  }
  trapSurvivor(t, s) {
    t.state = 'triggered'; t.victim = s; s.trap = t; s.trapAttempts = 0; s.stopAction(this);
    s.x = t.x; s.y = t.y;
    if (s.health === 'healthy') { s.health = 'injured'; this.events.emit(EV.SURVIVOR_INJURED, { survivor: s, source: 'trap' }); }
    else { s.goDown(this, 'trap'); }
    if (this.killers.some((k) => k.power.serrated)) { s.status.add('mangled', { duration: 90 }); s.status.add('hemorrhage', { duration: 90 }); }
    this.bb.model.trapCatches++;
    for (const o of this.survivors) if (o.ai && o !== s && Math.random() < o.ai.params.comms) { o.ai.memory.traps.set(t.id, { x: t.x, y: t.y, trap: t, t: this.time }); o.ai._trapVersion++; }
    this.loudNoise(t.x, t.y, 'trap'); this.fx.shake(5); this.audio?.play('snap');
    this.notifyK(`${s.name} caught in a trap!`, '#ffd27a');
    this.events.emit(EV.TRAP_TRIGGERED, { trap: t, survivor: s });
  }
  trapEscapeAttempt(s) {
    if (!s.trap) return;
    const coil = this.killers.some((k) => k.power.ironCoil) ? 0.6 : 1;
    const ch = (0.16 + 0.06 * s.trapAttempts) * coil;
    s.trapAttempts++;
    if (Math.random() < ch) this.releaseTrap(s, null);
  }
  releaseTrap(s, rescuer) {
    const t = s.trap; if (!t) return;
    t.state = 'unset'; t.victim = null; s.trap = null;
    if (rescuer) rescuer.stats.unhooks += 0;
    this.notifyK(`${s.name} escaped a trap`, '#cfe3e3');
  }
  disarmTrap(t, s) { if (t.state === 'set') { t.state = 'unset'; this.events.emit(EV.TRAP_DISARMED, { trap: t, survivor: s }); s.ai?.note('Disarmed a trap', 'disarm'); } }
  checkKillerTraps(k = this.killer) {
    if (k.power.id !== 'traps') return;
    for (const t of this.traps) if (t.state === 'set' && this.time - t.setT > 2 && dist(k.x, k.y, t.x, t.y) < 0.4 * M) { t.state = 'unset'; k.stun(this, 2, 'trap'); this.fx.text(k.x, k.y - 40, 'OWN TRAP', '#ffd27a'); }
  }

  // ------------------------------------------------------------ misc objectives
  openChest(c, s) { c.opened = true; c.user = null; if (!s.item || s.item.charges <= 0) { const pool = ['medkit', 'toolbox', 'flashlight', 'medkit', 'toolbox', 'key']; const id = pool[Math.floor(Math.random() * pool.length)]; s.item = makeItem(id); s.ai?.note('Found a ' + s.item.name, 'chest'); } s.stats.chests++; this.events.emit(EV.CHEST_OPENED, { chest: c, survivor: s }); }
  cleanseTotem(t, s) { const hex = t.hex; t.cleansed = true; t.user = null; s.stats.totems++; this.events.emit(EV.TOTEM_CLEANSED, { totem: t, survivor: s, hex }); if (hex) { this.notifyK(`Your hex was cleansed`, '#e05a5a'); s.ai?.note('Cleansed the hex totem', 'hex'); } }
  flashlightTick(s, dt) {
    // flashlights burn away Phantasm traps caught in the beam
    for (const d of this.devices) if (d.kind === 'phantasm' && dist(s.x, s.y, d.x, d.y) < 7 * M && angleDiff(Math.atan2(d.y - s.y, d.x - s.x), s.facing) < 0.45 && this.world.losClear(s.x, s.y, d.x, d.y)) {
      d.data.burn = (d.data.burn || 0) + dt; if (d.data.burn > 0.8) { this.removeDevice(d); this.fx.burst(d.x, d.y, 12, '#e8e0a0', 60, 0.6, 2, 2); s.ai?.note('Burned a Phantasm trap with the flashlight', 'burn'); s.stopAction(this); return; }
    }
    const k = this.killers.reduce((b, q) => (angleDiff(Math.atan2(q.y - s.y, q.x - s.x), s.facing) < angleDiff(Math.atan2(b.y - s.y, b.x - s.x), s.facing) ? q : b), this.killers[0]);
    if (this.perks.killerHas('flashImmune', k) || k.power.flashImmune?.(this)) return; const d = dist(s.x, s.y, k.x, k.y);
    const toK = Math.atan2(k.y - s.y, k.x - s.x);
    const ok = d < 7 * M && angleDiff(toK, s.facing) < 0.4 * (s.item?.beam || 1) && angleDiff(k.facing, toK + Math.PI) < 1.25 && this.world.losClear(s.x, s.y, k.x, k.y);
    k.flashAcc = Math.max(0, (k.flashAcc || 0) + (ok ? dt * (s.hasPerk('champion_of_light') ? 1.5 : 1) : -dt * 0.5));
    if (k.flashAcc > 0.6) {
      k.flashAcc = 0; k.blindT = 2.5 * this.perks.killerProduct('stunMult', k); k.status.add('blindness', { duration: 6 }); this.fx.flash = 1; this.fx.flashColor = '255,250,230';
      if (k.carrying) { this.dropCarried('flashlight', k); s.ai?.note('Flashlight save!', 'flash'); }
      else if (k.action?.type === 'pickup') { k.action = null; s.ai?.note('Blinded the killer during a pickup', 'flash'); }
      s.stopAction(this);
    }
  }
  openGate(g, s) {
    if (g.open) return;
    g.open = true; g.user = null; this.world.remove(g.solid);
    this.events.emit(EV.EXIT_GATE_OPENED, { gate: g, survivor: s }); this.notifyK(`${g.name} is open`, '#ffd27a');
    this.loudNoise(g.x, g.y, 'gate');
    if (!this.collapse) this.startCollapse();
  }
  startCollapse() { this.collapse = true; this.collapseT = COLLAPSE_TIME; this.setState('ENDGAME_COLLAPSE'); this.events.emit(EV.ENDGAME_COLLAPSE, {}); this.audio?.play('collapse'); }
  updateGates(dt) {
    for (const s of this.survivors) {
      if (!s.standing) continue;
      for (const g of this.map.gates) {
        if (!g.open || (this.gatesSealedUntil || 0) > this.time || (s.gateBlockUntil || 0) > this.time || s.status.has('chained') || s.status.has('grabbed')) continue; const r = g.exitRect;
        if (s.x > r.x && s.x < r.x + r.w && s.y > r.y && s.y < r.y + r.h) this.escape(s, 'gate');
      }
    }
    if (this.collapse) {
      const slow = this.survivors.some((s) => s.health === 'hooked' || s.health === 'dying' || s.health === 'carried');
      this.collapseT -= dt * (slow ? 0.5 : 1);
      if (this.collapseT <= 0) { for (const s of this.survivors) if (s.alive) this.killSurvivor(s, 'collapse'); }
    }
  }
  escape(s, how) {
    if (!s.alive) return;
    s.stopAction(this); if (s.trap) s.trap = null;
    s.health = 'escaped'; s.outcome = how === 'hatch' ? 'Escaped (hatch)' : 'Escaped'; s.stats.escapes++;
    this.bb.release(s);
    this.events.emit(EV.SURVIVOR_ESCAPED, { survivor: s, how }); this.notifyK(`${s.name} escaped`, '#9fd0a0');
    this.checkHatch();
  }
  checkHatch() {
    const alive = this.aliveCount();
    if (this.hatch.state === 'shut') return;
    if (alive === 1 && this.hatch.state !== 'open' && !this.cfg.modifiers.noHatch) { this.hatch.state = 'open'; this.events.emit(EV.HATCH_OPENED, {}); this.notifyK('The hatch has opened', '#9fd0d0'); }
    else if (alive === 2 && this.hatch.state === 'hidden' && this.survivors.some((s) => s.alive && s.item?.id === 'key')) this.hatch.state = 'closed';
  }
  openHatchWithKey(s) { if (this.hatch.state === 'closed') { this.hatch.state = 'open'; s.item.charges = 0; s.ai?.note('Opened the hatch with a key', 'key'); } }
  escapeHatch(s) { if (this.hatch.state === 'open' && dist(s.x, s.y, this.hatch.x, this.hatch.y) < 1.2 * M) this.escape(s, 'hatch'); }
  closeHatch() {
    if (this.hatch.state !== 'open') return;
    this.hatch.state = 'shut'; this.events.emit(EV.HATCH_CLOSED, {}); this.notifyK('Hatch closed — gates powered', '#ffd27a');
    if (!this.gatesPowered) this.powerGates();
    if (!this.collapse) this.startCollapse();
  }

  // ------------------------------------------------------------ chase (killer side)
  updateChase(dt) { for (const k of this.killers) this.updateChaseFor(dt, k); }
  updateChaseFor(dt, k) {
    let tgt = k.chaseTarget;
    if (tgt && (!tgt.standing || dist(k.x, k.y, tgt.x, tgt.y) > 28 * M)) { this.endChase(k); tgt = null; }
    if (tgt) {
      const los = this.world.losClear(k.x, k.y, tgt.x, tgt.y);
      k.chaseLOS = los ? 0 : (k.chaseLOS || 0) + dt;
      if (k.chaseLOS > 5) { this.endChase(k); return; }
      this.bb.reportChase(tgt); // teammates can see who is being chased (HUD icon)
      k.chaseT += dt * (this.cfg.modifiers.bloodMoon ? 2 : 1);
      const tier = k.chaseT > 45 ? 3 : k.chaseT > 30 ? 2 : k.chaseT > 15 ? 1 : 0;
      if (tier > k.bloodlust) { k.bloodlust = tier; this.fx.text(k.x, k.y - 44, `BLOODLUST ${'I'.repeat(tier)}`, '#d33'); }
      tgt.stats.chaseTime += 0;
      this.score.hunter += dt * 4;
    } else {
      for (const s of this.survivors) {
        if (!s.standing) continue;
        const d = dist(k.x, k.y, s.x, s.y); if (d > 14 * M) continue;
        if (!this.world.losClear(k.x, k.y, s.x, s.y)) continue;
        if (angleDiff(Math.atan2(s.y - k.y, s.x - k.x), k.facing) > 1.2) continue;
        if (s.moveMode === 'crouch' && this.map.isGrass(s.x, s.y) && d > 4 * M) continue;
        s._spotT = (s._spotT || 0) + dt;
        if (s._spotT > 0.8) { k.chaseTarget = s; k.chaseLOS = 0; k.chaseT = 0; this.events.emit(EV.CHASE_START, { survivor: s, killer: k }); if (k.isPlayer || s.isPlayer) this.audio?.play('chase'); break; }
      }
    }
  }
  endChase(k = this.killer) { if (k.chaseTarget) { this.events.emit(EV.CHASE_END, { survivor: k.chaseTarget, killer: k }); k.chaseTarget._spotT = 0; } k.chaseTarget = null; this.endBloodlust(k); }
  endChaseOn(s, k) { this.endBloodlust(k || this.killers.find((q) => q.chaseTarget === s) || this.killer); }
  endBloodlust(k = this.killer) { k.bloodlust = 0; k.chaseT = 0; }

  // ------------------------------------------------------------ results
  results() {
    const kills = this.survivors.filter((s) => s.health === 'dead').length;
    const esc = this.survivors.filter((s) => s.health === 'escaped').length;
    const n = this.survivors.length;
    const grade = kills === n ? 'Merciless Killer' : kills >= Math.ceil(n * 0.75) ? 'Ruthless Killer' : kills >= Math.ceil(n / 2) ? 'Brutal Killer' : kills >= 1 ? 'Ruthless... almost' : 'Entity Displeased';
    return { kills, escapes: esc, total: n, grade, score: { ...this.score }, time: this.time, survivors: this.survivors.map((s) => ({ name: s.name, color: s.color, cls: s.cls || null, isPlayer: !!s.isPlayer, outcome: s.outcome || 'Escaped', difficulty: s.difficulty, archetype: s.personality.label, perks: s.perks.map((p) => p.def.name), item: s.item?.name || '—', stats: s.stats })), log: this.aiLog.slice(-40), killerStats: this.killer.stats, killers: this.killers.map((k) => ({ name: k.def.name, accent: k.def.accent, cls: k.cls || null, bot: !!k.bot, difficulty: k.bot ? k.botDifficulty : null, stats: k.stats })), mode: this.cfg.mode, playerRole: this.cfg.playerRole, player: this.player && this.player.kind === 'survivor' ? { name: this.player.name, outcome: this.player.outcome || (this.player.alive ? 'Alive' : '—') } : null };
  }
}
