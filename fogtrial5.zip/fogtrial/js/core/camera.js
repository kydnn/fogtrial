// Smooth follow camera with look-ahead, zoom and map clamping. The killer never sees
// the whole map: zoom is clamped so the view is always smaller than the map.
import { clamp, lerp } from './util.js';

export class Camera {
  constructor() { this.x = 0; this.y = 0; this.zoom = 1; this.userZoom = 1; this.vw = 1000; this.vh = 700; this.shakeX = 0; this.shakeY = 0; }
  resize(w, h) { this.vw = w; this.vh = h; }
  baseZoom() { return clamp(Math.min(this.vw, this.vh * 1.6) / 1180, 0.55, 1.6); }
  update(dt, target, map, aim, shake) {
    const want = this.baseZoom() * this.userZoom;
    // never allow the view to cover the whole map
    const maxZ = Math.max(this.vw / (map.w * 0.62), this.vh / (map.h * 0.62));
    this.zoom = lerp(this.zoom, Math.max(want, maxZ), Math.min(1, dt * 6));
    const la = 70; // look-ahead toward aim
    const tx = target.x + Math.cos(aim) * la, ty = target.y + Math.sin(aim) * la;
    const k = 1 - Math.exp(-dt * 7);
    this.x = lerp(this.x, tx, k); this.y = lerp(this.y, ty, k);
    const hw = this.vw / 2 / this.zoom, hh = this.vh / 2 / this.zoom;
    this.x = clamp(this.x, hw, Math.max(hw, map.w - hw)); this.y = clamp(this.y, hh, Math.max(hh, map.h - hh));
    this.shakeX = (Math.random() - 0.5) * shake * 2; this.shakeY = (Math.random() - 0.5) * shake * 2;
  }
  snap(target) { this.x = target.x; this.y = target.y; }
  get left() { return this.x - this.vw / 2 / this.zoom; }
  get top() { return this.y - this.vh / 2 / this.zoom; }
  get right() { return this.x + this.vw / 2 / this.zoom; }
  get bottom() { return this.y + this.vh / 2 / this.zoom; }
  toScreen(x, y) { return { x: (x - this.x) * this.zoom + this.vw / 2, y: (y - this.y) * this.zoom + this.vh / 2 }; }
  toWorld(sx, sy) { return { x: (sx - this.vw / 2) / this.zoom + this.x, y: (sy - this.vh / 2) / this.zoom + this.y }; }
  inView(x, y, pad = 60) { return x > this.left - pad && x < this.right + pad && y > this.top - pad && y < this.bottom + pad; }
}
