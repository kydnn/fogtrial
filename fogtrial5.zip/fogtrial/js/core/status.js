// Reusable status-effect system. Every status is data; perks/killers only call add().
// Modifiers are aggregated: speed (multiplicative from percent), action speed, flags.
export const STATUS_DEFS = {
  haste:       { name: 'Haste', kind: 'buff', stack: 'max', mod: (s) => ({ speedPct: s.value ?? 0.5 }) },
  hindered:    { name: 'Hindered', kind: 'debuff', stack: 'max', mod: (s) => ({ speedPct: -(s.value ?? 0.2) }) },
  slow:        { name: 'Slow', kind: 'debuff', stack: 'max', mod: (s) => ({ speedPct: -(s.value ?? 0.25) }) },
  exhausted:   { name: 'Exhausted', kind: 'debuff', stack: 'max', mod: () => ({ exhausted: true }) },
  blindness:   { name: 'Blindness', kind: 'debuff', stack: 'max', mod: () => ({ blind: true }) },
  broken:      { name: 'Broken', kind: 'debuff', stack: 'max', mod: () => ({ broken: true }) },
  deepWound:   { name: 'Deep Wound', kind: 'debuff', stack: 'max', mod: () => ({ deepWound: true }) },
  hemorrhage:  { name: 'Hemorrhage', kind: 'debuff', stack: 'max', mod: () => ({ hemorrhage: true }) },
  mangled:     { name: 'Mangled', kind: 'debuff', stack: 'max', mod: () => ({ healPct: -0.2 }) },
  oblivious:   { name: 'Oblivious', kind: 'debuff', stack: 'max', mod: () => ({ oblivious: true }) },
  undetectable:{ name: 'Undetectable', kind: 'buff', stack: 'max', mod: () => ({ undetectable: true }) },
  exposed:     { name: 'Exposed', kind: 'debuff', stack: 'max', mod: () => ({ exposed: true }) },
  endurance:   { name: 'Endurance', kind: 'buff', stack: 'max', mod: () => ({ endurance: true }) },
  stunned:     { name: 'Stunned', kind: 'debuff', stack: 'max', mod: () => ({ stunned: true, speedPct: -1 }) },
  blinded:     { name: 'Blinded', kind: 'debuff', stack: 'max', mod: () => ({ flashBlind: true }) },
  intoxicated: { name: 'Intoxicated', kind: 'debuff', stack: 'max', mod: (s) => ({ speedPct: -(s.value ?? 0.2), intoxicated: true }) },
  tormented:   { name: 'Tormented', kind: 'debuff', stack: 'max', mod: () => ({ tormented: true }) },
  slipstream:  { name: 'Slipstreamed', kind: 'debuff', stack: 'max', mod: () => ({ slipstream: true }) },
  marked:      { name: 'Marked', kind: 'debuff', stack: 'max', mod: () => ({ exposed: true, marked: true }) },
  incapacitated: { name: 'Incapacitated', kind: 'debuff', stack: 'max', mod: () => ({ incapacitated: true }) },
  // expansion: killer-specific states, all through the central framework
  infected:    { name: 'Uroboros Infection', kind: 'debuff', stack: 'max', mod: (s) => ((s.value ?? 0) >= 100 ? { speedPct: -0.04, critInfected: true, infected: true } : { infected: true }) },
  chained:     { name: 'Chained', kind: 'debuff', stack: 'max', mod: (s) => ({ speedPct: [0, -0.435, -0.576, -0.718][Math.min(3, s.value ?? 3)], incapacitated: true, chained: s.value ?? 3 }) },
  grabbed:     { name: 'Grabbed', kind: 'debuff', stack: 'max', mod: () => ({ incapacitated: true, grabbed: true }) },
  nightfall:   { name: 'Nightfall', kind: 'debuff', stack: 'max', mod: () => ({ sightMult: 0.22, nightfall: true }) },
  dispelled:   { name: 'Dispelled', kind: 'debuff', stack: 'max', mod: () => ({ dispelled: true }) },
  deepWoundFrenzy: { name: 'Deep Wound', kind: 'debuff', stack: 'max', mod: () => ({}) },
  // Skull Merchant / Unknown / Nemesis / Ghoul
  lockOn:      { name: 'Lock-On', kind: 'debuff', stack: 'max', mod: (s) => ({ lockOn: s.value ?? 1 }) },
  clawTrap:    { name: 'Claw Trap', kind: 'debuff', stack: 'max', mod: () => ({ clawTrap: true }) },
  weakened:    { name: 'Weakened', kind: 'debuff', stack: 'max', mod: () => ({ weakened: true }) },
  contaminated:{ name: 'Contaminated', kind: 'debuff', stack: 'max', mod: () => ({ contaminated: true }) },
  kaguneMark:  { name: 'Kagune Mark', kind: 'debuff', stack: 'max', mod: () => ({ kaguneMark: true }) },
  latched:     { name: 'Latched', kind: 'debuff', stack: 'max', mod: () => ({ latched: true }) },
  cannotAttack:{ name: 'Cannot Attack', kind: 'debuff', stack: 'max', mod: () => ({ cannotAttack: true }) },
  actionSpeed: { name: 'Action Speed', kind: 'buff', stack: 'sum', mod: (s) => ({ actionPct: s.value ?? 0.1 }) },
  repairSpeed: { name: 'Repair Speed', kind: 'buff', stack: 'sum', mod: (s) => ({ repairPct: s.value ?? 0.1 }) },
};

export class StatusManager {
  constructor(owner) { this.owner = owner; this.list = []; }
  // add({id, duration, value, source, stacks}) — duration Infinity = until removed
  add(id, opts = {}) {
    const def = STATUS_DEFS[id]; if (!def) { console.warn('unknown status', id); return; }
    const existing = this.list.find((s) => s.id === id && (def.stack === 'max' || s.source === opts.source));
    const duration = opts.duration ?? Infinity;
    if (existing) {
      existing.expiration = Math.max(existing.expiration, duration);
      existing.duration = Math.max(existing.duration, duration);
      if (opts.value !== undefined) existing.value = def.stack === 'max' ? Math.max(existing.value ?? 0, opts.value) : opts.value;
      existing.stacks = Math.min((existing.stacks || 1) + (opts.stacks ? 1 : 0), 8);
      return existing;
    }
    const s = { id, duration, expiration: duration, value: opts.value, stacks: opts.stacks || 1, source: opts.source || null, modifiers: null };
    this.list.push(s);
    return s;
  }
  remove(id, source) { this.list = this.list.filter((s) => !(s.id === id && (source === undefined || s.source === source))); }
  has(id) { return this.list.some((s) => s.id === id); }
  get(id) { return this.list.find((s) => s.id === id); }
  timeLeft(id) { const s = this.get(id); return s ? s.expiration : 0; }
  update(dt) {
    for (const s of this.list) s.expiration -= dt;
    this.list = this.list.filter((s) => s.expiration > 0);
  }
  // Aggregate: speed haste uses max, hindered max, combined additively like DBD.
  mods() {
    const out = { speedPct: 0, actionPct: 0, repairPct: 0, healPct: 0 };
    let haste = 0, slow = 0;
    for (const s of this.list) {
      const m = STATUS_DEFS[s.id].mod(s);
      for (const k in m) {
        if (k === 'speedPct') { if (m[k] > 0) haste = Math.max(haste, m[k]); else slow = Math.min(slow, m[k]); }
        else if (k === 'sightMult') out[k] = Math.min(out[k] ?? 1, m[k]);
        else if (typeof m[k] === 'number') out[k] += m[k];
        else out[k] = out[k] || m[k];
      }
    }
    out.speedPct = haste + slow;
    return out;
  }
}
