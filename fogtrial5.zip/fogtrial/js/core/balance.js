// Balance configuration: tunable numbers that designers change often live here instead of
// deep inside power or rules code.
export const BALANCE = {
  trapper: {
    // Haste after a bear trap is successfully set (never on a failed/cancelled placement).
    trapSetHaste: 0.10,        // +10% movement speed
    trapSetHasteDuration: 4,   // seconds
    trapSetHasteStacks: false, // false: a new placement refreshes the timer instead of stacking
  },
  cenobite: { chainRecoverySpeed: 0.25 },
};
