// Tiny synthesized sound kit (WebAudio). Starts after the first user click.
export class Audio {
  constructor() { this.ctx = null; this.vol = 0.5; this.last = {}; this.musicGain = null; this.chaseLevel = 0; }
  init() {
    if (this.ctx) return;
    try { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); this.master = this.ctx.createGain(); this.master.gain.value = this.vol; this.master.connect(this.ctx.destination); this.startDrone(); } catch (e) { this.ctx = null; }
  }
  setVolume(v) { this.vol = v; if (this.master) this.master.gain.value = v; }
  env(node, t0, a, d, peak = 1) { const g = this.ctx.createGain(); g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(peak, t0 + a); g.gain.exponentialRampToValueAtTime(0.0001, t0 + a + d); node.connect(g); g.connect(this.master); return g; }
  osc(type, f, t0, a, d, peak = 0.3, f2 = null) { const o = this.ctx.createOscillator(); o.type = type; o.frequency.setValueAtTime(f, t0); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t0 + a + d); this.env(o, t0, a, d, peak); o.start(t0); o.stop(t0 + a + d + 0.05); }
  noise(t0, d, peak = 0.3, filt = 1200, q = 1) {
    const len = Math.ceil(this.ctx.sampleRate * d); const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate); const ch = buf.getChannelData(0);
    for (let i = 0; i < len; i++) ch[i] = Math.random() * 2 - 1;
    const src = this.ctx.createBufferSource(); src.buffer = buf; const f = this.ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = filt; f.Q.value = q; src.connect(f);
    this.env(f, t0, 0.005, d, peak); src.start(t0);
  }
  play(name, opts = {}) {
    if (!this.ctx) return; const t = this.ctx.currentTime;
    if (this.last[name] && t - this.last[name] < 0.05) return; this.last[name] = t;
    switch (name) {
      case 'hit': this.noise(t, 0.25, 0.5, 500, 0.8); this.osc('sine', 90, t, 0.005, 0.25, 0.4, 40); break;
      case 'scream': this.osc('sawtooth', 620, t, 0.03, 0.5, 0.08, 380); this.osc('sawtooth', 660, t + 0.02, 0.03, 0.45, 0.06, 420); break;
      case 'swing': this.noise(t, 0.15, 0.15, 2500, 2); break;
      case 'pallet': this.noise(t, 0.3, 0.6, 300, 0.7); this.osc('triangle', 120, t, 0.005, 0.2, 0.3, 60); break;
      case 'break': this.noise(t, 0.4, 0.6, 700, 0.6); this.noise(t + 0.1, 0.3, 0.4, 1500, 1); break;
      case 'vault': this.noise(t, 0.12, 0.25, 900, 1.5); break;
      case 'gendone': this.osc('sine', 330, t, 0.02, 1.2, 0.25); this.osc('sine', 495, t + 0.1, 0.02, 1.2, 0.18); break;
      case 'genfail': this.noise(t, 0.4, 0.5, 2000, 0.6); this.osc('square', 80, t, 0.005, 0.3, 0.2, 50); break;
      case 'kick': this.osc('square', 70, t, 0.005, 0.15, 0.3, 40); this.noise(t, 0.2, 0.3, 1800, 2); break;
      case 'hook': this.osc('sawtooth', 200, t, 0.02, 0.8, 0.12, 90); this.noise(t, 0.6, 0.2, 400, 1); break;
      case 'unhook': this.osc('triangle', 260, t, 0.02, 0.3, 0.15, 330); break;
      case 'pickup': this.noise(t, 0.2, 0.2, 600, 1); break;
      case 'trapset': this.osc('square', 1200, t, 0.002, 0.05, 0.12); this.osc('square', 900, t + 0.06, 0.002, 0.05, 0.12); break;
      case 'snap': this.osc('square', 1500, t, 0.001, 0.08, 0.35, 300); this.noise(t, 0.2, 0.4, 3000, 1); break;
      case 'bell': for (let i = 0; i < 3; i++) { this.osc('sine', 523 * (1 + i * 0.5), t, 0.005, 2.2, 0.12 / (i + 1)); } break;
      case 'rev': this.osc('sawtooth', 70 + (opts.charge || 0) * 60, t, 0.01, 0.3, 0.06, 90 + (opts.charge || 0) * 80); break;
      case 'saw': this.osc('sawtooth', 160, t, 0.01, 1.2, 0.1, 200); this.noise(t, 1.2, 0.12, 1200, 0.8); break;
      case 'clang': this.osc('square', 300, t, 0.001, 0.4, 0.3, 120); this.noise(t, 0.3, 0.4, 2500, 3); break;
      case 'stun': this.osc('triangle', 180, t, 0.005, 0.3, 0.3, 90); break;
      case 'chase': this.osc('sine', 55, t, 0.05, 0.9, 0.2, 52); break;
      case 'gates': this.osc('sawtooth', 110, t, 0.2, 2.0, 0.08, 220); break;
      case 'collapse': this.osc('sawtooth', 80, t, 0.3, 3, 0.1, 40); break;
      case 'glass': this.noise(t, 0.25, 0.4, 3500, 2); this.noise(t + 0.05, 0.6, 0.15, 900, 0.5); break;
      case 'wave': this.osc('sawtooth', 60, t, 0.02, 0.6, 0.25, 30); this.noise(t, 0.6, 0.3, 300, 0.6); break;
      case 'teleport': this.osc('sine', 900, t, 0.01, 0.4, 0.2, 200); this.osc('square', 300, t, 0.01, 0.2, 0.08, 1200); break;
      case 'emp': this.osc('square', 1600, t, 0.002, 0.3, 0.15, 80); break;
      case 'throw': this.noise(t, 0.18, 0.25, 2200, 3); break;
      case 'reload': this.osc('square', 500, t, 0.002, 0.06, 0.1); this.osc('square', 700, t + 0.08, 0.002, 0.06, 0.1); break;
      case 'ui': this.osc('triangle', 660, t, 0.002, 0.07, 0.07); break;
      case 'notify': this.osc('sine', 880, t, 0.005, 0.25, 0.08); break;
    }
  }
  startDrone() {
    const t = this.ctx.currentTime; this.musicGain = this.ctx.createGain(); this.musicGain.gain.value = 0.0; this.musicGain.connect(this.master);
    for (const f of [41.2, 61.7, 82.4]) { const o = this.ctx.createOscillator(); o.type = 'sine'; o.frequency.value = f; const g = this.ctx.createGain(); g.gain.value = 0.05; o.connect(g); g.connect(this.musicGain); o.start(t); }
    this.pulse = this.ctx.createOscillator(); this.pulse.type = 'sine'; this.pulse.frequency.value = 1.6; const pg = this.ctx.createGain(); pg.gain.value = 0.0; this.pulseGain = pg;
  }
  setMood(level) { if (!this.ctx || !this.musicGain) return; this.musicGain.gain.setTargetAtTime(0.15 + level * 0.5, this.ctx.currentTime, 0.4); }
}
