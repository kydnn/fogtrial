// Spatial partitioning (uniform bucket grid) for collision + line-of-sight queries.
// Solid = { x, y, w, h, blocksMove, blocksLOS, kind, ref }
export class SpatialGrid {
  constructor(w, h, cell = 128) {
    this.cell = cell; this.cols = Math.ceil(w / cell); this.rows = Math.ceil(h / cell);
    this.buckets = Array.from({ length: this.cols * this.rows }, () => []);
    this.stamp = 0;
  }
  _range(x0, y0, x1, y1) {
    const c = this.cell;
    return [Math.max(0, Math.floor(x0 / c)), Math.max(0, Math.floor(y0 / c)), Math.min(this.cols - 1, Math.floor(x1 / c)), Math.min(this.rows - 1, Math.floor(y1 / c))];
  }
  insert(s) {
    const [a, b, cc, d] = this._range(s.x, s.y, s.x + s.w, s.y + s.h);
    s._stamp = 0;
    for (let j = b; j <= d; j++) for (let i = a; i <= cc; i++) this.buckets[j * this.cols + i].push(s);
  }
  remove(s) {
    const [a, b, cc, d] = this._range(s.x, s.y, s.x + s.w, s.y + s.h);
    for (let j = b; j <= d; j++) for (let i = a; i <= cc; i++) {
      const bk = this.buckets[j * this.cols + i]; const k = bk.indexOf(s); if (k >= 0) bk.splice(k, 1);
    }
  }
  query(x0, y0, x1, y1, out = []) {
    const [a, b, cc, d] = this._range(Math.min(x0, x1), Math.min(y0, y1), Math.max(x0, x1), Math.max(y0, y1));
    const st = ++this.stamp;
    for (let j = b; j <= d; j++) for (let i = a; i <= cc; i++) {
      for (const s of this.buckets[j * this.cols + i]) { if (s._stamp !== st) { s._stamp = st; out.push(s); } }
    }
    return out;
  }
}

// Segment vs AABB (slab). Returns entry t in [0,1] or -1.
export function segRect(ax, ay, bx, by, r, pad = 0) {
  const dx = bx - ax, dy = by - ay;
  let t0 = 0, t1 = 1;
  const minX = r.x - pad, maxX = r.x + r.w + pad, minY = r.y - pad, maxY = r.y + r.h + pad;
  if (Math.abs(dx) < 1e-9) { if (ax < minX || ax > maxX) return -1; }
  else {
    let ta = (minX - ax) / dx, tb = (maxX - ax) / dx; if (ta > tb) [ta, tb] = [tb, ta];
    t0 = Math.max(t0, ta); t1 = Math.min(t1, tb); if (t0 > t1) return -1;
  }
  if (Math.abs(dy) < 1e-9) { if (ay < minY || ay > maxY) return -1; }
  else {
    let ta = (minY - ay) / dy, tb = (maxY - ay) / dy; if (ta > tb) [ta, tb] = [tb, ta];
    t0 = Math.max(t0, ta); t1 = Math.min(t1, tb); if (t0 > t1) return -1;
  }
  return t0;
}

export class World {
  constructor(w, h) { this.w = w; this.h = h; this.grid = new SpatialGrid(w, h, 128); this._q = []; }
  add(s) { this.grid.insert(s); return s; }
  remove(s) { this.grid.remove(s); }

  losClear(ax, ay, bx, by, ignore = null) {
    this._q.length = 0;
    const list = this.grid.query(ax, ay, bx, by, this._q);
    for (const s of list) {
      if (!s.blocksLOS || s === ignore) continue;
      if (segRect(ax, ay, bx, by, s) >= 0) return false;
    }
    return true;
  }
  // Is a straight circle sweep free of movement blockers? (used for path smoothing / dash checks)
  sweepClear(ax, ay, bx, by, r, filter = null) {
    this._q.length = 0;
    const list = this.grid.query(ax - r, ay - r, bx + r, by + r, this._q);
    for (const s of list) {
      if (!s.blocksMove) continue;
      if (filter && !filter(s)) continue;
      if (segRect(ax, ay, bx, by, s, r) >= 0) return false;
    }
    return true;
  }
  firstHit(ax, ay, bx, by, r, filter = null) {
    this._q.length = 0;
    const list = this.grid.query(ax - r, ay - r, bx + r, by + r, this._q);
    let best = 2, hit = null;
    for (const s of list) {
      if (!s.blocksMove || (filter && !filter(s))) continue;
      const t = segRect(ax, ay, bx, by, s, r);
      if (t >= 0 && t < best) { best = t; hit = s; }
    }
    return hit ? { t: best, solid: hit } : null;
  }
  // Move a circle with collision resolution. filter(solid) -> true if it should block this mover.
  move(e, dx, dy, r, filter = null) {
    const steps = Math.max(1, Math.ceil(Math.hypot(dx, dy) / (r * 0.5)));
    const sx = dx / steps, sy = dy / steps;
    let collided = false;
    for (let i = 0; i < steps; i++) {
      e.x += sx; e.y += sy;
      if (this.resolve(e, r, filter)) collided = true;
    }
    e.x = Math.max(r, Math.min(this.w - r, e.x));
    e.y = Math.max(r, Math.min(this.h - r, e.y));
    return collided;
  }
  resolve(e, r, filter) {
    this._q.length = 0;
    const list = this.grid.query(e.x - r, e.y - r, e.x + r, e.y + r, this._q);
    let hit = false;
    for (const s of list) {
      if (!s.blocksMove || (filter && !filter(s))) continue;
      const cx = Math.max(s.x, Math.min(e.x, s.x + s.w));
      const cy = Math.max(s.y, Math.min(e.y, s.y + s.h));
      let dx = e.x - cx, dy = e.y - cy;
      const d2 = dx * dx + dy * dy;
      if (d2 >= r * r) continue;
      hit = true;
      if (d2 > 1e-6) {
        const d = Math.sqrt(d2); const push = r - d;
        e.x += (dx / d) * push; e.y += (dy / d) * push;
      } else {
        // center inside rect: push out along shortest axis
        const l = e.x - s.x, rr = s.x + s.w - e.x, t = e.y - s.y, b = s.y + s.h - e.y;
        const m = Math.min(l, rr, t, b);
        if (m === l) e.x = s.x - r; else if (m === rr) e.x = s.x + s.w + r; else if (m === t) e.y = s.y - r; else e.y = s.y + s.h + r;
      }
    }
    return hit;
  }
  pointBlocked(x, y, r = 0, filter = null) {
    this._q.length = 0;
    const list = this.grid.query(x - r, y - r, x + r, y + r, this._q);
    for (const s of list) {
      if (!s.blocksMove || (filter && !filter(s))) continue;
      const cx = Math.max(s.x, Math.min(x, s.x + s.w)), cy = Math.max(s.y, Math.min(y, s.y + s.h));
      if ((x - cx) ** 2 + (y - cy) ** 2 < r * r || (r === 0 && x >= s.x && x <= s.x + s.w && y >= s.y && y <= s.y + s.h)) return true;
    }
    return false;
  }
}
