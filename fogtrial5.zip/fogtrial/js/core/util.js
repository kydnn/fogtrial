// Shared math + helpers. 1 meter = M pixels in world space.
export const M = 32;

export const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
export const lerp = (a, b, t) => a + (b - a) * t;
export const invLerp = (a, b, v) => clamp((v - a) / (b - a), 0, 1);
export const smoothstep = (a, b, v) => { const t = invLerp(a, b, v); return t * t * (3 - 2 * t); };
export const dist = (ax, ay, bx, by) => Math.hypot(bx - ax, by - ay);
export const dist2 = (ax, ay, bx, by) => { const dx = bx - ax, dy = by - ay; return dx * dx + dy * dy; };
export const dE = (a, b) => Math.hypot(b.x - a.x, b.y - a.y);
export const angleTo = (a, b) => Math.atan2(b.y - a.y, b.x - a.x);
export const normAngle = (a) => { while (a > Math.PI) a -= Math.PI * 2; while (a < -Math.PI) a += Math.PI * 2; return a; };
export const angleDiff = (a, b) => Math.abs(normAngle(a - b));
export const len = (x, y) => Math.hypot(x, y);
export const norm = (x, y) => { const l = Math.hypot(x, y) || 1; return { x: x / l, y: y / l }; };

// Seeded RNG so maps are reproducible from a seed.
export function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export const rr = (rng, a, b) => a + (b - a) * rng();
export const ri = (rng, a, b) => Math.floor(rr(rng, a, b + 1));
export const pick = (rng, arr) => arr[Math.floor(rng() * arr.length)];
export function shuffle(rng, arr) {
  for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [arr[i], arr[j]] = [arr[j], arr[i]]; }
  return arr;
}
// Gaussian-ish noise
export const gauss = (rng = Math.random) => (rng() + rng() + rng() - 1.5) / 1.5;

// Response curves for utility AI considerations.
export const curves = {
  linear: (x) => clamp(x, 0, 1),
  inverse: (x) => 1 - clamp(x, 0, 1),
  quad: (x) => { x = clamp(x, 0, 1); return x * x; },
  invQuad: (x) => { x = 1 - clamp(x, 0, 1); return x * x; },
  sqrt: (x) => Math.sqrt(clamp(x, 0, 1)),
  logistic: (x, k = 10, mid = 0.5) => 1 / (1 + Math.exp(-k * (x - mid))),
};

let _id = 1;
export const uid = (p = 'e') => `${p}${_id++}`;

export function fmtTime(s) {
  s = Math.max(0, Math.floor(s));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

// Point-in-rect and rect helpers. Rect = {x,y,w,h} with x,y top-left.
export const inRect = (px, py, r, pad = 0) => px >= r.x - pad && px <= r.x + r.w + pad && py >= r.y - pad && py <= r.y + r.h + pad;
export const rectCenter = (r) => ({ x: r.x + r.w / 2, y: r.y + r.h / 2 });
export const rectsOverlap = (a, b, pad = 0) => a.x - pad < b.x + b.w && a.x + a.w + pad > b.x && a.y - pad < b.y + b.h && a.y + a.h + pad > b.y;
