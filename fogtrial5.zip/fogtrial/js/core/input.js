// Keyboard/mouse input with a rebindable action map (ready for a controls screen).
export const DEFAULT_BINDS = {
  up: ['KeyW', 'ArrowUp'], down: ['KeyS', 'ArrowDown'], left: ['KeyA', 'ArrowLeft'], right: ['KeyD', 'ArrowRight'],
  interact: ['Space'], power: ['KeyQ'], secondary: ['KeyE'], pause: ['Escape', 'KeyP'], debug: ['Backquote', 'F3'],
  slot1: ['Digit1'], slot2: ['Digit2'], slot3: ['Digit3'], slot4: ['Digit4'], cycle: ['KeyF'], zoomIn: ['Equal', 'NumpadAdd'], zoomOut: ['Minus', 'NumpadSubtract'],
  // survivor mode
  walk: ['ShiftLeft', 'ShiftRight'], crouch: ['ControlLeft', 'KeyC'], perk: ['KeyF'], skip: ['Enter', 'NumpadEnter'], spectateNext: ['Tab'],
};

export class Input {
  constructor(el) {
    this.el = el; this.binds = JSON.parse(JSON.stringify(DEFAULT_BINDS));
    this.down = new Set(); this.pressed = new Set(); this.mouse = { x: 0, y: 0, l: false, r: false, lP: false, rP: false, rR: false, wheel: 0 };
    this.enabled = true;
    window.addEventListener('keydown', (e) => {
      if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT')) return;
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'F3', 'Tab'].includes(e.code)) e.preventDefault();
      if (!this.down.has(e.code)) this.pressed.add(e.code);
      this.down.add(e.code);
    });
    window.addEventListener('keyup', (e) => this.down.delete(e.code));
    window.addEventListener('blur', () => { this.down.clear(); this.mouse.l = this.mouse.r = false; });
    el.addEventListener('mousemove', (e) => { const r = el.getBoundingClientRect(); this.mouse.x = e.clientX - r.left; this.mouse.y = e.clientY - r.top; });
    el.addEventListener('mousedown', (e) => {
      if (e.button === 0) { this.mouse.l = true; this.mouse.lP = true; }
      if (e.button === 2) { this.mouse.r = true; this.mouse.rP = true; }
    });
    window.addEventListener('mouseup', (e) => { if (e.button === 0) this.mouse.l = false; if (e.button === 2) { this.mouse.r = false; this.mouse.rR = true; } });
    el.addEventListener('contextmenu', (e) => e.preventDefault());
    el.addEventListener('wheel', (e) => { this.mouse.wheel += Math.sign(e.deltaY); e.preventDefault(); }, { passive: false });
  }
  is(action) { return this.binds[action].some((k) => this.down.has(k)); }
  was(action) { return this.binds[action].some((k) => this.pressed.has(k)); }
  endFrame() { this.pressed.clear(); this.mouse.lP = this.mouse.rP = this.mouse.rR = false; this.mouse.wheel = 0; }
}
