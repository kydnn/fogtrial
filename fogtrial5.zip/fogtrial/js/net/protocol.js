// Network state sync shared by the server (Node) and the client (browser).
//
// The server runs the real Match. Clients build a "mirror" Match from the same config and seed
// (so the map, perks and characters are identical) and never simulate it: every snapshot
// patches the mirror's live state. The renderer and HUDs then draw the mirror exactly as they
// draw a local match.
//
// Encoding: values are turned into JSON-safe data; references to game objects become
// { $r: 'sv:0' } style refs (survivor 0, killer 1, pallet 7, device #12…), Sets/Maps/Infinity are
// tagged, functions are dropped. The server diffs every object field-by-field per client, so
// only what changed is sent.
import { Trap } from '../entities/objects.js';
import { Device, Projectile, Zone, Minion } from '../killers/framework.js';

export const NET_VERSION = 1;
export const SNAP_HZ = 20;
// fields never synced (bot brains, static definitions, collision geometry, scratch state)
export const SKIP = new Set(['ai', 'bot', 'def', 'Power', 'solid', 'rect', 'doorRect', 'exitRect', 'tile', 'aiProfile', 'unsubs', 'controller', 'netId']);
// dynamic object lists: server objects get a numeric net id
export const LISTS = { traps: 'tp', devices: 'dv', minions: 'mn', projectiles: 'pj', zones: 'zn' };
// static map arrays, matched by index (same seed → same map)
export const STATIC = { gens: 'gn', pallets: 'pl', windows: 'wn', hooks: 'hk', gates: 'gt', chests: 'ch', totems: 'tm' };
// append-only feeds streamed as new items
export const FEEDS = ['scratches', 'blood', 'grunts', 'sounds', 'loudNoises', 'notify', 'feed', 'aiLog'];
// match-level fields patched like an object
export const MATCH_FIELDS = ['time', 'state', 'stateT', 'gensDone', 'gatesPowered', 'collapse', 'collapseT', 'score', 'reveals', 'killerReveals', 'instinct', 'hookStageTime', 'camping'];

const round = (n) => (Number.isInteger(n) ? n : Math.round(n * 100) / 100);

export class Registry {
  constructor(m) { this.m = m; this.byObj = new Map(); this.byRef = new Map(); this.nid = new WeakMap(); this.next = 1; }
  set(obj, ref) { if (!obj) return; this.byObj.set(obj, ref); this.byRef.set(ref, obj); }
  // server: refresh every tick (lists change)
  rebuild() {
    const m = this.m; this.byObj.clear(); this.byRef.clear();
    this.set(m, 'm'); this.set(m.map, 'map'); this.set(m.world, 'world'); this.set(m.map.nav, 'nav'); this.set(m.bb, 'bb'); this.set(m.perks, 'perks'); this.set(m.events, 'events'); this.set(m.fx, 'fx'); this.set(m.map.hatch, 'ht');
    m.survivors.forEach((s, i) => this.set(s, 'sv:' + i)); m.killers.forEach((k, i) => this.set(k, 'kl:' + i));
    for (const [arr, p] of Object.entries(STATIC)) (m.map[arr] || []).forEach((o, i) => this.set(o, p + ':' + i));
    for (const [arr, p] of Object.entries(LISTS)) for (const o of m[arr]) this.set(o, p + ':' + this.idOf(o));
    for (const t of m.map.tiles || []) this.set(t, 'ti:' + t.id);
  }
  idOf(o) { let i = this.nid.get(o); if (!i) { i = this.next++; this.nid.set(o, i); } return i; }
}

// ---------------------------------------------------------------- encode (server)
export function enc(v, reg, depth = 0) {
  if (v === null || v === undefined) return null;
  const t = typeof v;
  if (t === 'number') return Number.isFinite(v) ? round(v) : Number.isNaN(v) ? 0 : { $i: v > 0 ? 1 : -1 };
  if (t === 'string' || t === 'boolean') return v;
  if (t === 'function' || t === 'symbol' || t === 'bigint') return undefined;
  const r = reg.byObj.get(v); if (r) return { $r: r };
  if (depth > 6) return undefined;
  if (Array.isArray(v)) return v.map((x) => { const e = enc(x, reg, depth + 1); return e === undefined ? null : e; });
  if (v instanceof Set) return { $s: [...v].map((x) => enc(x, reg, depth + 1)).filter((x) => x !== undefined) };
  if (v instanceof Map) return { $m: [...v].map(([a, b]) => [enc(a, reg, depth + 1), enc(b, reg, depth + 1)]).filter(([a, b]) => a !== undefined && b !== undefined) };
  if (ArrayBuffer.isView(v)) return undefined;
  const o = {};
  for (const k of Object.keys(v)) { if (SKIP.has(k) || k[0] === '_') continue; const e = enc(v[k], reg, depth + 1); if (e !== undefined) o[k] = e; }
  return o;
}
// Encode an object's own fields into { key: jsonString } (for diffing).
export function fieldsOf(obj, reg, only = null) {
  const out = {};
  for (const k of only || Object.keys(obj)) {
    if (SKIP.has(k) || k[0] === '_') continue;
    const e = enc(obj[k], reg, 1); if (e === undefined) continue;
    out[k] = JSON.stringify(e);
  }
  return out;
}
export function classTag(o) {
  if (o instanceof Trap) return 'Trap';
  if (o instanceof Device) return 'Device';
  if (o instanceof Projectile) return 'Projectile';
  if (o instanceof Zone) return 'Zone';
  if (o instanceof Minion) return 'Minion';
  return 'Obj';
}

// ---------------------------------------------------------------- decode (client)
const PROTO = { Trap: Trap.prototype, Device: Device.prototype, Projectile: Projectile.prototype, Zone: Zone.prototype, Minion: Minion.prototype, Obj: Object.prototype };
export function makeObj(tag) { return Object.create(PROTO[tag] || Object.prototype); }

const isTagged = (v) => v && typeof v === 'object' && !Array.isArray(v) && ('$r' in v || '$s' in v || '$m' in v || '$i' in v);
export function dec(v, resolve) {
  if (v === null || typeof v !== 'object') return v;
  if (Array.isArray(v)) return v.map((x) => dec(x, resolve));
  if ('$r' in v) return resolve(v.$r);
  if ('$i' in v) return v.$i > 0 ? Infinity : -Infinity;
  if ('$s' in v) return new Set(v.$s.map((x) => dec(x, resolve)));
  if ('$m' in v) return new Map(v.$m.map(([a, b]) => [dec(a, resolve), dec(b, resolve)]));
  const o = {}; for (const k in v) o[k] = dec(v[k], resolve); return o;
}
const isPlainTarget = (t) => t && typeof t === 'object' && !Array.isArray(t) && !(t instanceof Set) && !(t instanceof Map);
// Patch one field into a live object, keeping existing nested objects (and their prototypes).
export function applyField(target, key, val, resolve, isEntity) {
  const cur = target[key];
  if (val && typeof val === 'object' && !Array.isArray(val) && !isTagged(val) && isPlainTarget(cur) && !isEntity(cur)) {
    for (const k in val) applyField(cur, k, val[k], resolve, isEntity);
    for (const k of Object.keys(cur)) if (!(k in val) && !SKIP.has(k) && k[0] !== '_' && typeof cur[k] !== 'function') delete cur[k];
    return;
  }
  if (Array.isArray(val) && Array.isArray(cur) && cur.length === val.length && val.every((x) => x && typeof x === 'object' && !Array.isArray(x) && !isTagged(x)) && cur.every((x) => isPlainTarget(x) && !isEntity(x))) {
    val.forEach((x, i) => { for (const k in x) applyField(cur[i], k, x[k], resolve, isEntity); });
    return;
  }
  try { target[key] = dec(val, resolve); } catch (e) { /* getter-only property: ignore */ }
}
