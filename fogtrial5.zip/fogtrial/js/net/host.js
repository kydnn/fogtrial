// Server-side match host: runs the authoritative Match, applies human inputs, turns humans
// into bots when they disconnect, and builds per-client snapshot diffs. No networking here —
// server/server.js owns the sockets. Runs in Node (and in the browser for tests).
import { Match } from '../core/game.js';
import { SurvivorController } from '../player/survivorController.js';
import { SurvivorAI } from '../ai/survivorAI.js';
import { KillerAI } from '../ai/killer/killerAI.js';
import { Registry, enc, fieldsOf, classTag, LISTS, STATIC, FEEDS, MATCH_FIELDS } from './protocol.js';

const FX_SKIP = new Set(['constructor', 'update', 'draw']);

export class NetHost {
  // humans: [{ pid, role: 'killer' | 'survivor', index }]
  constructor(cfg, humans) {
    this.cfg = cfg; this.humans = new Map(); this.events = [];
    const audio = { play: (name, opts) => this.events.push({ a: name, o: opts && typeof opts === 'object' ? opts : undefined }) };
    this.m = new Match(cfg, { audio });
    const m = this.m;
    this.reg = new Registry(m);
    // record top-level fx calls so clients can replay the effects
    let depth = 0;
    const proto = Object.getPrototypeOf(m.fx);
    for (const f of Object.getOwnPropertyNames(proto)) {
      if (FX_SKIP.has(f) || typeof proto[f] !== 'function') continue;
      const orig = m.fx[f].bind(m.fx);
      m.fx[f] = (...args) => { if (depth === 0) this.events.push({ f, args }); depth++; try { return orig(...args); } finally { depth--; } };
    }
    for (const h of humans) {
      const e = { ...h, seq: 0 };
      if (h.role === 'survivor') { const s = m.survivors[h.index]; e.ent = s; e.ctl = new SurvivorController(m, s); e.ctl.grace = 0.35; }
      else e.ent = m.killers[h.index];
      this.humans.set(h.pid, e);
    }
    this.feedSeq = {}; this.seqOf = new WeakMap(); for (const f of FEEDS) this.feedSeq[f] = 0;
    this.clients = new Map(); // pid → per-client diff state
    this.frame = null;
  }
  get over() { return this.m.state === 'RESULTS'; }
  step(dt) { this.m.update(dt); }

  // ------------------------------------------------------------ inputs
  input(pid, msg) {
    const h = this.humans.get(pid); if (!h || h.bot) return;
    if (msg.seq) h.seq = Math.max(h.seq, msg.seq);
    const P = msg.p || {};
    if (h.role === 'killer') {
      const i = h.ent.input;
      i.mx = +msg.mx || 0; i.my = +msg.my || 0; i.aim = msg.aim ?? i.aim; i.aimDist = msg.aimDist ?? i.aimDist;
      if (msg.aimX !== undefined) { i.aimX = msg.aimX; i.aimY = msg.aimY; } else { delete i.aimX; delete i.aimY; }
      i.lmb = !!msg.lmb; i.rmb = !!msg.rmb; i.e = !!msg.e; i.space = !!msg.space;
      for (const k of ['lmbP', 'rmbP', 'rmbR', 'eP', 'spaceP', 'cycleP']) if (P[k]) i[k] = true;
      if (P.wheel) i.wheel = (i.wheel || 0) + P.wheel;
      if (P.slot) i.slot = P.slot;
    } else {
      const c = h.ctl;
      c.setInput({ mx: +msg.mx || 0, my: +msg.my || 0, walk: !!msg.walk, crouch: !!msg.crouch, aimX: msg.aimX ?? c.in.aimX, aimY: msg.aimY ?? c.in.aimY, e: !!msg.e, space: !!msg.space, item: !!msg.item });
      for (const k of ['eP', 'spaceP', 'itemP', 'perkP', 'leftP', 'rightP']) if (P[k]) c.in[k] = true;
    }
  }
  check(pid, res) { const h = this.humans.get(pid); if (h?.role === 'survivor' && h.ent.skillCheck) this.m.answerPlayerCheck(h.ent, true, res); }
  // a human left: their character keeps playing as a bot
  dropHuman(pid, difficulty = 5) {
    const h = this.humans.get(pid); if (!h || h.bot) return; h.bot = true;
    const m = this.m;
    if (h.role === 'survivor') {
      const s = h.ent; s.isPlayer = false; s.skillCheck = null; s.moveTo = null;
      m.playerCtls = m.playerCtls.filter((c) => c !== h.ctl); if (m.playerCtl === h.ctl) m.playerCtl = m.playerCtls[0] || null;
      if (s.alive) new SurvivorAI(s, m, difficulty, s.personality);
    } else {
      const k = h.ent; k.isPlayer = false; k.bot = new KillerAI(k, m, difficulty);
    }
    m.notifyK(`${h.name || 'A player'} left — a bot took over`, '#9fd0d0');
    this.clients.delete(pid);
  }

  // ------------------------------------------------------------ snapshots
  // Encode the whole live state once per snapshot tick (shared by every client).
  buildFrame() {
    const m = this.m, reg = this.reg; reg.rebuild();
    const ents = new Map(); // ref → { fields }
    ents.set('m', fieldsOf(m, reg, MATCH_FIELDS.filter((k) => k in m)));
    ents.set('ht', fieldsOf(m.map.hatch, reg));
    m.survivors.forEach((s, i) => ents.set('sv:' + i, fieldsOf(s, reg)));
    m.killers.forEach((k, i) => { const f = fieldsOf(k, reg); delete f.power; ents.set('kl:' + i, f); ents.set('kp:' + i, fieldsOf(k.power, reg)); });
    for (const [arr, p] of Object.entries(STATIC)) (m.map[arr] || []).forEach((o, i) => ents.set(p + ':' + i, fieldsOf(o, reg)));
    const lists = {};
    for (const [arr, p] of Object.entries(LISTS)) {
      lists[arr] = [];
      for (const o of m[arr]) { const ref = p + ':' + reg.idOf(o); lists[arr].push(ref); ents.set(ref, fieldsOf(o, reg)); ents.get(ref).$cls = classTag(o); }
    }
    // feeds: tag new items with a sequence number
    const feeds = {};
    for (const f of FEEDS) {
      const arr = m[f]; if (!Array.isArray(arr)) continue;
      let min = Infinity;
      for (const it of arr) { let q = this.seqOf.get(it); if (!q) { q = ++this.feedSeq[f]; this.seqOf.set(it, q); } if (q < min) min = q; }
      feeds[f] = { arr, min: min === Infinity ? this.feedSeq[f] + 1 : min };
    }
    const fx = { flash: m.fx.flash, flashColor: m.fx.flashColor };
    const events = this.events.map((e) => (e.f ? { f: e.f, a: e.args.map((x) => enc(x, reg)) } : { a: e.a, o: e.o ? enc(e.o, reg) : undefined }));
    this.events = [];
    this.frame = { ents, lists, feeds, events, fx };
    return this.frame;
  }
  // Diff of the current frame against what this client last received.
  snapshotFor(pid) {
    const F = this.frame, reg = this.reg;
    let c = this.clients.get(pid);
    if (!c) { c = { last: new Map(), feed: {}, full: true }; this.clients.set(pid, c); }
    const out = { t: 'snap', e: {}, l: {}, f: {}, ev: F.events };
    for (const [ref, fields] of F.ents) {
      let prev = c.last.get(ref); if (!prev) { prev = {}; c.last.set(ref, prev); }
      let d = null;
      for (const k in fields) { if (k === '$cls') continue; if (prev[k] !== fields[k]) { (d ||= {})[k] = fields[k]; prev[k] = fields[k]; } }
      if (d) { if (fields.$cls && !prev.$cls) { d.$cls = fields.$cls; prev.$cls = fields.$cls; } out.e[ref] = d; }
    }
    // forget objects that disappeared
    for (const ref of c.last.keys()) if (!F.ents.has(ref)) c.last.delete(ref);
    for (const k in F.lists) { const key = F.lists[k].join(','); if (c['L' + k] !== key) { out.l[k] = F.lists[k]; c['L' + k] = key; } }
    for (const f in F.feeds) {
      const { arr, min } = F.feeds[f]; const last = c.feed[f] || 0; const add = [];
      for (const it of arr) { const q = this.seqOf.get(it); if (q > last) add.push([q, enc(it, reg)]); }
      if (add.length || c.full) { out.f[f] = { min, add: f === 'aiLog' ? add.slice(-20) : add }; c.feed[f] = this.feedSeq[f]; }
    }
    const fxk = F.fx.flash.toFixed(2) + F.fx.flashColor; if (c.fx !== fxk) { out.fx = F.fx; c.fx = fxk; }
    // per-player extras: input ack, prompts, killer context
    const h = this.humans.get(pid);
    if (h && !h.bot) {
      out.ack = h.seq;
      if (h.role === 'survivor') out.pr = h.ctl.prompts();
      else { const ctx = this.m.killerContext(h.ent); out.ctx = ctx ? { type: ctx.type, label: ctx.label } : null; }
    }
    // stringify sub-values (fields are already JSON strings)
    c.full = false;
    return out;
  }
  // Serialize a snapshot whose field values are pre-encoded JSON strings.
  static serialize(snap) {
    const parts = [];
    for (const ref in snap.e) { const d = snap.e[ref]; parts.push(JSON.stringify(ref) + ':{' + Object.entries(d).map(([k, v]) => JSON.stringify(k) + ':' + (k === '$cls' ? JSON.stringify(v) : v)).join(',') + '}'); }
    const rest = { ...snap }; delete rest.e;
    const j = JSON.stringify(rest);
    return j.slice(0, -1) + (j.length > 2 ? ',' : '') + '"e":{' + parts.join(',') + '}}';
  }
  results() { return this.m.results(); }
}
