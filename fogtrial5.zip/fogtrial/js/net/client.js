// Multiplayer client: lobby connection, the mirror match, snapshot application, smoothing of
// other players and client-side prediction (with server reconciliation) for your own movement.
import { Match } from '../core/game.js';
import { M, dist } from '../core/util.js';
import { Registry, applyField, dec, makeObj, LISTS, STATIC, NET_VERSION } from './protocol.js';

const SMOOTH = new Set(['sv', 'kl', 'mn']);
export class NetClient {
  constructor({ onRoom, onStart, onEnd, onError, onClose, onChat }) {
    this.cb = { onRoom, onStart, onEnd, onError, onClose, onChat };
    this.ws = null; this.pid = null; this.room = null; this.m = null; this.seq = 0; this.hist = []; this.pending = {}; this.sendT = 0; this.prompts = [];
  }
  static defaultUrl() {
    try { const s = localStorage.getItem('fogtrial.server'); if (s) return s; } catch (e) { /* ignore */ }
    if (location.protocol === 'http:' || location.protocol === 'https:') return location.origin;
    return '';
  }
  wsUrl(u) { u = (u || '').trim().replace(/\/+$/, ''); if (!/^(https?|wss?):\/\//.test(u)) u = 'https://' + u; return u.replace(/^http/, 'ws'); }
  connect(url, name) {
    return new Promise((resolve, reject) => {
      let ws; try { ws = new WebSocket(this.wsUrl(url)); } catch (e) { reject(e); return; }
      this.ws = ws; let opened = false;
      const timer = setTimeout(() => { if (!opened) { ws.close(); reject(new Error('Could not reach the server (it can take a minute to wake up on Render — try again).')); } }, 70000);
      ws.onopen = () => { opened = true; clearTimeout(timer); try { localStorage.setItem('fogtrial.server', url); } catch (e) { /* ignore */ } this.send({ t: 'hello', name, v: NET_VERSION }); };
      ws.onmessage = (ev) => { let msg; try { msg = JSON.parse(ev.data); } catch (e) { return; } if (msg.t === 'welcome') { this.pid = msg.pid; resolve(this); } this.onMsg(msg); };
      ws.onerror = () => { if (!opened) { clearTimeout(timer); reject(new Error('Could not connect to ' + url)); } };
      ws.onclose = () => { this.ws = null; this.cb.onClose?.(); };
    });
  }
  get connected() { return !!this.ws && this.ws.readyState === 1; }
  send(o) { if (this.connected) this.ws.send(JSON.stringify(o)); }
  close() { try { this.ws?.close(); } catch (e) { /* ignore */ } this.ws = null; }
  onMsg(msg) {
    switch (msg.t) {
      case 'room': this.room = msg; this.cb.onRoom?.(msg); break;
      case 'err': this.cb.onError?.(msg.msg); break;
      case 'start': this.startMatch(msg); break;
      case 'snap': if (this.m) this.applySnap(msg); break;
      case 'end': if (this.m) { const r = msg.results; r.playerRole = this.role === 'killer' ? 'killer' : this.role === 'survivor' ? 'survivor' : 'spectate'; const me = this.me; r.player = me && me.kind === 'survivor' ? { name: me.name, outcome: me.outcome || (me.alive ? 'Alive' : '—') } : null; r.survivors.forEach((s, i) => (s.isYou = this.role === 'survivor' && i === this.index)); this.cb.onEnd?.(r); } this.m = null; break;
      case 'left': this.room = null; break;
    }
  }

  // ------------------------------------------------------------ mirror match
  startMatch(msg) {
    const cfg = { ...msg.cfg, playerRole: msg.role === 'killer' ? 'killer' : msg.role === 'survivor' ? 'survivor' : 'spectate', mirror: true };
    // the server's human flags decide isPlayer; the local role only decides whose eyes we use
    const m = new Match(cfg);
    for (const s of m.survivors) s.ai = null;
    for (const k of m.killers) k.bot = null;
    for (const arr of Object.keys(LISTS)) m[arr] = [];
    m.playerCtls = []; m.aiPaused = true; m.net = this;
    this.role = msg.role; this.index = msg.index; this.m = m; this.objs = new Map(); this.reg = new Registry(m); this.hist = []; this.seq = 0; this.first = true;
    const me = msg.role === 'killer' ? m.killers[msg.index] : msg.role === 'survivor' ? m.survivors[msg.index] : null; this.me = me;
    Object.defineProperty(m, 'player', { value: me, configurable: true });
    if (me?.kind === 'killer') m.killer = me;
    this.input = { mx: 0, my: 0, walk: false, crouch: false, aimX: me ? me.x : 0, aimY: me ? me.y : 0 };
    const net = this;
    m.playerCtl = me?.kind === 'survivor' ? { in: this.input, prompts: () => net.prompts } : null;
    this.pred = me ? { x: me.x, y: me.y, r: me.r } : null;
    this.rebuildReg();
    this.cb.onStart?.(m, msg);
  }
  rebuildReg() {
    const reg = this.reg, m = this.m; reg.byObj.clear(); reg.byRef.clear();
    reg.set(m, 'm'); reg.set(m.map, 'map'); reg.set(m.world, 'world'); reg.set(m.map.nav, 'nav'); reg.set(m.bb, 'bb'); reg.set(m.perks, 'perks'); reg.set(m.events, 'events'); reg.set(m.fx, 'fx'); reg.set(m.map.hatch, 'ht');
    m.survivors.forEach((s, i) => reg.set(s, 'sv:' + i)); m.killers.forEach((k, i) => reg.set(k, 'kl:' + i));
    for (const [arr, p] of Object.entries(STATIC)) (m.map[arr] || []).forEach((o, i) => reg.set(o, p + ':' + i));
    for (const t of m.map.tiles || []) reg.set(t, 'ti:' + t.id);
    for (const [ref, o] of this.objs) reg.set(o, ref);
  }
  resolve = (ref) => {
    const o = this.reg.byRef.get(ref); if (o) return o;
    const p = ref.split(':')[0];
    if (Object.values(LISTS).includes(p)) { const n = makeObj('Obj'); this.objs.set(ref, n); this.reg.set(n, ref); return n; } // seen before its list entry
    return null;
  };
  isEntity = (o) => this.reg.byObj.has(o);

  applySnap(s) {
    const m = this.m;
    // 1. dynamic lists (devices, minions, projectiles…)
    for (const arr in s.l) {
      const refs = s.l[arr];
      const keep = new Set(refs);
      for (const ref of [...this.objs.keys()]) if (ref.startsWith(LISTS[arr] + ':') && !keep.has(ref)) { this.objs.delete(ref); }
      m[arr] = refs.map((ref) => {
        let o = this.objs.get(ref);
        const cls = s.e[ref]?.$cls;
        if (!o || (cls && Object.getPrototypeOf(o) === Object.prototype && cls !== 'Obj')) { const n = makeObj(cls || 'Obj'); if (o) Object.assign(n, o); o = n; this.objs.set(ref, o); }
        return o;
      });
    }
    this.rebuildReg();
    // 2. entity fields
    for (const ref in s.e) {
      const d = s.e[ref];
      let o;
      if (ref.startsWith('kp:')) o = m.killers[+ref.slice(3)]?.power; else o = ref === 'm' ? m : this.reg.byRef.get(ref);
      if (!o) continue;
      const smooth = SMOOTH.has(ref.split(':')[0]);
      for (const k in d) {
        if (k === '$cls') continue;
        if (smooth && (k === 'x' || k === 'y')) { o['_n' + k] = d[k]; if (this.first || o['_seen'] !== true) o[k] = d[k]; continue; }
        applyField(o, k, d[k], this.resolve, this.isEntity);
      }
      if (smooth) { o._seen = true; o._nt = performance.now(); }
    }
    // 3. world geometry that changes during play: dropped / broken pallets, opened gates
    for (const p of m.map.pallets) { const want = p.state === 'down'; if (want !== !!p._inWorld) { if (want) m.world.add(p.solid); else m.world.remove(p.solid); p._inWorld = want; } }
    for (const g of m.map.gates) if (g.open && !g._gone) { m.world.remove(g.solid); g._gone = true; }
    // 4. streamed feeds (scratch marks, noises, notifications, AI log…)
    for (const f in s.f) {
      const F = s.f[f]; let arr = (m[f] ||= []);
      arr = arr.filter((it) => (it._seq || 0) >= F.min);
      for (const [q, v] of F.add) { const it = dec(v, this.resolve); if (it && typeof it === 'object') it._seq = q; arr.push(it); }
      m[f] = arr;
    }
    if (s.fx) { m.fx.flash = Math.max(m.fx.flash, s.fx.flash); m.fx.flashColor = s.fx.flashColor; }
    // 5. effects and sounds that happened on the server
    for (const e of s.ev || []) {
      try {
        if (e.f) m.fx[e.f]?.(...e.a.map((x) => dec(x, this.resolve)));
        else if (e.a && this.audio) this.audio.play(e.a, e.o ? dec(e.o, this.resolve) : undefined);
      } catch (err) { /* cosmetic */ }
    }
    this.serverTime = m.time; this.recvAt = performance.now();
    if (s.pr) this.prompts = s.pr;
    if ('ctx' in s) this.ctx = s.ctx;
    // 6. reconcile our own predicted movement
    if (this.me && s.ack !== undefined) this.reconcile(s.ack);
    this.first = false;
  }

  // ------------------------------------------------------------ prediction
  canPredict() {
    const me = this.me; if (!me) return false;
    if (me.kind === 'survivor') {
      if (!me.standing || me.vault || me.trap || me.control || me.health === 'dying') return false;
      const moving = Math.hypot(this.input.mx, this.input.my) > 0.1;
      if (me.action && (!moving || ['dropPallet', 'useEmp', 'vault', 'unhookSelf'].includes(me.action.type))) return false;
      return true;
    }
    if (me.action || me.stunT > 0 || me.attack?.state === 'lunge') return false;
    if (me.power.overrideMove?.(0, this.m)) return false;
    return true;
  }
  stepPred(P, mx, my, dt, walk, crouch) {
    const me = this.me, m = this.m; const l = Math.hypot(mx, my); if (l < 0.1) return;
    let sp;
    if (me.kind === 'survivor') { const mm = me.moveMode; me.moveMode = crouch ? 'crouch' : walk ? 'walk' : 'run'; sp = me.speed(); me.moveMode = mm; }
    else sp = me.baseSpeed(m);
    m.world.move(P, (mx / l) * sp * dt, (my / l) * sp * dt, me.r, (q) => !(q.kind === 'gate' && q.ref.open));
  }
  reconcile(ack) {
    const me = this.me, P = this.pred;
    if (me._nx === undefined) return;
    this.hist = this.hist.filter((h) => h.seq > ack);
    P.x = me._nx; P.y = me._ny;
    if (this.canPredict()) for (const h of this.hist) this.stepPred(P, h.mx, h.my, h.dt, h.walk, h.crouch);
  }
  // per render frame
  frame(dt, input) {
    const m = this.m; if (!m) return;
    if (this.recvAt) m.time = this.serverTime + Math.min(0.3, (performance.now() - this.recvAt) / 1000);
    m.fx.update(dt);
    const now = performance.now();
    // others: glide toward the last server position (with a little velocity lead)
    for (const e of [...m.survivors, ...m.killers, ...m.minions]) {
      if (e === this.me || e._nx === undefined) continue;
      const age = Math.min(0.12, (now - (e._nt || now)) / 1000);
      const tx = e._nx + (e.vx || 0) * age, ty = e._ny + (e.vy || 0) * age;
      if (Math.hypot(tx - e.x, ty - e.y) > 6 * M) { e.x = tx; e.y = ty; }
      else { const k = Math.min(1, dt * 16); e.x += (tx - e.x) * k; e.y += (ty - e.y) * k; }
    }
    for (const p of m.projectiles) if (p.vx !== undefined && !p.arc) { p.x += p.vx * dt; p.y += p.vy * dt; }
    // me: predicted movement from my own input, corrected by the server
    const me = this.me; if (!me || me._nx === undefined) return;
    const P = this.pred;
    if (this.canPredict()) {
      this.hist.push({ seq: this.seq + 1, mx: input.mx, my: input.my, dt, walk: input.walk, crouch: input.crouch });
      if (this.hist.length > 240) this.hist.shift();
      this.stepPred(P, input.mx, input.my, dt, input.walk, input.crouch);
    } else { this.hist.length = 0; const k = Math.min(1, dt * 18); P.x += (me._nx - P.x) * k; P.y += (me._ny - P.y) * k; }
    if (Math.hypot(P.x - me.x, P.y - me.y) > 5 * M) { me.x = P.x; me.y = P.y; }
    else { const k = Math.min(1, dt * 30); me.x += (P.x - me.x) * k; me.y += (P.y - me.y) * k; }
    if (me.kind === 'killer' && !me.power.lockFacing && input.aim !== undefined) me.facing = input.aim;
  }
  // ------------------------------------------------------------ input
  // held: current key state; presses: edge-triggered keys since the last send
  sendInput(dt, held, presses) {
    for (const k in presses) if (presses[k]) this.pending[k] = k === 'wheel' ? (this.pending.wheel || 0) + presses[k] : presses[k];
    this.sendT -= dt;
    const urgent = Object.keys(this.pending).length > 0;
    if (this.sendT > 0 && !urgent) return;
    this.sendT = 1 / 30;
    this.seq++;
    this.send({ t: 'in', seq: this.seq, ...held, p: this.pending });
    this.pending = {};
  }
  sendCheck(res) { this.send({ t: 'chk', res }); }
}
