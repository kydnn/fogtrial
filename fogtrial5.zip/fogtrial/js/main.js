// App shell: game-state flow (LOBBY → LOADOUT → MAP_LOADING → match → RESULTS),
// fixed-step loop, player input → killer, rendering, HUD, menus and debug.
import { Match } from './core/game.js';
import { Camera } from './core/camera.js';
import { Input } from './core/input.js';
import { Audio } from './core/audio.js';
import { EV } from './core/events.js';
import { Renderer } from './ui/render.js';
import { HUD } from './ui/hud.js';
import { SurvivorHUD } from './ui/survivorHud.js';
import { SurvivorController } from './player/survivorController.js';
import { Menus } from './ui/menus.js';
import { DebugPanel } from './ui/debug.js';
import { STORY_LEVELS, levelConfig, loadProgress, saveProgress } from './story/levels.js';
import { MAPS } from './maps/maps.js';
import { NetClient } from './net/client.js';

const canvas = document.getElementById('game');
const renderer = new Renderer(canvas);
const cam = new Camera();
const input = new Input(canvas);
const audio = new Audio();
const killerHud = new HUD(document.getElementById('hud'));
const survivorHud = new SurvivorHUD(document.getElementById('hud'));
let hud = killerHud;
const debug = new DebugPanel(document.getElementById('debug'), renderer);
const loading = document.getElementById('loading');

const app = { phase: 'LOBBY', match: null, cfg: null, story: null, paused: false, spectating: false, specIdx: 0, settings: { zoom: 1, volume: 0.5, debug: false } };
try { Object.assign(app.settings, JSON.parse(localStorage.getItem('fogtrial.settings') || '{}')); } catch (e) { /* ignore */ }
const saveSettings = () => { try { localStorage.setItem('fogtrial.settings', JSON.stringify(app.settings)); } catch (e) { /* ignore */ } };
cam.userZoom = app.settings.zoom; audio.setVolume(app.settings.volume);
document.body.classList.toggle('nohints', app.settings.hints === false);

const menus = new Menus(document.getElementById('screen'), {
  sfx: (n) => { audio.init(); audio.play(n); },
  start: (cfg) => startMatch(cfg, null),
  startStory: (level, loadout) => startMatch(levelConfig(level, loadout), level),
  retry: () => startMatch(app.cfg, app.story),
  settings: () => app.settings,
  setSetting: (k, v) => {
    app.settings[k] = v; saveSettings();
    if (k === 'volume') audio.setVolume(v); if (k === 'zoom') cam.userZoom = v; if (k === 'hints') document.body.classList.toggle('nohints', v === false);
  },
  net: () => getNet(),
  spectate: (d) => startMatch({ mapId: 'rotwood', killerId: 'trapper', survivorCount: 4, difficulty: d, killerPerks: [], playerRole: 'spectate', killerDifficulty: d }, null),
});

// ---------------------------------------------------------------- multiplayer
let net = null;
function getNet() {
  if (net) return net;
  net = new NetClient({
    onRoom: (st) => { if (app.phase === 'MATCH') return; if (menus.inRoom || menus.mpWaiting || app.phase === 'RESULTS' && false) menus.mpRoom(st); },
    onStart: (m, msg) => startNetMatch(m, msg),
    onEnd: (res) => { res.net = true; app.match = null; setPhase('RESULTS'); menus.inRoom = false; menus.results(res, {}); },
    onError: (msg) => { if (app.phase === 'MATCH') app.match?.notifyK(msg, '#e05a5a'); else if (menus.mpWaiting && !net.room) menus.mpConnect(msg); else menus.toast(msg); },
    onClose: () => { const wasIn = app.phase === 'MATCH' && app.match?.net; net.room = null; menus.inRoom = false; if (wasIn) { app.match = null; setPhase('LOBBY'); } if (wasIn || menus.mpWaiting || menus.root.querySelector('.mproom')) menus.mpConnect('Disconnected from the server.'); },
  });
  net.audio = audio;
  return net;
}
function startNetMatch(m, msg) {
  audio.init();
  menus.hide(); menus.inRoom = false;
  app.match = m; app.cfg = m.cfg; app.story = null; app.paused = false; app.spectating = msg.role === 'spectator'; app.skip = false; app.specIdx = 0;
  hud = msg.role === 'survivor' ? survivorHud : killerHud;
  renderer.setMap(m.map); cam.snap(viewTarget(m)); cam.zoom = cam.baseZoom() * cam.userZoom;
  renderer.debug.on = false; debug.root.hidden = true; syncDebugClass();
  hud.build(m);
  setPhase('MATCH');
}
// multiplayer input: same keys, sent to the server instead of driving the local match
function applyNetInput(m, dt) {
  const me = m.player; const nc = m.net;
  let mx = (input.is('right') ? 1 : 0) - (input.is('left') ? 1 : 0), my = (input.is('down') ? 1 : 0) - (input.is('up') ? 1 : 0);
  const l = Math.hypot(mx, my); if (l > 0) { mx /= l; my /= l; }
  if (!me || app.paused) { nc.frame(dt, { mx: 0, my: 0 }); return; }
  const w = cam.toWorld(input.mouse.x, input.mouse.y);
  if (me.kind === 'survivor') {
    const held = { mx, my, walk: input.is('walk'), crouch: input.is('crouch'), aimX: w.x, aimY: w.y, e: input.is('secondary'), space: input.is('interact'), item: input.mouse.r || input.is('power') };
    Object.assign(nc.input, held);
    let spaceP = input.was('interact');
    // skill checks are judged here, against the needle the player actually saw
    const c = me.skillCheck;
    if (c && spaceP) { const pos = (m.time - c.t0 - c.warn) / c.dur; if (pos > -0.2) { const res = pos >= c.zone && pos <= c.zone + c.good ? (pos <= c.zone + c.great ? 'great' : 'good') : 'fail'; nc.sendCheck(res); me.skillCheck = null; spaceP = false; audio.play(res === 'fail' ? 'genfail' : 'ui'); } }
    nc.frame(dt, held);
    nc.sendInput(dt, held, { eP: input.was('secondary'), spaceP, itemP: input.mouse.rP || input.was('power'), perkP: input.was('perk'), leftP: input.was('left'), rightP: input.was('right') });
  } else {
    const p = cam.toScreen(me.x, me.y);
    const held = { mx, my, aim: Math.atan2(input.mouse.y - p.y, input.mouse.x - p.x), aimDist: Math.hypot(input.mouse.y - p.y, input.mouse.x - p.x) / cam.zoom, lmb: input.mouse.l, rmb: input.mouse.r || input.is('power'), e: input.is('secondary'), space: input.is('interact') };
    if (me.power.viewPoint?.(m)) { held.aimX = w.x; held.aimY = w.y; }
    me.input.aim = held.aim; me.input.aimDist = held.aimDist; if (held.aimX !== undefined) { me.input.aimX = held.aimX; me.input.aimY = held.aimY; }
    let slot = 0; for (let n = 1; n <= 4; n++) if (input.was('slot' + n)) slot = n;
    nc.frame(dt, held);
    nc.sendInput(dt, held, { lmbP: input.mouse.lP, rmbP: input.mouse.rP || input.was('power'), rmbR: input.mouse.rR, eP: input.was('secondary'), spaceP: input.was('interact'), cycleP: input.was('cycle'), wheel: input.mouse.wheel && wheelForAbility(me) ? input.mouse.wheel : 0, slot });
  }
}

function resize() { const w = window.innerWidth, h = window.innerHeight; renderer.resize(w, h); cam.resize(w, h); }
window.addEventListener('resize', resize); resize();

function setPhase(p) { app.phase = p; document.body.dataset.phase = p; }
function syncDebugClass() { document.body.classList.toggle('dbg', !debug.root.hidden); }

function startMatch(cfg, story) {
  const spectate = cfg.playerRole === 'spectate';
  audio.init();
  app.cfg = cfg; app.story = story; setPhase('MAP_LOADING');
  menus.hide();
  loading.hidden = false;
  loading.querySelector('b').textContent = (MAPS[cfg.mapId] || MAPS.rotwood).name;
  loading.querySelector('span').textContent = story ? (story.random ? story.name : `Scenario ${story.id} · ${story.name}`) : 'Entering the trial';
  setTimeout(() => {
    const m = new Match({ ...cfg, perf: app.settings.perf || 'high' }, { audio });
    app.match = m; app.paused = false; app.spectating = spectate; app.skip = false;
    if (cfg.playerRole === 'survivor') new SurvivorController(m, m.player);
    hud = cfg.playerRole === 'survivor' ? survivorHud : killerHud;
    wireAudio(m);
    renderer.setMap(m.map); cam.snap(viewTarget(m)); cam.zoom = cam.baseZoom() * cam.userZoom;
    renderer.debug.on = app.settings.debug || spectate; debug.root.hidden = !renderer.debug.on; syncDebugClass();
    if (spectate) renderer.debug.xray = true;
    hud.build(m);
    loading.hidden = true;
    setPhase('MATCH');
  }, 60);
}

function wireAudio(m) {
  m.events.on(EV.KILLER_HIT, () => audio.play('hit'));
  m.events.on(EV.KILLER_MISS, () => audio.play('swing'));
  m.events.on(EV.KILLER_STUNNED, () => { audio.play('stun'); m.fx.shake(8); });
  m.events.on(EV.SKILL_CHECK_FAILURE, () => audio.play('genfail'));
}

function finishMatch() {
  const m = app.match; const res = m.results();
  setPhase('RESULTS');
  let passed = false, next = null;
  if (app.story) {
    const L = app.story; passed = res.kills >= L.requiredKills;
    if (!L.random) {
      const prog = loadProgress(); prog.best[L.id] = Math.max(prog.best[L.id] ?? 0, res.kills);
      if (passed) { prog.unlocked = Math.max(prog.unlocked, L.id + 1); next = STORY_LEVELS.find((l) => l.id === L.id + 1) || null; }
      saveProgress(prog);
    }
  }
  menus.results(res, { story: app.story, passed, nextLevel: next });
}

function togglePause() {
  if (app.phase !== 'MATCH') return;
  app.paused = !app.paused;
  if (app.paused) {
    menus.pause(() => togglePause(), () => { app.paused = false; const wasNet = app.match?.net; app.match = null; setPhase('LOBBY'); if (wasNet) { net.send({ t: 'leave' }); net.room = null; menus.mpConnect('You left the match.'); } else menus.main(); }, {
      zoom: cam.userZoom, volume: audio.vol, debug: renderer.debug.on,
      onZoom: (z) => { cam.userZoom = z; app.settings.zoom = z; saveSettings(); },
      onVolume: (v) => { audio.setVolume(v); app.settings.volume = v; saveSettings(); },
      wheel: app.settings.wheel || 'auto', onWheel: (w) => { app.settings.wheel = w; saveSettings(); },
      onDebug: (d) => { renderer.debug.on = d; debug.root.hidden = !d; syncDebugClass(); app.settings.debug = d; saveSettings(); },
    });
  } else menus.hide();
}

function moodFor(m) {
  const p = m.player;
  if (p && p.kind === 'survivor') return m.inChase(p) ? 1 : Math.min(0.8, 0.2 + (renderer.heartbeat || 0));
  return m.chaseTarget ? 1 : 0.2;
}
function wheelForAbility(k) { const w = app.settings.wheel || 'auto'; return w === 'ability' || (w === 'auto' && !!k.power.selectable); }
// Who the camera follows / whose eyes the renderer uses
function viewTarget(m) {
  const p = m.player;
  if (p && (p.kind === 'killer' || p.alive)) return p;
  if (p && p.kind === 'survivor') { const alive = m.survivors.filter((s) => s.alive); return alive.length ? alive[app.specIdx % alive.length] : m.killer; }
  if (m.net && app.specIdx) { const all = [...m.killers, ...m.survivors.filter((s) => s.alive)]; return all[app.specIdx % all.length]; }
  return m.killer;
}
function applySurvivorInput(m) {
  const ctl = m.playerCtl; if (!ctl) return;
  let mx = (input.is('right') ? 1 : 0) - (input.is('left') ? 1 : 0), my = (input.is('down') ? 1 : 0) - (input.is('up') ? 1 : 0);
  const l = Math.hypot(mx, my); if (l > 0) { mx /= l; my /= l; }
  const w = cam.toWorld(input.mouse.x, input.mouse.y), I = ctl.in;
  ctl.setInput({ mx, my, walk: input.is('walk'), crouch: input.is('crouch'), aimX: w.x, aimY: w.y, e: input.is('secondary'), space: input.is('interact'), item: input.mouse.r || input.is('power') });
  // presses accumulate until the controller consumes them (the fixed step may not run this frame)
  I.eP ||= input.was('secondary'); I.spaceP ||= input.was('interact'); I.itemP ||= input.mouse.rP || input.was('power'); I.perkP ||= input.was('perk');
  I.leftP ||= input.was('left'); I.rightP ||= input.was('right');
}
function applyInput(m) {
  if (m.cfg.playerRole === 'survivor') return applySurvivorInput(m);
  if (m.cfg.playerRole === 'spectate') return;
  const k = m.killer, i = k.input;
  let mx = (input.is('right') ? 1 : 0) - (input.is('left') ? 1 : 0), my = (input.is('down') ? 1 : 0) - (input.is('up') ? 1 : 0);
  const l = Math.hypot(mx, my); if (l > 0) { mx /= l; my /= l; }
  i.mx = mx; i.my = my;
  const p = cam.toScreen(k.x, k.y); i.aim = Math.atan2(input.mouse.y - p.y, input.mouse.x - p.x);
  i.aimDist = Math.hypot(input.mouse.y - p.y, input.mouse.x - p.x) / cam.zoom;
  if (k.power.viewPoint?.(m)) { const w = cam.toWorld(input.mouse.x, input.mouse.y); i.aimX = w.x; i.aimY = w.y; } else { delete i.aimX; delete i.aimY; }
  i.lmb = input.mouse.l; i.lmbP = i.lmbP || input.mouse.lP;
  i.rmb = input.mouse.r || input.is('power'); i.rmbP = i.rmbP || input.mouse.rP || input.was('power'); i.rmbR = input.mouse.rR;
  i.e = input.is('secondary'); i.eP = i.eP || input.was('secondary');
  i.space = input.is('interact'); i.spaceP = i.spaceP || input.was('interact');
  // Ability selection (the Lich's spells): number keys, F to cycle, and the mouse wheel
  // when the wheel is set to 'ability' (or 'auto' and the killer has selectable abilities).
  for (let n = 1; n <= 4; n++) if (input.was('slot' + n)) i.slot = n;
  if (input.was('cycle')) i.cycleP = true;
  if (input.mouse.wheel && wheelForAbility(k)) i.wheel = (i.wheel || 0) + input.mouse.wheel;
}

let last = performance.now(), acc = 0;
const STEP = 1 / 60;
function frame(now) {
  requestAnimationFrame(frame);
  let dt = Math.min(0.1, (now - last) / 1000); last = now;
  const m = app.match;
  if (input.was('debug') && m) { renderer.debug.on = !renderer.debug.on; debug.root.hidden = !renderer.debug.on; syncDebugClass(); app.settings.debug = renderer.debug.on; saveSettings(); }
  if (input.was('pause')) togglePause();
  if (m && (app.phase === 'MATCH' || app.phase === 'RESULTS')) {
    if (app.phase === 'MATCH' && m.net) {
      if (input.was('zoomIn')) cam.userZoom = Math.min(1.5, cam.userZoom + 0.08); if (input.was('zoomOut')) cam.userZoom = Math.max(0.7, cam.userZoom - 0.08);
      if (input.mouse.wheel && (!m.player || m.player.kind !== 'killer' || !wheelForAbility(m.player))) cam.userZoom = Math.max(0.7, Math.min(1.5, cam.userZoom - input.mouse.wheel * 0.08));
      applyNetInput(m, dt);
      const p = m.player;
      if (!p || (p.kind === 'survivor' && !p.alive)) { if (input.was('spectateNext')) app.specIdx++; }
      audio.setMood(moodFor(m));
    } else if (app.phase === 'MATCH' && !app.paused) {
      if (input.was('zoomIn')) cam.userZoom = Math.min(1.5, cam.userZoom + 0.08); if (input.was('zoomOut')) cam.userZoom = Math.max(0.7, cam.userZoom - 0.08);
      if (input.mouse.wheel && (m.cfg.playerRole !== 'killer' || !wheelForAbility(m.killer))) { cam.userZoom = Math.max(0.7, Math.min(1.5, cam.userZoom - input.mouse.wheel * 0.08)); app.settings.zoom = cam.userZoom; }
      applyInput(m);
      const p = m.player;
      if (p && p.kind === 'survivor' && !p.alive) {
        if (input.was('skip')) app.skip = true;
        if (input.was('spectateNext')) app.specIdx++;
      }
      acc += dt;
      let steps = 0;
      if (app.skip) { for (let n = 0; n < 1200 && m.state !== 'RESULTS'; n++) m.update(STEP); acc = 0; }
      while (acc >= STEP && steps < 5) { m.update(STEP); acc -= STEP; steps++; }
      if (m.state === 'RESULTS') finishMatch();
      audio.setMood(moodFor(m));
    }
    const vt = viewTarget(m);
    const vp = vt.kind === 'killer' && vt.power.viewPoint?.(m);
    const aim = vp ? 0 : vt.kind === 'killer' ? (vt.input.aim ?? 0) : (vt.isPlayer && m.playerCtl ? Math.atan2(m.playerCtl.in.aimY - vt.y, m.playerCtl.in.aimX - vt.x) : vt.facing);
    cam.update(dt, vp ? { x: vp.x, y: vp.y, kind: 'pod' } : vt, m.map, aim, m.fx.shakeAmt);
    renderer.draw(m, cam, { viewer: vt });
    if (app.phase === 'MATCH') { hud.update(m, dt, m.net ? (m.player?.kind === 'killer' ? m.net.ctx : null) : m.cfg.playerRole === 'killer' ? m.killerContext() : null); if (!m.net) debug.update(m, dt); }
  } else {
    // idle backdrop
    const ctx = renderer.ctx; ctx.setTransform(renderer.dpr, 0, 0, renderer.dpr, 0, 0);
    ctx.fillStyle = '#0b0c0e'; ctx.fillRect(0, 0, renderer.w, renderer.h);
  }
  input.endFrame();
}

setPhase('LOBBY');
{ const code = new URLSearchParams(location.search).get('room'); if (code) menus.mpConnect('', code.toUpperCase().slice(0, 4)); else menus.main(); }
requestAnimationFrame(frame);
window.__fog = app; // handy in the console
app.start = (cfg) => startMatch(cfg, null); // tests / console: start any configuration
