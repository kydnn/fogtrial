// 2v8 mode: two killers against eight survivors (rules after the live DBD 2v8 event).
//  • a larger version of the chosen map: 13 generators, 8 to power the 3 exit gates
//  • hooking sends the survivor to a CAGE somewhere else on the map (60 s per hook stage);
//    teammates free them there
//  • no perks or items: every player picks a CLASS with a fixed kit (modes/classes.js)
//  • no self-healing (the Medic class excepted), no hatch
//  • REVEALED: survivors are revealed to both killers when a chase starts on them, when they
//    are near a generator a killer kicks (20 m) and when they finish a generator
// Two configurations: the player is Killer A (bot Killer B, 8 bot survivors), or the player
// is one of the survivors (7 bot teammates, two killer bots).
import { M, dist } from '../core/util.js';
import { EV } from '../core/events.js';
import { SURVIVOR_CLASSES, KILLER_CLASSES } from './classes.js';

export const TWO_V_EIGHT = {
  generators: 13, gensRequired: 8, gates: 3, survivors: 8, cageStageTime: 90, mapScale: 1.4,
  repairMult: 1.25, revealChase: 5, revealKick: 20, revealKickTime: 4, revealGenDone: 4, allowPerks: false, hatch: false,
};
const SV_CLASS_ORDER = ['escapist', 'guide', 'medic', 'scout'];
const K_CLASS_ORDER = ['brute', 'enforcer', 'fearmonger', 'shadow'];

// Build a Match config for 2v8.
//  o = { role: 'killer'|'survivor'|'spectate', killerA, killerB, killerAClass, killerBClass,
//        survivorClass (player), mapId, survivorDifficulty, teammateDifficulty, killerDifficulty,
//        killerBDifficulty, allowPerks, seed }
export function config2v8(o = {}) {
  const role = o.role || 'killer';
  const kA = o.killerA || 'trapper', kB = o.killerB || 'wraith';
  const kAc = KILLER_CLASSES[o.killerAClass] ? o.killerAClass : K_CLASS_ORDER[0];
  const kBc = KILLER_CLASSES[o.killerBClass] ? o.killerBClass : K_CLASS_ORDER[(K_CLASS_ORDER.indexOf(kAc) + 1) % 4];
  const perks = o.allowPerks ?? TWO_V_EIGHT.allowPerks;
  const survivors = [];
  for (let i = 0; i < TWO_V_EIGHT.survivors; i++) {
    const player = i === 0 && role === 'survivor';
    const cls = player && SURVIVOR_CLASSES[o.survivorClass] ? o.survivorClass : SV_CLASS_ORDER[(i + (player ? 0 : 1)) % 4];
    const diff = player ? 5 : role === 'survivor' ? (o.teammateDifficulty ?? 5) : (o.survivorDifficulty ?? 5);
    survivors.push({ difficulty: diff, perks: [SURVIVOR_CLASSES[cls].id, ...(perks && o.survivorPerks ? o.survivorPerks.slice(0, 2) : [])], item: perks ? undefined : null, cls });
  }
  return {
    mode: '2v8', playerRole: role, mapId: o.mapId || 'rotwood', seed: o.seed ?? null,
    killers: [
      { killerId: kA, perks: [KILLER_CLASSES[kAc].id, ...(perks && o.killerPerks ? o.killerPerks.slice(0, 2) : [])], addons: [], difficulty: o.killerDifficulty ?? 5, cls: kAc },
      { killerId: kB, perks: [KILLER_CLASSES[kBc].id], addons: [], difficulty: o.killerBDifficulty ?? o.killerDifficulty ?? 5, cls: kBc },
    ],
    killerDifficulty: o.killerDifficulty ?? 5, killerId: kA,
    survivors, survivorCount: TWO_V_EIGHT.survivors, difficulty: o.survivorDifficulty ?? 5,
    gensOnMap: TWO_V_EIGHT.generators, gensRequired: TWO_V_EIGHT.gensRequired, gateCount: TWO_V_EIGHT.gates,
    perkMode: 'none', itemMode: perks ? 'random' : 'none',
    modifiers: { noHatch: !TWO_V_EIGHT.hatch, ...(o.modifiers || {}) },
  };
}

// A larger copy of a map definition for 2v8.
export function scaleMapDef(def) {
  const s = TWO_V_EIGHT.mapScale;
  return { ...def, size: [Math.round(def.size[0] * s), Math.round(def.size[1] * s)], tiles: Math.round(def.tiles * s * s), fillers: Math.round(def.fillers * s * s),
    grassPatches: Math.round((def.grassPatches || 0) * s * s), hooks: Math.round(def.hooks * 1.7), gens: TWO_V_EIGHT.generators };
}

// Match-side rules (called from the Match constructor when cfg.mode === '2v8').
export function install2v8(m) {
  m.hookStageTime = m.cfg.modifiers.hardcoreHooks ? 40 : TWO_V_EIGHT.cageStageTime;
  m.is2v8 = true; m.repairMult = TWO_V_EIGHT.repairMult;
  // second survivor group spawns elsewhere; the two killers start apart
  const extra = m.map.openSpots(8, 8, [...m.map.gens]).filter((p) => m.killers.every((k) => dist(k.x, k.y, p.x, p.y) > 30 * M));
  const base = extra[0] || m.map.spawn.survivors[0];
  m.survivors.forEach((s, i) => { if (i >= 4) { const a = (i - 4) * Math.PI / 2; s.x = base.x + Math.cos(a) * 1.2 * M; s.y = base.y + Math.sin(a) * 1.2 * M; m.world.resolve(s, s.r); } });
  // Revealed: chase start, kicked generator (20 m), finished generator
  const R = TWO_V_EIGHT;
  m.events.on(EV.CHASE_START, (d) => { if (d.survivor) m.reveal(d.survivor, R.revealChase, 'Revealed'); });
  m.events.on(EV.GENERATOR_DAMAGED, (d) => { for (const s of m.survivors) if (s.standing && dist(s.x, s.y, d.gen.x, d.gen.y) < R.revealKick * M) m.reveal(s, R.revealKickTime, 'Revealed'); });
  m.events.on(EV.GENERATOR_REPAIRED, (d) => { for (const s of m.survivors) if (s.standing && dist(s.x, s.y, d.gen.x, d.gen.y) < 3 * M) m.reveal(s, R.revealGenDone, 'Revealed'); });
  // remember each player's class for the HUD / results
  m.cfg.killers?.forEach((c, i) => { if (m.killers[i]) m.killers[i].cls = c.cls; });
  m.cfg.survivors?.forEach((c, i) => { if (m.survivors[i]) m.survivors[i].cls = c.cls; });
}

// Cage instead of hook: the survivor is sent to a free cage far from both killers.
export function pickCage(m, from) {
  const free = m.map.hooks.filter((h) => !h.survivor && !h.broken);
  const far = free.filter((h) => m.killers.every((k) => dist(h.x, h.y, k.x, k.y) > 24 * M));
  const pool = far.length ? far : free;
  return pool.length ? pool[Math.floor(m.rng() * pool.length)] : from;
}
export { SURVIVOR_CLASSES, KILLER_CLASSES };
