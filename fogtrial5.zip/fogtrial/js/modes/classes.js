// 2v8 classes. In 2v8 survivors and killers don't bring perks or items: each picks a class
// with a fixed kit. Classes are perk-shaped definitions so they run through the central perk /
// status / event systems like everything else (and work for the player and for bots alike).
import { M, dist } from '../core/util.js';
import { EV } from '../core/events.js';

export const SURVIVOR_CLASSES = {
  escapist: { id: 'class_escapist', name: 'Escapist', icon: '➹', blurb: 'Runner. After being hit: +50% Haste for 3 s more. Gains 10% Haste for 5 s whenever a chase starts (60 s cooldown).' },
  guide:    { id: 'class_guide', name: 'Guide', icon: '⚑', blurb: 'Rescuer. Frees caged teammates 50% faster and picks up dying teammates 30% faster.' },
  medic:    { id: 'class_medic', name: 'Medic', icon: '✚', blurb: 'Healer. Heals 40% faster and is the only class that can heal themselves (at half speed).' },
  scout:    { id: 'class_scout', name: 'Scout', icon: '◉', blurb: 'Lookout. When a killer comes within 24 m, the whole team sees that killer for 5 s (30 s cooldown).' },
};
export const KILLER_CLASSES = {
  brute:      { id: 'class_brute', name: 'Brute', icon: '⚒', blurb: 'Breaks pallets and kicks generators 25% faster; stuns last 20% less.' },
  enforcer:   { id: 'class_enforcer', name: 'Enforcer', icon: '⚔', blurb: 'Each hit gives 5% Haste for 6 s.' },
  fearmonger: { id: 'class_fearmonger', name: 'Fearmonger', icon: '☠', blurb: 'Terror radius +20%; survivors inside it repair 10% slower.' },
  shadow:     { id: 'class_shadow', name: 'Shadow', icon: '☾', blurb: 'Undetectable for 12 s after caging a survivor; vaults 15% faster.' },
};

export const CLASS_PERKS = {
  class_escapist: { id: 'class_escapist', side: 'survivor', cat: 'class', name: 'Escapist', icon: '➹', description: SURVIVOR_CLASSES.escapist.blurb, cooldown: 60,
    triggers: { [EV.KILLER_HIT]: (p, d, m) => { if (d.survivor === p.owner && d.survivor.standing) { p.owner.status.add('haste', { duration: 3, value: 0.5, source: 'escapist' }); m.perks.proc(p, 'Escapist'); } },
      [EV.CHASE_START]: (p, d, m) => { if (d.survivor === p.owner && p.cooldownT <= 0) { p.owner.status.add('haste', { duration: 5, value: 0.1, source: 'escapist_run' }); p.cooldownT = 60; m.perks.proc(p, 'Escapist'); } } } },
  class_guide: { id: 'class_guide', side: 'survivor', cat: 'class', name: 'Guide', icon: '⚑', description: SURVIVOR_CLASSES.guide.blurb,
    actionMult: (p, sv, type) => (type === 'unhook' ? 1.5 : 1),
    healMult: (p, healer, target) => (target.health === 'dying' ? 1.3 : 1) },
  class_medic: { id: 'class_medic', side: 'survivor', cat: 'class', name: 'Medic', icon: '✚', description: SURVIVOR_CLASSES.medic.blurb,
    healMult: (p, healer, target) => (healer === target ? 1 : 1.4) },
  class_scout: { id: 'class_scout', side: 'survivor', cat: 'class', name: 'Scout', icon: '◉', description: SURVIVOR_CLASSES.scout.blurb, cooldown: 30,
    update: (p, m) => { const s = p.owner; if (!s.standing || p.cooldownT > 0) return; for (const k of m.killers) if (dist(k.x, k.y, s.x, s.y) < 24 * M) { for (const o of m.survivors) if (o.alive) m.revealKillerTo(o, 5, 'Scout', k); p.cooldownT = 30; m.perks.proc(p, 'Scout'); s.ai?.note(`Scouted the ${k.def.short}`, 'scout'); m.bb.report?.(k.x, k.y, 'scout', k); break; } } },
  class_brute: { id: 'class_brute', side: 'killer', cat: 'class', name: 'Brute', icon: '⚒', description: KILLER_CLASSES.brute.blurb,
    killerActionMult: (p, type) => (type === 'break' || type === 'kick' ? 0.75 : 1), stunMult: 0.8 },
  class_enforcer: { id: 'class_enforcer', side: 'killer', cat: 'class', name: 'Enforcer', icon: '⚔', description: KILLER_CLASSES.enforcer.blurb,
    triggers: { [EV.KILLER_HIT]: (p, d, m) => { if (d.killer !== p.owner) return; p.owner.status.add('haste', { duration: 6, value: 0.05, source: 'enforcer' }); m.perks.proc(p, 'Enforcer'); } } },
  class_fearmonger: { id: 'class_fearmonger', side: 'killer', cat: 'class', name: 'Fearmonger', icon: '☠', description: KILLER_CLASSES.fearmonger.blurb, terrorMult: 1.2,
    update: (p, m) => { const k = p.owner; for (const s of m.survivors) if (s.action?.type === 'repair' && dist(s.x, s.y, k.x, k.y) < k.terrorRadius) s.status.add('repairSpeed', { duration: 0.2, value: -0.1, source: 'fearmonger' }); } },
  class_shadow: { id: 'class_shadow', side: 'killer', cat: 'class', name: 'Shadow', icon: '☾', description: KILLER_CLASSES.shadow.blurb,
    killerActionMult: (p, type) => (type === 'vault' ? 0.85 : 1),
    triggers: { [EV.SURVIVOR_HOOKED]: (p, d, m) => { if (d.killer !== p.owner) return; p.owner.status.add('undetectable', { duration: 12, source: 'shadow' }); m.perks.proc(p, 'Shadow'); } } },
};
