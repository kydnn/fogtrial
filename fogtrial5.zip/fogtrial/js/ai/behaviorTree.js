// Minimal behavior-tree runtime. Nodes record the active path for the debug overlay.
export const S = 'SUCCESS', F = 'FAILURE', R = 'RUNNING';

export class Node { constructor(name) { this.name = name; } tick() { return F; } }

export class Selector extends Node {
  constructor(name, children) { super(name); this.children = children; }
  tick(ctx) { ctx.trace.push(this.name); for (const c of this.children) { const r = c.tick(ctx); if (r !== F) return r; } ctx.trace.pop(); return F; }
}
export class Sequence extends Node {
  constructor(name, children) { super(name); this.children = children; }
  tick(ctx) { ctx.trace.push(this.name); for (const c of this.children) { const r = c.tick(ctx); if (r !== S) { if (r === F) ctx.trace.pop(); return r; } } return S; }
}
export class Cond extends Node {
  constructor(name, fn) { super(name); this.fn = fn; }
  tick(ctx) { return this.fn(ctx) ? S : F; }
}
export class Act extends Node {
  constructor(name, fn) { super(name); this.fn = fn; }
  tick(ctx) { ctx.trace.push(this.name); const r = this.fn(ctx) || R; if (r === F) ctx.trace.pop(); return r; }
}
// Guarded branch: if cond holds, run action (and never fall through).
export const Branch = (name, cond, action) => new Sequence(name, [new Cond(name + '?', cond), new Act(name, action)]);
