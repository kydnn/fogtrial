// Utility AI: scores every goal a survivor could pursue from what it currently knows.
// Each option keeps its reasons so the debug overlay can explain the decision.
import { M, dist, clamp, smoothstep } from '../core/util.js';
import { HOOK_STAGE_TIME } from '../entities/survivor.js';

export const GOAL_STATE = {
  REPAIR: 'REPAIRING_GENERATOR', RESCUE: 'RESCUING', HEAL: 'HEALING_TEAMMATE', BE_HEALED: 'HELPING_TEAMMATE', HEAL_SELF: 'HEALING_SELF',
  CLEANSE: 'INVESTIGATING', CHEST: 'SEARCHING_CHEST', DISARM: 'INVESTIGATING', FREE: 'HELPING_TEAMMATE', OPEN_GATE: 'OPENING_EXIT_GATE',
  ESCAPE: 'GOING_TO_EXIT', HATCH: 'GOING_TO_EXIT', PROTECT: 'TAKING_PROTECTION_HIT', FLASHLIGHT: 'HELPING_TEAMMATE', PATROL: 'PATROLLING', KEY_HATCH: 'GOING_TO_EXIT', PRINT_EMP: 'INVESTIGATING', USE_EMP: 'INVESTIGATING', DEVICE: 'INVESTIGATING', BURN_TRAP: 'INVESTIGATING', FOLLOW_CARRY: 'HELPING_TEAMMATE',
};

export function evaluateGoals(ai) {
  const m = ai.m, s = ai.sv, P = ai.params, pers = ai.pers, bb = m.bb;
  const opts = [];
  const add = (type, target, score, why, extra = null) => { if (score > 0.5) opts.push({ type, target, key: type + ':' + (target?.id ?? ''), score, why, ...(extra || {}) }); };
  const myD = (x, y) => dist(s.x, s.y, x, y) / M;
  const safety = (x, y) => ai.safetyAt(x, y);
  const gatesPowered = m.gatesPowered, anyOpen = m.map.gates.some((g) => g.open);
  const others = m.survivors.filter((o) => o !== s && o.alive);
  const kn = ai.knobs, pb = ai.perkBrain.bias; // killer counterplay knobs, perk-driven biases
  const marked = s.status.has('marked') || s.status.has('exposed');
  const pods = [...ai.memory.devices.values()].filter((d) => d.kind === 'biopod' && !d.dead && (d.data.disabledUntil || 0) <= m.time);

  // ---- generators ------------------------------------------------------
  if (!gatesPowered) {
    const incomplete = m.map.gens.filter((g) => !g.done);
    const need = m.gensNeeded - m.gensDone;
    for (const g of incomplete) {
      if (g.blockedUntil > m.time) continue;
      const prog = ai.genKnowledge(g);
      const d = myD(g.x, g.y);
      let sc = 52 + 26 * pers.objectiveFocus;
      const fProg = 0.75 + 0.45 * prog;
      const fDist = 0.3 + 0.7 / (1 + d / 40);
      const fSafe = 0.2 + 0.8 * safety(g.x, g.y);
      const n = [...g.repairers].filter((o) => o !== s).length;
      let fCrowd = n === 0 ? 1 : n === 1 ? (prog > 0.55 ? 1.05 : 0.82) : n === 2 ? 0.5 : 0.25;
      if (n > 0 && kn.groupPenalty) fCrowd *= 1 - kn.groupPenalty * P.awareness;
      const claimer = bb.claimedBy('REPAIR:' + g.id);
      if (claimer && claimer !== s && !g.repairers.has(claimer) && Math.random() < P.comms) fCrowd *= 0.75;
      let fStrat = 1, why = [`prog ${Math.round(prog * 100)}%`, `${d.toFixed(0)}m`, `safe ${fSafe.toFixed(2)}`];
      if (P.genStrategy && incomplete.length > need) {
        const dens = incomplete.filter((o) => o !== g && dist(o.x, o.y, g.x, g.y) < 32 * M).length;
        fStrat = 1 + 0.14 * dens * P.clusterAware * pb.cluster;
        if (dens >= 2) why.push('breaks 3-gen cluster');
      }
      if (g.regressing && prog > 0.3) { fStrat *= 1.1; why.push('regressing'); }
      let fEsc = 1;
      if (P.difficulty >= 6) {
        const t = ai.nearestTile(g.x, g.y, 16 * M);
        fEsc = 0.85 + (t ? t.safety : 0) * 0.2 * kn.genEscape;
      }
      // surveillance / area denial around the generator (known pods, gas, trails)
      if (pods.length && P.difficulty >= 3) { const w = pods.filter((d) => dist(d.x, d.y, g.x, g.y) < d.dangerRadius + 2 * M).length; if (w) { fEsc *= Math.pow(0.8 - 0.25 * P.zoneSense, w) * (s.status.has('slipstream') ? 0.7 : 1); why.push(`${w} pod${w > 1 ? 's' : ''} watching`); } }
      const gz = [...ai.memory.zones.values()].filter((z) => z.aiCost > 0 && z.until > m.time && dist(z.x, z.y, g.x, g.y) < z.r + 1.2 * M);
      if (gz.length) { fEsc *= gz.some((z) => z.kind === 'tonic') ? 0.75 - 0.45 * P.zoneSense : 0.85; why.push('gas/trail on it'); }
      const pgf = ai.profile.genFactor?.(ai, g); if (pgf) { fEsc *= pgf.f; if (pgf.why) why.push(pgf.why); }
      fStrat *= pb.repair;
      if (n > 0) fStrat *= pb.joinGen;
      if (s.item?.id === 'toolbox' && s.item.charges > 4 && prog < 0.5) fStrat *= 1.08;
      sc *= fProg * fDist * fSafe * fCrowd * fStrat * fEsc;
      add('REPAIR', g, sc, why);
    }
  }

  // ---- rescues ----------------------------------------------------------
  for (const o of others) {
    if (o.health !== 'hooked') continue;
    const left = Math.max(0, m.hookStageTime - o.hookTimer);
    const urgency = o.hookStage >= 2 ? 0.95 + 0.1 * (1 - left / m.hookStageTime) : 0.66 + 0.34 * (1 - left / m.hookStageTime);
    const d = myD(o.x, o.y);
    let sc = 78 + 30 * pers.rescuePriority - 20 * pers.selfishness;
    const fDist = 0.75 + 0.25 / (1 + d / 50);
    const kh = ai.killerDistAt(o.x, o.y);
    const travel = d / 4;
    let fCamp = 1; const why = [`stage ${o.hookStage}`, `${left.toFixed(0)}s left`];
    if (kh < 16 * kn.rescueWait && ai.belief.conf > 0.25) {
      if (P.waitsForCamper && left > travel + 14) { fCamp = 0.45 / kn.rescueWait; why.push('killer near hook: wait'); }
      else fCamp = 0.85;
    }
    if (o.hook?.cage) why.push('caged');
    if (marked && !(left < travel + 15)) { fCamp *= 0.45; why.push('I am marked'); }
    sc *= pb.rescue;
    let urgent = o.hookStage >= 2;
    if (left < travel + 15) { sc *= 1.3; why.push('must go now'); urgent = true; }
    let fClaim = 1;
    const c = bb.claimedBy('RESCUE:' + o.id);
    if (c && c !== s && Math.random() < P.comms + 0.2) { fClaim = dist(c.x, c.y, o.x, o.y) < dist(s.x, s.y, o.x, o.y) ? 0.08 : 0.5; why.push(`${c.name} going`); }
    if (s.health === 'injured' && others.some((q) => q.health === 'healthy' && q !== o)) fClaim *= 0.85;
    add('RESCUE', o, sc * urgency * fDist * fCamp * fClaim, why);
    if (urgent && fClaim > 0.4) opts[opts.length - 1] && (opts[opts.length - 1].urgent = true);
  }

  // ---- healing ----------------------------------------------------------
  for (const o of others) {
    if (o.health !== 'injured' && o.health !== 'dying') continue;
    if (o.status.has('broken')) continue;
    if (bb.inChase(o) || (o.ai && o.ai.inChase)) continue;
    const d = myD(o.x, o.y);
    const dying = o.health === 'dying';
    if (dying && (o.knockOutUntil || 0) > m.time && d > 16) continue; // Knock Out: can't locate them
    if (s.status.has('blindness') && d > 24) continue; // Blinded: teammates' auras are hidden
    let sc = (dying ? 62 + 30 * pers.rescuePriority : 34 + 40 * pers.healingPriority) * kn.healBias * pb.heal;
    if (o.status.has('tormented') && !dying) sc *= 1.15;
    const fSafe = 0.15 + 0.85 * safety(o.x, o.y);
    let f = (0.25 + 0.75 / (1 + d / 22)) * fSafe;
    if (s.item?.id === 'medkit' && s.item.charges > 2) f *= 1.2;
    if (dying && ai.killerDistAt(o.x, o.y) < 12 && ai.belief.conf > 0.3) f *= 0.25; // slugged as bait
    const c = bb.claimedBy('HEAL:' + o.id); if (c && c !== s) f *= 0.25;
    if (s.health === 'injured' && !dying) f *= 0.6;
    if (anyOpen && !dying) f *= 0.3;
    add('HEAL', o, sc * f, [dying ? 'pick up' : 'injured', `${d.toFixed(0)}m`]);
  }
  // Teammate is coming to heal me
  if (s.health === 'injured') {
    const c = bb.claimedBy('HEAL:' + s.id);
    if (c && c !== s && dist(c.x, c.y, s.x, s.y) < 24 * M) add('BE_HEALED', c, 58 + 10 * pers.teamwork, [`${c.name} will heal`]);
    const can = (s.item?.id === 'medkit' && s.item.charges > 1) || s.hasPerk('self_care') || pb.selfHeal;
    if (can) {
      let sc = (22 + 36 * pers.healingPriority) * kn.healBias * pb.healSelf;
      sc *= 0.2 + 0.8 * safety(s.x, s.y);
      if (P.healWisdom > 0.5 && m.map.gens.some((g) => !g.done && g.progress > 0.7 && dist(g.x, g.y, s.x, s.y) < 20 * M)) sc *= 0.6;
      sc += (1 - P.healWisdom) * 18 * Math.random(); // inexperienced bots heal at bad times
      if (gatesPowered) sc *= 0.5;
      add('HEAL_SELF', null, sc, [s.item?.id === 'medkit' ? 'med-kit' : 'self-care']);
    }
  }

  // ---- traps (Trapper) --------------------------------------------------
  for (const o of others) if (o.trap) add('FREE', o, (68 + 20 * pers.teamwork) * (0.3 + 0.7 / (1 + myD(o.x, o.y) / 30)) * (0.3 + 0.7 * safety(o.x, o.y)), ['trapped']);
  if (m.hasPower('traps') && P.difficulty >= 4) {
    for (const t of ai.memory.traps.values()) {
      if (t.trap.state !== 'set') continue;
      const d = myD(t.x, t.y); if (d > 30) continue;
      const nearObj = m.map.gens.some((g) => !g.done && dist(g.x, g.y, t.x, t.y) < 12 * M) || !!m.map.tileAt(t.x, t.y);
      add('DISARM', t.trap, (14 + (nearObj ? 22 : 6) * P.trapSense) * (0.2 + 0.8 * safety(t.x, t.y)) / (1 + d / 25), ['known trap', nearObj ? 'blocks objective' : '']);
    }
  }

  // ---- totems -------------------------------------------------------------
  for (const [id, info] of ai.memory.totems) {
    const t = info.totem; if (t.cleansed) continue;
    const d = myD(t.x, t.y);
    let sc = (t.hex === 'ruin' ? 46 : t.hex === 'noed' ? 92 : t.hex ? 40 : (P.difficulty >= 8 && m.gensDone >= 2 ? 10 : 3)) * pb.cleanse;
    sc *= (0.3 + 0.7 / (1 + d / 30)) * (0.25 + 0.75 * safety(t.x, t.y));
    add('CLEANSE', t, sc, [t.hex ? 'hex: ' + t.hex : 'dull totem']);
  }
  // ---- chests --------------------------------------------------------------
  if (!s.item || s.item.charges <= 0) for (const c of m.map.chests) {
    if (c.opened) continue; const d = myD(c.x, c.y); if (d > 40) continue;
    add('CHEST', c, (10 + 14 * (m.time < 150 ? 1 : 0.4)) * pb.chest * (0.2 + 0.8 * safety(c.x, c.y)) / (1 + d / 25), ['no item']);
  }

  // ---- endgame ------------------------------------------------------------
  if (gatesPowered) {
    for (const g of m.map.gates) {
      if (g.open) { add('ESCAPE', g, 96 * (0.55 + 0.45 * safety(g.x, g.y)) * (0.6 + 0.4 / (1 + myD(g.x, g.y) / 60)), ['gate open']); continue; }
      let sc = 88 * pb.gate * (0.3 + 0.7 * safety(g.x, g.y)) * (0.5 + 0.5 / (1 + myD(g.x, g.y) / 50));
      const c = bb.claimedBy('OPEN_GATE:' + g.id); if (c && c !== s) sc *= 0.3;
      add('OPEN_GATE', g, sc, ['powered']);
    }
  }
  const h = m.map.hatch;
  if (h.state === 'open' && (myD(h.x, h.y) < 26 || ai.memory.hatchSeen)) add('HATCH', h, 130, ['hatch open']);
  if (h.state === 'closed' && s.item?.id === 'key' && m.aliveCount() <= 2 && ai.memory.hatchSeen) add('KEY_HATCH', h, 110, ['key']);

  // ---- Singularity: carry the EMP to the densest known pod cluster ----
  if (s.emp && pods.length) {
    for (const d of pods) {
      const n = pods.filter((o) => dist(o.x, o.y, d.x, d.y) < 9 * M).length;
      const onGen = m.map.gens.some((g) => !g.done && dist(g.x, g.y, d.x, d.y) < 14 * M);
      if (n < 2 && !onGen && !s.status.has('slipstream')) continue;
      add('USE_EMP', d, (44 + 14 * n + (onGen ? 14 : 0)) * (0.35 + 0.65 * P.zoneSense) * (0.3 + 0.7 * safety(d.x, d.y)) / (1 + myD(d.x, d.y) / 50), [`${n} pods here`]);
    }
  }
  // ---- protection / saves --------------------------------------------------
  // ---- Singularity: print an EMP when pods are watching our objectives ----
  if (!s.emp && m.hasPower('quantum') && P.difficulty >= 3) {
    const nearPods = pods.filter((d) => m.map.gens.some((g) => !g.done && dist(g.x, g.y, d.x, d.y) < 14 * M)).length;
    // Team plan: one or two EMP carriers keep the pod network down. Skilled teams value
    // this much more (zoneSense) — the Singularity snowballs if pods stay up.
    const carriers = m.survivors.filter((o) => o !== s && o.alive && (o.emp || o.ai?.goal?.type === 'PRINT_EMP')).length;
    const want = (s.status.has('slipstream') ? 1.2 : 0) + nearPods * 0.6 + (pods.length >= 4 ? 0.6 : 0) + (pods.length >= 6 ? 0.6 : 0);
    if (want > 0 && carriers < 2) for (const d of ai.memory.devices.values()) {
      if (d.kind !== 'printer' || !d.usable(s, m)) continue;
      const dd = myD(d.x, d.y);
      add('PRINT_EMP', d, (30 + 30 * want) * (0.35 + 0.65 * P.zoneSense) * (carriers ? 0.7 : 1) * (0.3 + 0.7 * safety(d.x, d.y)) / (1 + dd / 70), ['counter surveillance', `${nearPods} pods on gens`, `${pods.length} pods known`]);
    }
  }
  // ---- follow a carried teammate (Breakout / body-block / flashlight setups) ----
  const ck = m.killers.find((k) => k.carrying && k.carrying !== s);
  if (ck && (pb.followCarry > 1 || P.protectionHits) && s.health !== 'dying' && !marked) {
    const d = myD(ck.x, ck.y); if (d < 22) add('FOLLOW_CARRY', ck.carrying, 26 * pers.bravery * pb.followCarry / (1 + d / 18), ['shadow the carry']);
  }
  if (P.protectionHits && s.health === 'healthy' && !marked) {
    for (const o of others) {
      if (o.health !== 'injured' || !o.ai?.inChase) continue;
      const d = myD(o.x, o.y); if (d > 24) continue;
      add('PROTECT', o, 30 * pers.bravery * P.protect * pb.protect * (1 + pers.teamwork) / (1 + d / 15), ['body block']);
    }
  }
  if (s.item?.id === 'flashlight' && s.item.charges > 1 && P.flashlightSaves) {
    const k = m.killers.find((q) => q.carrying || q.action?.type === 'pickup') || ai.fk;
    const target = k.carrying || (k.action?.type === 'pickup' ? k.action.target : null);
    if (target && myD(k.x, k.y) < 20 && ai.belief.conf > 0.6) add('FLASHLIGHT', target, 80 * (0.5 + pers.bravery), ['flashlight save']);
  }
  // ---- killer-specific objectives (lock lockers, solve the box, sprays, Magic Items…) ----
  ai.profile.goals?.(ai, add, { myD, safety });
  add('PATROL', null, 6, ['nothing better']);
  return opts;
}

// Choose with commitment (hysteresis), softmax temperature and deliberate mistakes.
export function chooseGoal(ai, opts) {
  const P = ai.params; const cur = ai.goal;
  opts.sort((a, b) => b.score - a.score);
  if (!opts.length) return null;
  // Commitment: keep the current goal unless something is clearly better.
  const curOpt = cur ? opts.find((o) => o.key === cur.key) : null;
  if (curOpt) {
    const working = ai.sv.action && (ai.sv.action.type === 'repair' || ai.sv.action.type === 'heal' || ai.sv.action.type === 'openGate');
    const bonus = curOpt.score * 0.12 + 6 + (ai.m.time < ai.goalCommitUntil ? 20 : 0) + (working ? 8 : 0);
    curOpt.commitBonus = bonus;
    const urgentBetter = opts[0].urgent && opts[0] !== curOpt && opts[0].score > curOpt.score;
    if (!urgentBetter && (opts[0] === curOpt || curOpt.score + bonus >= opts[0].score)) return curOpt;
    if (urgentBetter) return opts[0];
  }
  if (Math.random() < P.mistakeRate * 0.5 && opts.length > 2) { const o = opts[1 + Math.floor(Math.random() * Math.min(3, opts.length - 1))]; o.mistake = o.score < opts[0].score * 0.6; return o; }
  const T = P.temperature; const top = opts.slice(0, 6);
  const mx = top[0].score; const w = top.map((o) => Math.exp((o.score - mx) / T)); const tot = w.reduce((a, b) => a + b, 0);
  let r = Math.random() * tot; for (let i = 0; i < top.length; i++) { r -= w[i]; if (r <= 0) return top[i]; }
  return top[0];
}
