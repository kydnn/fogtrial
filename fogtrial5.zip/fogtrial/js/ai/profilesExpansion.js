// Counterplay profiles for the ten expansion killers. Same shape as killerProfiles.js:
// knobs bend the generic AI (pathing, loops, pallets, gens, rescues, healing), `tactical`
// runs killer-specific reactions every tactical tick, `goals` adds killer-specific
// objectives (lock lockers, solve the box, cure infection, loot Magic Items…),
// `genFactor`/`dynKnobs` adjust decisions from what the survivor currently knows.
// Everything reads the survivor's own perception (belief, memory) — no omniscience.
import { M, dist, angleDiff, clamp } from '../core/util.js';
import { K, sidestep, dodgeProjectiles, fleeFrom, minionOnMe, palletOnMinion } from './counterplayKit.js';

const knownDevices = (ai, kind) => [...ai.memory.devices.values()].filter((d) => d.kind === kind && !d.dead);
const inLane = (fromX, fromY, dir, s, len, half) => {
  const rx = s.x - fromX, ry = s.y - fromY; const along = rx * Math.cos(dir) + ry * Math.sin(dir);
  const side = Math.abs(-rx * Math.sin(dir) + ry * Math.cos(dir)); return along > 0 && along < len && side < half;
};
// Walk away from bunched-up teammates (Legion chains, Infectious Fright, Wesker grabs).
function spreadOut(ai, radius, label) {
  const s = ai.sv, m = ai.m; const near = m.survivors.filter((o) => o !== s && o.standing && dist(o.x, o.y, s.x, s.y) < radius * M);
  if (!near.length) return null;
  const cx = near.reduce((a, o) => a + o.x, 0) / near.length, cy = near.reduce((a, o) => a + o.y, 0) / near.length;
  return fleeFrom(ai, cx, cy, label, { minD: 6, maxD: 12, holdFor: 1.2 });
}

export const EXPANSION_PROFILES = {
  // ------------------------------------------------------------------ LEGION
  legion: {
    power: 'Feral Frenzy', strengths: ['fast Frenzy that vaults pallets', 'chains Deep Wound across the team', 'reveals survivors near each Frenzy hit'], weaknesses: ['Frenzy cannot down', 'Fatigue after the Frenzy', 'Deep Wound can be mended'],
    avoid: ['grouping up on gens or heals', 'standing in his terror radius during a Frenzy', 'relying on pallets mid-Frenzy'], exploit: ['his Fatigue window', 'mending early', 'spreading the team out'],
    knobs: K({ groupPenalty: 0.35, palletValue: 0.8, windowValue: 0.9, greed: 1.2, healBias: 1.15, genEscape: 1.1, rescueWait: 0.9 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, k = ai.fk, B = ai.belief, P = ai.params, pw = k.power;
      if (!s.standing) return null;
      const frenzy = pw.frenzy && (B.observing || (m.time - (B.windupT || -99) < 4 && B.windupWhat === 'frenzy'));
      // Deep Wound: mend before the timer runs out, even with some pressure around
      const dw = s.status.get('deepWound');
      if (dw && dw.expiration < 9 && !s.action && ai.threat < 0.75 && P.difficulty >= 3) { s.startAction('mend', null, m); ai.note('Mending the Deep Wound before it runs out', 'legmend'); ai.chase.sidestepUntil = m.time + 0.3; return 'mend'; }
      // High-level teams refuse to give him an easy chain: scatter when he frenzies near a group.
      if (frenzy && P.difficulty >= 5 && !ai.inChase && Math.random() < 0.25 + 0.75 * P.awareness) {
        const kd = dist(B.x, B.y, s.x, s.y) / M;
        if (kd < 28) { const r = spreadOut(ai, 9, 'Spreading out — no easy Frenzy chain'); if (r) { if (s.action && s.action.type !== 'heal') s.stopAction(m); return r; } }
      }
      return null;
    },
    genFactor(ai, g) { const n = [...g.repairers].filter((o) => o !== ai.sv).length; return n && ai.params.difficulty >= 6 ? { f: 1 - 0.18 * n * ai.params.awareness, why: 'avoid stacking vs Legion' } : null; },
  },

  // ------------------------------------------------------------------ HAG
  hag: {
    power: 'Phantasm Traps + teleport', strengths: ['teleports to triggered traps', 'webs of traps around hooks and gens', 'hard to spot traps'], weaknesses: ['slow base speed', 'crouching avoids traps', 'flashlights burn traps'],
    avoid: ['walking over known traps', 'trapped loops', 'running straight into a trapped hook'], exploit: ['crouch past traps', 'burn traps with a flashlight', 'loops she has not trapped yet'],
    knobs: K({ zoneAvoid: 1.6, palletValue: 1.1, windowValue: 1.1, rescueWait: 1.15, genEscape: 1.15, hideBias: 0.1 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, P = ai.params;
      if (!s.standing || s.vault) return null;
      // Crouch-walk across a known trap that lies on my path (never sprint through one).
      const traps = knownDevices(ai, 'phantasm');
      if (!traps.length) return null;
      const dir = Math.hypot(s.vx, s.vy) > 0.5 * M ? Math.atan2(s.vy, s.vx) : s.facing;
      for (const t of traps) {
        const d = dist(t.x, t.y, s.x, s.y); if (d > 3.2 * M) continue;
        if (angleDiff(Math.atan2(t.y - s.y, t.x - s.x), dir) > 0.9 && d > 1.3 * M) continue;
        if (ai.inChase && ai.threat > 0.85 && P.difficulty < 7) continue; // panicking low skill bots just run
        ai.crouchUntil = m.time + 0.9; if (!ai._hagNoteT || m.time - ai._hagNoteT > 6) { ai._hagNoteT = m.time; ai.note('Crouching over a Phantasm trap', 'hagcrouch'); }
        return null;
      }
      return null;
    },
    goals(ai, add, { myD, safety }) {
      const s = ai.sv, P = ai.params;
      if (s.item?.id !== 'flashlight' || s.item.charges < 2 || P.difficulty < 4) return;
      for (const t of knownDevices(ai, 'phantasm')) {
        const nearObj = ai.m.map.gens.some((g) => !g.done && dist(g.x, g.y, t.x, t.y) < 8 * M) || ai.m.map.hooks.some((h) => dist(h.x, h.y, t.x, t.y) < 6 * M);
        add('BURN_TRAP', t, (14 + (nearObj ? 16 : 0)) * (0.3 + 0.7 * safety(t.x, t.y)) / (1 + myD(t.x, t.y) / 20), [nearObj ? 'trap guards an objective' : 'clear a trap']);
      }
    },
    genFactor(ai, g) { const n = knownDevices(ai, 'phantasm').filter((t) => dist(t.x, t.y, g.x, g.y) < 8 * M).length; return n ? { f: Math.pow(0.85, n), why: `${n} trap${n > 1 ? 's' : ''} at gen` } : null; },
  },

  // ------------------------------------------------------------------ CANNIBAL
  cannibal: {
    power: "Bubba's Chainsaw (sweep)", strengths: ['instant downs at close range', 'can down several survivors in one sweep', 'pallets are dangerous to greed'], weaknesses: ['short reach (sweep ramps up over 2.5 s)', 'tantrums when the sweep rams a wall', '2 s rev telegraph', 'cannot vault while sawing', 'a dropped pallet ends the sweep'],
    avoid: ['tight loops and short walls', 'greeding pallets', 'letting him get within 6 m while he revs', 'standing next to teammates (multi-downs)'], exploit: ['pre-dropping pallets so the sweep stops', 'windows and long loops', 'distance — the sweep is short', 'turning tight around walls so he rams them'],
    knobs: K({ losValue: 0.4, openPenalty: 0.9, preDrop: 1.6, greed: 0, palletValue: 1.35, windowValue: 1.35, tightPenalty: 1.3, groupPenalty: 0.15, rescueWait: 1.2, genEscape: 1.15 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, k = ai.fk, B = ai.belief, P = ai.params, pw = k.power;
      if (!s.standing || s.vault || s.action?.type === 'dropPallet') return null;
      const revving = (pw.state === 'revving' && B.observing) || (m.time - B.revvingT < 0.8 && B.conf > 0.5);
      const sweeping = pw.state === 'sweep' && B.observing;
      if (!revving && !sweeping) return null;
      const d = dist(B.x, B.y, s.x, s.y) / M;
      if (d > 7.5 || ai._bubbaT > m.time) return null;
      ai._bubbaT = m.time + 0.6;
      // Not Hillbilly: breaking line of sight is pointless — make distance or put a pallet/window between.
      if (Math.random() > 0.2 + 0.75 * P.dodge) return null;
      // multi-down risk: a teammate right next to me → split up first
      const mate = m.survivors.find((o) => o !== s && o.standing && dist(o.x, o.y, s.x, s.y) < 4 * M);
      if (mate && Math.random() < P.awareness) { const a = Math.atan2(s.y - mate.y, s.x - mate.x) * 0.5 + Math.atan2(s.y - B.y, s.x - B.x) * 0.5; s.moveTo = { x: s.x + Math.cos(a) * 5 * M, y: s.y + Math.sin(a) * 5 * M }; ai.note('Splitting up so one sweep can\'t down us both', 'split'); return 'split from the group'; }
      // sweeping already: turn hard around the nearest solid so he rams it
      if (sweeping && d < 5) {
        for (const w of m.map.windows) if (dist(w.x, w.y, s.x, s.y) < 4 * M) { s.moveTo = { x: w.x, y: w.y }; ai.note('Vaulting away from the sweep (he can\'t vault)', 'sweepwin'); return 'window vs sweep'; }
        const sideA = Math.atan2(s.y - B.y, s.x - B.x) + (Math.random() < 0.5 ? 1.35 : -1.35);
        const tx = s.x + Math.cos(sideA) * 3 * M, ty = s.y + Math.sin(sideA) * 3 * M;
        if (!m.world.pointBlocked(tx, ty, s.r)) { s.moveTo = { x: tx, y: ty }; ai.note('Hard turn so the saw rams the wall', 'sweepturn'); return 'side-step the sweep'; }
      }
      return fleeFrom(ai, B.x, B.y, 'Creating distance from the saw sweep', { windows: true, minD: 5, maxD: 9, holdFor: 0.8 });
    },
  },

  // ------------------------------------------------------------------ DEATHSLINGER
  deathslinger: {
    power: 'Harpoon gun', strengths: ['ranged hits through open lanes', 'reels survivors in', 'quick at mid range'], weaknesses: ['reload after every shot', 'chain snaps on obstacles', 'small terror radius but slow ADS'],
    avoid: ['straight sightlines', 'open fields', 'predictable movement while he aims'], exploit: ['his reload', 'obstacles to snap the chain', 'breaking line of sight'],
    knobs: K({ losValue: 3.5, openPenalty: 1.6, windowValue: 0.9, palletValue: 1.1, greed: 0.6, healBias: 1.2, rescueWait: 1.2, hideBias: 0.1 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, k = ai.fk, B = ai.belief, P = ai.params, pw = k.power;
      // speared: drag the chain across an obstacle so it snaps
      if (s.control?.kind === 'harpoon') {
        if (ai._snapT && ai._snapT > m.time) return 'snap the chain';
        let best = null, bs = Infinity;
        for (let a = 0; a < 12; a++) { const x = s.x + Math.cos(a * 0.52) * 3 * M, y = s.y + Math.sin(a * 0.52) * 3 * M; if (m.world.pointBlocked(x, y, s.r)) continue; if (!m.world.losClear(k.x, k.y, x, y)) { const c = dist(x, y, s.x, s.y); if (c < bs) { bs = c; best = { x, y }; } } }
        if (best && Math.random() < 0.3 + 0.7 * P.awareness) { s.moveTo = best; ai._snapT = m.time + 0.6; ai.note('Pulling the harpoon chain against an obstacle', 'snapit'); }
        else { const a = Math.atan2(s.y - k.y, s.x - k.x) + (Math.random() - 0.5); s.moveTo = { x: s.x + Math.cos(a) * 3 * M, y: s.y + Math.sin(a) * 3 * M }; }
        ai.chase.sidestepUntil = m.time + 0.4; return 'snap the chain';
      }
      const dodged = dodgeProjectiles(ai); if (dodged) return dodged;
      // He is aiming at me: juke out of the sightline / toward cover.
      if (B.observing && pw.state === 'aiming' && pw.loaded) {
        const d = dist(k.x, k.y, s.x, s.y);
        if (d > 3.5 * M && d < pw.range + 2 * M && angleDiff(k.facing, Math.atan2(s.y - k.y, s.x - k.x)) < 0.25 && m.time > ai.chase.sidestepUntil + 0.2) {
          if (Math.random() < P.dodge * 0.3) return sidestep(ai, Math.atan2(s.y - k.y, s.x - k.x), 'Juked out of the harpoon sightline', 1.5);
        }
      }
      return null;
    },
  },

  // ------------------------------------------------------------------ DREDGE
  dredge: {
    power: 'Locker teleports & Nightfall', strengths: ['crosses the map through lockers', 'Nightfall blinds survivors', 'Remnant snap-back mindgames'], weaknesses: ['lockers can be locked', 'teleports rattle the destination locker', 'Daytime cooldowns'],
    avoid: ['repairing next to unlocked lockers', 'being caught alone at Nightfall', 'standing near his Remnant'], exploit: ['lock lockers near objectives', 'his long teleport cooldown in Daytime', 'grouping up (auras) at Nightfall'],
    knobs: K({ genEscape: 1.2, leaveEarly: 1.15, rescueWait: 1.1, hideBias: 0.05 }),
    dynKnobs(ai) { return ai.sv.status.has('nightfall') ? { hideBias: 0.35, leaveEarly: 1.4, stealthy: true, unknownParanoia: 0.4 } : null; },
    tactical(ai) {
      const s = ai.sv, m = ai.m, k = ai.fk, pw = k.power, P = ai.params;
      if (s.status.has('nightfall') && !ai._nightNote) { ai._nightNote = true; ai.note('Nightfall — staying close to cover and teammates', 'night'); }
      if (!s.status.has('nightfall')) ai._nightNote = false;
      // a visible Remnant: he can snap back here at any moment
      if (pw.remnant && !ai.inChase && dist(pw.remnant.x, pw.remnant.y, s.x, s.y) < 9 * M && m.world.losClear(s.x, s.y, pw.remnant.x, pw.remnant.y) && Math.random() < P.awareness) {
        if (!ai._remT || m.time - ai._remT > 5) { ai._remT = m.time; return fleeFrom(ai, pw.remnant.x, pw.remnant.y, 'Backing off from the Dredge\'s Remnant', { minD: 6, maxD: 10 }); }
      }
      return null;
    },
    goals(ai, add, { myD, safety }) {
      const s = ai.sv, m = ai.m, P = ai.params; if (P.difficulty < 4) return;
      const myGen = ai.goal?.type === 'REPAIR' ? ai.goal.target : s.action?.type === 'repair' ? s.action.target : (ai.goal?.type === 'DEVICE' && ai.goal.target.kind === 'locker') ? ai._lockGen : null;
      if (myGen) ai._lockGen = myGen;
      for (const l of knownDevices(ai, 'locker')) {
        if (l.data.locked) continue;
        const nearGen = m.map.gens.some((g) => !g.done && g.progress > 0.15 && dist(g.x, g.y, l.x, l.y) < 12 * M);
        const nearMine = myGen && dist(myGen.x, myGen.y, l.x, l.y) < 12 * M;
        if (!nearGen && !nearMine) continue;
        const c = m.bb.claimedBy('DEVICE:' + l.id); if (c && c !== s) continue;
        add('DEVICE', l, (18 + (nearMine ? (dist(l.x, l.y, s.x, s.y) < 10 * M ? 70 : 18) : 0)) * (0.4 + 0.6 * P.zoneSense) * (0.3 + 0.7 * safety(l.x, l.y)) / (1 + myD(l.x, l.y) / 14), ['lock a locker near the objective'], { urgent: !!nearMine && dist(l.x, l.y, s.x, s.y) < 10 * M });
      }
    },
    genFactor(ai, g) {
      if (!ai.sv.status.has('nightfall')) return null;
      const n = knownDevices(ai, 'locker').filter((l) => !l.data.locked && dist(l.x, l.y, g.x, g.y) < 12 * M).length;
      return n ? { f: Math.pow(0.8, n), why: 'unlocked lockers at Nightfall' } : null;
    },
  },

  // ------------------------------------------------------------------ KNIGHT
  knight: {
    power: 'Guard patrols & hunts', strengths: ['guards zone generators and hooks', 'two threats at once', 'guards break pallets'], weaknesses: ['guards can be outrun and stunned', 'Standards end hunts', 'hunts drain if the survivor gets away'],
    avoid: ['a patrolling guard\'s vision cone', 'looping the Knight while a guard hunts you', 'gens on an active patrol path'], exploit: ['grab the Standard', 'pallets on guards', 'leading guards away from teammates'],
    knobs: K({ genEscape: 1.15, palletValue: 1.1, rescueWait: 1.1 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, P = ai.params;
      if (!s.standing || s.vault) return null;
      const on = minionOnMe(ai);
      if (on && on.n.kind === 'guard') {
        const g = on.n;
        // Standard: the cleanest way to end a hunt (skilled bots go straight for it)
        const st = knownDevices(ai, 'standard').find((d) => d.usable(s, m));
        if (st && P.difficulty >= 4) {
          const dS = dist(st.x, st.y, s.x, s.y), dG = dist(g.x, g.y, s.x, s.y);
          if (dS < 18 * M && (dS < dG * 1.6 || P.difficulty >= 8)) {
            if (dS < 1.6 * M) { s.startAction('device', st, m); ai.chase.sidestepUntil = m.time + 0.6; return 'grab Standard'; }
            ai.navigateTo(st.x, st.y, 1.2 * M); ai.chase.sidestepUntil = m.time + 0.5; if (!ai._stNote || m.time - ai._stNote > 6) { ai._stNote = m.time; ai.note('Going for the Standard to end the hunt', 'standard'); }
            return 'go to Standard';
          }
        }
        if (on.d < 3.5 * M && palletOnMinion(ai, g)) return 'pallet the guard';
        if (on.d < 14 * M && Math.random() < 0.4 + 0.6 * P.awareness) return fleeFrom(ai, g.x, g.y, `Running from ${g.label}`, { windows: false, minD: 6, maxD: 11, holdFor: 0.9 });
      }
      // Patrolling guard nearby that hasn't seen me: get out of its cone / line of sight.
      for (const e of ai.memory.minions.values()) {
        const g = e.n; if (g.kind !== 'guard' || g.state !== 'patrol' || g.dead) continue;
        const d = dist(g.x, g.y, s.x, s.y);
        if (d > (g.type.detect + 4) * M) continue;
        const facing = angleDiff(g.facing, Math.atan2(s.y - g.y, s.x - g.x)) < Math.PI / 2 + 0.3;
        if (!facing && d > 3 * M) continue;
        if (Math.random() > 0.3 + 0.7 * P.awareness) continue;
        if (s.action && s.action.type !== 'unhook') s.stopAction(m);
        return fleeFrom(ai, g.x, g.y, `Leaving ${g.label}'s patrol`, { minD: 6, maxD: 12, holdFor: 1.2 });
      }
      return null;
    },
    genFactor(ai, g) {
      for (const e of ai.memory.minions.values()) { const n = e.n; if (n.kind === 'guard' && !n.dead && n.patrol?.some((p) => dist(p.x, p.y, g.x, g.y) < (n.type.detect + 2) * M)) return { f: 0.55, why: 'guard patrols here' }; }
      return null;
    },
  },

  // ------------------------------------------------------------------ CENOBITE
  cenobite: {
    power: 'Possessed Chains & the Lament Configuration', strengths: ['chains through long sightlines', 'Chain Hunt pressure', 'teleports to box solvers'], weaknesses: ['chains stop on walls', 'box solving ends the pressure', 'slow while aiming chains'],
    avoid: ['long open sightlines', 'leaving the box alone too long', 'solving the box with the killer close'], exploit: ['walls to block chains', 'solving in safe spots', 'breaking chains fast'],
    knobs: K({ losValue: 3, openPenalty: 1.4, palletValue: 1.1, healBias: 1.1, rescueWait: 1.1 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, k = ai.fk, B = ai.belief, P = ai.params, pw = k.power;
      if (!s.standing) return null;
      // break free of chains — quickly, unless the killer is right on top of us
      // break free of chains when there is time; with the killer on top of us keep running (they snap on their own)
      if (s.status.has('chained') && !s.action) {
        const kd = ai.killerDistAt(s.x, s.y);
        if (kd > 9 || (!ai.inChase && ai.threat < 0.6) || P.difficulty < 4) { s.moveTo = null; ai.path = null; ai.chase.sidestepUntil = m.time + 1.05; s.startAction('breakChain', null, m); return 'break chains'; }
      }
      if (s.action?.type === 'breakChain') { ai.chase.sidestepUntil = Math.max(ai.chase.sidestepUntil, m.time + 0.2); return 'breaking chains'; }
      // a chain head coming at me in line of sight: put a wall between us / side-step
      const chains = [pw.chain, ...(pw.hunters || [])].filter((c) => c && !c.dead);
      for (const c of chains) {
        const d = dist(c.x, c.y, s.x, s.y); if (d > 14 * M || !m.world.losClear(c.x, c.y, s.x, s.y)) continue;
        if (angleDiff(c.dir, Math.atan2(s.y - c.y, s.x - c.x)) > 0.6) continue;
        if (ai._chainDodge === c) return null; ai._chainDodge = c;
        if (Math.random() < 0.15 + 0.7 * P.dodge) return fleeFrom(ai, c.x, c.y, 'Breaking line of sight from a chain', { minD: 2, maxD: 4, holdFor: 0.5 });
      }
      // solving: only when it is safe
      if (s.box && !s.action && ai.threat < 0.45 && ai.killerDistAt(s.x, s.y) > 18 && !ai.inChase) { s.startAction('solveBox', null, m); ai.note('Solving the Lament Configuration somewhere safe', 'solve'); return 'solve box'; }
      if (s.action?.type === 'solveBox' && ai.threat > 0.5) s.stopAction(m);
      return null;
    },
    goals(ai, add, { myD, safety }) {
      const s = ai.sv, m = ai.m, P = ai.params, pw = ai.fk.power;
      const box = pw.box; if (!box || s.box || s.status.has('chained')) return;
      const claim = m.bb.claimedBy('DEVICE:' + box.id); if (claim && claim !== s && claim.alive) return;
      // who should get it: the closest healthy survivor not in a chase
      const mates = m.survivors.filter((o) => o.standing && !o.ai?.inChase);
      const closest = mates.sort((a, b) => dist(a.x, a.y, box.x, box.y) - dist(b.x, b.y, box.x, box.y))[0];
      const urgency = pw.hunt ? 2.2 : pw.boxCharge / pw.huntCharge;
      if (closest !== s && P.difficulty >= 4 && !pw.hunt) return;
      // The box is a team objective: the designated runner leaves early enough to beat the timer
      // (travel time vs. time left); during a Chain Hunt everyone free considers it.
      const left = pw.huntCharge - pw.boxCharge, travel = myD(box.x, box.y) / 4;
      const late = pw.hunt ? 1 : clamp(1.4 - (left - travel) / 40, 0, 1);
      add('DEVICE', box, (24 + 50 * urgency + 60 * late) * (0.55 + 0.45 * P.zoneSense) * (0.35 + 0.65 * safety(box.x, box.y)) / (1 + myD(box.x, box.y) / 70), [pw.hunt ? 'CHAIN HUNT — get the box' : `Chain Hunt in ${Math.ceil(pw.huntCharge - pw.boxCharge)} s`], { urgent: pw.hunt });
    },
  },

  // ------------------------------------------------------------------ MASTERMIND
  mastermind: {
    power: 'Virulent Bound', strengths: ['huge dash distance', 'grabs and slams survivors into walls', 'infection Hinders'], weaknesses: ['dashes are straight lines', 'charge-up telegraph', 'sprays cure infection'],
    avoid: ['straight open dash lanes', 'walls behind you when he dashes', 'staying fully infected'], exploit: ['side-step the bound', 'windows and tall loops', 'First Aid Sprays'],
    knobs: K({ openPenalty: 1.5, losValue: 2, windowValue: 1.2, palletValue: 1.1, greed: 0.7, groupPenalty: 0.1, healBias: 1.1 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, k = ai.fk, B = ai.belief, P = ai.params, pw = k.power;
      if (!s.standing || s.vault) return null;
      // cure the infection when it is safe
      const inf = s.status.get('infected');
      if (inf && (s.sprays || 0) > 0 && !s.action && ai.threat < 0.35 && (inf.value > 55 || P.difficulty < 6)) { s.startAction('spray', null, m); return 'spray'; }
      // he is charging / between bounds and I am in the lane: side-step out of it
      // Timing matters: side-stepping early just lets him re-aim. Good survivors wait until the
      // charge is nearly full (or the second bound is primed) and step out at the last moment.
      if (B.observing && (pw.state === 'charging' || pw.state === 'between' || pw.state === 'bound')) {
        const len = (pw.state === 'between' ? 15 : pw.state === 'bound' ? 14 * pw.boundT + 1 : 8.5) * M;
        if (inLane(k.x, k.y, k.facing, s, len, 1.5 * M)) {
          const d = dist(k.x, k.y, s.x, s.y) / M;
          const late = pw.state === 'charging' ? pw.charge > 0.97 - 0.08 * P.awareness : true;
          // reacting to a bound already in flight needs time: the closer he is, the less chance
          const react = pw.state === 'bound' ? clamp((d / 14 - P.reaction) / 0.35, 0, 1) : 1;
          const key = pw.state + ':' + (pw.state === 'charging' ? 'c' : Math.round(m.time * 2));
          if (late && ai._wkKey !== key) { ai._wkKey = key; if (Math.random() < (0.05 + 0.85 * P.dodge) * react) return sidestep(ai, k.facing, 'Side-stepped out of the bound lane', 2.4); }
          // he is slowed while charging: skilled survivors open the distance (or break LOS) so
          // the bound falls short, instead of looping in front of him
          if (pw.state === 'charging' && !late && P.difficulty >= 6 && d < 10 && m.time - (ai._wkRun || -9) > 0.8) { ai._wkRun = m.time; return fleeFrom(ai, k.x, k.y, 'Opening distance while he charges', { windows: true, minD: 4, maxD: 7, holdFor: 0.8 }); }
          // low-skill survivors flinch early (and get re-aimed)
          if (!late && P.difficulty <= 4 && ai._wkEarly !== Math.round(m.time) && Math.random() < 0.3) { ai._wkEarly = Math.round(m.time); return sidestep(ai, k.facing, 'Panicked out of the lane too early', 2); }
        }
      }
      return null;
    },
    goals(ai, add, { myD, safety }) {
      const s = ai.sv, inf = s.status.get('infected'); if (!inf || (s.sprays || 0) > 0) return;
      for (const c of knownDevices(ai, 'supply')) if (c.data.sprays > 0) add('DEVICE', c, (10 + 40 * inf.value / 100) * (0.3 + 0.7 * safety(c.x, c.y)) / (1 + myD(c.x, c.y) / 25), [`infection ${Math.round(inf.value)}%`]);
    },
  },

  // ------------------------------------------------------------------ HOUNDMASTER
  houndmaster: {
    power: 'The dog (Chase & Search Commands)', strengths: ['the dog finds and drags survivors', 'two threats at once', 'fast while searching'], weaknesses: ['the dog cannot vault', 'pallets stun the dog', 'Chase Command runs in a straight line'],
    avoid: ['the dog\'s charge lane', 'open ground near the dog', 'its lullaby radius'], exploit: ['windows (the dog goes around)', 'pallets on the dog', 'side-stepping the charge'],
    knobs: K({ windowValue: 1.3, palletValue: 1.2, openPenalty: 1.2, rescueWait: 1.1 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, P = ai.params, k = ai.fk;
      // grabbed: slam a pallet on the dog if one is right here
      if (s.control?.kind === 'dog') { const d = k.power.dog; if (d && palletOnMinion(ai, d)) return 'pallet the dog'; return 'grabbed'; }
      if (!s.standing || s.vault) return null;
      const on = minionOnMe(ai); if (!on || on.n.kind !== 'dog') return null;
      const dog = on.n;
      if (dog.state === 'chase') {
        // charge: get out of the straight lane (or behind something)
        if (ai._dogDodge === dog.t0 || on.d > 16 * M) return null; ai._dogDodge = dog.t0;
        if (Math.random() < 0.1 + 0.8 * P.dodge) return sidestep(ai, dog.facing, 'Side-stepped the dog\'s charge', 2.2);
        return null;
      }
      if (on.d < 3.5 * M && palletOnMinion(ai, dog)) return 'pallet the dog';
      if (Math.random() < 0.3 + 0.7 * P.awareness) return fleeFrom(ai, dog.x, dog.y, 'Breaking the dog\'s pursuit through a window', { windows: true, minD: 5, maxD: 10, holdFor: 0.8 });
      return null;
    },
  },

  // ------------------------------------------------------------------ LICH
  lich: {
    power: 'Four spells', strengths: ['Flight of the Damned through walls', 'Mage Hand undoes pallets', 'Fly crosses loops'], weaknesses: ['long spell cooldowns', 'crouching dodges the damned', 'Magic Items counter each spell'],
    avoid: ['dropping a pallet he can Mage Hand', 'standing tall in front of the damned', 'the Dispelling Sphere\'s path'], exploit: ['his cooldown windows', 'Magic Items from chests', 'crouching against Flight of the Damned'],
    knobs: K({ palletValue: 1, windowValue: 1.1, losValue: 1, rescueWait: 1.05 }),
    // Survivors who heard a spell know its cooldown; Mage Hand being up makes pallets worth less.
    dynKnobs(ai) {
      const P = ai.params; if (P.difficulty < 6) return null;
      const last = ai.m.bb.lichCasts?.magehand ?? -99;
      return ai.m.time - last > 35 ? { palletValue: 0.75, preDrop: -0.5, windowValue: 1.3 } : { palletValue: 1.2 };
    },
    tactical(ai) {
      const s = ai.sv, m = ai.m, P = ai.params;
      if (!s.standing || s.vault) return null;
      const nightwatch = s.magic === 'nightwatch' && !s.status.has('dispelled');
      for (const p of m.projectiles) {
        if (p.kind !== 'damned') continue;
        const d = dist(p.x, p.y, s.x, s.y); if (d > 12 * M) continue;
        if (!nightwatch && !m.world.losClear(s.x, s.y, p.x, p.y)) continue;
        const ap = p.approach(s.x, s.y); if (ap.t < 0 || ap.d > 1.4 * M) continue;
        (p.crouchRolled ||= new Set());
        if (!p.crouchRolled.has(s)) { p.crouchRolled.add(s); p['c_' + s.id] = Math.random() < 0.2 + 0.75 * (nightwatch ? 1 : P.dodge); }
        if (p['c_' + s.id]) { ai.crouchUntil = m.time + 0.7; if (!ai._fotdN || m.time - ai._fotdN > 4) { ai._fotdN = m.time; ai.note(nightwatch ? 'Nightwatch: crouched under the damned' : 'Crouched under Flight of the Damned', 'fotdc'); } }
      }
      // Archivist sees the sphere: step out of its path
      const sp = ai.fk.power.sphere;
      if (sp && s.magic === 'archivist' && !s.status.has('dispelled') && dist(sp.x, sp.y, s.x, s.y) < 10 * M && inLane(sp.x, sp.y, sp.dir, s, 12 * M, sp.r + 0.6 * M)) return sidestep(ai, sp.dir, 'Archivist: stepped out of the Dispelling Sphere', 3);
      return null;
    },
    goals(ai, add, { myD, safety }) {
      const s = ai.sv, P = ai.params; if (s.magic || P.difficulty < 3) return;
      for (const c of knownDevices(ai, 'magic_chest')) if (!c.data.opened) add('DEVICE', c, (14 + 10 * P.awareness) * (ai.m.time < 200 ? 1.2 : 0.6) * (0.3 + 0.7 * safety(c.x, c.y)) / (1 + myD(c.x, c.y) / 22), ['loot a Magic Item']);
    },
  },
};
