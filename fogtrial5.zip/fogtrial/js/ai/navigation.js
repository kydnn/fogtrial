// Grid navigation (1 m cells) with special vault/pallet links, A* pathing and local
// Dijkstra distance fields used by the chase AI for loop reasoning.
import { M } from '../core/util.js';

class Heap { // min-heap of (key, val)
  constructor(n = 4096) { this.k = new Float32Array(n); this.v = new Int32Array(n); this.n = 0; }
  clear() { this.n = 0; }
  push(key, val) {
    if (this.n >= this.k.length) { const k = new Float32Array(this.k.length * 2); k.set(this.k); this.k = k; const v = new Int32Array(this.v.length * 2); v.set(this.v); this.v = v; }
    let i = this.n++; this.k[i] = key; this.v[i] = val;
    while (i > 0) { const p = (i - 1) >> 1; if (this.k[p] <= this.k[i]) break; this._sw(i, p); i = p; }
  }
  pop() {
    const v = this.v[0]; this.n--;
    if (this.n > 0) { this.k[0] = this.k[this.n]; this.v[0] = this.v[this.n]; let i = 0;
      for (;;) { const l = 2 * i + 1, r = l + 1; let m = i;
        if (l < this.n && this.k[l] < this.k[m]) m = l; if (r < this.n && this.k[r] < this.k[m]) m = r;
        if (m === i) break; this._sw(i, m); i = m; } }
    return v;
  }
  _sw(a, b) { const k = this.k[a]; this.k[a] = this.k[b]; this.k[b] = k; const v = this.v[a]; this.v[a] = this.v[b]; this.v[b] = v; }
}

const SQ2 = Math.SQRT2;
const DIRS = [[1, 0, 1], [-1, 0, 1], [0, 1, 1], [0, -1, 1], [1, 1, SQ2], [1, -1, SQ2], [-1, 1, SQ2], [-1, -1, SQ2]];

export class NavGrid {
  constructor(widthPx, heightPx) {
    this.cols = Math.ceil(widthPx / M); this.rows = Math.ceil(heightPx / M);
    const n = this.cols * this.rows;
    this.blocked = new Uint8Array(n);
    this.pallet = new Int32Array(n).fill(-1); // index into pallets when cell is a pallet gap
    this.grass = new Uint8Array(n);
    this.deadZone = new Float32Array(n);      // 0 = covered by tiles, 1 = pure dead zone
    this.tileOf = new Int16Array(n).fill(-1);
    this.links = []; this.linksAt = new Map();
    this.pallets = [];
    // A* scratch
    this.g = new Float32Array(n); this.par = new Int32Array(n); this.seen = new Uint32Array(n); this.closed = new Uint32Array(n);
    this.parLink = new Int32Array(n); this.stamp = 1; this.heap = new Heap();
    this.searches = 0;
  }
  idx(cx, cy) { return cy * this.cols + cx; }
  cellOf(x, y) { return [Math.max(0, Math.min(this.cols - 1, Math.floor(x / M))), Math.max(0, Math.min(this.rows - 1, Math.floor(y / M)))]; }
  idxAt(x, y) { const [c, r] = this.cellOf(x, y); return this.idx(c, r); }
  center(i) { return { x: (i % this.cols + 0.5) * M, y: (Math.floor(i / this.cols) + 0.5) * M }; }
  isBlocked(i) {
    if (this.blocked[i]) return true;
    const p = this.pallet[i]; return p >= 0 && this.pallets[p].state === 'down';
  }

  build(solids, pallets, windows, inflate = 0.45 * M) {
    this.pallets = pallets;
    for (let r = 0; r < this.rows; r++) for (let c = 0; c < this.cols; c++) {
      const x = (c + 0.5) * M, y = (r + 0.5) * M;
      for (const s of solids) {
        if (!s.blocksMove || s.kind === 'pallet') continue;
        if (x > s.x - inflate && x < s.x + s.w + inflate && y > s.y - inflate && y < s.y + s.h + inflate) { this.blocked[this.idx(c, r)] = 1; break; }
      }
    }
    pallets.forEach((p, k) => {
      const pad = 0.45 * M;
      for (let r = Math.floor((p.rect.y - pad) / M); r <= Math.floor((p.rect.y + p.rect.h + pad) / M); r++)
        for (let c = Math.floor((p.rect.x - pad) / M); c <= Math.floor((p.rect.x + p.rect.w + pad) / M); c++) {
          if (c < 0 || r < 0 || c >= this.cols || r >= this.rows) continue;
          const x = (c + 0.5) * M, y = (r + 0.5) * M;
          if (x > p.rect.x - pad && x < p.rect.x + p.rect.w + pad && y > p.rect.y - pad && y < p.rect.y + p.rect.h + pad) {
            const i = this.idx(c, r); if (!this.blocked[i]) this.pallet[i] = k;
          }
        }
      this._addLink(p, 'pallet');
    });
    for (const w of windows) this._addLink(w, 'window');
  }
  _addLink(obj, kind) {
    const [A, B] = obj.sides(1.25 * M);
    let a = this.nearestOpen(A.x, A.y, 2, true), b = this.nearestOpen(B.x, B.y, 2, true);
    if (a < 0 || b < 0 || a === b) return;
    const link = { a, b, kind, ref: obj, id: this.links.length };
    this.links.push(link);
    for (const c of [a, b]) { if (!this.linksAt.has(c)) this.linksAt.set(c, []); this.linksAt.get(c).push(link); }
    obj.navLink = link;
  }
  nearestOpen(x, y, maxR = 6, ignorePallets = false) {
    const [c0, r0] = this.cellOf(x, y);
    let best = -1, bd = 1e9;
    for (let rad = 0; rad <= maxR; rad++) {
      for (let dy = -rad; dy <= rad; dy++) for (let dx = -rad; dx <= rad; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== rad) continue;
        const c = c0 + dx, r = r0 + dy; if (c < 0 || r < 0 || c >= this.cols || r >= this.rows) continue;
        const i = this.idx(c, r);
        if (this.blocked[i] || (!ignorePallets && this.isBlocked(i))) continue;
        if (ignorePallets && this.pallet[i] >= 0) continue;
        const cc = this.center(i); const d = (cc.x - x) ** 2 + (cc.y - y) ** 2;
        if (d < bd) { bd = d; best = i; }
      }
      if (best >= 0) return best;
    }
    return best;
  }

  // A* from world point to world point. agent: { linkCost(link)->seconds-equivalent meters or Infinity, cellCost(i)->extra }
  findPath(sx, sy, tx, ty, agent = {}, maxNodes = 12000) {
    this.searches++;
    const s = this.nearestOpen(sx, sy), t = this.nearestOpen(tx, ty);
    if (s < 0 || t < 0) return null;
    const st = ++this.stamp; const h = this.heap; h.clear();
    const cols = this.cols;
    const tc = t % cols, tr = (t / cols) | 0;
    const heur = (i) => { const dx = Math.abs(i % cols - tc), dy = Math.abs(((i / cols) | 0) - tr); return (dx + dy) + (SQ2 - 2) * Math.min(dx, dy); };
    this.g[s] = 0; this.seen[s] = st; this.par[s] = -1; this.parLink[s] = -1; h.push(heur(s), s);
    let expanded = 0, found = false;
    const cellCost = agent.cellCost, linkCost = agent.linkCost;
    while (h.n) {
      const cur = h.pop();
      if (this.closed[cur] === st) continue; this.closed[cur] = st;
      if (cur === t) { found = true; break; }
      if (++expanded > maxNodes) break;
      const cx = cur % cols, cy = (cur / cols) | 0;
      for (const [dx, dy, w] of DIRS) {
        const nx = cx + dx, ny = cy + dy; if (nx < 0 || ny < 0 || nx >= cols || ny >= this.rows) continue;
        const ni = ny * cols + nx; if (this.isBlocked(ni)) continue;
        if (dx && dy && (this.isBlocked(cy * cols + nx) || this.isBlocked(ny * cols + cx))) continue;
        const ng = this.g[cur] + w + (cellCost ? cellCost(ni) : 0);
        if (this.seen[ni] !== st || ng < this.g[ni]) { this.seen[ni] = st; this.g[ni] = ng; this.par[ni] = cur; this.parLink[ni] = -1; h.push(ng + heur(ni), ni); }
      }
      const ls = this.linksAt.get(cur);
      if (ls && linkCost) for (const L of ls) {
        const c = linkCost(L); if (!isFinite(c)) continue;
        const ni = L.a === cur ? L.b : L.a;
        const ng = this.g[cur] + c;
        if (this.seen[ni] !== st || ng < this.g[ni]) { this.seen[ni] = st; this.g[ni] = ng; this.par[ni] = cur; this.parLink[ni] = L.id; h.push(ng + heur(ni), ni); }
      }
    }
    if (!found) return null;
    const cells = []; let c = t;
    while (c >= 0) { cells.push({ i: c, link: this.parLink[c] }); c = this.par[c]; }
    cells.reverse();
    const pts = cells.map((q, k) => {
      const p = this.center(q.i);
      // a link index on node k means we arrived at k by crossing that link from k-1
      return { x: p.x, y: p.y, viaLink: q.link >= 0 ? this.links[q.link] : null };
    });
    pts[pts.length - 1] = { x: tx, y: ty, viaLink: pts[pts.length - 1].viaLink };
    return { pts, cost: this.g[t] };
  }

  // String-pull a path using world sweeps; never smooths across link crossings.
  smooth(world, path, r) {
    if (!path || path.length < 3) return path;
    const out = [path[0]]; let i = 0;
    while (i < path.length - 1) {
      let j = path.length - 1;
      // don't skip a link: find first link index after i
      for (let k = i + 1; k < path.length; k++) if (path[k].viaLink) { j = Math.min(j, k - 1 > i ? k - 1 : k); break; }
      while (j > i + 1 && !world.sweepClear(path[i].x, path[i].y, path[j].x, path[j].y, r, (s) => s.kind !== 'gate' || !s.ref.open)) j--;
      out.push(path[j]); i = j;
    }
    return out;
  }

  // Local Dijkstra distance field (meters) from a source, within a square window.
  // Returns { ox, oy, size, d: Float32Array } where d is Infinity for unreachable.
  field(sx, sy, half, linkCost, cellCost = null, maxCost = 80) {
    const [c0, r0] = this.cellOf(sx, sy);
    const size = half * 2 + 1, ox = c0 - half, oy = r0 - half;
    const d = new Float32Array(size * size).fill(Infinity);
    const at = (x, y) => { const [c, r] = this.cellOf(x, y); const lc = c - ox, lr = r - oy; return lc < 0 || lr < 0 || lc >= size || lr >= size ? Infinity : d[lr * size + lc]; };
    const h = new Heap(1024);
    const src = this.nearestOpen(sx, sy, 3);
    if (src < 0) return { ox, oy, size, d, at };
    const lid = (i) => { const c = i % this.cols - ox, r = ((i / this.cols) | 0) - oy; return c < 0 || r < 0 || c >= size || r >= size ? -1 : r * size + c; };
    const sL = lid(src); if (sL < 0) return { ox, oy, size, d, at };
    d[sL] = 0; h.push(0, src);
    const cols = this.cols;
    while (h.n) {
      const kv = h.k[0]; const cur = h.pop(); const cl = lid(cur);
      if (kv > d[cl]) continue; if (kv > maxCost) break;
      const cx = cur % cols, cy = (cur / cols) | 0;
      for (const [dx, dy, w] of DIRS) {
        const nx = cx + dx, ny = cy + dy; if (nx < 0 || ny < 0 || nx >= cols || ny >= this.rows) continue;
        const ni = ny * cols + nx; const nl = lid(ni); if (nl < 0 || this.isBlocked(ni)) continue;
        if (dx && dy && (this.isBlocked(cy * cols + nx) || this.isBlocked(ny * cols + cx))) continue;
        const nd = kv + w + (cellCost ? cellCost(ni) : 0);
        if (nd < d[nl]) { d[nl] = nd; h.push(nd, ni); }
      }
      const ls = this.linksAt.get(cur);
      if (ls && linkCost) for (const L of ls) {
        const c = linkCost(L); if (!isFinite(c)) continue;
        const ni = L.a === cur ? L.b : L.a; const nl = lid(ni); if (nl < 0) continue;
        const nd = kv + c; if (nd < d[nl]) { d[nl] = nd; h.push(nd, ni); }
      }
    }
    return { ox, oy, size, d, at };
  }
}
