// Difficulty 1–10 maps to *how the bot thinks*, never to raw speed or extra information.
// Every value is data so tuning never touches AI code.
import { lerp, clamp } from '../core/util.js';

const SPEC = {
  reaction:        [1.15, 0.12],  // s before a newly-visible killer is acted on
  tacticalHz:      [4, 10],       // chase/tactical decisions per second
  strategicEvery:  [1.4, 0.5],    // s between utility re-evaluations
  temperature:     [20, 2.5],     // softmax temperature on utility scores (randomness)
  mistakeRate:     [0.22, 0.0],   // chance to take a poor option on purpose
  memoryTau:       [4, 15],       // s for killer-belief confidence to decay by e
  predictLead:     [0.0, 0.9],    // s of killer motion extrapolation
  awareness:       [0.35, 1.0],   // shimmer / sound interpretation quality
  fieldHalf:       [16, 24],      // local chase field radius in cells (meters)
  horizon:         [3.0, 7.0],    // chase lookahead (m)
  loopIQ:          [0.05, 1.0],   // weight on loop margin vs naive running away
  fastVault:       [0.45, 0.98],  // chance a vault is a fast vault
  throwDist:       [5.8, 3.7],    // m: killer distance that prompts a pallet drop
  greed:           [0.0, 0.85],   // willingness to keep a pallet up while safe
  palletWaste:     [0.3, 0.0],    // chance to drop with no real gain
  dodge:           [0.08, 0.92],  // Dead Hard / chainsaw sidestep timing quality
  mindgameRead:    [0.0, 0.9],
  deadZoneAware:   [0.0, 1.0],
  tileGraph:       [0.1, 1.0],
  stealth:         [0.2, 1.0],
  scGreat:         [0.08, 0.72],
  scFail:          [0.3, 0.01],
  clusterAware:    [0.0, 1.0],
  comms:           [0.25, 1.0],
  leaveAhead:      [1.0, 4.2],    // s of predicted killer ETA that makes a bot leave a gen
  threatSense:     [0.45, 1.0],
  protect:         [0.0, 1.0],
  hookWisdom:      [0.0, 1.0],
  pathNoise:       [2.6, 0.0],    // m of waypoint error
  healWisdom:      [0.0, 1.0],
  lineAware:       [0.15, 1.0],   // chainsaw line-of-fire awareness
  trapSense:       [0.35, 1.0],   // trap spotting radius multiplier
  leadAway:        [0.0, 1.0],    // drag the killer away from teammates' gens
  zoneSense:       [0.2, 1.0],    // how much known danger zones (gas, trails, pods) shape routes
  perkIQ:          [0.15, 1.0],   // how well perks are used (timing, saving charges)
};

export function aiParams(d) {
  d = clamp(d, 1, 10);
  const t = (d - 1) / 9;
  const out = { difficulty: d };
  for (const k in SPEC) out[k] = lerp(SPEC[k][0], SPEC[k][1], k === 'mistakeRate' || k === 'palletWaste' ? Math.pow(t, 0.7) : t);
  out.tacticalHz = Math.round(out.tacticalHz);
  out.fieldHalf = Math.round(out.fieldHalf);
  // Discrete capability gates (low levels simply do not use some techniques)
  out.usesMindgames = d >= 6; out.preDrops = d >= 6; out.usesGreed = d >= 7; out.leavesEarly = d >= 4;
  out.protectionHits = d >= 8; out.flashlightSaves = d >= 6; out.genStrategy = d >= 6; out.waitsForCamper = d >= 6;
  return out;
}

export const DIFFICULTY_LABELS = ['', 'Fresh Meat', 'Beginner', 'Beginner+', 'Average', 'Average+', 'Good', 'Good+', 'Strong', 'Very Strong', 'Elite'];
