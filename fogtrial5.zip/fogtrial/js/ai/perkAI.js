// Perk utility layer. Every survivor bot owns a PerkBrain that
//  1. turns its own perks into goal biases (Empathy → heal more, Breakout → follow carries…)
//  2. decides WHEN to fire active / exhaustion perks (and saves them otherwise)
//  3. learns the killer's perks as they reveal themselves and adapts the team plan.
// Everything scales with the difficulty knob perkIQ: low-skill bots misjudge the moment,
// waste exhaustion perks and barely change their plan; high-skill bots play around perks.
import { M, dist } from '../core/util.js';

const BASE = () => ({ repair: 1, heal: 1, healSelf: 1, rescue: 1, cleanse: 1, hide: 0, protect: 1, gate: 1, joinGen: 1, followCarry: 1, cluster: 1, chest: 1, stunHunt: 1, selfHeal: false });

// How a known killer perk changes the plan (multipliers, applied with perkIQ weight).
const KILLER_PERK_REACT = {
  coulrophobia: { heal: 0.85, healSelf: 0.85 },
  genetic_limits: { heal: 0.9 },
  deathbound: { heal: 0.85 },
  make_your_choice: { rescue: 0.85, protect: 1.1 },
  starstruck: { followCarry: 0.75, protect: 0.85 },
  forced_penance: { protect: 0.7 },
  eruption: { repair: 0.95, joinGen: 0.85 },
  pain_resonance: { repair: 0.95, joinGen: 0.85 },
  jolt: { repair: 0.95 },
  grim_embrace: { rescue: 1.1 },
  deadlock: { cluster: 1.2 },
  machine_learning: { repair: 0.97 },
  ruin: { cleanse: 1.4, repair: 1.05 },
  noed: { cleanse: 1.8, gate: 1.1 },
  no_way_out: { gate: 0.95 },
  infectious_fright: { joinGen: 0.85 },
  discordance: { joinGen: 0.75 },
  thanatophobia: { heal: 1.2 },
  nurses_calling: { heal: 0.85, healSelf: 0.85 },
  bbq: { hide: 0.15 },
};
// Killer perks that are visible to survivors when they fire (notifications, screams, gens exploding…)
const OBSERVABLE = new Set(['eruption', 'grim_embrace', 'jolt', 'overcharge', 'deadlock', 'pain_resonance', 'starstruck', 'forced_penance', 'genetic_limits', 'forced_hesitation',
  'infectious_fright', 'deathbound', 'make_your_choice', 'no_way_out', 'blood_warden', 'rancor', 'noed', 'ruin', 'bbq', 'discordance', 'nurses_calling', 'corrupt', 'pop', 'spirit_fury', 'bitter_murmur']);

export class PerkBrain {
  constructor(ai) {
    this.ai = ai; this.m = ai.m; this.sv = ai.sv;
    this.bias = BASE(); this.lastUse = new Map(); this._sbNow = false;
    // Team knowledge of killer perks lives on the blackboard so callouts are shared.
    const bb = this.m.bb; bb.killerPerksKnown ||= new Map();
    if (!this.m._perkWatch) {
      this.m._perkWatch = true;
      this.m.events.on('perkProc', (d) => {
        const p = d.perk; if (p.def.side !== 'killer' || !OBSERVABLE.has(p.id)) return;
        if (!bb.killerPerksKnown.has(p.id)) { bb.killerPerksKnown.set(p.id, this.m.time); const s = this.m.survivors.find((q) => q.ai && q.alive); s?.ai.note(`Killer has ${p.def.name}`, 'kp_' + p.id); }
      });
    }
    this.recompute();
  }
  get iq() { return this.ai.params.perkIQ ?? 0.5; }
  // weight a multiplier by skill: 1 + (k-1)*w
  w(k, w) { return 1 + (k - 1) * w; }
  recompute() {
    const b = BASE(), iq = this.iq, wt = 0.35 + 0.65 * iq, s = this.sv, m = this.m;
    for (const p of s.perks) {
      const a = p.def.ai; if (!a) continue;
      const apply = (src) => { for (const k in src) { if (k === 'hide') b.hide += src.hide * wt; else b[k] *= this.w(src[k], wt); } };
      if (a.bias) apply(a.bias);
      if (a.dynBias) { const d = a.dynBias(p, this.ai); if (d) apply(d); }
    }
    // Killer perks the team has figured out (only skilled bots adapt much)
    const known = m.bb.killerPerksKnown;
    if (known?.size) for (const id of known.keys()) { const r = KILLER_PERK_REACT[id]; if (!r) continue; for (const k in r) { if (k === 'hide') b.hide += r.hide * iq; else b[k] *= this.w(r[k], iq * 0.9); } }
    b.selfHeal = m.perks.anySurvivorHas('circle_of_healing');
    this.bias = b;
  }
  has(id) { return this.sv.perks.find((p) => p.id === id); }

  // Exhaustion perks: Sprint Burst is fired by the brain at the right moment (see tick),
  // other callers ask through here. Low perkIQ wastes them on nothing.
  wantsExhaustion(p) {
    const ai = this.ai, iq = this.iq;
    if (p.id === 'sprint_burst') {
      if (this._sbNow) return true;
      if (iq < 0.45) return Math.random() < 0.7 - iq; // careless: bursts while just jogging around
      return ai.inChase || ai.threat > 0.7;
    }
    return true;
  }
  wantsBurst(kind) {
    const iq = this.iq;
    if (kind === 'save') return Math.random() < 0.35 + 0.65 * iq && this.ai.threat < 0.75;
    return true;
  }
  tick() {
    const ai = this.ai, s = this.sv, m = this.m, iq = this.iq;
    if (!s.standing) return;
    if (m.time - (this._rc || -9) > 1) { this._rc = m.time; this.recompute(); }
    // Sprint Burst at the decisive moment: the killer is closing in and we are not yet
    // committed to a loop. Skilled bots wait for it; poor bots fire early or late.
    const sb = this.has('sprint_burst');
    if (sb && !s.status.has('exhausted')) {
      const B = ai.belief; const kd = B.conf > 0.3 ? dist(s.x, s.y, B.x, B.y) / M : 99;
      const ideal = (ai.inChase && kd < 9) || (B.observing && kd < 11 && ai.threat > 0.6);
      const jitter = (1 - iq) * 6;
      if (ideal && kd < 9 + (Math.random() - 0.5) * jitter && Math.random() < 0.25 + 0.75 * iq) {
        this._sbNow = true; sb.def.onStartRun(sb, s, m); this._sbNow = false;
        if (s.status.has('exhausted')) ai.note('Sprint Burst away from the killer', 'sbuse');
      }
    }
    // Active perks with an AI value function
    for (const p of s.perks) {
      const use = p.def.ai?.use; if (!use || !p.def.activate) continue;
      if (m.time - (this.lastUse.get(p.id) || -99) < 1.5) continue;
      const v = use.value(p, ai);
      let fire = v >= 1 && Math.random() < 0.3 + 0.7 * iq;
      if (!fire && iq < 0.4 && Math.random() < (0.4 - iq) * 0.03) fire = true; // misclick / bad timing
      if (fire && m.perks.activate(s, p.id)) this.lastUse.set(p.id, m.time);
    }
  }
  describe() {
    const b = this.bias, out = [];
    for (const k of ['repair', 'heal', 'healSelf', 'rescue', 'cleanse', 'protect', 'gate', 'joinGen', 'followCarry', 'cluster']) if (Math.abs(b[k] - 1) > 0.04) out.push(`${k}×${b[k].toFixed(2)}`);
    if (b.hide) out.push(`hide+${b.hide.toFixed(2)}`);
    return out.join(' · ');
  }
}
