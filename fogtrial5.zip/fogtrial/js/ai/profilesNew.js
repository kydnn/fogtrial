// Counterplay profiles for the six newest killers (Skull Merchant, Blight, Nurse, Unknown,
// Nemesis, Ghoul). Same shape as killerProfiles.js / profilesExpansion.js. Everything reads
// the survivor's own perception (belief, memory, sounds) — no omniscience.
import { M, dist, angleDiff, clamp } from '../core/util.js';
import { K, sidestep, fleeFrom, minionOnMe, palletOnMinion } from './counterplayKit.js';

const knownDevices = (ai, kind) => [...ai.memory.devices.values()].filter((d) => d.kind === kind && !d.dead);
const activeDrone = (d, m) => !d.dead && (d.data.disabledUntil || 0) <= m.time;
const inLane = (fromX, fromY, dir, s, len, half) => {
  const rx = s.x - fromX, ry = s.y - fromY; const along = rx * Math.cos(dir) + ry * Math.sin(dir);
  const side = Math.abs(-rx * Math.sin(dir) + ry * Math.cos(dir)); return along > 0 && along < len && side < half;
};

export const NEW_PROFILES = {
  // ------------------------------------------------------------------ SKULL MERCHANT
  skull_merchant: {
    power: 'Drones (Eyes in the Sky)', strengths: ['map-wide information', 'lock-ons injure without a chase', 'claw traps track and hinder'], weaknesses: ['scan lines are visible and predictable', 'crouching / standing still avoids detection', 'drones can be hacked'],
    avoid: ['running through scan lines', 'stacking lock-ons', 'repairing inside overlapping zones'], exploit: ['crouch as the line passes', 'hack drones near objectives', 'claw traps come off by hacking'],
    knobs: K({ zoneAvoid: 1.3, hideBias: 0.15, genEscape: 1.1, stealthy: true, leaveEarly: 1.1 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, P = ai.params;
      if (!s.standing || s.vault || ai.inChase) return null;
      // the scan line is about to sweep over me: crouch (or freeze) until it has passed
      for (const d of knownDevices(ai, 'drone')) {
        if (!activeDrone(d, m)) continue;
        const r = dist(s.x, s.y, d.x, d.y); if (r > 10.5 * M || !m.world.losClear(d.x, d.y, s.x, s.y)) continue;
        const b = Math.atan2(s.y - d.y, s.x - d.x);
        // angle the line still has to turn (it sweeps counter-clockwise in screen space: +105°/s)
        let ahead = b - d.data.a; while (ahead < 0) ahead += Math.PI * 2; while (ahead > Math.PI * 2) ahead -= Math.PI * 2;
        const tIn = ahead / (105 * Math.PI / 180);
        const react = 0.25 + (1 - P.awareness) * 0.6;
        if (tIn < 0.9 && tIn > react * 0.5 && Math.random() < 0.15 + 0.85 * P.awareness) {
          if (s.action?.type === 'repair' || s.action?.type === 'heal' || s.action?.type === 'device') return null; // working = standing still: safe
          s.moveMode = 'crouch'; ai.crouchUntil = m.time + tIn + 0.35; ai.chase.sidestepUntil = m.time + tIn + 0.35; ai.setPath([{ x: s.x, y: s.y }], true);
          ai.note('Crouched under the drone\'s scan line', 'scancrouch'); return 'crouch for the scan';
        }
      }
      return null;
    },
    goals(ai, add, { myD, safety }) {
      const s = ai.sv, m = ai.m, P = ai.params;
      const trapped = s.status.has('clawTrap'), stacks = s.status.get('lockOn')?.value ?? 0;
      for (const d of knownDevices(ai, 'drone')) {
        if (!activeDrone(d, m) || !d.usable(s, m)) continue;
        const onGen = m.map.gens.some((g) => !g.done && dist(g.x, g.y, d.x, d.y) < 12 * M);
        const v = (trapped ? 120 : 0) + (onGen ? 34 : 8) + stacks * 12;
        add('DEVICE', d, v * (0.35 + 0.65 * P.zoneSense) * (0.3 + 0.7 * safety(d.x, d.y)) / (1 + myD(d.x, d.y) / 60), [trapped ? 'claw trap: hack to remove it' : onGen ? 'drone watching a generator' : 'hack a drone']);
      }
    },
    genFactor(ai, g) { const n = knownDevices(ai, 'drone').filter((d) => activeDrone(d, ai.m) && dist(d.x, d.y, g.x, g.y) < 10 * M).length; return n ? { f: Math.pow(0.8, n), why: `${n} drone${n > 1 ? 's' : ''} on gen` } : null; },
  },

  // ------------------------------------------------------------------ BLIGHT
  blight: {
    power: 'Blighted Rush', strengths: ['crosses the map in seconds', 'lethal rush after a slam', 'smashes pallets during lethal rushes'], weaknesses: ['turns slowly while rushing', 'bumps do no damage', 'long fatigue after the chain'],
    avoid: ['open fields', 'running in a straight line from him', 'standing next to walls he can slam'], exploit: ['side-step late', 'tall loops and windows', 'run during fatigue'],
    knobs: K({ openPenalty: 1.6, losValue: 1.8, windowValue: 1.15, palletValue: 0.9, greed: 0.5, tightPenalty: 0.6 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, k = ai.fk, B = ai.belief, P = ai.params, pw = k.power;
      if (!s.standing || s.vault || !B.observing) return null;
      // rushing at me: side-step at the last moment (he can't turn in time)
      if (pw.state === 'rush' || pw.state === 'special') {
        const d = dist(k.x, k.y, s.x, s.y) / M;
        if (inLane(k.x, k.y, pw.dir, s, (pw.state === 'special' ? 4 : 9) * M, 1.6 * M) && d < (pw.lethal ? 6.5 : 5) && ai._blKey !== Math.round(m.time * 3)) {
          ai._blKey = Math.round(m.time * 3);
          const late = d < 2.5 + 2.5 * P.awareness; // skilled survivors wait for the last moment
          if (late && Math.random() < 0.1 + 0.8 * P.dodge) return sidestep(ai, pw.dir, pw.lethal ? 'Side-stepped the lethal rush' : 'Side-stepped the rush', 2.4);
        }
      }
      // fatigued: make distance now
      if (pw.state === 'fatigue' && ai.inChase && m.time - (ai._blRun || -9) > 1) { ai._blRun = m.time; return fleeFrom(ai, k.x, k.y, 'He is fatigued — running', { windows: true, minD: 6, maxD: 11, holdFor: 1 }); }
      return null;
    },
  },

  // ------------------------------------------------------------------ NURSE
  nurse: {
    power: "Blink (Spencer's Last Breath)", strengths: ['blinks through walls', 'ignores pallets and windows', 'closes 20 m instantly'], weaknesses: ['slow walker', 'long fatigue after blinking', 'charge-up is audible and must be predicted'],
    avoid: ['predictable straight lines', 'relying on pallets/windows', 'open space when she has blinks'], exploit: ['double back as her charge ends', 'break line of sight at the last moment', 'distance during fatigue'],
    knobs: K({ palletValue: 0.45, windowValue: 0.45, losValue: 1.6, openPenalty: 1.1, preDrop: 0, greed: 0, loopAbandon: true, hideBias: 0.25, stealthy: true }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, k = ai.fk, B = ai.belief, P = ai.params, pw = k.power;
      if (!s.standing || s.vault) return null;
      const d = dist(B.x, B.y, s.x, s.y) / M;
      // charging (seen or heard): she will blink to where I'm heading → reverse / cut sideways
      // right before the charge completes. Beginners keep running straight.
      const charging = (pw.state === 'charging' && (B.observing || m.time - (B.windupT || -9) < 0.4));
      if (charging && d < 22 && ai._nuKey !== (pw.blinks + ':' + Math.round(pw.charge * 2))) {
        const expect = pw.blinkDist / M;
        if (Math.abs(expect - d) < 4 + 4 * P.awareness && Math.random() < 0.1 + 0.75 * P.dodge) {
          ai._nuKey = pw.blinks + ':' + Math.round(pw.charge * 2);
          const back = Math.atan2(k.y - s.y, k.x - s.x); // double back toward her side, diagonally
          const a = back + (Math.random() < 0.5 ? 1 : -1) * (0.9 + Math.random() * 0.5);
          const tx = s.x + Math.cos(a) * 3 * M, ty = s.y + Math.sin(a) * 3 * M;
          if (!m.world.pointBlocked(tx, ty, s.r)) { ai.setPath([{ x: s.x, y: s.y }, { x: tx, y: ty }], true); ai.chase.sidestepUntil = m.time + 0.5; ai.note('Doubled back as the Nurse charged her blink', 'nursejuke'); return 'juke the blink'; }
        }
      }
      // fatigued: run, hard
      if (pw.state === 'fatigue' && B.observing && d < 14 && m.time - (ai._nuRun || -9) > 1) { ai._nuRun = m.time; return fleeFrom(ai, k.x, k.y, 'She is fatigued — gaining distance', { minD: 6, maxD: 12, holdFor: 1 }); }
      return null;
    },
  },

  // ------------------------------------------------------------------ UNKNOWN
  unknown: {
    power: 'UVX & hallucinations', strengths: ['bouncing ranged bursts', 'Weakened turns bursts into damage', 'teleports to hallucinations'], weaknesses: ['UVX needs a 1 s charge', 'Weakened is cleared by looking at him', 'hallucinations can be dispelled'],
    avoid: ['grouping (bursts hit several)', 'straight lanes while he charges', 'walking into hallucinations'], exploit: ['side-step the UVX', 'stare him down to clear Weakened', 'dispel hallucinations near gens'],
    knobs: K({ losValue: 2.5, openPenalty: 1.4, groupPenalty: 0.2, zoneAvoid: 1.2 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, k = ai.fk, B = ai.belief, P = ai.params, pw = k.power;
      if (!s.standing || s.vault) return null;
      // UVX charging at me: open the angle (late side-step)
      if (pw.state === 'charging' && B.observing && pw.charge > 0.8 - 0.3 * P.awareness && ai._unKey !== Math.round(m.time)) {
        ai._unKey = Math.round(m.time);
        if (inLane(k.x, k.y, k.facing, s, 22 * M, 2.4 * M) && Math.random() < 0.1 + 0.7 * P.dodge) return sidestep(ai, k.facing, 'Side-stepped the UVX', 2.4);
      }
      // Weakened and not chased: turn and look at him to clear it (skilled survivors do it from cover)
      if (s.status.has('weakened') && B.observing && !ai.inChase && dist(k.x, k.y, s.x, s.y) < 24 * M && dist(k.x, k.y, s.x, s.y) > 10 * M && P.difficulty >= 3) {
        s.facing = Math.atan2(k.y - s.y, k.x - s.x); s.lookTarget = { x: k.x, y: k.y }; s.lookUntil = m.time + 0.6;
        if (m.time - (ai._unLook || -9) > 4) { ai._unLook = m.time; ai.note('Staring at the Unknown to shake off Weakened', 'stare'); }
      }
      // a hallucination I know about near me: stare at it (dispel) rather than walking into it
      for (const h of knownDevices(ai, 'hallucination')) {
        const d = dist(h.x, h.y, s.x, s.y);
        if (d < 11 * M && d > 3.5 * M && !ai.inChase && m.world.losClear(s.x, s.y, h.x, h.y) && Math.random() < 0.3 + 0.7 * P.awareness) {
          s.facing = Math.atan2(h.y - s.y, h.x - s.x); s.lookTarget = { x: h.x, y: h.y }; s.lookUntil = m.time + 0.6;
          if (s.action?.type !== 'repair') { ai.chase.sidestepUntil = m.time + 0.4; ai.setPath([{ x: s.x, y: s.y }], true); }
          if (m.time - (ai._unHal || -9) > 4) { ai._unHal = m.time; ai.note('Dispelling a hallucination', 'dispelling'); }
          return 'dispel';
        }
      }
      return null;
    },
    genFactor(ai, g) { const n = knownDevices(ai, 'hallucination').filter((h) => dist(h.x, h.y, g.x, g.y) < 8 * M).length; return n ? { f: Math.pow(0.8, n), why: 'hallucination at gen' } : null; },
  },

  // ------------------------------------------------------------------ NEMESIS
  nemesis: {
    power: 'Tentacle Strike & zombies', strengths: ['5–6.5 m tentacle', 'smashes pallets at MR 2+', 'zombies add a second threat'], weaknesses: ['tentacle wind-up', 'first hit only contaminates', 'vaccines cure', 'zombies are slow'],
    avoid: ['staying at 3–6 m from him', 'zombie sightlines', 'staying contaminated'], exploit: ['vaccines when safe', 'pallet-stun zombies', 'windows before MR 2'],
    knobs: K({ losValue: 1.4, palletValue: 1.05, windowValue: 1.1, greed: 0.6, zoneAvoid: 1.1 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, k = ai.fk, B = ai.belief, P = ai.params, pw = k.power;
      if (!s.standing || s.vault) return null;
      // cure contamination when it is safe
      if (s.status.has('contaminated') && (s.vaccines || 0) > 0 && !s.action && ai.threat < 0.35) { s.startAction('vaccinate', null, m); ai.note('Injecting a vaccine', 'vaxuse'); return 'vaccinate'; }
      // a zombie is coming for me: drop a pallet on it or leave its path
      const z = minionOnMe(ai);
      if (z && z.n.kind === 'zombie' && z.d < 6 * M) { if (palletOnMinion(ai, z.n)) return 'pallet on zombie'; if (m.time - (ai._zRun || -9) > 1.5) { ai._zRun = m.time; return fleeFrom(ai, z.n.x, z.n.y, 'Walking away from a zombie', { windows: true, minD: 5, maxD: 9, holdFor: 1 }); } }
      // tentacle wind-up in my lane: side-step out (late), or step out of range
      if (pw.state === 'charging' && B.observing && inLane(k.x, k.y, k.facing, s, pw.reach + 0.5 * M, 1.4 * M) && ai._neKey !== Math.round(m.time * 2)) {
        ai._neKey = Math.round(m.time * 2);
        if (Math.random() < 0.1 + 0.7 * P.dodge) return sidestep(ai, k.facing, 'Side-stepped the tentacle', 2.2);
      }
      return null;
    },
    goals(ai, add, { myD, safety }) {
      const s = ai.sv; if (!s.status.has('contaminated') || (s.vaccines || 0) > 0) return;
      for (const c of knownDevices(ai, 'vaccine')) if (c.data.vaccines > 0) add('DEVICE', c, 75 * (0.3 + 0.7 * safety(c.x, c.y)) / (1 + myD(c.x, c.y) / 30), ['contaminated: get a vaccine']);
    },
  },

  // ------------------------------------------------------------------ GHOUL
  ghoul: {
    power: 'Kagune Leap', strengths: ['latches from 14 m', 'grab attacks inflict Deep Wound and the Kagune Mark', 'Enraged while anyone is marked'], weaknesses: ['leaps are straight lines', 'a latch alone does no damage', 'the mark is cleared by mending'],
    avoid: ['open lanes', 'leaving the Deep Wound unmended', 'straight runs while he has tokens'], exploit: ['tight corners and tall walls', 'mend quickly', 'turn hard right after a latch'],
    knobs: K({ openPenalty: 1.5, losValue: 2, tightPenalty: -0.3, windowValue: 1.1, greed: 0.7, healBias: 1.1 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, k = ai.fk, B = ai.belief, P = ai.params, pw = k.power;
      if (!s.standing || s.vault) return null;
      // mend the Deep Wound fast: it also clears the Kagune Mark
      if (s.status.has('deepWound') && !s.action && (ai.threat < 0.5 || s.status.get('deepWound').expiration < 8) && P.difficulty >= 2) { s.startAction('mend', null, m); ai.note(s.status.has('kaguneMark') ? 'Mending to clear the Kagune Mark' : 'Mending the Deep Wound', 'kmend'); return 'mend'; }
      // latched: break away around the nearest corner before the grab
      if (s.status.has('latched') && ai._ghKey !== Math.round(m.time * 2)) {
        ai._ghKey = Math.round(m.time * 2);
        if (Math.random() < 0.15 + 0.7 * P.dodge) return fleeFrom(ai, k.x, k.y, 'Breaking away from the latch', { windows: true, minD: 3, maxD: 6, holdFor: 0.6 });
      }
      // leap incoming (seen): side-step
      if (pw.state === 'leap' && B.observing && inLane(k.x, k.y, pw.dir, s, 8 * M, 1.4 * M) && ai._ghL !== Math.round(m.time * 3)) { ai._ghL = Math.round(m.time * 3); if (Math.random() < 0.05 + 0.5 * P.dodge) return sidestep(ai, pw.dir, 'Dodged the Kagune leap', 2.2); }
      return null;
    },
  },
};
