// Hidden personality traits (0..1). Archetypes are data; each bot rolls variance on top,
// so two bots at the same difficulty still play differently.
import { clamp, gauss, pick } from '../core/util.js';

export const TRAITS = ['bravery', 'selfishness', 'teamwork', 'riskTolerance', 'loopSkill', 'stealthSkill', 'objectiveFocus',
  'rescuePriority', 'healingPriority', 'killerAwareness', 'palletDiscipline', 'vaultSkill', 'predictionSkill'];

export const ARCHETYPES = {
  altruist: { label: 'Altruist', bravery: 0.75, selfishness: 0.1, teamwork: 0.9, riskTolerance: 0.6, loopSkill: 0.55, stealthSkill: 0.45, objectiveFocus: 0.5, rescuePriority: 0.95, healingPriority: 0.75, killerAwareness: 0.6, palletDiscipline: 0.55, vaultSkill: 0.55, predictionSkill: 0.55 },
  genrusher: { label: 'Gen Rusher', bravery: 0.4, selfishness: 0.55, teamwork: 0.55, riskTolerance: 0.45, loopSkill: 0.5, stealthSkill: 0.6, objectiveFocus: 0.95, rescuePriority: 0.45, healingPriority: 0.2, killerAwareness: 0.7, palletDiscipline: 0.6, vaultSkill: 0.5, predictionSkill: 0.6 },
  looper: { label: 'Looper', bravery: 0.9, selfishness: 0.3, teamwork: 0.65, riskTolerance: 0.8, loopSkill: 0.95, stealthSkill: 0.25, objectiveFocus: 0.55, rescuePriority: 0.6, healingPriority: 0.35, killerAwareness: 0.8, palletDiscipline: 0.85, vaultSkill: 0.95, predictionSkill: 0.85 },
  stealth: { label: 'Stealthy', bravery: 0.25, selfishness: 0.6, teamwork: 0.45, riskTolerance: 0.25, loopSkill: 0.4, stealthSkill: 0.95, objectiveFocus: 0.7, rescuePriority: 0.35, healingPriority: 0.6, killerAwareness: 0.85, palletDiscipline: 0.5, vaultSkill: 0.45, predictionSkill: 0.6 },
  medic: { label: 'Medic', bravery: 0.5, selfishness: 0.15, teamwork: 0.85, riskTolerance: 0.4, loopSkill: 0.5, stealthSkill: 0.55, objectiveFocus: 0.5, rescuePriority: 0.7, healingPriority: 0.95, killerAwareness: 0.6, palletDiscipline: 0.6, vaultSkill: 0.5, predictionSkill: 0.5 },
  wildcard: { label: 'Wildcard', bravery: 0.6, selfishness: 0.4, teamwork: 0.5, riskTolerance: 0.7, loopSkill: 0.6, stealthSkill: 0.4, objectiveFocus: 0.55, rescuePriority: 0.55, healingPriority: 0.45, killerAwareness: 0.5, palletDiscipline: 0.4, vaultSkill: 0.6, predictionSkill: 0.5 },
};

export function rollPersonality(rng, archetype = null) {
  const key = archetype || pick(rng, Object.keys(ARCHETYPES));
  const base = ARCHETYPES[key];
  const p = { archetype: key, label: base.label };
  const spread = key === 'wildcard' ? 0.3 : 0.12;
  for (const t of TRAITS) p[t] = clamp(base[t] + gauss(rng) * spread, 0.02, 0.98);
  return p;
}

export const SURVIVOR_ROSTER = [
  { name: 'Mara', color: '#d98c6a' }, { name: 'Desmond', color: '#6aa7d9' }, { name: 'Ivy', color: '#8fd97a' }, { name: 'Tomas', color: '#d9c86a' },
  { name: 'June', color: '#c58ad9' }, { name: 'Rook', color: '#6ad9c4' }, { name: 'Elena', color: '#e0a0b8' }, { name: 'Bram', color: '#b0b8c8' },
];
