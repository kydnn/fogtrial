// Survivor brain: perception → belief → utility goal selection (strategic, ~1–2 Hz)
// → behavior tree (tactical, 4–10 Hz) → path following / actions (every frame).
import { M, dist, clamp, smoothstep, gauss, angleDiff } from '../core/util.js';
import { aiParams } from './difficulty.js';
import { KillerBelief, INFO } from './killerPrediction.js';
import { ChaseBrain } from './chaseAI.js';
import { evaluateGoals, chooseGoal, GOAL_STATE } from './utilityAI.js';
import { Selector, Branch, Act, S, F, R } from './behaviorTree.js';
import { HOOK_STAGE_TIME } from '../entities/survivor.js';
import { profileFor, dodgeProjectiles } from './killerProfiles.js';
import { PerkBrain } from './perkAI.js';

const GOAL_ACTION = { REPAIR: 'repair', HEAL: 'heal', HEAL_SELF: 'healSelf', CLEANSE: 'cleanse', CHEST: 'searchChest', DISARM: 'disarm', FREE: 'freeTrapped', OPEN_GATE: 'openGate',
  DEVICE: 'device', PRINT_EMP: 'device', BURN_TRAP: 'flashlight', RESCUE: 'unhook', KEY_HATCH: 'openHatch', USE_EMP: 'useEmp' };
const KEEP_ACTIONS = new Set(['useEmp', 'dropPallet', 'vault', 'wiggle', 'breakChain', 'solveBox', 'mend', 'spray', 'vaccinate', 'escapeTrap', 'recover', 'flashlight']);

export class SurvivorAI {
  constructor(sv, m, difficulty, pers) {
    this.sv = sv; this.m = m; this.pers = pers; this.setDifficulty(difficulty);
    // One belief per killer; `belief`/`fk` point at the killer that matters most right now.
    this.beliefs = new Map(m.killers.map((k) => [k, new KillerBelief(this, k)]));
    this.fk = m.killer; this.belief = this.beliefs.get(this.fk); this.chase = new ChaseBrain(this);
    this.memory = { traps: new Map(), totems: new Map(), gens: new Map(), hatchSeen: false, zones: new Map(), devices: new Map(), minions: new Map() };
    this.crouchUntil = 0;
    this.profile = profileFor(m, this.fk); this.knobs = this.profile.knobs; this.perkBrain = new PerkBrain(this);
    this._zoneCells = new Map(); this._zoneV = 0; this._zoneCellsV = -1; this._overrideUntil = 0;
    this._trapCells = new Set(); this._trapVersion = -1; this._trapCellsV = -2;
    this.goal = null; this.goalCommitUntil = 0; this.options = [];
    this.state = 'IDLE'; this.trace = []; this.threat = 0; this.inChase = false; this.chaseSince = 0; this.lostT = 0;
    this.path = null; this.pathIdx = 0; this.pathTarget = null; this.pathT = -99; this.stuckT = 0; this.lastPos = { x: 0, y: 0 };
    this.tT = Math.random() * 0.2; this.sT = Math.random() * 0.8; this.pT = Math.random() * 0.1;
    this.evadeMode = null; this.evadeUntil = 0; this.hideSpot = null; this.waitSpot = null; this.forced = null;
    this.notes = new Map(); this.selfUnhookT = 0;
    this.tree = this.buildTree();
    sv.ai = this;
  }
  setDifficulty(d) { this.difficulty = d; this.params = aiParams(d); this.sv.difficulty = d; }

  // ---------------------------------------------------------------- helpers
  note(text, tag) {
    const last = this.notes.get(tag) || -99; if (this.m.time - last < 5) return;
    this.notes.set(tag, this.m.time);
    this.m.aiLog.push({ t: this.m.time, who: this.sv.name, color: this.sv.color, text, tag });
    if (this.m.aiLog.length > 200) this.m.aiLog.shift();
  }
  // Killer-power callbacks (things the survivor directly experiences)
  onPhantasm(d) { this.note('Triggered a Phantasm trap — the Hag can teleport here', 'phantasm'); this.evadeUntil = this.m.time + 3; this.evadeMode = 'run'; this.evadeDecideT = this.m.time + 3; }
  onGuardSpotted(g) { this.note(`${g.label} spotted me`, 'gspot'); this.sv.stopAction(this.m); }
  onStandard(d) { this.memory.devices.set(d.id, d); this.note('A Standard appeared — grabbing it ends the hunt', 'stdseen'); }
  onDogPursuit(dog) { this.memory.minions.set(dog.id, { n: dog, x: dog.x, y: dog.y, t: this.m.time }); this.note('The dog is on my trail', 'dogtrail'); this.sv.stopAction(this.m); }
  beliefFor(k) { return this.beliefs.get(k) || this.belief; }
  // 2v8: focus on the killer that threatens me most (seen/heard, close, approaching). A small
  // hysteresis keeps the focus from flickering between two killers at similar distances.
  pickFocus() {
    const s = this.sv; let best = null, bs = -1;
    for (const [k, b] of this.beliefs) {
      if (b.conf < 0.12 && !b.heartbeat) continue;
      const p = b.pos(); const d = dist(p.x, p.y, s.x, s.y) / M;
      let sc = b.conf / (1 + d / 14) + (b.observing ? 0.4 : 0) + b.heartbeat * 0.5 + Math.max(0, b.approach) / M * 0.05;
      if (k === this.fk) sc *= 1.15;
      if (sc > bs) { bs = sc; best = k; }
    }
    if (best && best !== this.fk) { this.fk = best; this.belief = this.beliefs.get(best); this.profile = profileFor(this.m, best); this.knobs = this.profile.knobs; this.note(`Watching ${best.def.short}`, 'focus'); }
  }
  wantsExhaustionPerk(p) { return this.perkBrain.wantsExhaustion(p); }
  killerDistAt(x, y) {
    const B = this.belief; const kn = this.knobs;
    // Against stealth killers an unknown position is treated as closer (ambush paranoia).
    const unknown = kn.stealthy ? 32 - (6 + 10 * kn.unknownParanoia) * this.params.awareness : 32;
    if (B.conf < 0.12) return unknown;
    const p = B.pos(); const d = dist(p.x, p.y, x, y) / M;
    return d * B.conf + unknown * (1 - B.conf);
  }
  safetyAt(x, y) { return smoothstep(6, 30, this.killerDistAt(x, y)); }
  nearestTile(x, y, maxD) { let best = null, bd = maxD; for (const t of this.m.map.tiles) { if (t.safety < 0.2) continue; const d = dist(t.x, t.y, x, y); if (d < bd) { bd = d; best = t; } } return best; }
  genKnowledge(g) {
    const mem = this.memory.gens.get(g.id), bbk = this.m.bb.knownGen(g);
    let p = mem ? mem.p : 0; if (bbk && Math.random() < this.params.comms && (!mem || bbk.t > mem.t)) p = bbk.p;
    return p;
  }
  trapNear(x, y, r) { for (const t of this.memory.traps.values()) if (t.trap.state === 'set' && dist(t.x, t.y, x, y) < r) return true; return false; }
  trapCells() {
    if (this._trapCellsV === this._trapVersion) return this._trapCells;
    const nav = this.m.map.nav; const set = new Set();
    for (const t of this.memory.traps.values()) {
      if (t.trap.state !== 'set') continue;
      const [c, r] = nav.cellOf(t.x, t.y);
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) set.add((r + dy) * nav.cols + c + dx);
    }
    this._trapCells = set; this._trapCellsV = this._trapVersion; return set;
  }
  // Known danger areas (gas, torment trails, biopod surveillance) as per-cell path costs.
  zoneCells() {
    if (this._zoneCellsV === this._zoneV && this.m.time - (this._zoneBuiltT || 0) < 1) return this._zoneCells;
    const m = this.m, nav = m.map.nav, P = this.params, kn = this.knobs, s = this.sv;
    const map = new Map(); const w = kn.zoneAvoid * (0.25 + 0.75 * P.zoneSense);
    const slip = s.status.has('slipstream');
    const add = (x, y, r, cost) => {
      const [c0, r0] = nav.cellOf(x - r, y - r), [c1, r1] = nav.cellOf(x + r, y + r);
      for (let rr = r0; rr <= r1; rr++) for (let cc = c0; cc <= c1; cc++) { const i = rr * nav.cols + cc; const p = nav.center(i); if ((p.x - x) ** 2 + (p.y - y) ** 2 < r * r) map.set(i, (map.get(i) || 0) + cost); }
    };
    for (const z of this.memory.zones.values()) if (z.until > m.time && z.aiCost > 0) add(z.x, z.y, z.r + 0.4 * M, z.aiCost * w);
    for (const d of this.memory.devices.values()) if (!d.dead && d.dangerRadius && (d.data?.disabledUntil || 0) <= m.time) add(d.x, d.y, d.dangerRadius, (d.kind === 'phantasm' ? d.aiCost : slip ? 6 : 2.5) * w);
    this._zoneCells = map; this._zoneCellsV = this._zoneV; this._zoneBuiltT = m.time; return map;
  }
  agent() {
    const cellCost = this.chase.survivorCellCost(); const P = this.params; const m = this.m; const B = this.belief;
    const kb = B.conf > 0.3 ? B.pos() : null;
    return {
      linkCost: this.chase.survivorLinkCost(),
      cellCost: (i) => {
        let c = cellCost(i);
        // high-level bots route around the killer's believed position
        if (kb && P.difficulty >= 4) { const p = m.map.nav.center(i); const d = dist(p.x, p.y, kb.x, kb.y) / M; if (d < 14) c += (14 - d) * 0.35 * B.conf * (0.4 + 0.6 * P.awareness); }
        return c;
      },
    };
  }

  // -------------------------------------------------------------- movement
  setPath(pts, fromChase = false) {
    const P = this.params;
    if (!fromChase && P.pathNoise > 0.1) for (let i = 1; i < pts.length - 1; i++) if (!pts[i].viaLink && !(pts[i + 1] && pts[i + 1].viaLink)) { pts[i] = { ...pts[i], x: pts[i].x + gauss() * P.pathNoise * M * 0.3, y: pts[i].y + gauss() * P.pathNoise * M * 0.3 }; }
    this.path = pts; this.pathIdx = Math.min(1, pts.length - 1); this.pathT = this.m.time;
  }
  navigateTo(x, y, tol = 0.6 * M) {
    const s = this.sv, m = this.m;
    if (dist(s.x, s.y, x, y) <= tol) { this.path = null; s.moveTo = null; return true; }
    const tgtMoved = !this.pathTarget || dist(this.pathTarget.x, this.pathTarget.y, x, y) > 1.5 * M;
    if (!this.path || tgtMoved || m.time - this.pathT > 3) {
      if (m.pathBudget <= 0) return false;
      m.pathBudget--;
      const r = m.map.nav.findPath(s.x, s.y, x, y, this.agent());
      if (r) { const sm = m.map.nav.smooth(m.world, r.pts, s.r * 0.9); this.setPath(sm); this.pathTarget = { x, y }; }
      else { this.path = [{ x: s.x, y: s.y }, { x, y }]; this.pathIdx = 1; this.pathT = m.time; this.pathTarget = { x, y }; }
    }
    return false;
  }
  followPath(dt) {
    const s = this.sv, m = this.m;
    if (s.busy && !(s.action && s.action.type === 'flashlight')) { s.moveTo = null; return; }
    if (!this.path || this.pathIdx >= this.path.length) { s.moveTo = null; return; }
    let p = this.path[this.pathIdx];
    // Link crossing: vault the window / dropped pallet between previous point and p
    if (p.viaLink) {
      const L = p.viaLink, o = L.ref;
      const near = dist(s.x, s.y, o.x, o.y) < (o.kind === 'window' ? 1.75 : 1.85) * M;
      const crossed = o.sideOf(s) === o.sideOf(p);
      if (crossed) { this.pathIdx++; return; }
      if (near) {
        const can = o.kind === 'window' ? o.blockedUntil <= m.time : o.state === 'down';
        if (can) { s.startVault(o, this.vaultQuality(o), m); this.pathIdx++; return; }
        this.path = null; return; // blocked: replan
      }
      // walk to the near side of the link first
      const side = o.sideOf(s); const sp = o.sides(1.2 * M)[side];
      s.moveTo = sp; return;
    }
    s.moveTo = p;
    if (dist(s.x, s.y, p.x, p.y) < 0.45 * M || (this.pathIdx < this.path.length - 1 && dist(s.x, s.y, p.x, p.y) < 0.9 * M && !this.path[this.pathIdx + 1].viaLink)) this.pathIdx++;
    if (this.pathIdx >= this.path.length) {
      const e = this.path[this.path.length - 1]; const ld = this.chase.lastDir;
      // in a chase, momentum carries on between replans instead of stopping dead
      s.moveTo = (this.inChase || this.evadeUntil > m.time) && ld ? { x: e.x + ld.x * 1.5 * M, y: e.y + ld.y * 1.5 * M } : e;
    }
  }
  vaultQuality(o) {
    const P = this.params, s = this.sv;
    const speed = Math.hypot(s.vx, s.vy);
    const r = Math.random();
    if (speed > 3 * M && r < P.fastVault * (0.75 + 0.35 * this.pers.vaultSkill)) return 'fast';
    if (P.difficulty <= 2 && r > 0.85) return 'slow';
    return 'medium';
  }

  // -------------------------------------------------------------- perception
  perceiveWorld() {
    const s = this.sv, m = this.m, P = this.params;
    const smallGame = s.hasPerk('small_game');
    for (const t of m.traps) {
      if (t.state !== 'set') { if (this.memory.traps.has(t.id) && t.state !== 'set') { this.memory.traps.delete(t.id); this._trapVersion++; } continue; }
      if (this.memory.traps.has(t.id)) continue;
      const d = dist(s.x, s.y, t.x, t.y);
      let r = (t.inGrass ? 2.5 : 7.5) * M * P.trapSense; if (smallGame) r = Math.max(r, 8 * M); if (s.hasPerk('vigilant_eye')) r = Math.max(r, 12 * M);
      if (d < r && m.world.losClear(s.x, s.y, t.x, t.y)) {
        this.memory.traps.set(t.id, { x: t.x, y: t.y, trap: t, t: m.time }); this._trapVersion++;
        if (Math.random() < P.comms) m.bb.reportTrap(t);
        this.note('Spotted a bear trap', 'trapseen');
      }
    }
    // Team-shared trap callouts
    if (Math.random() < P.comms * 0.5) for (const [id, info] of m.bb.traps) if (!this.memory.traps.has(id) && info.trap.state === 'set') { this.memory.traps.set(id, { ...info }); this._trapVersion++; }
    for (const t of m.map.totems) if (!this.memory.totems.has(t.id) && dist(s.x, s.y, t.x, t.y) < (t.hex ? 22 : 12) * M && m.world.losClear(s.x, s.y, t.x, t.y)) this.memory.totems.set(t.id, { totem: t, t: m.time });
    for (const g of m.map.gens) if (dist(s.x, s.y, g.x, g.y) < 18 * M) { this.memory.gens.set(g.id, { p: g.progress, t: m.time }); if (g.repairers.has(s)) m.bb.reportGen(g); }
    const h = m.map.hatch; if (h.state !== 'hidden' && dist(s.x, s.y, h.x, h.y) < 24 * M) this.memory.hatchSeen = true;
    // Killer-power objects: gas clouds, torment trails, pods, printers, lockers.
    const vig = s.hasPerk('vigilant_eye') ? 12 * M : 0;
    for (const z of m.zones) {
      if (this.memory.zones.has(z.id)) continue;
      if (dist(s.x, s.y, z.x, z.y) < vig || dist(s.x, s.y, z.x, z.y) < z.seenRange && (dist(s.x, s.y, z.x, z.y) < 6 * M || m.world.losClear(s.x, s.y, z.x, z.y))) { this.memory.zones.set(z.id, z); this._zoneV++; }
    }
    for (const [id, z] of this.memory.zones) if (z.until <= m.time) { this.memory.zones.delete(id); this._zoneV++; }
    for (const d of m.devices) {
      if (this.memory.devices.has(d.id)) continue;
      if (d.kind === 'printer' || dist(s.x, s.y, d.x, d.y) < vig || (dist(s.x, s.y, d.x, d.y) < d.seenRange && m.world.losClear(s.x, s.y, d.x, d.y))) {
        this.memory.devices.set(d.id, d); this._zoneV++;
        if (d.kind === 'biopod') { this.note('Spotted a biopod', 'pod'); if (Math.random() < P.comms) for (const o of m.survivors) if (o.ai && o !== s) { o.ai.memory.devices.set(d.id, d); o.ai._zoneV++; } }
      }
    }
    for (const [id, d] of this.memory.devices) if (d.dead) { this.memory.devices.delete(id); this._zoneV++; }
    // Killer minions (the dog, guards): tracked separately from the killer, by sight only.
    const sight = (s.status.mods().sightMult ?? 1);
    for (const n of m.minions) {
      const d = dist(s.x, s.y, n.x, n.y);
      if (d < n.visRange * sight && m.world.losClear(s.x, s.y, n.x, n.y)) {
        if (!this.memory.minions.has(n.id)) this.note(`Spotted the ${n.label}`, 'minion-' + n.kind);
        this.memory.minions.set(n.id, { n, x: n.x, y: n.y, t: m.time });
      }
    }
    for (const [id, e] of this.memory.minions) if (e.n.dead || m.time - e.t > 6) this.memory.minions.delete(id);
  }

  computeThreat() {
    const B = this.belief, s = this.sv, m = this.m, P = this.params;
    const kp = B.pos(); const kd = dist(s.x, s.y, kp.x, kp.y) / M;
    let th = B.conf * (1 - smoothstep(4, 30, kd));
    if (B.approach > 0.6 * M) th += 0.2 * B.conf;
    th += B.heartbeat * P.threatSense * 0.55 * (B.observing ? 0 : 1);
    if (B.spineChill) th += 0.3;
    if (m.time - B.bellT < 2 && B.bellKind === 'uncloak' && kd < 16) th += 0.5;
    if (m.time - B.revvingT < 1 && kd < 22) th += 0.35;
    if (m.time - (B.teleportT || -99) < 2 && kd < 18) th += 0.6;
    if (s.status.has('marked')) th += 0.15;
    for (const e of this.memory.minions.values()) { const n = e.n; if (n.target === s && ['hunt', 'pursue', 'spotted'].includes(n.state)) th += 0.45 * (1 - smoothstep(4, 18, dist(n.x, n.y, s.x, s.y) / M)); }
    if (s.status.has('nightfall')) th += 0.1;
    this.threat = clamp(th, 0, 1);
    // chase state with hysteresis
    const seenRecently = B.observing || B.age < 2.5;
    const hitRecently = m.time - s.lastHitT < 6;
    const close = kd < 10 + 6 * this.pers.killerAwareness;
    const coming = B.approach > 0.3 * M || kd < 6;
    if (!this.inChase) {
      if ((seenRecently && close && coming && B.conf > 0.5) || (hitRecently && B.conf > 0.3) || (m.time - B.bellT < 1.5 && B.bellKind === 'uncloak' && kd < 12)) {
        this.inChase = true; this.chaseSince = m.time; this.lostT = 0; this.sv.stopAction(m); m.bb.reportChase(s);
      }
    } else {
      if (!B.observing && kd > 14) this.lostT += 1 / P.tacticalHz; else this.lostT = 0;
      if (this.lostT > 3 + 2 * this.pers.killerAwareness || kd > 30 || B.conf < 0.2) { this.inChase = false; this.note(kd > 25 ? 'Broke the chase' : 'Lost the killer', 'lost'); }
      else m.bb.reportChase(s);
    }
  }

  // -------------------------------------------------------------- behavior tree
  buildTree() {
    const ai = this;
    return new Selector('Root', [
      Branch('Spectate', () => !ai.sv.alive, () => { ai.state = 'SPECTATING'; return R; }),
      Branch('Hook', () => ai.sv.health === 'hooked', () => ai.hookBehavior()),
      Branch('Carried', () => ai.sv.health === 'carried', () => { ai.state = 'DOWNED'; return R; }),
      Branch('Downed', () => ai.sv.health === 'dying', () => ai.downedBehavior()),
      Branch('Trapped', () => !!ai.sv.trap, () => ai.trappedBehavior()),
      Branch('Forced', () => !!ai.forced, () => ai.forcedBehavior()),
      Branch('BeingHealed', () => ai.beingHealed() && ai.threat < 0.55 && !ai.inChase, () => { ai.state = 'RECOVERING'; ai.sv.moveTo = null; ai.path = null; return R; }),
      Branch('Chase', () => ai.inChase, () => ai.chaseBehavior()),
      Branch('Evade', () => ai.shouldEvade(), () => ai.evadeBehavior()),
      Branch('Mend', () => ai.sv.status.has('deepWound') && ai.threat < 0.4, () => { ai.state = 'RECOVERING'; ai.sv.startAction('mend', null, ai.m); return R; }),
      new Act('Goal', () => ai.executeGoal()),
    ]);
  }
  beingHealed() { const s = this.sv; return this.m.survivors.some((o) => o !== s && o.action?.type === 'heal' && o.action.target === s); }

  shouldEvade() {
    const P = this.params, m = this.m;
    if (this.evadeUntil > m.time) return true;
    const thr = 0.62 - 0.22 * this.pers.riskTolerance + (this.sv.action?.type === 'repair' ? 0.05 : 0);
    if (this.threat > thr) { this.evadeUntil = m.time + 2.5; this.evadeMode = null; return true; }
    return false;
  }

  hookBehavior() {
    const s = this.sv, m = this.m, P = this.params;
    this.state = 'HOOKED'; s.moveTo = null; this.path = null;
    if (s.hookStage === 1) {
      const dl = s.perk('deliverance');
      if (dl && dl.tokens > 0 && s.hookTimer > 3) { dl.tokens = 0; m.selfUnhook(s, true); this.note('Self-unhooked with Deliverance', 'deliv'); return R; }
      const others = m.survivors.filter((o) => o !== s && o.alive && o.standing);
      const hopeless = others.length === 0 || (m.collapse && m.collapseT < 25);
      if ((hopeless || (this.pers.selfishness > 0.75 && P.difficulty <= 3)) && s.unhookAttempts < 3 && s.hookTimer > 5 + s.unhookAttempts * 8) { m.selfUnhookAttempt(s); }
    }
    return R;
  }

  downedBehavior() {
    const s = this.sv, m = this.m, B = this.belief, P = this.params;
    this.state = 'DOWNED';
    const healer = m.survivors.find((o) => o !== s && o.action?.type === 'heal' && o.action.target === s);
    const coming = m.bb.claimedBy('HEAL:' + s.id);
    if (healer || (coming && dist(coming.x, coming.y, s.x, s.y) < 5 * M)) { s.moveTo = null; this.path = null; s.stopAction(m); return R; }
    const kd = this.killerDistAt(s.x, s.y);
    const canFull = s.hasPerk('unbreakable') && !s.unbreakableUsed;
    if ((kd > 22 || B.conf < 0.2) && (canFull || s.recovery < 0.95)) {
      if (!coming || canFull) { s.startAction('recover', null, m); if (canFull && s.recovery > 0.9) this.note('Picked themselves up (Unbreakable)', 'unb'); return R; }
    }
    if (s.action?.type === 'recover') s.stopAction(m);
    // crawl: away from the killer, toward healthy teammates / cover
    if (!this._crawlT || m.time - this._crawlT > 1.5) {
      this._crawlT = m.time;
      let tx = s.x, ty = s.y;
      const mates = m.survivors.filter((o) => o !== s && o.standing);
      if (mates.length && P.difficulty >= 4) { const o = mates.sort((a, b) => dist(a.x, a.y, s.x, s.y) - dist(b.x, b.y, s.x, s.y))[0]; tx = o.x; ty = o.y; }
      if (B.conf > 0.2) { const kp = B.pos(); const ax = s.x - kp.x, ay = s.y - kp.y; const l = Math.hypot(ax, ay) || 1; tx = (tx + s.x + ax / l * 10 * M) / 2; ty = (ty + s.y + ay / l * 10 * M) / 2; }
      this._crawlTarget = { x: tx, y: ty };
    }
    if (this._crawlTarget) this.navigateTo(this._crawlTarget.x, this._crawlTarget.y, 1.5 * M);
    return R;
  }

  trappedBehavior() {
    const s = this.sv, m = this.m; this.state = 'RECOVERING';
    const freer = m.survivors.find((o) => o !== s && o.action?.type === 'freeTrapped' && o.action.target === s);
    if (!freer && !s.action) s.startAction('escapeTrap', null, m);
    return R;
  }

  forcedBehavior() {
    // Debug "force state": temporarily pins a behavior
    const f = this.forced; const m = this.m;
    if (f.until < m.time) { this.forced = null; return F; }
    if (f.state === 'HIDING') return this.hide(true);
    if (f.state === 'CHASE') { this.state = 'CHASE'; this.chase.tick(true); return R; }
    if (f.state === 'REPAIRING_GENERATOR') { const g = m.map.gens.filter((g) => !g.done).sort((a, b) => dist(a.x, a.y, this.sv.x, this.sv.y) - dist(b.x, b.y, this.sv.x, this.sv.y))[0]; if (g) return this.doRepair(g); }
    if (f.state === 'IDLE') { this.state = 'IDLE'; this.sv.moveTo = null; this.path = null; return R; }
    this.forced = null; return F;
  }

  chaseBehavior() {
    const s = this.sv, m = this.m;
    this.sv.moveMode = 'run';
    if (s.action && s.action.type !== 'dropPallet') s.stopAction(m);
    const tile = m.map.tileAt(s.x, s.y);
    this.state = s.vault ? 'VAULTING' : s.action?.type === 'dropPallet' ? 'USING_PALLET' : tile && tile.safety > 0.25 ? 'LOOPING' : 'CHASE';
    if (!this._chaseNoteT && this.params.difficulty >= 7 && m.bb.activeGens(s).length) { this._chaseNoteT = 1; }
    this.chase.tick(true);
    if (this.chase.debug.nextTile && this.params.leadAway > 0.5 && m.bb.activeGens(s).length && Math.random() < 0.02) this.note('Leading the killer away from a teammate\'s generator', 'leadaway');
    s.stats.chaseTime += 1 / this.params.tacticalHz;
    return R;
  }

  evadeBehavior() {
    const s = this.sv, m = this.m, P = this.params, B = this.belief, pers = this.pers;
    if (s.action && s.action.type !== 'dropPallet') {
      if (s.action.type === 'repair' && this.threat > 0.5) this.note(B.state === INFO.HEARD ? 'Left the generator on the heartbeat' : 'Stopped repairing — killer approaching', 'leavegen');
      s.stopAction(m);
    }
    if (!this.evadeMode || m.time > this.evadeDecideT) {
      // Hide when stealthy, uninjured (no blood/grunts) and the killer has not seen us; else pre-run to a tile.
      const kp = B.pos(); const seen = B.observing && m.world.losClear(kp.x, kp.y, s.x, s.y) && dist(kp.x, kp.y, s.x, s.y) < 18 * M;
      const hideScore = (pers.stealthSkill * P.stealth * (s.health === 'healthy' ? 1 : 0.5) + this.knobs.hideBias + this.perkBrain.bias.hide) * (seen ? 0.25 : 1) * (this.fk.power.id === 'cloak' ? 0.7 : 1);
      const runScore = (1 - pers.stealthSkill * 0.6) * (0.4 + pers.riskTolerance * 0.6) * (seen ? 1.6 : 0.8);
      this.evadeMode = hideScore > runScore ? 'hide' : 'run'; this.evadeDecideT = m.time + 2.5;
      this.hideSpot = null;
    }
    if (this.evadeMode === 'hide') return this.hide(false);
    this.state = 'FLEEING'; s.moveMode = 'run';
    // Pre-run: skilled survivors head for a strong tile before the killer arrives,
    // so the chase starts where they can loop instead of in the open.
    const kp = B.pos(); const kd = dist(kp.x, kp.y, s.x, s.y) / M;
    if (P.difficulty >= 5 && kd > 9 && B.conf > 0.3) {
      if (!this.preTile || m.time - this.preTileT > 2) { this.preTile = this.chase.chooseNextTile(kp); this.preTileT = m.time; }
      const t = this.preTile;
      if (t) {
        const ax = t.x - kp.x, ay = t.y - kp.y; const l = Math.hypot(ax, ay) || 1;
        const spot = { x: t.x + ax / l * Math.min(t.radius * 0.5, 3 * M), y: t.y + ay / l * Math.min(t.radius * 0.5, 3 * M) };
        const i = m.map.nav.nearestOpen(spot.x, spot.y, 4); const c = i >= 0 ? m.map.nav.center(i) : spot;
        if (!this._preNote) { this._preNote = true; this.note(`Pre-running to the ${t.label.toLowerCase()}`, 'prerun'); }
        if (this.navigateTo(c.x, c.y, 1.2 * M)) { s.moveTo = null; this.path = null; }
        // keep evading while the killer keeps coming
        if (B.approach > 0.2 * M && kd < 30) this.evadeUntil = Math.max(this.evadeUntil, m.time + 1.5);
        return R;
      }
    }
    this._preNote = false;
    this.chase.tick(false);
    return R;
  }

  hide(forced) {
    const s = this.sv, m = this.m, B = this.belief, nav = m.map.nav;
    this.state = 'HIDING';
    const kp = B.conf > 0.15 ? B.pos() : (m.bb.sighting ? { x: m.bb.sighting.x, y: m.bb.sighting.y } : { x: s.x + 1, y: s.y });
    if (!this.hideSpot || (m.time - this.hideSpotT > 3)) {
      let best = null, bs = -1e9;
      for (let k = 0; k < 40; k++) {
        const a = Math.random() * Math.PI * 2, r = (2 + Math.random() * 12) * M;
        const x = s.x + Math.cos(a) * r, y = s.y + Math.sin(a) * r; const i = nav.idxAt(x, y); if (nav.isBlocked(i)) continue;
        const c = nav.center(i);
        let sc = 0; if (!m.world.losClear(kp.x, kp.y, c.x, c.y)) sc += 4; if (nav.grass[i]) sc += 2.5;
        sc += dist(c.x, c.y, kp.x, kp.y) / M * 0.15 - r / M * 0.12;
        if (this.trapCells().has(i)) sc -= 20;
        if (sc > bs) { bs = sc; best = c; }
      }
      this.hideSpot = best; this.hideSpotT = m.time;
    }
    if (this.hideSpot) {
      const arrived = this.navigateTo(this.hideSpot.x, this.hideSpot.y, 0.5 * M);
      s.moveMode = arrived || dist(s.x, s.y, kp.x, kp.y) < 14 * M ? 'crouch' : 'walk';
    }
    // If the killer clearly sees us up close, give up hiding and run.
    if (!forced && B.observing && dist(B.x, B.y, s.x, s.y) < 9 * M && m.world.losClear(B.x, B.y, s.x, s.y)) { this.evadeMode = 'run'; this.evadeDecideT = m.time + 3; }
    return R;
  }

  // -------------------------------------------------------------- goals
  strategic() {
    const opts = evaluateGoals(this); this.options = opts;
    const pick = chooseGoal(this, opts);
    if (!pick) return;
    if (!this.goal || pick.key !== this.goal.key) {
      if (this.goal) this.m.bb.release(this.sv);
      this.goal = pick; this.goalCommitUntil = this.m.time + 2.5 + this.pers.objectiveFocus;
      if (['REPAIR', 'RESCUE', 'HEAL', 'OPEN_GATE', 'DEVICE', 'BURN_TRAP'].includes(pick.type)) this.m.bb.claim(pick.key, this.sv);
      this.waitSpot = null;
      if (pick.mistake) this.note('Made a questionable call: ' + pick.type.toLowerCase(), 'mistake');
    } else { this.goal.score = pick.score; this.goal.why = pick.why; this.m.bb.refreshClaim(this.sv, this.goal.key); }
  }

  executeGoal() {
    const g = this.goal, s = this.sv, m = this.m; s.moveMode = 'run';
    if (!g) { this.state = 'IDLE'; return R; }
    this.state = GOAL_STATE[g.type] || 'IDLE';
    const t = g.target;
    // Switching goals mid-action (e.g. leaving a generator to lock a locker): let go of the old action.
    const want = GOAL_ACTION[g.type];
    if (want !== undefined && s.action && !KEEP_ACTIONS.has(s.action.type) && (s.action.type !== want || (s.action.target && t && s.action.target !== t && want !== 'unhook'))) s.stopAction(m);
    switch (g.type) {
      case 'REPAIR': return this.doRepair(t);
      case 'RESCUE': return this.doRescue(t);
      case 'HEAL': if (t.health !== 'injured' && t.health !== 'dying') { this.goal = null; return S; }
        if (this.navigateTo(t.x, t.y, 1.4 * M) || dist(s.x, s.y, t.x, t.y) < 1.6 * M) s.startAction('heal', t, m); return R;
      case 'BE_HEALED': if (dist(s.x, s.y, t.x, t.y) > 1.5 * M) this.navigateTo(t.x, t.y, 1.2 * M); else { s.moveTo = null; this.path = null; } return R;
      case 'HEAL_SELF': if (!s.action) s.startAction('healSelf', null, m); return R;
      case 'CLEANSE': if (this.navigateTo(t.x, t.y, 1.2 * M)) s.startAction('cleanse', t, m); return R;
      case 'CHEST': if (this.navigateTo(t.x, t.y, 1.2 * M)) s.startAction('searchChest', t, m); return R;
      case 'DISARM': if (t.state !== 'set') { this.goal = null; return S; } if (this.navigateTo(t.x, t.y, 1.1 * M)) s.startAction('disarm', t, m); return R;
      case 'FREE': if (!t.trap) { this.goal = null; return S; } if (this.navigateTo(t.x, t.y, 1.2 * M)) s.startAction('freeTrapped', t, m); return R;
      case 'OPEN_GATE': if (t.open) { this.goal = null; return S; } if (this.navigateTo(t.x, t.y, 1.0 * M)) s.startAction('openGate', t, m); return R;
      case 'ESCAPE': { const e = t.exitRect; this.navigateTo(e.x + e.w / 2, e.y + e.h / 2, 0.3 * M); return R; }
      case 'HATCH': case 'KEY_HATCH': if (this.navigateTo(t.x, t.y, 0.8 * M)) { if (t.state === 'open') m.escapeHatch(s); else s.startAction('openHatch', t, m); } return R;
      case 'PROTECT': { const kp = this.belief.pos(); const ax = kp.x - t.x, ay = kp.y - t.y; const l = Math.hypot(ax, ay) || 1; this.navigateTo(t.x + ax / l * 1.4 * M, t.y + ay / l * 1.4 * M, 0.5 * M); return R; }
      case 'FLASHLIGHT': return this.doFlashlight();
      case 'DEVICE': if (t.dead || !t.usable(s, m)) { this.goal = null; return S; } if (s.action?.type === 'device') return R; if (this.navigateTo(t.x, t.y, 1.2 * M)) s.startAction('device', t, m); return R;
      case 'BURN_TRAP': {
        if (t.dead || !s.item || s.item.charges <= 0) { this.goal = null; return S; }
        if (dist(s.x, s.y, t.x, t.y) < 5 * M && m.world.losClear(s.x, s.y, t.x, t.y)) { s.moveTo = null; this.path = null; s.facing = Math.atan2(t.y - s.y, t.x - s.x); if (s.action?.type !== 'flashlight') s.startAction('flashlight', t, m); return R; }
        this.navigateTo(t.x, t.y, 4 * M); return R;
      }
      case 'USE_EMP': if (!s.emp || t.dead) { this.goal = null; return S; } if (this.navigateTo(t.x, t.y, 3 * M)) { s.startAction('useEmp', null, m); this.goal = null; } return R;
      case 'PRINT_EMP': if (t.dead || !t.usable(s, m)) { this.goal = null; return S; } if (s.action?.type === 'device') return R; if (this.navigateTo(t.x, t.y, 1.2 * M)) s.startAction('device', t, m); return R;
      case 'FOLLOW_CARRY': { const k = m.carrier(t) || this.fk; if (!k.carrying) { this.goal = null; return S; } this.navigateTo(k.x - Math.cos(k.facing) * 3 * M, k.y - Math.sin(k.facing) * 3 * M, 1 * M); return R; }
      case 'PATROL': default: return this.doPatrol();
    }
  }

  doRepair(gen) {
    const s = this.sv, m = this.m, P = this.params, B = this.belief;
    if (gen.done || gen.blockedUntil > m.time) { this.goal = null; return S; }
    if (s.action?.type === 'repair' && s.action.target === gen) {
      this.state = 'REPAIRING_GENERATOR';
      // Predictive early leave: estimate killer ETA from the belief, not true position.
      // Heartbeat-only cue: distance shrinking fast and already close.
      if (!B.dirKnown && B.heardDist !== null && P.leavesEarly) {
        const closing = B.hbClosing(); const eta = Math.max(0, B.heardDist / M - 3) / 4.6;
        if (closing > 2.2 && eta < P.leaveAhead * 0.7 * (1.25 - 0.5 * this.pers.riskTolerance) && gen.progress < 0.92) {
          s.stopAction(m); this.evadeUntil = m.time + 3; this.evadeMode = null;
          this.note('Heartbeat rising fast — left the generator', 'hbleave'); return R;
        }
      }
      if (P.leavesEarly && B.conf > 0.3 && B.dirKnown) {
        const kp = B.pos(); const kd = dist(kp.x, kp.y, gen.x, gen.y) / M;
        const eta = Math.max(0, kd - 3) / 4.6;
        const approaching = B.approach > 0.4 * M || (B.observing && angleDiff(Math.atan2(B.vy, B.vx), Math.atan2(gen.y - B.y, gen.x - B.x)) < 0.6 && Math.hypot(B.vx, B.vy) > 2 * M);
        const thresh = P.leaveAhead * this.knobs.leaveEarly * (s.status.has('marked') ? 1.4 : 1) * (1.25 - 0.5 * this.pers.riskTolerance) * (gen.progress > 0.9 ? 0.4 : 1);
        if (approaching && eta < thresh) {
          s.stopAction(m); this.evadeUntil = m.time + 3; this.evadeMode = null;
          this.note(`Stopped repairing — predicted the killer in ${eta.toFixed(1)}s`, 'predictleave');
          return R;
        }
      }
      return R;
    }
    this.state = 'REPAIRING_GENERATOR';
    // pick a slot not occupied, preferring one facing away from the believed killer
    if (!this._slot || this._slotGen !== gen || m.time - this._slotT > 4) {
      const occ = [...gen.repairers].map((o) => ({ x: o.x, y: o.y }));
      const kp = B.conf > 0.2 ? B.pos() : null;
      const slots = gen.slots().filter((p) => !occ.some((o) => dist(o.x, o.y, p.x, p.y) < 0.8 * M));
      slots.sort((a, b) => (dist(a.x, a.y, s.x, s.y) - (kp ? dist(a.x, a.y, kp.x, kp.y) * 0.3 : 0)) - (dist(b.x, b.y, s.x, s.y) - (kp ? dist(b.x, b.y, kp.x, kp.y) * 0.3 : 0)));
      this._slot = slots[0] || gen.slots()[0]; this._slotGen = gen; this._slotT = m.time;
    }
    const arrived = this.navigateTo(this._slot.x, this._slot.y, 0.4 * M) || dist(s.x, s.y, gen.x, gen.y) < 1.9 * M;
    if (arrived) { s.moveTo = null; this.path = null; if (!s.startAction('repair', gen, m)) this._slot = null; }
    return R;
  }

  doRescue(o) {
    const s = this.sv, m = this.m, P = this.params, B = this.belief;
    if (o.health !== 'hooked') { this.goal = null; return S; }
    const left = m.hookStageTime - o.hookTimer; const d = dist(s.x, s.y, o.x, o.y) / M;
    const kh = this.killerDistAt(o.x, o.y);
    const camping = B.conf > 0.3 && kh < 14;
    if (camping && P.waitsForCamper && left > d / 4 + 10 && !(o.hookStage >= 2 && left < 20)) {
      this.state = 'GOING_TO_HOOK';
      if (!this.waitSpot) {
        const kp = B.pos(); const ax = o.x - kp.x, ay = o.y - kp.y; const l = Math.hypot(ax, ay) || 1;
        this.waitSpot = { x: o.x + ax / l * 20 * M, y: o.y + ay / l * 20 * M };
        this.note('Waiting for the killer to leave the hook', 'waitcamp');
        m.bb.model.camping += 0.2;
      }
      const arrived = this.navigateTo(this.waitSpot.x, this.waitSpot.y, 2 * M);
      s.moveMode = arrived ? 'crouch' : 'walk';
      return R;
    }
    this.waitSpot = null; this.state = 'RESCUING';
    if (this.navigateTo(o.x, o.y, 1.3 * M) || dist(s.x, s.y, o.x, o.y) < 1.7 * M) s.startAction('unhook', o, m);
    return R;
  }

  doFlashlight() {
    const s = this.sv, m = this.m, k = this.fk;
    const target = k.carrying || (k.action?.type === 'pickup' ? k.action.target : null);
    if (!target || !s.item || s.item.charges <= 0) { this.goal = null; return S; }
    this.state = 'HELPING_TEAMMATE';
    const spot = { x: k.x + Math.cos(k.facing) * 4 * M, y: k.y + Math.sin(k.facing) * 4 * M };
    if (dist(s.x, s.y, k.x, k.y) < 6.5 * M) { s.facing = Math.atan2(k.y - s.y, k.x - s.x); if (!s.action) s.startAction('flashlight', k, m); this.navigateTo(spot.x, spot.y, 1 * M); }
    else this.navigateTo(spot.x, spot.y, 1 * M);
    return R;
  }

  doPatrol() {
    const s = this.sv, m = this.m;
    this.state = 'PATROLLING';
    if (!this._patrol || dist(s.x, s.y, this._patrol.x, this._patrol.y) < 2 * M || m.time - this._patrolT > 15) {
      const gens = m.map.gens.filter((g) => !g.done);
      const pick = gens.length ? gens[Math.floor(Math.random() * gens.length)] : m.map.gates[0] || m.map.tiles[Math.floor(Math.random() * m.map.tiles.length)] || { x: s.x, y: s.y };
      this._patrol = { x: pick.x + (Math.random() - 0.5) * 6 * M, y: pick.y + (Math.random() - 0.5) * 6 * M }; this._patrolT = m.time;
    }
    this.navigateTo(this._patrol.x, this._patrol.y, 1.5 * M);
    return R;
  }

  // -------------------------------------------------------------- main update
  update(dt) {
    const m = this.m, s = this.sv;
    if (m.aiPaused) { s.moveTo = null; return; }
    if (!s.alive) { this.state = 'SPECTATING'; return; }
    this.pT -= dt;
    if (this.pT <= 0) { const step = 0.1 - this.pT; this.pT = 0.1; for (const b of this.beliefs.values()) b.update(step, m); if (this.beliefs.size > 1) this.pickFocus(); this.perceiveWorld(); }
    this.sT -= dt;
    if (this.sT <= 0) { this.sT = this.params.strategicEvery * (0.8 + Math.random() * 0.4); if (s.standing) this.strategic(); }
    this.tT -= dt;
    if (this.tT <= 0) {
      this.tT = 1 / (this.params.tacticalHz * (m.thinkScale || 1));
      this.computeThreat();
      // Killer-specific reactions (reveal Ghost Face, dodge hatchets, side-step waves, EMP pods…)
      const dk = this.profile.dynKnobs?.(this); this.knobs = dk ? { ...this.profile.knobs, ...dk } : this.profile.knobs;
      const tk = this.profile.tactical?.(this) || (m.projectiles.length && this.profile !== undefined ? dodgeProjectiles(this) : null);
      if (tk && this.chase.sidestepUntil > m.time) this._overrideUntil = this.chase.sidestepUntil;
      this.perkBrain.tick();
      if (m.time >= this._overrideUntil) { this.trace = []; this.tree.tick({ trace: this.trace, ai: this }); }
      else this.trace = ['Root', 'Counterplay', tk || 'dodge'];
      if (this.crouchUntil > m.time && s.standing && !s.vault) s.moveMode = 'crouch';
      // Stuck detection → replan
      if (s.moveTo && !s.busy) {
        if (dist(s.x, s.y, this.lastPos.x, this.lastPos.y) < 0.15 * M) { this.stuckT += this.tT; if (this.stuckT > 0.8) { this.path = null; this.stuckT = 0; this._slot = null; } }
        else this.stuckT = 0;
      }
      this.lastPos = { x: s.x, y: s.y };
    }
    this.followPath(dt);
  }
}
