// Per-survivor perception and belief about ONE killer (2v8 gives each survivor a belief per
// killer). Survivors never read a killer's true position unless they could perceive it.
import { M, dist, clamp, gauss, angleDiff, normAngle } from '../core/util.js';

export const INFO = { VISIBLE: 'VISIBLE', RECENT: 'RECENTLY_SEEN', HEARD: 'HEARD', PREDICTED: 'PREDICTED', UNKNOWN: 'UNKNOWN' };

export class KillerBelief {
  constructor(ai, k) {
    this.ai = ai; this.k = k;
    this.x = 0; this.y = 0; this.vx = 0; this.vy = 0; this.facing = 0; this.t = -999; this.conf = 0; this.state = INFO.UNKNOWN;
    this.rawVisible = false; this.noticeAt = 0; this.observing = false; this.heardDist = null; this.heartbeat = 0;
    this.lastHeading = null; this.headingT = 0; this.mindgameT = -999; this.standT = -999;
    this.revvingT = -999; this.sprintT = -999; this.bellT = -999; this.bellKind = null; this.cloakSeenT = -999;
    this.lastSoundT = 0; this.lastSighting = null; this.dirKnown = false; this.hbHist = []; this.spineChill = false; this.approach = 0; this._prevD = null;
    this.powerState = null; this.attacking = false; this.carrying = false; this.actionType = null;
  }
  get age() { return this.ai.m.time - this.t; }
  pos(lead = 0) {
    const a = Math.min(this.age, 2.5) + lead;
    const k = this.observing ? lead : a;
    return { x: this.x + this.vx * k * 0.85, y: this.y + this.vy * k * 0.85 };
  }
  known(minConf = 0.15) { return this.conf >= minConf; }
  // m/s the heartbeat distance is shrinking (distance-only cue, no direction)
  hbClosing() { const h = this.hbHist; if (h.length < 4) return 0; const a = h[0], b = h[h.length - 1]; return (a.d - b.d) / Math.max(0.3, b.t - a.t) / M; }

  observe(k, m, how = INFO.VISIBLE, conf = 1) {
    this.x = k.x; this.y = k.y; this.vx = k.vx; this.vy = k.vy; this.facing = k.facing; this.t = m.time; this.conf = conf; this.state = how; this.dirKnown = true;
    this.powerState = k.power.state ?? null; this.attacking = k.attack.state === 'lunge'; this.carrying = !!k.carrying; this.actionType = k.action?.type ?? null;
  }

  update(dt, m) {
    const ai = this.ai, s = ai.sv, k = this.k, P = ai.params, pers = ai.pers;
    const d = dist(s.x, s.y, k.x, k.y);
    this.observing = false;
    // --- vision ----------------------------------------------------------
    let visible = false;
    const sight = 46 * M * (s.status.mods().sightMult ?? 1);
    if (d < sight && !k.hidden && m.world.losClear(s.x, s.y, k.x, k.y)) {
      const pw = k.power;
      if (pw.id === 'cloak' && pw.state === 'cloaked') {
        const shimmer = (4 + 10 * P.awareness * (0.6 + 0.4 * pers.killerAwareness)) * M * (k.lastSpeed > 2 * M ? 1 : 0.6);
        visible = d < shimmer; if (visible) this.cloakSeenT = m.time;
      } else {
        // some powers (Ghost Face's shroud) shrink how far away a survivor can pick the killer out
        const vis = pw.visibilityTo?.(s, m) ?? 1;
        visible = (vis >= 1 && d < sight) || d < sight * vis * (0.65 + 0.35 * P.awareness) * (0.8 + 0.4 * pers.killerAwareness);
      }
      if (k.blindHidden) visible = false;
    }
    if (visible) {
      if (!this.rawVisible) {
        // Reaction delay — longer if the killer appears behind the survivor.
        const behind = angleDiff(Math.atan2(k.y - s.y, k.x - s.x), s.facing) > 1.9 ? 0.35 : 0;
        this.noticeAt = m.time + P.reaction * (1.25 - 0.45 * pers.killerAwareness) + behind * (1 - P.awareness);
        this.rawVisible = true;
      }
      if (m.time >= this.noticeAt) {
        this.detectMindgame(k, m, d);
        this.observe(k, m); this.observing = true;
        if (this.lastSighting === null || m.time - this.lastSighting > 0.5) { m.bb.report(s, k.x, k.y, k.vx, k.vy, k); this.lastSighting = m.time; }
      }
    } else this.rawVisible = false;

    // --- perk / aura information -----------------------------------------
    if (!this.observing) {
      if (m.killerRevealedTo(s, k)) { this.observe(k, m, INFO.VISIBLE, 0.95); this.observing = true; }
      else {
        // Kindred: a hooked teammate with Kindred shows the killer near the hook
        for (const o of m.survivors) if (o !== s && o.health === 'hooked' && o.hasPerk('kindred') && !s.status.has('blindness') && o.hook && dist(k.x, k.y, o.hook.x, o.hook.y) < 16 * M) { this.observe(k, m, INFO.VISIBLE, 0.9); this.observing = true; break; }
      }
    }
    // --- decay ------------------------------------------------------------
    if (!this.observing) {
      this.conf *= Math.exp(-dt / (P.memoryTau * (0.7 + 0.6 * pers.killerAwareness)));
      this.state = this.conf < 0.12 ? INFO.UNKNOWN : this.age < 2 ? INFO.RECENT : INFO.PREDICTED;
    }
    // --- terror radius (heartbeat): distance without direction -----------
    const mods = k.status.mods();
    this.heartbeat = 0; this.heardDist = null;
    if (!mods.undetectable && !s.status.has('oblivious') && d < k.terrorRadius) {
      this.heartbeat = 1 - d / k.terrorRadius;
      this.heardDist = d * (1 + gauss() * 0.12 * (1 - P.awareness));
      this.hbHist.push({ t: m.time, d: this.heardDist }); while (this.hbHist.length && m.time - this.hbHist[0].t > 2) this.hbHist.shift();
      if (!this.observing) {
        const p = this.pos();
        let dir;
        if (this.conf > 0.15) dir = Math.atan2(p.y - s.y, p.x - s.x);
        else if (m.bb.sightingOf(k) && Math.random() < P.comms) { const sg = m.bb.sightingOf(k); dir = Math.atan2(sg.y - s.y, sg.x - s.x); }
        else dir = this._hbDir ?? (this._hbDir = Math.random() * Math.PI * 2);
        const hd = this.heardDist;
        this.x = s.x + Math.cos(dir) * hd; this.y = s.y + Math.sin(dir) * hd; if (this.conf < 0.12) { this.vx = this.vy = 0; }
        this.dirKnown = this.dirKnown && this.age < 4;
        this.t = m.time; this.conf = Math.max(this.conf, 0.3 + 0.25 * P.threatSense); this.state = INFO.HEARD;
      }
    } else { this._hbDir = null; this.hbHist.length = 0; }
    // --- world sounds -------------------------------------------------------
    for (const snd of m.sounds) {
      if (snd.t <= this.lastSoundT || (snd.src && snd.src !== k)) continue;
      const sd = dist(s.x, s.y, snd.x, snd.y); if (sd > snd.radius) continue;
      const err = (1 - P.awareness) * 0.25 * sd;
      const ex = snd.x + gauss() * err, ey = snd.y + gauss() * err;
      if (snd.type === 'chainsaw_rev' || snd.type === 'chainsaw_sprint') {
        this.revvingT = m.time; if (snd.type === 'chainsaw_sprint') this.sprintT = m.time;
        if (!this.observing) { this.x = ex; this.y = ey; this.t = m.time; this.conf = Math.max(this.conf, 0.7); this.state = INFO.HEARD; this.dirKnown = true; }
        m.bb.model.chainsawUses += 0.02;
      } else if (snd.type === 'wraith_bell') {
        this.bellT = m.time; this.bellKind = snd.data.kind;
        if (!this.observing) { this.x = ex; this.y = ey; this.vx = this.vy = 0; this.t = m.time; this.conf = Math.max(this.conf, 0.75); this.state = INFO.HEARD; this.dirKnown = true; }
        m.bb.model.cloaks += 0.5;
      } else if (snd.type === 'teleport_warn') {
        // the Singularity is about to appear at this pod
        this.x = snd.x; this.y = snd.y; this.vx = this.vy = 0; this.t = m.time; this.conf = Math.max(this.conf, 0.85); this.state = INFO.HEARD; this.dirKnown = true; this.teleportT = m.time;
        if (sd < 16 * M) ai.note('Heard a biopod hum — teleport incoming', 'tpwarn');
      } else if (snd.type === 'power_warn') {
        // generic "the killer is about to appear here" cue (Dredge locker, Hag teleport, Cenobite box teleport…)
        this.x = snd.x; this.y = snd.y; this.vx = this.vy = 0; this.t = m.time; this.conf = Math.max(this.conf, 0.8); this.state = INFO.HEARD; this.dirKnown = true; this.teleportT = m.time; this.warnWhat = snd.data.what;
        if (sd < 16 * M) ai.note(snd.data.note || 'Heard the killer about to appear nearby', 'pwarn');
      } else if (snd.type === 'lich_cast') {
        // the team learns which spell went on cooldown
        (m.bb.lichCasts ||= {})[snd.data.spell] = m.time; this.lastSpell = snd.data.spell;
        if (!this.observing) { this.x = ex; this.y = ey; this.vx = this.vy = 0; this.t = m.time; this.conf = Math.max(this.conf, 0.7); this.state = INFO.HEARD; this.dirKnown = true; }
        if (sd < 30 * M && ai.params.difficulty >= 6) ai.note(`Heard the Lich cast ${({ fotd: 'Flight of the Damned', fly: 'Fly', magehand: 'Mage Hand', sphere: 'Dispelling Sphere' })[snd.data.spell]}`, 'lich-' + snd.data.spell);
      } else if (snd.type === 'dog_lullaby') {
        if (sd < 32 * M) { ai.note('Heard the dog\'s lullaby — it is searching nearby', 'lullaby'); this.lullabyT = m.time; }
      } else if (snd.type === 'blink_charge') {
        // the Nurse's charge: you hear where she is and that a blink is coming
        if (!this.observing) { this.x = ex; this.y = ey; this.vx = this.vy = 0; this.t = m.time; this.conf = Math.max(this.conf, 0.75); this.state = INFO.HEARD; this.dirKnown = true; }
        this.windupT = m.time; this.windupWhat = 'blink';
      } else if (snd.type === 'power_windup') {
        if (!this.observing) { this.x = ex; this.y = ey; this.vx = this.vy = 0; this.t = m.time; this.conf = Math.max(this.conf, 0.7); this.state = INFO.HEARD; this.dirKnown = true; }
        this.windupT = m.time; this.windupWhat = snd.data.what;
      } else if (snd.type === 'killer_action') {
        if (!this.observing) { this.x = ex; this.y = ey; this.vx = this.vy = 0; this.t = m.time; this.conf = Math.max(this.conf, 0.7); this.state = INFO.HEARD; this.dirKnown = true; }
      }
    }
    this.lastSoundT = m.time;
    // --- team callouts -------------------------------------------------------
    const sg = m.bb.sightingOf(k);
    if (!this.observing && sg && sg.by !== s && sg.t > this.t + 0.3 && Math.random() < P.comms * (0.6 + 0.4 * ai.pers.teamwork)) {
      const age = m.time - sg.t; const c = 0.8 * Math.exp(-age / P.memoryTau);
      if (c > this.conf) { this.x = sg.x + sg.vx * Math.min(age, 1.5); this.y = sg.y + sg.vy * Math.min(age, 1.5); this.vx = sg.vx; this.vy = sg.vy; this.t = sg.t; this.conf = c; this.state = INFO.RECENT; this.dirKnown = true; }
    }
    // --- Spine Chill: killer near and facing me, even undetectable --------
    this.spineChill = false;
    if (s.hasPerk('spine_chill') && d < 36 * M && angleDiff(k.facing, Math.atan2(s.y - k.y, s.x - k.x)) < 0.8 && m.world.losClear(k.x, k.y, s.x, s.y)) {
      this.spineChill = true; if (this.conf < 0.4) { this.conf = 0.4; this.state = INFO.HEARD; this.t = m.time; }
    }
    // approach rate (positive = closing in) based on belief
    const bp = this.pos(); const bd = dist(s.x, s.y, bp.x, bp.y);
    if (this._prevD !== null) this.approach = this.approach * 0.7 + ((this._prevD - bd) / Math.max(dt, 0.05)) * 0.3;
    this._prevD = bd;
  }

  detectMindgame(k, m, d) {
    const sp = Math.hypot(k.vx, k.vy);
    if (sp > 1 * M) {
      const h = Math.atan2(k.vy, k.vx);
      if (this.lastHeading !== null && d < 14 * M && m.time - this.headingT < 0.6 && angleDiff(h, this.lastHeading) > 1.9) {
        if (m.time - this.mindgameT > 2) m.bb.model.mindgames++;
        this.mindgameT = m.time;
      }
      if (this.lastHeading === null || angleDiff(h, this.lastHeading) > 0.3) { this.lastHeading = h; this.headingT = m.time; }
    } else if (d < 10 * M && !k.action && k.stunT <= 0) this.standT = m.time;
  }
}
