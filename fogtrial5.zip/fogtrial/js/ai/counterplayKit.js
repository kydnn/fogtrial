// Shared counterplay building blocks used by every killer profile.
import { M, dist, angleDiff, clamp } from '../core/util.js';

export const K = (o) => ({ hideBias: 0, palletValue: 1, windowValue: 1, preDrop: 0, greed: 1, openPenalty: 1, losValue: 0, loopAbandon: false,
  genEscape: 1, rescueWait: 1, healBias: 1, zoneAvoid: 1, leaveEarly: 1, stealthy: false, unknownParanoia: 0,
  tightPenalty: 0, groupPenalty: 0, windowBonus: 0, ...o });

// Shared reactions ------------------------------------------------------------
export function sidestep(ai, fromDir, label, dist2 = 2.6) {
  const s = ai.sv, m = ai.m;
  const perp = fromDir + (Math.random() < 0.5 ? 1 : -1) * Math.PI / 2;
  // prefer the side with open ground
  let best = null;
  for (const sgn of [1, -1]) {
    const a = fromDir + sgn * Math.PI / 2; const tx = s.x + Math.cos(a) * dist2 * M, ty = s.y + Math.sin(a) * dist2 * M;
    if (m.world.sweepClear(s.x, s.y, tx, ty, s.r)) { if (!best || Math.random() < 0.5) best = { x: tx, y: ty }; }
  }
  if (!best) best = { x: s.x + Math.cos(perp) * dist2 * M, y: s.y + Math.sin(perp) * dist2 * M };
  ai.chase.sidestep = best; ai.chase.sidestepUntil = m.time + 0.45;
  ai.setPath([{ x: s.x, y: s.y }, best], true);
  if (label) ai.note(label, 'dodge-' + label);
  if (label && /dodg|lane|dash|bound|harpoon|hatchet|dog|chain|wave|damned/i.test(label)) m.events.emit('dodged', { survivor: s, label });
  return label;
}

// Dodge any visible killer projectile on a collision course. Quality depends on
// difficulty, distance (time to impact), reaction time, awareness and the throw speed.
export function dodgeProjectiles(ai) {
  const s = ai.sv, m = ai.m, P = ai.params;
  for (const p of m.projectiles) {
    if (p.arc || p.dodgeRolled?.has(s)) continue;
    const d = dist(p.x, p.y, s.x, s.y); if (d > 32 * M) continue;
    if (!m.world.losClear(s.x, s.y, p.x, p.y)) continue;
    const ap = p.approach(s.x, s.y); if (ap.t < 0 || ap.d > s.r + p.r + 0.35 * M) continue;
    (p.dodgeRolled ||= new Set()).add(s);
    const speed = Math.hypot(p.vx, p.vy) / M;
    const react = P.reaction * (1.2 - 0.4 * ai.pers.killerAwareness) * (s.hasPerk('dodge_instinct') && !s.status.has('exhausted') ? 0.6 : 1);
    const window = ap.t - react;
    const timeFactor = clamp(window / 0.35, 0, 1);
    const aimFactor = 1 - clamp((speed - 22) / 40, 0, 0.35);
    const pDodge = P.dodge * timeFactor * aimFactor * (0.75 + 0.25 * P.awareness);
    if (Math.random() < pDodge) return sidestep(ai, Math.atan2(p.vy, p.vx), `Dodged a ${p.kind || 'projectile'}`, 1.8);
  }
  return null;
}


// Run from a threat point (a guard, the dog, a teleport spot). Samples nearby open cells and
// prefers ones that put a wall between us, are far from the threat and away from the killer
// belief; windows score extra when the chaser cannot vault (dog, guards).
export function fleeFrom(ai, tx, ty, label, { windows = false, holdFor = 1.0, minD = 5, maxD = 10 } = {}) {
  const s = ai.sv, m = ai.m, nav = m.map.nav, B = ai.belief;
  const kb = B.conf > 0.3 ? B.pos() : null;
  let best = null, bs = -1e9;
  const cands = [];
  for (let k = 0; k < 18; k++) { const a = Math.random() * Math.PI * 2, r = (minD + Math.random() * (maxD - minD)) * M; cands.push({ x: s.x + Math.cos(a) * r, y: s.y + Math.sin(a) * r, win: null }); }
  if (windows) for (const w of m.map.windows) if (w.blockedUntil <= m.time && dist(w.x, w.y, s.x, s.y) < 10 * M) { const sd = w.sides(1.4 * M); const far = sd[w.sideOf({ x: tx, y: ty }) === 0 ? 1 : 0]; cands.push({ x: far.x, y: far.y, win: w }); }
  for (const c of cands) {
    const i = nav.idxAt(c.x, c.y); if (i < 0 || nav.isBlocked(i)) continue;
    let sc = dist(c.x, c.y, tx, ty) / M - dist(c.x, c.y, s.x, s.y) / M * 0.35;
    if (!m.world.losClear(tx, ty, c.x, c.y)) sc += 4;
    if (c.win) sc += 6;
    if (kb) sc -= Math.max(0, 10 - dist(c.x, c.y, kb.x, kb.y) / M) * 0.6;
    // don't run past the threat
    const toC = Math.atan2(c.y - s.y, c.x - s.x), toT = Math.atan2(ty - s.y, tx - s.x); if (angleDiff(toC, toT) < 0.7) sc -= 8;
    if (sc > bs) { bs = sc; best = c; }
  }
  if (!best) return null;
  const r = m.map.nav.findPath(s.x, s.y, best.x, best.y, ai.agent(), 3000);
  if (r) ai.setPath(m.map.nav.smooth(m.world, r.pts, s.r * 0.9), true); else ai.setPath([{ x: s.x, y: s.y }, best], true);
  s.moveMode = 'run'; ai.chase.sidestepUntil = m.time + holdFor;
  if (label) ai.note(label, 'flee-' + label);
  return label;
}
// The minion (dog / guard) this survivor currently knows about that is coming for it.
export function minionOnMe(ai) {
  const s = ai.sv; let best = null, bd = Infinity;
  for (const e of ai.memory.minions.values()) {
    const n = e.n; if (n.dead) continue;
    const onMe = n.target === s && ['hunt', 'pursue', 'spotted'].includes(n.state);
    const charging = n.state === 'chase' && angleDiff(n.facing, Math.atan2(s.y - n.y, s.x - n.x)) < 0.5;
    if (!onMe && !charging) continue;
    const d = dist(n.x, n.y, s.x, s.y); if (d < bd) { bd = d; best = n; }
  }
  return best ? { n: best, d: bd } : null;
}
// Drop a standing pallet on a chasing minion when it is right behind us.
export function palletOnMinion(ai, n) {
  const s = ai.sv, m = ai.m;
  if (s.action || s.vault || !n.stunnable || n.stunT > 0) return false;
  for (const p of m.map.pallets) {
    if (p.state !== 'up' || p.dropping || dist(p.x, p.y, s.x, s.y) > 2.2 * M) continue;
    if (p.sideOf(s) === p.sideOf(n) || dist(p.x, p.y, n.x, n.y) > 3.2 * M) continue;
    if (s.startAction('dropPallet', p, m)) { ai.note(`Dropped a pallet on the ${n.label}`, 'mpal'); return true; }
  }
  return false;
}
