// Chase AI: real looping from map structure.
// Two Dijkstra distance fields (killer-model and self) over the nav grid let the bot
// find cells where it keeps the most time advantage — around walls, through windows
// (fast for survivors, slow for the killer) and behind dropped pallets (killer must break).
// A tile graph handles strategy: which loop to run to next, avoiding dead zones.
import { M, dist, clamp, angleDiff, gauss } from '../core/util.js';

const SURV_SPEED = 4.0;

export class ChaseBrain {
  constructor(ai) {
    this.ai = ai; this.nextTile = null; this.nextTileT = -99; this.lastDir = null; this.debug = {};
    this.palletMemo = new Map(); this.blockedTiles = new Map(); this.leaveTile = null; this.dodgeCD = 0; this.sidestepUntil = 0; this.sidestep = null;
  }

  survivorLinkCost() {
    const ai = this.ai, m = ai.m, P = ai.params;
    const vaultCost = 2.0 + (1 - P.fastVault) * 2.6;
    return (L) => {
      const o = L.ref;
      if (L.kind === 'window') {
        if (o.blockedUntil > m.time) return Infinity;
        if (ai.trapNear(o.x, o.y, 2.2 * M)) return Infinity;
        return vaultCost / ai.knobs.windowValue;
      }
      if (o.state !== 'down') return Infinity;
      if (ai.trapNear(o.x, o.y, 2.0 * M)) return Infinity;
      return 2.0;
    };
  }
  killerLinkCost() {
    const m = this.ai.m, noVault = this.ai.fk?.power.noVault?.();
    return (L) => {
      const o = L.ref;
      if (L.kind === 'window') return o.killerBlockedUntil > m.time || noVault ? Infinity : 1.7 * 4.6 + 1;
      if (o.state === 'down') return 2.6 * 4.6 + 1.5;
      return Infinity;
    };
  }
  survivorCellCost() {
    const ai = this.ai, nav = ai.m.map.nav, P = ai.params;
    const trapper = ai.m.hasPower('traps');
    const cells = ai.trapCells(); const zc = ai.zoneCells();
    return (i) => {
      let c = zc.get(i) || 0;
      if (cells.has(i)) c += 40;
      if (trapper && nav.grass[i] && P.difficulty >= 7) c += 1.5 * P.trapSense;
      return c;
    };
  }

  // Strategic: which tile should this chase move toward?
  chooseNextTile(kp) {
    const ai = this.ai, m = ai.m, s = ai.sv, P = ai.params, map = m.map;
    const cur = map.tileAt(s.x, s.y);
    let best = null, bs = -1e9;
    const teamGens = P.leadAway > 0.3 ? m.bb.activeGens(s) : [];
    const zones = [...ai.memory.zones.values()].filter((z) => z.until > m.time && z.aiCost > 0);
    const pods = [...ai.memory.devices.values()].filter((d) => d.dangerRadius && !d.dead && (d.data?.disabledUntil || 0) <= m.time);
    const slip = s.status.has('slipstream');
    for (const t of map.tiles) {
      if (t.safety < 0.12) continue;
      if ((this.blockedTiles.get(t.id) || 0) > m.time) continue;
      const dMe = dist(s.x, s.y, t.x, t.y) / M; if (dMe > 48) continue;
      if (t === cur && t.safety > 0.35 && (t.resources.up + t.resources.down + t.resources.wins) > 0) continue;
      const dK = dist(kp.x, kp.y, t.x, t.y) / M;
      const away = ((t.x - s.x) * (s.x - kp.x) + (t.y - s.y) * (s.y - kp.y)) / Math.max(1, dist(t.x, t.y, s.x, s.y) * dist(s.x, s.y, kp.x, kp.y));
      let dead = 0; for (let k = 1; k <= 5; k++) { const f = k / 6; dead += map.nav.deadZone[map.nav.idxAt(s.x + (t.x - s.x) * f, s.y + (t.y - s.y) * f)]; }
      dead /= 5;
      let sc = t.safety * 3.2 + (t.resources.up * 0.5 + t.resources.wins * 0.35) + away * 1.6 - dMe * 0.06 - dead * 2.5 * P.deadZoneAware + t.connected.length * 0.08;
      if (dK < dMe) sc -= 2.5 * P.tileGraph;
      // unsafe loops: gas / torment already on the tile, or a watched pod nearby while slipstreamed
      const r = t.rect; const onTile = zones.filter((z) => z.x > r.x - z.r && z.x < r.x + r.w + z.r && z.y > r.y - z.r && z.y < r.y + r.h + z.r).length;
      if (onTile) sc -= Math.min(3, onTile * (P.zoneSense * 1.2)) * ai.knobs.zoneAvoid;
      if (pods.length) { const watched = pods.some((d) => dist(d.x, d.y, t.x, t.y) < d.dangerRadius + t.radius * 0.5); if (watched) sc -= (slip ? 2.5 : 1) * P.zoneSense; }
      if (teamGens.length) { const near = teamGens.some((g) => dist(g.x, g.y, t.x, t.y) < 18 * M); if (near) sc -= 2 * P.leadAway * ai.pers.teamwork; }
      const kn2 = ai.knobs; if (kn2.tightPenalty && t.radius < 6.5 * M) sc -= kn2.tightPenalty * P.loopIQ;
      if (kn2.windowValue !== 1) sc += (kn2.windowValue - 1) * t.resources.wins * 1.2 * P.loopIQ;
      sc = sc * P.tileGraph + (1 - P.tileGraph) * (-dMe * 0.15 + Math.random() * 1.5);
      if (sc > bs) { bs = sc; best = t; }
    }
    return best;
  }

  // Walk the local field back from target to source to recover a path.
  descend(F, targetIdx, linkCost) {
    const nav = this.ai.m.map.nav, cols = nav.cols;
    const lid = (i) => { const c = i % cols - F.ox, r = ((i / cols) | 0) - F.oy; return c < 0 || r < 0 || c >= F.size || r >= F.size ? -1 : r * F.size + c; };
    const pts = []; let cur = targetIdx; let guard = 0;
    while (guard++ < 60) {
      const cl = lid(cur); if (cl < 0) break; const dc = F.d[cl];
      const c = nav.center(cur); pts.push({ x: c.x, y: c.y, viaLink: null, _i: cur });
      if (dc <= 0.01) break;
      let best = -1, bd = dc, viaLink = null;
      const cx = cur % cols, cy = (cur / cols) | 0;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue; const n = (cy + dy) * cols + (cx + dx); const nl = lid(n); if (nl < 0) continue;
        if (F.d[nl] < bd - 0.01) { bd = F.d[nl]; best = n; viaLink = null; }
      }
      const ls = nav.linksAt.get(cur);
      if (ls) for (const L of ls) { const c = linkCost(L); if (!isFinite(c)) continue; const n = L.a === cur ? L.b : L.a; const nl = lid(n); if (nl >= 0 && F.d[nl] + c <= dc + 0.05 && F.d[nl] < bd - 0.01) { bd = F.d[nl]; best = n; viaLink = L; } }
      if (best < 0) break;
      if (viaLink) pts[pts.length - 1].viaLink = viaLink; // arriving at this point required crossing the link
      cur = best;
    }
    pts.reverse();
    // viaLink was attached to the point *after* the crossing in walk order; shift to align with findPath convention
    return pts;
  }

  tick(urgent = true) {
    const ai = this.ai, m = ai.m, s = ai.sv, P = ai.params, pers = ai.pers, B = ai.belief, k = ai.fk, nav = m.map.nav;
    let lead = P.predictLead * (0.5 + 0.7 * pers.predictionSkill);
    // The killer cannot be predicted past the survivor: cap the lead by the gap that is left.
    const b0 = B.pos(0); const gap = dist(b0.x, b0.y, s.x, s.y); const kspd = Math.hypot(B.vx, B.vy);
    if (kspd > 1) lead = Math.min(lead, Math.max(0, (gap - 2.5 * M) / kspd));
    let kp = B.pos(lead);
    // Extrapolation never passes through walls: clip the prediction at the first obstacle.
    const hit = m.world.firstHit(B.x, B.y, kp.x, kp.y, 0.4 * M);
    if (hit) { const t = Math.max(0, hit.t - 0.05); kp = { x: B.x + (kp.x - B.x) * t, y: B.y + (kp.y - B.y) * t }; }
    // Read what the killer is committed to: a vault lands on the far side; a pallet being broken is effectively gone.
    const kAct = B.observing ? k.action : null;
    if (kAct && kAct.type === 'vault' && kAct.to && P.difficulty >= 4) kp = { x: kAct.to.x, y: kAct.to.y };
    const breakingPallet = kAct && kAct.type === 'break' && P.difficulty >= 3 ? kAct.target : null;
    if (breakingPallet) breakingPallet.state = 'broken';
    // Plan to use nearby standing pallets: model them as dropped for the killer's field,
    // so cells behind a pallet look safe and the bot plays the pallet instead of running past it.
    const kNow = B.pos(0.1);
    const planned = [];
    if (P.loopIQ > 0.3) for (const p of m.map.pallets) {
      if (p.state !== 'up' || p.dropping || this.isGreeding(p)) continue;
      const dp = dist(p.x, p.y, s.x, s.y) / M, dkp = dist(p.x, p.y, kNow.x, kNow.y) / M;
      if (dp < 6 && dkp > 2.2 && dkp < 18 && p.sideOf(kNow) !== p.sideOf(s) || (dp < 3 && dkp > 3 && dkp < 14)) { p.state = 'down'; planned.push(p); }
    }
    const dK = dist(s.x, s.y, kp.x, kp.y) / M;
    const mindgame = P.usesMindgames && m.time - B.mindgameT < 1.4 && Math.random() < P.mindgameRead + 0.1;
    const half = P.fieldHalf;
    const kF = nav.field(kp.x, kp.y, half + 12, this.killerLinkCost(), null, 70);
    let altF = null;
    if (mindgame && !B.observing) { const back = { x: B.x - B.vx * 0.9, y: B.y - B.vy * 0.9 }; altF = nav.field(back.x, back.y, half + 10, this.killerLinkCost(), null, 60); }
    const H = P.horizon * (0.8 + 0.4 * pers.loopSkill);
    if (breakingPallet) breakingPallet.state = 'down';
    for (const p of planned) p.state = 'up';
    const myF = nav.field(s.x, s.y, Math.ceil(H) + 3, this.survivorLinkCost(), this.survivorCellCost(), H + 4);

    // Tile strategy
    const curTile = m.map.tileAt(s.x, s.y);
    const depleted = curTile && curTile.resources && curTile.resources.up + curTile.resources.down + curTile.resources.wins === 0;
    const killerBreaking = B.observing && B.actionType === 'break';
    if (!this.nextTile || m.time - this.nextTileT > 1.5 || depleted || killerBreaking) { this.nextTile = this.chooseNextTile(kp); this.nextTileT = m.time; }
    if (killerBreaking && P.difficulty >= 6 && !this._brkNote) { this._brkNote = m.time; ai.note('Left the tile while the killer broke the pallet', 'tilechain'); }
    if (!killerBreaking) this._brkNote = 0;

    // Only the Hillbilly's long sprint makes line of sight matter; Bubba's sweep is about distance.
    const hilly = k.power.id === 'chainsaw';
    const revving = hilly && m.time - B.revvingT < 0.8 && B.conf > 0.5;
    const sprinting = hilly && m.time - B.sprintT < 0.5 && B.observing;
    const kn = ai.knobs, pw = k.power, zc = ai.zoneCells();
    // Ranged pressure from the current killer's power (only what the survivor can perceive).
    const ranged = revving || sprinting || (B.conf > 0.5 && dist(B.x, B.y, s.x, s.y) < 30 * M && ((pw.id === 'hatchets' && pw.count > 0) || (pw.id === 'shroud' && pw.shrouded && B.observing) || (pw.id === 'tonic' && pw.state === 'aiming' && B.observing) || (pw.id === 'redeemer' && pw.loaded) || (pw.id === 'lament' && pw.cd('chain') <= 1) || (pw.id === 'virulent' && pw.tokens > 0 && B.observing)));
    const losW = revving || sprinting ? 4 : ranged ? kn.losValue : 0;
    const straightW = (revving || sprinting ? 1.5 : ranged && kn.openPenalty > 1.4 ? 1.2 : 0) * P.lineAware;
    // Executioner in Punishment mode: loops do not protect from the wave — get distance, go lateral.
    const abandon = kn.loopAbandon && B.observing && ['punish', 'windup', 'recover'].includes(pw.state) && dist(B.x, B.y, s.x, s.y) < 19 * M;
    if (abandon && !this._abNote) { this._abNote = m.time; ai.note('Abandoned the loop — Punishment mode reaches through walls', 'abandon'); }
    if (!abandon) this._abNote = 0;
    const teamGens = P.leadAway > 0.3 && pers.teamwork > 0.4 ? m.bb.activeGens(s) : [];
    const ratio = 4.6 / SURV_SPEED;
    const onLoop = curTile && curTile.safety > 0.3 && !depleted;
    // Home tile: keep running the structure we are on while it still has resources.
    if (onLoop) this.home = curTile;
    else if (this.home && (dist(this.home.x, this.home.y, s.x, s.y) > this.home.radius + 8 * M || this.home.resources.up + this.home.resources.down + this.home.resources.wins === 0)) this.home = null;
    const home = killerBreaking || abandon ? null : this.home;
    const loop = 0.3 + 0.7 * P.loopIQ * (0.7 + 0.6 * pers.loopSkill);
    // Resources the survivor wants to put between itself and the killer (standing pallets).
    const pals = m.map.pallets.filter((p) => p.state === 'up' && !p.dropping && dist(p.x, p.y, s.x, s.y) < (H + 3) * M && dist(p.x, p.y, kp.x, kp.y) < 16 * M);
    let best = null, bestScore = -1e9, flat = 0, cnt = 0;
    const sz = myF.size;
    for (let r = 0; r < sz; r++) for (let c = 0; c < sz; c++) {
      const md = myF.d[r * sz + c]; if (!(md <= H) || md < 0.9) continue;
      const gi = (myF.oy + r) * nav.cols + (myF.ox + c); if (gi < 0 || gi >= nav.blocked.length) continue;
      if (nav.pallet[gi] >= 0) continue; // never plan to stand inside a pallet gap
      const p = nav.center(gi);
      let kd = kF.at(p.x, p.y); if (!isFinite(kd)) kd = 45;
      if (altF) { const a = altF.at(p.x, p.y); if (isFinite(a)) kd = Math.min(kd, a + 1.5); }
      const margin = kd - md * ratio;
      let sc = margin * loop + (1 - loop) * (dist(p.x, p.y, kp.x, kp.y) / M) * 0.6;
      const tile = nav.tileOf[gi] >= 0 ? m.map.tiles[nav.tileOf[gi]] : null;
      if (tile) sc += tile.safety * 1.6 * P.tileGraph;
      for (const pl of pals) if (dist(p.x, p.y, pl.x, pl.y) < 1.9 * M && pl.sideOf(p) !== pl.sideOf(kNow)) sc += 2.4 * (0.3 + P.loopIQ) * (0.6 + 0.4 * pers.palletDiscipline) * kn.palletValue;
      sc -= nav.deadZone[gi] * 3 * P.deadZoneAware * kn.openPenalty;
      const zcost = zc.get(gi); if (zcost) sc -= zcost * 0.35;
      if (abandon) { const fa = B.facing; const side = Math.abs(-(p.x - B.x) * Math.sin(fa) + (p.y - B.y) * Math.cos(fa)) / M; sc += Math.min(side, 4) * 0.6 * P.dodge; }
      if (this.nextTile) { const w = (onLoop && !killerBreaking && !abandon) ? (margin > 9 ? 0.15 : 0.03) : 0.32; sc -= dist(p.x, p.y, this.nextTile.x, this.nextTile.y) / M * w * P.tileGraph * (killerBreaking ? 2 : 1); }
      if (home) { const r = home.rect; const ex = Math.max(r.x - p.x, 0, p.x - (r.x + r.w)), ey = Math.max(r.y - p.y, 0, p.y - (r.y + r.h)); const out = Math.hypot(ex, ey) / M; if (out > 3) sc -= (out - 3) * 1.3 * P.tileGraph; }
      if (this.lastDir) { const dx = p.x - s.x, dy = p.y - s.y; const l = Math.hypot(dx, dy) || 1; sc += ((dx * this.lastDir.x + dy * this.lastDir.y) / l) * 0.7; }
      if (losW) {
        // break line of sight from ranged/stalking threats; avoid long straight lines away from them
        if (!m.world.losClear(p.x, p.y, B.x, B.y)) sc += losW * P.lineAware;
        if (straightW) {
          const ax = p.x - B.x, ay = p.y - B.y; const al = Math.hypot(ax, ay) || 1;
          const sx = s.x - B.x, sy = s.y - B.y; const sl = Math.hypot(sx, sy) || 1;
          sc -= ((ax * sx + ay * sy) / (al * sl)) * straightW;
        }
      }
      if (teamGens.length) for (const g of teamGens) { const gd = dist(g.x, g.y, p.x, p.y) / M; if (gd < 18) sc -= (18 - gd) * 0.12 * P.leadAway; }
      sc += md * 0.08; // prefer committing to a direction over shuffling between neighbours
      if (P.difficulty < 5) sc += gauss() * (5 - P.difficulty) * 0.6;
      if (sc > bestScore) { bestScore = sc; best = gi; }
      flat += margin; cnt++;
    }
    const meanMargin = cnt ? flat / cnt : 0;
    let decision = null;
    // --- chainsaw sidestep -------------------------------------------------
    if (sprinting && B.observing) {
      const toMe = Math.atan2(s.y - B.y, s.x - B.x);
      const d = dist(s.x, s.y, B.x, B.y);
      const eta = d / (9.2 * M);
      if (angleDiff(B.facing, toMe) < 0.4 && eta < 0.75 && this.sidestepUntil < m.time && Math.random() < P.dodge) {
        const side = Math.random() < 0.5 ? 1 : -1; const a = B.facing + side * Math.PI / 2;
        this.sidestep = { x: s.x + Math.cos(a) * 3 * M, y: s.y + Math.sin(a) * 3 * M }; this.sidestepUntil = m.time + 0.6;
        ai.note('Side-stepped the chainsaw', 'sidestep');
      }
    }
    if (this.sidestepUntil > m.time && this.sidestep) {
      ai.setPath([{ x: s.x, y: s.y }, this.sidestep]); decision = 'sidestep';
    } else if (best !== null) {
      const pts = this.descend(myF, best, this.survivorLinkCost());
      const bp = nav.center(best); let dx = bp.x - s.x, dy = bp.y - s.y; let l = Math.hypot(dx, dy);
      if (l < 0.5 * M && this.lastDir) { dx = this.lastDir.x; dy = this.lastDir.y; l = 1; }
      l = l || 1; this.lastDir = { x: dx / l, y: dy / l };
      if (pts.length) {
        pts[0] = { x: s.x, y: s.y, viaLink: pts[0].viaLink };
        // Never stall: if the plan is shorter than a couple of metres, keep running the same way.
        const end = pts[pts.length - 1]; const plen = dist(s.x, s.y, end.x, end.y);
        if (plen < 2.5 * M && !end.viaLink) {
          const ex = end.x + this.lastDir.x * 3 * M, ey = end.y + this.lastDir.y * 3 * M;
          if (m.world.sweepClear(end.x, end.y, ex, ey, s.r)) pts.push({ x: ex, y: ey, viaLink: null });
        }
        ai.setPath(pts, true);
      }
    }

    // --- pallet decisions ----------------------------------------------------
    decision = this.palletLogic(kF, kp, dK, meanMargin, urgent) || decision;
    // --- Dead Hard -----------------------------------------------------------
    if (s.health === 'injured' && s.hasPerk('dead_hard') && !s.status.has('exhausted') && B.observing && B.attacking && dist(s.x, s.y, B.x, B.y) < 3.2 * M && Math.random() < P.dodge * 0.8) {
      if (m.perks.activate(s, 'dead_hard')) { ai.note('Dead Hard dodge', 'dh'); decision = 'dead hard'; }
    }
    this.debug = { tile: curTile ? curTile.label : (nav.deadZone[nav.idxAt(s.x, s.y)] > 0.6 ? 'DEAD ZONE' : 'open'), nextTile: this.nextTile ? this.nextTile.label + ' #' + this.nextTile.id : '-', margin: meanMargin.toFixed(1), best: best !== null ? nav.center(best) : null, decision: decision || this.debug.decision, mindgame, killerD: dK.toFixed(1), kF, myF };
    return decision;
  }

  // Greed is decided once per pallet approach (not re-rolled every tick).
  isGreeding(p) { const g = this.greed?.get(p.id); return !!(g && g.greedy && this.ai.m.time - g.t < 7); }
  decideGreed(p, meanMargin) {
    if (!this.greed) this.greed = new Map();
    const ai = this.ai, m = ai.m, P = ai.params, g = this.greed.get(p.id);
    if (g && m.time - g.t < 7) return g.greedy;
    const chainsaw = ai.fk.power.id === 'chainsaw' || ai.fk.power.id === 'bubba';
    const others = m.map.pallets.filter((q) => q !== p && q.state === 'up' && dist(q.x, q.y, p.x, p.y) < 22 * M).length;
    const greedy = P.usesGreed && !chainsaw && others > 0 && meanMargin > 2.5 && Math.random() < P.greed * ai.knobs.greed * ai.pers.palletDiscipline * (0.5 + m.bb.tendencies.palletRespect);
    this.greed.set(p.id, { greedy, t: m.time });
    if (greedy) ai.note('Greeding the pallet — loop still safe', 'greed');
    return greedy;
  }

  palletLogic(kF, kp, dK, meanMargin, urgent) {
    const ai = this.ai, m = ai.m, s = ai.sv, P = ai.params, pers = ai.pers, B = ai.belief;
    if (s.action || s.vault || B.conf < 0.45) return null;
    kp = B.pos(0.1); // pallet calls use where the killer actually is, not a long extrapolation
    dK = dist(s.x, s.y, kp.x, kp.y) / M;
    for (const p of m.map.pallets) {
      if (p.state !== 'up' || p.dropping) continue;
      const along = Math.abs((s.x - p.x) * (p.alongX ? 1 : 0) + (s.y - p.y) * (p.alongX ? 0 : 1));
      const signed = (s.x - p.x) * p.nx + (s.y - p.y) * p.ny;
      if (along > p.len / 2 + 0.3 * M || Math.abs(signed) > 2.1 * M || Math.abs(signed) < 0.35 * M) continue;
      const mySide = signed < 0 ? 0 : 1; const kSide = p.sideOf(kp);
      if (mySide === kSide) continue;
      const kDistToPallet = dist(kp.x, kp.y, p.x, p.y) / M;
      if (kDistToPallet > 10) continue;
      // How much longer would the killer's path to me be with the pallet down?
      let gain = this.palletMemo.get(p.id);
      if (!gain || m.time - gain.t > 0.5) {
        p.state = 'down';
        const f = m.map.nav.field(kp.x, kp.y, 20, this.killerLinkCost(), null, 60);
        p.state = 'up';
        const f0 = m.map.nav.field(kp.x, kp.y, 20, this.killerLinkCost(), null, 60);
        const now = f0.at(s.x, s.y), after = f.at(s.x, s.y);
        gain = { v: (isFinite(after) ? after : 40) - (isFinite(now) ? now : 40), t: m.time };
        this.palletMemo.set(p.id, gain);
      }
      const stunPos = B.pos(0.35);
      const stun = p.stunZone(stunPos) && B.observing;
      const chainsaw = (ai.fk.power.id === 'chainsaw' || ai.fk.power.id === 'bubba') && (m.time - B.revvingT < 1);
      const pwr = ai.fk.power; const powerThreat = B.observing && (pwr.state === 'winding' || pwr.state === 'aiming' || pwr.state === 'charging' || pwr.state === 'revving' || pwr.frenzy);
      const throwDist = P.throwDist * (urgent ? 1 : 0.6);
      const greedy = dK < 7 ? this.decideGreed(p, meanMargin) : false;
      let why = null;
      if (stun && Math.random() < 0.25 + P.dodge * 0.7) why = 'stun';
      else if (dK < (greedy ? 2.9 : throwDist) && gain.v > 3.5) why = 'drop';
      else if (P.preDrops && gain.v > 4 && dK < 7 + ai.knobs.preDrop * 3 && (chainsaw || powerThreat || m.time - B.mindgameT < 1.5)) why = 'pre-drop';
      else if (dK < 9 && gain.v > 0 && Math.random() < P.palletWaste * 0.12) why = 'wasted';
      if (why && s.startAction('dropPallet', p, m)) {
        if (why === 'pre-drop') ai.note(chainsaw ? 'Pre-dropped the pallet against the chainsaw' : powerThreat ? 'Pre-dropped the pallet before the throw' : 'Pre-dropped the pallet expecting a cut-off', 'predrop');
        else if (why === 'stun') ai.note('Timed the pallet for a stun', 'stun');
        else if (why === 'wasted') ai.note('Panicked and dropped a pallet', 'waste');
        return 'pallet: ' + why;
      }
    }
    return null;
  }
}
