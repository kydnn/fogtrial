// Team blackboard: information survivors could plausibly share (callouts, HUD states).
// Reading it is gated by each bot's comms quality — nobody gets perfect omniscience.
import { M, dist } from '../core/util.js';

export class Blackboard {
  constructor(m) {
    this.m = m;
    this.sighting = null;          // latest { x, y, vx, vy, t, by, k } of any killer
    this.sightings = new Map();    // killer id -> latest sighting of that killer (2v8)
    this.killerTargets = new Map(); // killer coordination (2v8 killer AI uses its own board)
    this.claims = new Map();       // key -> { sv, t }
    this.chased = new Map();       // survivor id -> time last reported in chase
    this.traps = new Map();        // trap id -> { x, y, t }
    this.gens = new Map();         // gen id -> { p, t }
    this.totems = new Map();       // totem id -> { hex, t }
    // Learned killer tendencies (observed by anyone, shared over time)
    this.model = { palletBreaks: 0, palletRespects: 0, mindgames: 0, camping: 0, tunnels: 0, hooks: 0, chainsawUses: 0, cloaks: 0, trapCatches: 0 };
  }
  report(sv, x, y, vx, vy, k = this.m.killer) { this.sighting = { x, y, vx, vy, t: this.m.time, by: sv, k }; this.sightings.set(k.id, this.sighting); }
  sightingOf(k) { return this.sightings.get(k.id) || null; }
  claim(key, sv) { this.claims.set(key, { sv, t: this.m.time }); }
  release(sv) { for (const [k, c] of this.claims) if (c.sv === sv) this.claims.delete(k); }
  claimedBy(key) { const c = this.claims.get(key); if (!c) return null; if (this.m.time - c.t > 6 || !c.sv.alive || !c.sv.standing) { this.claims.delete(key); return null; } if (c.sv.ai && (c.sv.ai.inChase || c.sv.trap)) return null; return c.sv; }
  refreshClaim(sv, key) { const c = this.claims.get(key); if (c && c.sv === sv) c.t = this.m.time; }
  reportChase(sv) { this.chased.set(sv.id, this.m.time); }
  inChase(sv, within = 3) { const t = this.chased.get(sv.id); return t !== undefined && this.m.time - t < within; }
  reportTrap(t) { this.traps.set(t.id, { x: t.x, y: t.y, t: this.m.time, trap: t }); }
  forgetTrap(t) { this.traps.delete(t.id); }
  reportGen(g) { this.gens.set(g.id, { p: g.progress, t: this.m.time }); }
  knownGen(g) { return this.gens.get(g.id); }
  // gens currently being worked on by teammates (survivors call these out)
  activeGens(exclude) { return this.m.map.gens.filter((g) => !g.done && [...g.repairers].some((s) => s !== exclude)); }
  get tendencies() {
    const md = this.model;
    const respect = (md.palletRespects + 1) / (md.palletBreaks + md.palletRespects + 2);
    return { camping: Math.min(1, md.camping / Math.max(1, md.hooks)), tunneling: Math.min(1, md.tunnels / Math.max(1, md.hooks)), palletRespect: respect, mindgamer: Math.min(1, md.mindgames / 6) };
  }
}
