// Killer counterplay profiles. Survivors read the profile of the killer they face and it
// shapes pathing, loops, hiding, generator choice, rescue timing, pallet use, vaults,
// healing and positioning. Each profile answers:
//   What killer am I facing? What is its power? Strengths? Weaknesses? Avoid? Exploit?
// `knobs` are multipliers the generic AI applies; `tactical` is killer-specific reaction
// code run every tactical tick (returns a label when it took over movement).
import { M, dist, angleDiff, clamp } from '../core/util.js';
import { K, sidestep, dodgeProjectiles, fleeFrom, minionOnMe, palletOnMinion } from './counterplayKit.js';
import { EXPANSION_PROFILES } from './profilesExpansion.js';
import { NEW_PROFILES } from './profilesNew.js';



// Profiles ---------------------------------------------------------------------
export const KILLER_PROFILES = {
  trapper: {
    power: 'Bear traps', strengths: ['area denial at loops and gens', 'hidden traps in tall grass'], weaknesses: ['slow to set up', 'no ranged pressure'],
    avoid: ['tall grass near windows and pallets', 'known trap locations'], exploit: ['disarm traps near objectives', 'long chases on trap-free tiles'],
    knobs: K({ genEscape: 1.0, openPenalty: 0.9, palletValue: 1.05, zoneAvoid: 1 }),
  },
  hillbilly: {
    power: 'Chainsaw sprint', strengths: ['instant downs', 'fast map traversal'], weaknesses: ['collides with obstacles', 'loud rev', 'overheat'],
    avoid: ['long straight runs', 'open fields when he revs'], exploit: ['tight loops with obstacles', 'break line of sight while he revs'],
    knobs: K({ openPenalty: 1.6, losValue: 3.5, preDrop: 0.4, greed: 0.5, genEscape: 1.1, rescueWait: 1.2 }),
  },
  wraith: {
    power: 'Cloaking', strengths: ['undetectable ambushes', 'fast while cloaked'], weaknesses: ['bell warns on cloak/uncloak', 'cannot attack while cloaked'],
    avoid: ['repairing far from loops', 'staying put after hearing the bell'], exploit: ['the uncloak window', 'watching for shimmer'],
    knobs: K({ genEscape: 1.6, stealthy: true, unknownParanoia: 0.3, leaveEarly: 1.15 }),
  },
  ghostface: {
    power: 'Night Shroud (stalk & expose)', strengths: ['no heartbeat', 'one-hit downs on marked survivors', 'hard to spot when crouched'], weaknesses: ['revealed by being looked at', 'slow while stalking'],
    avoid: ['standing in his line of sight', 'chasing or rescuing while marked'], exploit: ['stare at him to reveal', 'break line of sight to deny stalk'],
    knobs: K({ genEscape: 1.4, stealthy: true, unknownParanoia: 0.35, hideBias: 0.25, losValue: 2.5, rescueWait: 1.15, leaveEarly: 1.1 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, k = ai.fk, B = ai.belief, P = ai.params;
      s.lookTarget = null;
      if (!B.observing || !k.power.shrouded || !s.standing) return null;
      const d = dist(k.x, k.y, s.x, s.y);
      const facingMe = angleDiff(k.facing, Math.atan2(s.y - k.y, s.x - k.x)) < 0.6;
      const stalked = facingMe && (k.power.stalking || k.lastSpeed < 1.5 * M) && d > 5 * M;
      if (stalked && m.time - (ai._stalkCall || 0) > 4) { ai._stalkCall = m.time; m.bb.report(s, k.x, k.y, 0, 0, k); m.bb.stalker = { x: k.x, y: k.y, t: m.time, by: s }; ai.note('Called out Ghost Face stalking', 'gfcall'); }
      // Reveal him by looking straight at him (skill gated), otherwise break line of sight.
      // Decide once per encounter whether this bot has the nerve/skill to stare him down.
      if (m.time - (ai._gfRollT || -99) > 6) { ai._gfRollT = m.time; ai._gfStare = P.difficulty >= 3 && Math.random() < 0.3 + 0.7 * P.awareness; }
      const canReveal = d < 13 * M && d > 4.5 * M && ai._gfStare;
      if (canReveal && (stalked || d < 9 * M)) {
        s.lookTarget = { x: k.x, y: k.y };
        if (s.action && s.action.type !== 'heal' && P.difficulty >= 6) s.stopAction(m);
        // Stand still and face him: running away shows him my back and lets him finish the stalk.
        if (!s.action) { s.moveTo = null; ai.path = null; ai.chase.sidestepUntil = m.time + 0.35; }
        if (stalked) ai.note('Staring down Ghost Face to reveal him', 'gfstare');
        return 'stare down';
      }
      if (stalked && P.difficulty >= 5 && !ai.inChase) { ai.evadeUntil = m.time + 2; ai.evadeMode = 'hide'; ai.note('Breaking line of sight from Ghost Face', 'gflos'); }
      return null;
    },
  },
  clown: {
    power: 'Gas bottles', strengths: ['slows survivors in loops', 'herds survivors with gas', 'antidote speed bursts'], weaknesses: ['slow base speed', 'reload downtime'],
    avoid: ['running through purple gas', 'loops already covered in gas'], exploit: ['his reload window', 'long loops with several exits', 'pallets before gas lands'],
    knobs: K({ zoneAvoid: 1.4, palletValue: 1.2, preDrop: 0.2, greed: 0.7, openPenalty: 0.9 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, nt = ai.chase.nextTile, P = ai.params;
      // Gassed while working: step out of the cloud (coughing gives away my position and
      // the slow makes me easy prey) and do something else until it clears.
      if (!ai.inChase && s.standing) {
        for (const z of m.zones) {
          if (z.kind !== 'tonic' || !z.contains(s.x, s.y)) continue;
          (z.rolled ||= new Map());
          if (!z.rolled.has(s)) z.rolled.set(s, Math.random() < 0.25 + 0.75 * P.zoneSense);
          if (!z.rolled.get(s)) break;
          ai.memory.zones.set(z.id, z); ai._zoneV++;
          if (s.action && s.action.type !== 'unhook') s.stopAction(m);
          const a = Math.atan2(s.y - z.y, s.x - z.x) + (Math.random() - 0.5) * 0.6; const r = z.r + 1.4 * M;
          let tx = z.x + Math.cos(a) * r, ty = z.y + Math.sin(a) * r;
          if (m.world.pointBlocked(tx, ty, s.r)) { tx = z.x - Math.cos(a) * r; ty = z.y - Math.sin(a) * r; }
          ai.setPath([{ x: s.x, y: s.y }, { x: tx, y: ty }], true); ai.chase.sidestepUntil = m.time + 0.9; ai.goal = null; ai.sT = Math.min(ai.sT, 0.9);
          ai.note('Gassed — stepping out of the tonic', 'gas');
          return 'leave gas';
        }
      }
      // Herding: gas landing ahead of me (between me and my next tile) means he wants me elsewhere.
      if (!ai.inChase || !nt) return null;
      for (const z of m.zones) {
        if (z.kind !== 'tonic' || m.time - z.t0 > 1) continue;
        const toT = Math.atan2(nt.y - s.y, nt.x - s.x), toZ = Math.atan2(z.y - s.y, z.x - s.x);
        if (dist(z.x, z.y, s.x, s.y) < 12 * M && angleDiff(toT, toZ) < 0.6) { ai.chase.blockedTiles.set(nt.id, m.time + 8); ai.chase.nextTileT = -99; ai.note('Clown is herding me — switching route', 'herd'); break; }
      }
      return null;
    },
  },
  executioner: {
    power: 'Torment trails & ground wave', strengths: ['wave goes through walls', 'trails deny areas', 'remote caging'], weaknesses: ['slow in Punishment mode', 'long telegraphed wind-up'],
    avoid: ['torment trails', 'loops while he is in Punishment mode', 'standing in the wave line'], exploit: ['side-step the telegraph', 'distance when he enters Punishment mode'],
    knobs: K({ zoneAvoid: 1.3, loopAbandon: true, windowValue: 0.8, palletValue: 0.9, healBias: 1.25, openPenalty: 0.8, rescueWait: 0.9 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, k = ai.fk, B = ai.belief, P = ai.params, pw = k.power;
      if (!B.observing || pw.state !== 'windup') return null;
      const a = k.facing; const rx = s.x - k.x, ry = s.y - k.y;
      const along = rx * Math.cos(a) + ry * Math.sin(a), side = Math.abs(-rx * Math.sin(a) + ry * Math.cos(a));
      if (along < 0 || along > pw.waveLen + 1 * M || side > 1.8 * M) return null;
      if (ai._telegraphSeen === pw.windT0) return null;
      ai._telegraphSeen = pw.windT0;
      if (Math.random() < 0.15 + 0.8 * P.dodge) return sidestep(ai, a, 'Side-stepped the Punishment wave', 2.8);
      return null;
    },
  },
  singularity: {
    power: 'Biopods & teleport', strengths: ['map-wide pressure', 'teleports to slipstreamed survivors'], weaknesses: ['pods can be dodged and EMPed', 'needs slipstream to teleport'],
    avoid: ['line of sight of known pods', 'being near pods while slipstreamed'], exploit: ['EMPs', 'objectives away from pods'],
    knobs: K({ zoneAvoid: 1.2, losValue: 1.5, hideBias: 0.1, genEscape: 1.2, leaveEarly: 1.1 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, P = ai.params;
      if (!s.emp || s.action || !s.standing || P.difficulty < 3) return null;
      const slip = s.status.has('slipstream');
      const pods = [...ai.memory.devices.values()].filter((d) => d.kind === 'biopod' && !d.dead && (d.data.disabledUntil || 0) <= m.time && dist(d.x, d.y, s.x, s.y) < 10 * M);
      if (pods.length >= (slip ? 1 : 2) || (pods.length && s.action?.type === 'repair')) { s.startAction('useEmp', null, m); return 'emp'; }
      return null;
    },
  },
  huntress: {
    power: 'Hatchet throws', strengths: ['ranged hits in the open', 'punishes long loops and window vaults in sight'], weaknesses: ['slow base speed', 'limited hatchets', 'wind-up telegraph'],
    avoid: ['open fields', 'predictable straight runs', 'staying in her line of sight'], exploit: ['walls and tall structures', 'her reload trips to lockers', 'dodging the wind-up'],
    knobs: K({ openPenalty: 1.8, losValue: 4, windowValue: 0.85, palletValue: 1.1, greed: 0.6, healBias: 1.3, rescueWait: 1.3, hideBias: 0.15 }),
    tactical(ai) {
      const s = ai.sv, m = ai.m, k = ai.fk, B = ai.belief, P = ai.params, pw = k.power;
      const dodged = dodgeProjectiles(ai); if (dodged) return dodged;
      // She is aiming at me: juke (fake movement) instead of running in a straight line.
      if (B.observing && pw.state === 'winding' && pw.count > 0) {
        const d = dist(k.x, k.y, s.x, s.y);
        if (d > 4 * M && d < 28 * M && angleDiff(k.facing, Math.atan2(s.y - k.y, s.x - k.x)) < 0.3 && m.time > ai.chase.sidestepUntil + 0.3) {
          if (Math.random() < P.dodge * 0.35 * (1 / 6)) return sidestep(ai, Math.atan2(s.y - k.y, s.x - k.x), 'Juked her wind-up', 1.6);
        }
      }
      return null;
    },
  },
};

Object.assign(KILLER_PROFILES, EXPANSION_PROFILES, NEW_PROFILES);
export function profileFor(m, k = m.killer) { return KILLER_PROFILES[k.def.id] || KILLER_PROFILES.trapper; }
// Generic projectile reaction used against any killer that throws things.
export { dodgeProjectiles };
