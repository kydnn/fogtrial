// Killer bot movement: A* over the shared nav grid (windows are vault links, dropped pallets
// are "break" links), path following with stuck recovery, and direct pursuit when the way is
// clear. Writes only into the killer's input (mx, my, aim, spaceP) like a human would.
import { M, dist } from '../../core/util.js';

export class KillerSteering {
  constructor(ai) { this.ai = ai; this.m = ai.m; this.k = ai.k; this.path = null; this.idx = 0; this.goal = null; this.repathT = 0; this.stuckT = 0; this.last = { x: 0, y: 0 }; this.nudge = null; }
  linkCost() {
    const m = this.m, k = this.k, P = this.ai.P;
    const breakCost = 9 + 6 * P.palletIQ; // smarter killers value the time a break costs
    return (L) => {
      if (L.kind === 'window') return (L.ref.killerBlockedUntil || 0) > m.time || k.power.noVault?.() ? Infinity : this.ai.vaultCost ?? 7;
      if (L.kind === 'pallet') return L.ref.state === 'down' ? (this.ai.powerCtl?.passesPallets?.(this.ai) ? 1 : breakCost) : Infinity;
      return Infinity;
    };
  }
  // Move toward (x, y). Returns distance remaining (px).
  goTo(x, y, { direct = true, arrive = 0.6 * M, repath = 0.5 } = {}) {
    const m = this.m, k = this.k, inp = k.input;
    const d = dist(k.x, k.y, x, y);
    if (d < arrive) { inp.mx = inp.my = 0; return d; }
    // straight line when nothing is in the way (cheap and smooth)
    if (direct && d < 26 * M && m.world.sweepClear(k.x, k.y, x, y, k.r * 0.9, (s) => s.kind !== 'gate' || !s.ref.open)) {
      this.path = null; this.steer(x, y); this.checkStuck(); return d;
    }
    this.repathT -= 1 / 60;
    const far = !this.goal || dist(this.goal.x, this.goal.y, x, y) > 1.8 * M;
    if (!this.path || far || this.repathT <= 0) {
      if (m.pathBudget > 0 || !this.path) {
        m.pathBudget--;
        const r = m.map.nav.findPath(k.x, k.y, x, y, { linkCost: this.linkCost() });
        this.path = r ? m.map.nav.smooth(m.world, r.pts, k.r * 0.9) : [{ x: k.x, y: k.y }, { x, y }];
        this.idx = 1; this.goal = { x, y }; this.repathT = repath + Math.random() * repath * 0.5;
      }
    }
    const P = this.path; let p = P[Math.min(this.idx, P.length - 1)];
    // link handling: vault the window / break the pallet that the path crosses
    const next = P[this.idx];
    if (next && next.viaLink) {
      const L = next.viaLink, ref = L.ref;
      if (dist(k.x, k.y, ref.x, ref.y) < 2.0 * M) {
        const ctx = m.killerContext(k);
        if (ctx && (ctx.type === 'vault' || ctx.type === 'break') && ctx.target === ref) { inp.spaceP = true; this.idx++; inp.mx = inp.my = 0; return d; }
        if (L.kind === 'pallet' && ref.state !== 'down') this.idx++;
        // line up with the obstacle so the context action becomes available
        this.steer(ref.x, ref.y); return d;
      }
    }
    if (p && dist(k.x, k.y, p.x, p.y) < 0.7 * M && this.idx < P.length - 1) { this.idx++; p = P[this.idx]; }
    if (!p) p = { x, y };
    this.steer(p.x, p.y); this.checkStuck();
    return d;
  }
  steer(x, y) {
    const k = this.k, inp = k.input;
    let dx = x - k.x, dy = y - k.y; const l = Math.hypot(dx, dy) || 1; dx /= l; dy /= l;
    if (this.nudge && this.m.time < this.nudge.until) { dx = dx * 0.4 + this.nudge.x; dy = dy * 0.4 + this.nudge.y; const l2 = Math.hypot(dx, dy) || 1; dx /= l2; dy /= l2; }
    inp.mx = dx; inp.my = dy;
    if (!this.ai.aimLocked) inp.aim = Math.atan2(dy, dx);
  }
  checkStuck() {
    const k = this.k, m = this.m;
    if (k.action || k.stunT > 0) { this.stuckT = 0; return; }
    if (dist(k.x, k.y, this.last.x, this.last.y) < 0.03 * M) {
      this.stuckT += 1 / 60;
      if (this.stuckT > 0.7) { this.path = null; this.stuckT = 0; const a = Math.random() * Math.PI * 2; this.nudge = { x: Math.cos(a), y: Math.sin(a), until: m.time + 0.5 }; }
    } else this.stuckT = Math.max(0, this.stuckT - 1 / 120);
    this.last = { x: k.x, y: k.y };
  }
  stop() { const inp = this.k.input; inp.mx = inp.my = 0; }
  faceTo(x, y) { this.k.input.aim = Math.atan2(y - this.k.y, x - this.k.x); }
}
