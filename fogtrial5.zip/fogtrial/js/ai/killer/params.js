// Killer bot difficulty (1–10). Difficulty changes how well the killer perceives, decides and
// plays its power — never its movement speed, damage or information access.
const lerp = (a, b, t) => a + (b - a) * t;

export const KILLER_DIFFICULTY_LABELS = ['', 'Beginner', 'Beginner+', 'Novice', 'Novice+', 'Competent', 'Competent+', 'Advanced', 'Advanced+', 'Expert', 'Expert+'];

export function killerParams(d) {
  const t = Math.max(0, Math.min(1, (d - 1) / 9));
  const e = t * t; // "expert-only" features ramp late
  return {
    difficulty: d,
    // --- timing --------------------------------------------------------------
    tacticalHz: lerp(4, 10, t),           // chase / power decisions per second
    strategicEvery: lerp(1.2, 0.5, t),    // seconds between plan re-evaluations
    reaction: lerp(0.75, 0.16, t),        // s before a newly visible survivor is noticed
    // --- perception (what the bot *notices*, never more than the screen shows) --
    attention: lerp(0.55, 1.0, t),        // chance per tick to notice a visible survivor at the edge of view
    viewRange: lerp(15, 21, t),           // m, how far across the "screen" the bot pays attention
    scratchUse: lerp(0.15, 1.0, t),       // follows scratch marks / blood
    gruntUse: lerp(0.1, 1.0, t),          // follows grunts of pain
    noiseUse: lerp(0.35, 1.0, t),         // reacts to loud noise notifications
    memory: lerp(4, 14, t),               // s a lost sighting stays useful
    // --- chase -------------------------------------------------------------------
    predict: lerp(0.0, 1.0, t),           // leads targets, cuts loops
    lungeSkill: lerp(0.35, 1.0, t),       // lunge timing quality
    swingNoise: lerp(0.35, 0.03, t),      // chance to swing at a bad moment / whiff
    mindgame: lerp(0.0, 0.55, e),         // chance to fake/turn back at a loop
    palletIQ: lerp(0.1, 1.0, t),          // break vs. go around, avoid stuns
    stunAvoid: lerp(0.05, 0.85, t),       // keeps out of stun range when a pallet can drop
    abandon: lerp(0.0, 1.0, t),           // recognises unproductive chases
    chasePatience: lerp(70, 34, t),       // s before a chase is reconsidered (high = stubborn)
    // --- strategy ----------------------------------------------------------------
    patrolIQ: lerp(0.0, 1.0, t),          // gen choice: progress, clusters, likely objectives
    pressure: lerp(0.2, 1.0, t),          // kicks gens, rotates, defends 3-gens
    hookIQ: lerp(0.1, 1.0, t),            // hook choice, rescue reads, anti-camping balance
    tunnel: lerp(0.0, 0.45, e),           // willingness to go back for the unhooked survivor late
    slug: lerp(0.0, 0.5, e),              // leaves survivors downed to pressure others
    perkIQ: lerp(0.1, 1.0, t),            // plays around survivor perks it has seen
    powerIQ: lerp(0.25, 1.0, t),          // power used at the right time, aimed well
    aim: lerp(0.45, 0.97, t),             // projectile / dash aim quality
    temperature: lerp(0.55, 0.05, t),     // randomness of strategic picks
    mistakes: lerp(0.18, 0.01, t),        // odd decisions per strategic tick
    coordination: lerp(0.2, 1.0, t),      // 2v8 teamwork
  };
}
