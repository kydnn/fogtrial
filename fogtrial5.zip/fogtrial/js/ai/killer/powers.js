// Per-killer AI power controllers. Each one plays its killer's real power through the same
// inputs a human uses (hold/press RMB, E, LMB, aim, aim distance). Hooks:
//   chase(ai, b, d, tick)  → use the power on the chase target; return true to own this frame
//   patrol(ai)             → between chases (set up traps, pods, guards, scouting); true = owns movement
//   travel(ai, x, y)       → cover distance with the power (cloak, teleports, sprints)
//   passesPallets(ai)      → movement that ignores dropped pallets (pathing cost)
// Quality scales with ai.P.powerIQ (timing/choice) and ai.P.aim (aiming).
import { M, dist, angleDiff, clamp, normAngle } from '../../core/util.js';

const CTL = {};
export function powerControllerFor(id) { return CTL[id] || null; }
export function registerPowerController(id, ctl) { CTL[id] = ctl; }

// ---- shared helpers -----------------------------------------------------------
export const H = {
  aimAt(ai, p) { const k = ai.k; k.input.aim = Math.atan2(p.y - k.y, p.x - k.x); k.input.aimDist = dist(k.x, k.y, p.x, p.y); },
  // lead a believed survivor by t seconds; aim error grows as skill drops
  lead(ai, b, t) {
    const err = (1 - ai.P.aim) * 1.6 * M;
    const p = ai.per.pos(b, t * (0.4 + 0.6 * ai.P.predict));
    if (!ai.mem._aimErr || ai.m.time - ai.mem._aimErrT > 0.8) { ai.mem._aimErr = { x: (Math.random() - 0.5) * 2 * err, y: (Math.random() - 0.5) * 2 * err }; ai.mem._aimErrT = ai.m.time; }
    return { x: p.x + ai.mem._aimErr.x, y: p.y + ai.mem._aimErr.y };
  },
  clear(ai, s) { return ai.m.world.losClear(ai.k.x, ai.k.y, s.x, s.y); },
  lane(ai, x, y) { return ai.m.world.sweepClear(ai.k.x, ai.k.y, x, y, ai.k.r * 0.8); },
  // the power is worth using this tick (skill gated)
  roll(ai, p = 1) { return ai.tick && Math.random() < ai.P.powerIQ * p; },
  nearestGen(ai, pred = () => true) { let best = null, bd = Infinity; for (const g of ai.m.map.gens) { if (g.done || !pred(g)) continue; const d = dist(g.x, g.y, ai.k.x, ai.k.y); if (d < bd) { bd = d; best = g; } } return best; },
  hotGen(ai) { // the gen the bot believes is most valuable to cover
    let best = null, bs = -1;
    for (const [g, gi] of ai.per.gens) { if (g.done) continue; const sc = (gi.repairing && ai.m.time - gi.t < 15 ? 2 : 0) + gi.progress * 2 - dist(g.x, g.y, ai.k.x, ai.k.y) / (60 * M); if (sc > bs) { bs = sc; best = g; } }
    return best;
  },
};

// ---- Trapper: traps at loops, windows and generators -----------------------------
CTL.traps = {
  spots(ai) {
    if (ai.mem.trapSpots) return ai.mem.trapSpots;
    const m = ai.m, out = [];
    for (const w of m.map.windows) out.push({ x: w.x + w.nx * 1.3 * M, y: w.y + w.ny * 1.3 * M, w: 1.3 }, { x: w.x - w.nx * 1.3 * M, y: w.y - w.ny * 1.3 * M, w: 1.3 });
    for (const p of m.map.pallets) out.push({ x: p.x + p.nx * 1.2 * M, y: p.y + p.ny * 1.2 * M, w: 1.1 });
    for (const g of m.map.gens) out.push({ x: g.x + 2 * M, y: g.y, w: 0.8 }, { x: g.x - 2 * M, y: g.y, w: 0.8 });
    for (const s of out) s.grass = m.map.isGrass(s.x, s.y);
    return (ai.mem.trapSpots = out);
  },
  chase(ai, b, d) {
    const k = ai.k, pw = k.power;
    if (pw.setting) { k.input.rmb = d > 8 * M; return true; }
    return false;
  },
  patrol(ai) {
    const m = ai.m, k = ai.k, pw = k.power, P = ai.P, inp = k.input;
    if (pw.setting) { inp.rmb = true; ai.state = 'USING_POWER'; return true; }
    if (pw.picking) return true;
    // pick up spare traps lying around
    if (pw.carried < pw.maxCarry) {
      const t = m.traps.filter((q) => q.state === 'unset' && dist(q.x, q.y, k.x, k.y) < 14 * M).sort((a, b) => dist(a.x, a.y, k.x, k.y) - dist(b.x, b.y, k.x, k.y))[0];
      if (t && Math.random() < 0.3 + 0.7 * P.powerIQ) { if (dist(t.x, t.y, k.x, k.y) < 1.6 * M) { inp.eP = true; return true; } ai.steer.goTo(t.x, t.y, { arrive: 1.2 * M }); ai.state = 'USING_POWER'; return true; }
    }
    if (pw.carried <= 0) return false;
    // choose a spot near the generator we are heading to: windows/pallets of nearby loops, grass preferred
    const g = ai.goal?.target; if (!g || g.x === undefined) return false;
    if (!ai.mem.trapPlan || ai.m.time - ai.mem.trapPlan.t > 20 || ai.mem.trapPlan.done) {
      const cands = CTL.traps.spots(ai).filter((s) => dist(s.x, s.y, g.x, g.y) < 18 * M && !m.traps.some((t) => t.state === 'set' && dist(t.x, t.y, s.x, s.y) < 6 * M));
      const pick = cands.sort((a, b) => (b.w + (b.grass ? 0.6 * P.powerIQ : 0)) - (a.w + (a.grass ? 0.6 * P.powerIQ : 0)) + (Math.random() - 0.5) * (1 - P.powerIQ))[0];
      // decide once per plan whether this trap is worth the detour (skill gated)
      ai.mem.trapPlan = pick && Math.random() < 0.25 + 0.75 * P.powerIQ ? { ...pick, t: m.time } : { done: true, t: m.time };
    }
    const tp = ai.mem.trapPlan; if (tp.done) return false;
    if (m.time - tp.t > 12) { tp.done = true; return false; } // couldn't get there: drop the plan
    const dd = dist(k.x, k.y, tp.x, tp.y);
    if (dd < 2.0 * M || (dd < 3 * M && ai.steer.stuckT > 0.3)) { H.aimAt(ai, { x: tp.x + (tp.x - k.x), y: tp.y + (tp.y - k.y) }); inp.rmbP = true; inp.rmb = true; tp.done = true; ai.note('Setting a bear trap'); return true; }
    if (dd < 22 * M) { ai.steer.goTo(tp.x, tp.y, { arrive: 1.2 * M }); ai.state = 'USING_POWER'; return true; }
    return false;
  },
};

// ---- Hillbilly: chainsaw sprints down clear lanes, never into clutter ----------
CTL.chainsaw = {
  chase(ai, b, d) {
    const k = ai.k, pw = k.power, inp = k.input;
    if (pw.state === 'sprint') { const p = H.lead(ai, b, 0.4); H.aimAt(ai, p); inp.rmb = true; return true; }
    if (pw.state === 'revving') { const p = H.lead(ai, b, 0.6); H.aimAt(ai, p); inp.rmb = H.lane(ai, p.x, p.y) || pw.charge < 0.4; return true; }
    if ((pw.overheatT ?? 0) > 0 || pw.state !== 'idle') return false;
    if (d > 6 * M && d < 22 * M && b.visible && H.lane(ai, b.x, b.y) && H.roll(ai, 0.9)) { inp.rmb = true; H.aimAt(ai, b); return true; }
    return false;
  },
  travel(ai, x, y) {
    const k = ai.k, pw = k.power, inp = k.input, st = ai.steer;
    const p = st.path?.[st.idx]; if (!p || (pw.overheatT ?? 0) > 0 || (pw.heat ?? 0) > 0.6) return;
    if (dist(p.x, p.y, k.x, k.y) > 14 * M && H.lane(ai, p.x, p.y) && Math.random() < ai.P.powerIQ) { inp.rmb = true; H.aimAt(ai, p); }
  },
};

// ---- Wraith: cloak to travel and ambush, uncloak behind the target ------------
CTL.cloak = {
  chase(ai, b, d) {
    const pw = ai.k.power, inp = ai.k.input;
    if (pw.state === 'cloaked' && d < (5 + 4 * ai.P.powerIQ) * M && H.roll(ai, 1.2)) { inp.rmbP = true; ai.note('Uncloaking for the hit'); }
    if (pw.state === 'visible' && d > 18 * M && !b.visible && H.roll(ai, 0.3)) inp.rmbP = true;
    return false;
  },
  patrol(ai) { const pw = ai.k.power; if (pw.state === 'visible' && H.roll(ai, 0.15)) ai.k.input.rmbP = true; return false; },
  travel(ai) { const pw = ai.k.power; if (pw.state === 'visible' && H.roll(ai, 0.3)) ai.k.input.rmbP = true; },
};

// ---- Ghost Face: shroud, stalk from cover, mark, then one-hit -----------------
CTL.shroud = {
  chase(ai, b, d) {
    const pw = ai.k.power, inp = ai.k.input, s = b.s;
    if (pw.state === 'visible' && H.roll(ai, 0.6)) inp.rmbP = true;
    if (pw.shrouded && b.visible && d > 7 * M && d < 24 * M && !s.status.has('marked') && !s.status.has('exposed')) {
      // stalk while the target isn't looking at us (they'd reveal us)
      const looking = angleDiff(s.facing, Math.atan2(ai.k.y - s.y, ai.k.x - s.x)) < 0.7;
      if (!looking || Math.random() > ai.P.powerIQ) { inp.rmb = true; H.aimAt(ai, b); ai.state = 'USING_POWER'; ai.steer.stop(); return true; }
    }
    return false;
  },
  patrol(ai) { const pw = ai.k.power; if (pw.state === 'visible' && H.roll(ai, 0.5)) ai.k.input.rmbP = true; return false; },
};

// ---- Clown: gas thrown ahead of the target to cut loops; antidote to catch up -----
CTL.tonic = {
  chase(ai, b, d) {
    const pw = ai.k.power, inp = ai.k.input;
    if (pw.state === 'aiming') { const p = H.lead(ai, b, 0.7); H.aimAt(ai, p); ai.mem.aimT = (ai.mem.aimT || 0) + 1 / 60; inp.rmb = ai.mem.aimT < 0.3; return false; }
    ai.mem.aimT = 0;
    if (pw.type === 'antidote' && H.roll(ai, 0.5)) inp.eP = true; // default to tonic in chases
    if (pw.bottles > 0 && d > 3.5 * M && d < 14 * M && H.roll(ai, 0.35)) inp.rmb = true;
    return false;
  },
};

// ---- Executioner: punishment wave through walls, torment trails around loops ----
CTL.judgement = {
  chase(ai, b, d) {
    const pw = ai.k.power, inp = ai.k.input;
    if (pw.state === 'windup') { H.aimAt(ai, H.lead(ai, b, 0.9)); return true; }
    if (pw.state === 'normal' && d < 16 * M && d > 4 * M && H.roll(ai, 0.7)) inp.rmbP = true;
    else if (pw.state === 'punish' && d < 2.8 * M) inp.rmbP = true; // M1 range: drop the power and swing
    else if (pw.state === 'punish' && d < 15 * M && pw.cd('wave') <= 0 && H.roll(ai, 0.4)) { H.aimAt(ai, H.lead(ai, b, 0.9)); inp.lmbP = true; return true; }
    return false;
  },
  patrol(ai) { const pw = ai.k.power; if (pw.state === 'punish') ai.k.input.rmbP = true; return false; },
};

// ---- Huntress: hatchets on clean sightlines, reload at lockers ----------------
CTL.hatchets = {
  chase(ai, b, d) {
    const k = ai.k, pw = k.power, inp = k.input;
    if (pw.state === 'winding') {
      const want = clamp(d / (24 * M), 0.45, 1) * pw.maxWind; const p = H.lead(ai, b, d / (34 * M));
      H.aimAt(ai, p); ai.mem.windT = (ai.mem.windT || 0) + 1 / 60; inp.rmb = ai.mem.windT < want && H.clear(ai, b.s); if (!inp.rmb) ai.mem.windT = 0; return true;
    }
    ai.mem.windT = 0;
    if (pw.count > 0 && d > 4 * M && d < 26 * M && b.visible && H.clear(ai, b.s) && H.roll(ai, 0.3)) { inp.rmb = true; H.aimAt(ai, b); return true; }
    return false;
  },
  patrol(ai) {
    const m = ai.m, k = ai.k, pw = k.power; if (pw.count > 1) return false;
    const l = m.devices.filter((d) => d.kind === 'locker').sort((a, b) => dist(a.x, a.y, k.x, k.y) - dist(b.x, b.y, k.x, k.y))[0];
    if (!l) return false;
    if (dist(l.x, l.y, k.x, k.y) < 1.7 * M) { k.input.eP = true; ai.state = 'USING_POWER'; return true; }
    ai.steer.goTo(l.x, l.y, { arrive: 1.2 * M }); ai.state = 'REPOSITIONING'; return true;
  },
};

// ---- Legion: Frenzy into groups, chain between survivors, vault through loops ------
CTL.frenzy = {
  chase(ai, b, d) {
    const m = ai.m, k = ai.k, pw = k.power, inp = k.input, s = b.s;
    if (pw.state === 'ready' && d < 14 * M && H.roll(ai, 0.8)) inp.rmbP = true;
    if (pw.state !== 'frenzy') return false;
    // chain: never re-slash the same survivor; go for the nearest unslashed one
    let tgt = s;
    if (s === pw.lastHit || s.status.has('deepWoundFrenzy')) {
      const o = m.survivors.filter((q) => q.standing && q !== pw.lastHit && !q.status.has('deepWoundFrenzy') && dist(q.x, q.y, k.x, k.y) < 24 * M).sort((a, bb) => dist(a.x, a.y, k.x, k.y) - dist(bb.x, bb.y, k.x, k.y))[0];
      if (o) tgt = o; else return false;
    }
    const td = dist(tgt.x, tgt.y, k.x, k.y);
    ai.steer.goTo(tgt.x, tgt.y, { arrive: 0.3 * M });
    if (td < 2.3 * M && pw.slashT <= 0) { H.aimAt(ai, tgt); inp.lmbP = true; }
    const c = m.killerContext(k); if (c?.type === 'vault' && td < 8 * M) inp.spaceP = true;
    ai.state = 'USING_POWER';
    return true;
  },
};

// ---- Hag: traps at hooks/gens/loops, teleport to triggered phantoms ------------------
CTL.phantasm = {
  chase(ai, b, d) {
    const pw = ai.k.power, inp = ai.k.input;
    const t = pw.teleportTarget(ai.m); if (t && dist(t.x, t.y, b.x, b.y) < 6 * M && H.roll(ai, 1.2)) inp.eP = true;
    // trap loops mid-chase when the target is circling a structure
    if (pw.state === 'drawing') { inp.rmb = true; return true; }
    if (d > 10 * M && !b.visible && H.roll(ai, 0.15) && pw.traps.length < pw.maxTraps) { inp.rmb = true; return true; }
    return false;
  },
  patrol(ai) {
    const m = ai.m, k = ai.k, pw = k.power, inp = k.input;
    if (pw.teleportTarget(m) && H.roll(ai, 1.5)) { inp.eP = true; ai.note('Teleporting to a triggered Phantasm'); return true; }
    if (pw.state === 'drawing') { inp.rmb = true; ai.steer.stop(); ai.state = 'USING_POWER'; return true; }
    if (pw.traps.length >= pw.maxTraps) return false;
    // trap the approach to the goal generator / a hook, spaced out
    const g = ai.goal?.target; if (!g || g.x === undefined) return false;
    const d = dist(k.x, k.y, g.x, g.y);
    if (d < 7 * M && d > 2 * M && !pw.traps.some((t) => dist(t.x, t.y, k.x, k.y) < 6 * M) && H.roll(ai, 0.5)) { inp.rmb = true; ai.steer.stop(); ai.state = 'USING_POWER'; return true; }
    return false;
  },
};

// ---- Deathslinger: aim from mid range, fire on clean lines, reel and strike -------
CTL.redeemer = {
  chase(ai, b, d) {
    const k = ai.k, pw = k.power, inp = k.input, s = b.s;
    if (pw.state === 'reel') { if (dist(s.x, s.y, k.x, k.y) < 2.6 * M) { inp.lmbP = true; inp.lmb = true; } H.aimAt(ai, pw.speared || s); ai.steer.goTo(k.x - Math.cos(k.facing) * 2 * M, k.y - Math.sin(k.facing) * 2 * M); return true; }
    if (pw.state === 'aiming') {
      const p = H.lead(ai, b, d / (55 * M)); H.aimAt(ai, p); inp.rmb = true; ai.mem.aimT = (ai.mem.aimT || 0) + 1 / 60;
      // fire when the line is clean and the aim has settled (experts wait for the commit)
      if (ai.mem.aimT > 0.6 - 0.25 * ai.P.powerIQ && H.clear(ai, s) && d < pw.range * 0.95) { inp.lmbP = true; ai.mem.aimT = 0; }
      return true;
    }
    ai.mem.aimT = 0;
    if (pw.loaded && pw.state === 'idle' && d > 3 * M && d < pw.range * 0.9 && b.visible && H.clear(ai, s) && H.roll(ai, 0.6)) { inp.rmb = true; H.aimAt(ai, b); return true; }
    return false;
  },
};

// ---- Dredge: locker hops toward activity, Remnant returns, Nightfall pushes ----------
CTL.nightfall = {
  travel(ai, x, y) {
    const k = ai.k, pw = k.power, inp = k.input;
    if (pw.state === 'idle' && pw.tokens > 0 && pw.cd('tp') <= 0 && H.roll(ai, 0.35)) inp.rmbP = true;
    if (pw.state === 'gloaming') CTL.nightfall.pickLocker(ai, x, y);
  },
  pickLocker(ai, x, y) {
    const k = ai.k, pw = k.power, inp = k.input;
    const l = pw.lockers.filter((q) => !q.data.locked).sort((a, b) => dist(a.x, a.y, x, y) - dist(b.x, b.y, x, y))[0];
    if (!l || dist(l.x, l.y, x, y) > dist(k.x, k.y, x, y) * 0.7) { inp.eP = true; return; }
    k.input.aim = Math.atan2(l.y - k.y, l.x - k.x); inp.aimDist = dist(l.x, l.y, k.x, k.y) / 2.2;
    if (pw.target === l) inp.rmbP = true;
  },
  chase(ai, b, d) {
    const pw = ai.k.power, inp = ai.k.input;
    if (pw.state === 'gloaming') { if (d < 12 * M) inp.eP = true; else CTL.nightfall.pickLocker(ai, b.x, b.y); return true; }
    if (pw.state !== 'idle') return true;
    if (d > 28 * M && pw.tokens > 0 && pw.cd('tp') <= 0 && H.roll(ai, 0.4)) inp.rmbP = true;
    return false;
  },
  patrol(ai) {
    const pw = ai.k.power;
    if (pw.state === 'gloaming') { const g = H.hotGen(ai) || ai.goal?.target; if (g) CTL.nightfall.pickLocker(ai, g.x, g.y); if (pw.gloamT > 3) ai.k.input.eP = true; return true; }
    return pw.state !== 'idle';
  },
};

// ---- Knight: guards across survivors' escape routes and onto generators -------------
CTL.guardia = {
  chase(ai, b, d) {
    const k = ai.k, pw = k.power, inp = k.input;
    if (pw.state === 'drawing') {
      // draw the patrol line toward / past the target, then summon
      ai.mem.knightDraw = (ai.mem.knightDraw || 0) + 1 / 60; H.aimAt(ai, b); inp.mx = Math.cos(k.facing); inp.my = Math.sin(k.facing);
      if (ai.mem.knightDraw > 0.9 + 0.6 * ai.P.powerIQ || pw.pathLen?.() > d) inp.rmbP = true;
      return true;
    }
    if (pw.state === 'idle' && !pw.guard && pw.cd('power') <= 0 && d > 6 * M && d < 20 * M && H.roll(ai, 0.5)) { inp.rmbP = true; H.aimAt(ai, b); ai.mem.knightDraw = 0; return true; }
    return false;
  },
  patrol(ai) {
    const k = ai.k, pw = k.power, inp = k.input;
    if (pw.state === 'drawing') { ai.mem.knightDraw = (ai.mem.knightDraw || 0) + 1 / 60; if (ai.mem.knightDraw > 1.6) inp.rmbP = true; return false; }
    // cycle to the Jailer for generator patrols when idle
    if (pw.state === 'idle' && !pw.guard && pw.cd('power') <= 0) {
      const g = ai.goal?.target; if (g && g.x !== undefined && dist(g.x, g.y, k.x, k.y) < 14 * M && H.roll(ai, 0.4)) {
        if (pw.type?.id !== 'jailer' && Math.random() < ai.P.powerIQ) inp.eP = true;
        else { H.aimAt(ai, g); inp.rmbP = true; ai.mem.knightDraw = 0; }
      }
    }
    return false;
  },
};

// ---- Cenobite: steer chains around cover, manage the box ----------------------
CTL.lament = {
  chase(ai, b, d) {
    const pw = ai.k.power, inp = ai.k.input;
    if (pw.chain) { H.aimAt(ai, H.lead(ai, b, 0.2)); inp.rmb = true; return true; }
    if (pw.state === 'idle' && pw.cd('chain') <= 0 && d > 4 * M && d < 20 * M && b.visible && H.roll(ai, 0.55)) { inp.rmb = true; H.aimAt(ai, b); return true; }
    return false;
  },
  patrol(ai) {
    const m = ai.m, k = ai.k, pw = k.power, inp = k.input;
    if (m.survivors.some((s) => s.action?.type === 'solveBox') && pw.state === 'idle' && H.roll(ai, 1.5)) { inp.eP = true; ai.note('Summoning to the box solver'); return true; }
    if (pw.box && dist(pw.box.x, pw.box.y, k.x, k.y) < 1.7 * M && ai.P.powerIQ > 0.5) { inp.spaceP = true; return true; }
    return false;
  },
};

// ---- Mastermind: bounds on open lanes, chain the second bound -----------------------
CTL.virulent = {
  chase(ai, b, d) {
    const pw = ai.k.power, inp = ai.k.input;
    if (pw.state === 'charging') { H.aimAt(ai, H.lead(ai, b, 0.45)); inp.rmb = pw.charge < 1.0; return true; }
    if (pw.state === 'between') { if (d < 13 * M && b.visible && H.lane(ai, b.x, b.y)) { H.aimAt(ai, H.lead(ai, b, 0.5)); inp.rmbP = true; } return true; }
    if (pw.state === 'bound' || pw.state === 'recover') return true;
    if (pw.state === 'idle' && pw.tokens > 0 && d > 3 * M && d < 11 * M && b.visible && H.lane(ai, b.x, b.y) && H.roll(ai, 0.7)) { inp.rmb = true; H.aimAt(ai, b); return true; }
    return false;
  },
};

// ---- Houndmaster: Chase Command down clean lines, Search Command toward activity ----
CTL.hound = {
  chase(ai, b, d) {
    const pw = ai.k.power, inp = ai.k.input, dog = pw.dog;
    if (pw.state === 'plotting') { H.aimAt(ai, H.lead(ai, b, 0.8)); inp.rmb = pw.plot < 0.9; return true; }
    if (dog?.state === 'follow' && pw.cd('dog') <= 0 && d > 4 * M && d < 18 * M && b.visible && H.clear(ai, b.s) && H.roll(ai, 0.5)) { inp.rmb = true; H.aimAt(ai, b); return true; }
    return false;
  },
  patrol(ai) {
    const pw = ai.k.power, inp = ai.k.input, k = ai.k;
    if (pw.dog?.state === 'follow' && pw.cd('dog') <= 0 && H.roll(ai, 0.12)) {
      const g = H.hotGen(ai) || ai.goal?.target;
      if (g && g.x !== undefined && dist(g.x, g.y, k.x, k.y) < 40 * M) { H.aimAt(ai, g); inp.eP = true; }
    }
    return false;
  },
};

// ---- Lich: pick the spell for the moment ---------------------------------------
CTL.vecna = {
  chase(ai, b, d) {
    const m = ai.m, k = ai.k, pw = k.power, inp = k.input;
    if (pw.state !== 'idle') return false;
    const pick = (i) => { inp.slot = i + 1; return pw.sel === i; };
    if (pw.ready('fotd') && d < 16 * M && d > 4 * M && H.roll(ai, 0.5)) { if (pick(0)) { H.aimAt(ai, H.lead(ai, b, 0.6)); inp.rmbP = true; } return false; }
    const pal = m.map.pallets.find((q) => q.state === 'down' && dist(q.x, q.y, k.x, k.y) < 7 * M && q.sideOf(k) !== q.sideOf(b.s));
    if (pw.ready('magehand') && pal && H.roll(ai, 0.8)) { if (pick(2)) { H.aimAt(ai, pal); inp.rmbP = true; } return false; }
    if (pw.ready('fly') && d > 10 * M && d < 26 * M && H.roll(ai, 0.3)) { if (pick(1)) inp.rmbP = true; }
    return false;
  },
  patrol(ai) { const pw = ai.k.power, inp = ai.k.input; if (pw.state === 'idle' && pw.ready('sphere') && H.roll(ai, 0.05)) { inp.slot = 4; if (pw.sel === 3) inp.rmbP = true; } return false; },
  travel(ai) { const pw = ai.k.power, inp = ai.k.input; if (pw.state === 'idle' && pw.ready('fly') && H.roll(ai, 0.15)) { inp.slot = 2; if (pw.sel === 1) inp.rmbP = true; } },
};

// Singularity and Cannibal controllers live with their reworked powers (see below).

// ---- Singularity: biopods on walls overlooking objectives, pod scouting, tag + teleport ----
const podActive = (p, m) => !p.dead && (p.data.disabledUntil || 0) <= m.time;
CTL.quantum = {
  // a wall spot (raycast) in 22 m whose surface overlooks a generator / loop
  podShot(ai, focus) {
    const m = ai.m, k = ai.k, pw = k.power; let best = null, bs = -Infinity;
    for (let i = 0; i < 24; i++) {
      const a = i / 24 * Math.PI * 2, ex = k.x + Math.cos(a) * 21 * M, ey = k.y + Math.sin(a) * 21 * M;
      const h = m.world.firstHit(k.x, k.y, ex, ey, 0.15 * M, (q) => q.blocksLOS); if (!h || h.t < 0.12) continue;
      const x = k.x + (ex - k.x) * h.t - Math.cos(a) * 0.35 * M, y = k.y + (ey - k.y) * h.t - Math.sin(a) * 0.35 * M;
      if (m.map.gens.some((g) => dist(g.x, g.y, x, y) < 2.5 * M) || m.map.windows.some((w) => dist(w.x, w.y, x, y) < 2.5 * M) || pw.pods.some((p) => dist(p.x, p.y, x, y) < 7 * M)) continue;
      let sc = -dist(x, y, focus.x, focus.y) / M;
      sc += m.map.gens.filter((g) => !g.done && dist(g.x, g.y, x, y) < 16 * M && m.world.losClear(x, y, g.x, g.y)).length * 6 * ai.P.powerIQ;
      if (sc > bs) { bs = sc; best = { a, x, y }; }
    }
    return best;
  },
  shoot(ai, a) { const k = ai.k; k.input.aim = a; k.input.rmb = true; ai.mem.podShot = { a, t: ai.m.time }; },
  always(ai, g) {
    const m = ai.m, k = ai.k, pw = k.power, inp = k.input, P = ai.P;
    if (pw.state === 'teleporting') { ai.state = 'USING_POWER'; ai.steer.stop(); return true; }
    if (pw.state === 'aiming') { // finish the pod shot (hold ≥0.15 s on the chosen angle, then release)
      const sh = ai.mem.podShot; if (sh) inp.aim = sh.a; inp.rmb = pw.charge < 0.22; ai.steer.stop(); ai.state = 'USING_POWER'; return true;
    }
    if (pw.state !== 'control') { ai.mem.ctrlT = 0; delete inp.aimX; delete inp.aimY; return false; }
    ai.state = 'USING_POWER'; ai.steer.stop();
    ai.mem.ctrlT = (ai.mem.ctrlT || 0) + 1 / 60;
    if (pw.ctrlT < 1 / 30) ai.mem.ctrlTotal = 0; ai.mem.ctrlTotal = (ai.mem.ctrlTotal || 0) + 1 / 60;
    const c = pw.ctrl;
    // anything urgent pulls us out of the pod
    const close = ai.per.known(0.6).find((b) => b.visible && dist(b.x, b.y, k.x, k.y) < 9 * M && b.s.standing);
    if (!c || g?.type === 'CARRY' || g?.type === 'PICKUP' || (close && m.world.losClear(k.x, k.y, close.x, close.y)) || ai.mem.ctrlT > 4 + 4 * P.powerIQ || ai.mem.ctrlTotal > 7 + 5 * P.powerIQ) { inp.eP = true; ai.mem.podScoutT = m.time; return true; }
    if (!podActive(c, m)) {
      if (Math.random() < 0.5 + 0.5 * P.powerIQ) { inp.lmb = true; ai.note('Destroying a disabled biopod'); }
      else inp.eP = true;
      return true;
    }
    // look for someone this pod can see; aim error makes low-skill locks wobble off target
    let tgt = null, bd = Infinity;
    for (const s of m.survivors) {
      if (!s.standing || dist(s.x, s.y, c.x, c.y) > 20 * M || !m.world.losClear(c.x, c.y, s.x, s.y)) continue;
      const v = (s.status.has('slipstream') ? -6 * M : 0) + dist(s.x, s.y, c.x, c.y) + (s.action?.type === 'repair' ? -4 * M : 0);
      if (v < bd) { bd = v; tgt = s; }
    }
    if (!tgt) { if (ai.mem.ctrlT > 1.2 + Math.random() * 2) { if ((ai.mem.cycles = (ai.mem.cycles || 0) + 1) < 3 && pw.pods.length > 1) { inp.cycleP = true; ai.mem.ctrlT = 0.5; } else { inp.eP = true; ai.mem.cycles = 0; ai.mem.podScoutT = m.time; } } return true; }
    if (!ai.mem.aimErr || m.time - (ai.mem.aimErrT || 0) > 0.5) { const e = (1 - P.aim) * 2.2 * M; ai.mem.aimErr = { x: (Math.random() - 0.5) * e, y: (Math.random() - 0.5) * e }; ai.mem.aimErrT = m.time; }
    inp.aimX = tgt.x + tgt.vx * 0.1 + ai.mem.aimErr.x; inp.aimY = tgt.y + tgt.vy * 0.1 + ai.mem.aimErr.y;
    if (!tgt.status.has('slipstream')) ai.mem.ctrlT = Math.min(ai.mem.ctrlT, 2.5);
    // locked on a Slipstreamed survivor: teleport when it's worth it (not right next to us already)
    const L = pw.lock;
    if (L && L.s === tgt && tgt.status.has('slipstream') && L.t >= 0.8 && dist(k.x, k.y, tgt.x, tgt.y) > 12 * M && !tgt.status.has('hooked') && Math.random() < 0.15 + 0.6 * P.powerIQ) { inp.lmbP = true; ai.note(`Quantum Instantiation to ${tgt.name}`); }
    return true;
  },
  chase(ai, b, d) {
    const m = ai.m, k = ai.k, pw = k.power, inp = k.input, s = b.s, P = ai.P;
    if (pw.overheatT > 0 || pw.state !== 'idle' || pw.cd('reload') > 0) return false;
    // direct shot: tags, or teleports straight onto an already Slipstreamed target across a loop
    if (b.visible && d > 4 * M && d < 18 * M && H.clear(ai, s) && H.roll(ai, s.status.has('slipstream') ? (d > 8 * M ? 0.6 : 0.1) : 0.35)) {
      const p = H.lead(ai, b, d / (50 * M) + 0.05); const a = Math.atan2(p.y - k.y, p.x - k.x);
      if (m.world.sweepClear(k.x, k.y, p.x, p.y, 0.2 * M)) { CTL.quantum.shoot(ai, a); return true; }
    }
    // lost sight: check a pod that overlooks where they went
    if (!b.visible && d > 10 * M && H.roll(ai, 0.25)) {
      const pod = pw.pods.filter((p) => podActive(p, m) && dist(p.x, p.y, b.x, b.y) < 18 * M).sort((a, q) => dist(a.x, a.y, b.x, b.y) - dist(q.x, q.y, b.x, b.y))[0];
      if (pod) { inp.aimX = pod.x; inp.aimY = pod.y; inp.eP = true; ai.mem.ctrlT = 1.5; ai.note('Checking a biopod for the lost survivor'); return true; }
    }
    return false;
  },
  patrol(ai) {
    const m = ai.m, k = ai.k, pw = k.power, inp = k.input, P = ai.P;
    if (pw.overheatT > 0 || pw.state !== 'idle' || k.carrying) return false;
    const pods = pw.pods.filter((p) => podActive(p, m));
    // re-seed the pod net around the area we're heading to
    const g = ai.goal?.target; const focus = g && g.x !== undefined ? g : H.hotGen(ai);
    if (focus && pw.cd('reload') <= 0 && pods.filter((p) => dist(p.x, p.y, focus.x, focus.y) < 18 * M).length < 2 && dist(focus.x, focus.y, k.x, k.y) < 24 * M && m.time - (ai.mem.podTry || 0) > 2.5 - 1.5 * P.powerIQ) {
      ai.mem.podTry = m.time;
      if (Math.random() < 0.3 + 0.7 * P.powerIQ) { const sh = CTL.quantum.podShot(ai, focus); if (sh) { CTL.quantum.shoot(ai, sh.a); ai.note('Shooting a biopod onto a wall'); return true; } }
    }
    // scout through the pod network now and then
    if (pods.length >= 2 && m.time - (ai.mem.podScoutT || 0) > 14 - 8 * P.powerIQ && H.roll(ai, 0.2)) {
      const hot = H.hotGen(ai) || focus; const pod = hot ? pods.sort((a, b) => dist(a.x, a.y, hot.x, hot.y) - dist(b.x, b.y, hot.x, hot.y))[0] : pods[0];
      inp.aimX = pod.x; inp.aimY = pod.y; inp.eP = true; ai.mem.podScoutT = m.time; ai.mem.ctrlT = 0; ai.mem.cycles = 0; ai.note('Scouting through a biopod');
      return true;
    }
    return false;
  },
  travel(ai, x, y) {
    // a Slipstreamed survivor near the destination + a pod near them = free teleport
    const m = ai.m, k = ai.k, pw = k.power; if (pw.state !== 'idle' || pw.overheatT > 0 || k.carrying) return;
    const s = ai.per.known(0.4).map((b) => b.s).find((q) => q.standing && q.status.has('slipstream') && dist(q.x, q.y, x, y) < 14 * M);
    if (!s || !H.roll(ai, 0.5)) return;
    const pod = pw.pods.find((p) => podActive(p, m) && dist(p.x, p.y, s.x, s.y) < 18 * M);
    if (pod) { k.input.aimX = pod.x; k.input.aimY = pod.y; k.input.eP = true; ai.mem.ctrlT = 0; }
  },
};

// ---- Cannibal: short-range sweeps at tight loops and groups, rev-cancel reads, dash to finish ----
CTL.bubba = {
  ahead(ai, dir, d = 1.6 * M) { const k = ai.k; return !ai.m.world.sweepClear(k.x, k.y, k.x + Math.cos(dir) * d, k.y + Math.sin(dir) * d, k.r * 0.8); },
  chase(ai, b, d) {
    const m = ai.m, k = ai.k, pw = k.power, inp = k.input, P = ai.P, s = b.s;
    if (pw.state === 'tantrum') { ai.steer.stop(); return true; }
    if (pw.state === 'revving') {
      // keep closing in at rev speed; release the full rev only when the target is in reach
      ai.steer.goTo(b.x, b.y, { arrive: 0.3 * M, repath: 0.25 }); H.aimAt(ai, H.lead(ai, b, 0.5));
      const tooFar = d > (9 + 2 * P.powerIQ) * M || b.conf < 0.3;
      if (pw.rev < 1) { inp.rmb = !(tooFar && Math.random() < 0.3 + 0.7 * P.powerIQ); if (!inp.rmb) ai.note('Cancelled the rev'); return true; }
      const inReach = b.visible && d < (3.8 + 1.2 * P.powerIQ) * M && H.lane(ai, b.x, b.y);
      const limit = 2.85 - (1 - P.powerIQ) * 0.15 + (Math.random() < P.mistakes * 0.05 ? 1 : 0); // beginners sometimes over-rev
      inp.rmb = !inReach && pw.revHeld < limit && !tooFar;
      if (!inp.rmb && !inReach) ai.note(tooFar ? 'Rev wasted — target too far' : 'Released the rev to avoid a tantrum');
      return true;
    }
    if (pw.state === 'sweep') {
      const p = H.lead(ai, b, 0.35); H.aimAt(ai, p);
      // stop before ramming a wall (tantrum) unless the target is right there
      const wall = CTL.bubba.ahead(ai, pw.dir, (1.2 + 0.8 * P.powerIQ) * M);
      if ((wall && d > 2.2 * M && Math.random() < P.powerIQ) || d > 12 * M) inp.rmbP = true; // stop the sweep
      if (pw.charges >= 1 && d > 2.4 * M && d < (4 + 1.5 * P.powerIQ) * M && b.visible && H.lane(ai, b.x, b.y) && H.roll(ai, 0.5)) { inp.lmbP = true; ai.note('Chainsaw dash'); }
      return true;
    }
    if (pw.state !== 'idle' || pw.charges < 1) return false;
    // when to rev: close, in sight, and (skilled) the target is stuck at a tight tile / pallet
    // or a second survivor is close enough to share the sweep
    const others = ai.per.known(0.6).filter((o) => o.s !== s && o.s.standing && dist(o.x, o.y, b.x, b.y) < 4 * M).length;
    const pal = m.map.pallets.some((q) => q.state !== 'broken' && dist(q.x, q.y, b.x, b.y) < 3 * M);
    // pre-rev: start the rev while closing in (even around a loop) so the sweep is ready on contact
    const want = b.conf > 0.5 && d < (6 + 3 * P.powerIQ + (others ? 1.5 : 0)) * M && d > 1.8 * M;
    if (want && H.roll(ai, (pal || others ? 0.9 : 0.35 + 0.4 * P.powerIQ))) { inp.rmb = true; H.aimAt(ai, b); ai.note(others ? 'Revving on a group' : 'Pre-revving the chainsaw'); return false; }
    return false;
  },
  patrol(ai) {
    const pw = ai.k.power; if (pw.state === 'tantrum') { ai.steer.stop(); return true; }
    if (pw.state === 'revving') { ai.k.input.rmb = false; } // never sit in the rev
    if (pw.state === 'sweep') ai.k.input.rmbP = true;
    return false;
  },
};

// ---- Skull Merchant: drones on contested generators and on the chase loop, recall to stalk ----
CTL.drones = {
  always(ai) { const pw = ai.k.power; if (pw.state === 'deploying') { ai.k.input.rmb = true; H.aimAt(ai, ai.mem.droneAt || ai.k); } return false; },
  deployAt(ai, p) { const k = ai.k; ai.mem.droneAt = { x: p.x, y: p.y }; H.aimAt(ai, p); k.input.rmb = true; },
  chase(ai, b, d) {
    const m = ai.m, pw = ai.k.power;
    if (pw.state !== 'idle' || pw.cd('deploy') > 0) return false;
    const covered = pw.drones.some((q) => pw.active(q, m) && dist(q.x, q.y, b.x, b.y) < 9 * M);
    if (!covered && b.visible && d < 10 * M && d > 3 * M && H.roll(ai, 0.1 + 0.4 * ai.P.powerIQ)) { CTL.drones.deployAt(ai, H.lead(ai, b, 0.8)); ai.note('Drone on the chase loop'); }
    return false;
  },
  patrol(ai) {
    const m = ai.m, k = ai.k, pw = k.power;
    if (pw.state !== 'idle' || k.carrying) return false;
    const g = ai.goal?.target?.x !== undefined ? ai.goal.target : H.hotGen(ai);
    if (g && pw.cd('deploy') <= 0 && dist(g.x, g.y, k.x, k.y) < 10 * M && !pw.drones.some((q) => pw.active(q, m) && dist(q.x, q.y, g.x, g.y) < 12 * M) && H.roll(ai, 0.15 + 0.55 * ai.P.powerIQ)) {
      // low-skill bots drop drones roughly where they stand instead of over the generator
      const p = Math.random() < ai.P.powerIQ ? g : { x: k.x + (Math.random() - 0.5) * 8 * M, y: k.y + (Math.random() - 0.5) * 8 * M };
      CTL.drones.deployAt(ai, p); ai.note('Drone over a generator'); return false;
    }
    return false;
  },
  travel(ai, x, y) {
    // recall a nearby drone to go Undetectable before arriving at a contested spot
    const m = ai.m, k = ai.k, pw = k.power; if (pw.state !== 'idle' || k.status.has('undetectable')) return;
    const dd = dist(k.x, k.y, x, y); if (dd > 40 * M || dd < 14 * M) return;
    const q = pw.drones.find((d) => dist(d.x, d.y, k.x, k.y) < 20 * M && dist(d.x, d.y, x, y) > 16 * M);
    if (q && pw.drones.length >= 3 && H.roll(ai, 0.15)) { H.aimAt(ai, q); k.input.eP = true; ai.note('Recalling a drone to sneak up'); }
  },
};

// ---- Blight: rush down lanes, slam a wall next to the target, lethal rush + special attack ----
CTL.rush = {
  slamSpot(ai, s) { // a wall the bot can bounce off close to the target (within ~70° of the rush)
    const m = ai.m, k = ai.k, pw = k.power; let best = null, bs = Infinity;
    for (let i = -4; i <= 4; i++) {
      const a = pw.dir + i * 0.3, ex = k.x + Math.cos(a) * 3.5 * M, ey = k.y + Math.sin(a) * 3.5 * M;
      const h = m.world.firstHit(k.x, k.y, ex, ey, k.r * 0.8); if (!h) continue;
      const c = Math.abs(i) + dist(ex, ey, s.x, s.y) / M * 0.2; if (c < bs) { bs = c; best = a; }
    }
    return best;
  },
  chase(ai, b, d) {
    const m = ai.m, k = ai.k, pw = k.power, inp = k.input, P = ai.P, s = b.s;
    if (pw.state === 'fatigue') return false;
    if (pw.state === 'rush') {
      const p = H.lead(ai, b, Math.min(0.6, d / (9.2 * M)));
      if (pw.lethal) { H.aimAt(ai, p); if (d < 2.8 * M && b.visible) { inp.lmbP = true; } return true; }
      // normal rush: bumping the survivor wastes it → slam a wall close to them instead (skill)
      if (d < (5 + 4 * P.powerIQ) * M && pw.tokens >= 1) {
        if (ai.mem.slamA === undefined || m.time - (ai.mem.slamT || 0) > 0.3) { ai.mem.slamA = Math.random() < 0.4 + 0.6 * P.powerIQ ? CTL.rush.slamSpot(ai, s) : null; ai.mem.slamT = m.time; }
        if (ai.mem.slamA !== null) { inp.aim = ai.mem.slamA; return true; }
      }
      H.aimAt(ai, p); return true;
    }
    if (pw.state === 'window') {
      if (pw.tokens >= 1 && (d < 16 * M || pw.tokens >= 2) && (b.visible || b.conf > 0.5)) { const p = H.lead(ai, b, d / (9.2 * M)); H.aimAt(ai, p); inp.rmbP = true; ai.note('Lethal rush'); }
      return true;
    }
    if (pw.state === 'special') return true;
    if (pw.state !== 'idle' || pw.tokens < 2) return false;
    if (b.visible && d > 7 * M && d < 26 * M && H.roll(ai, 0.7)) {
      const p = H.lead(ai, b, d / (9.2 * M) * 0.6);
      if (H.lane(ai, p.x, p.y) || Math.random() > P.powerIQ) { H.aimAt(ai, p); inp.rmbP = true; }
    }
    return false;
  },
  travel(ai, x, y) {
    const k = ai.k, pw = k.power, st = ai.steer;
    if (pw.state === 'rush') { const p = st.path?.[st.idx] || { x, y }; H.aimAt(ai, p); if (dist(k.x, k.y, x, y) < 8 * M) k.input.aim = pw.dir; return; }
    if (pw.state === 'window') { if (pw.tokens >= 2) { const p = st.path?.[st.idx] || { x, y }; H.aimAt(ai, p); k.input.rmbP = true; } return; }
    const p = st.path?.[st.idx]; if (!p || pw.state !== 'idle' || pw.tokens < 4) return;
    if (dist(p.x, p.y, k.x, k.y) > 12 * M && H.lane(ai, p.x, p.y) && H.roll(ai, 0.5)) { H.aimAt(ai, p); k.input.rmbP = true; }
  },
};

// ---- Nurse: predict where the survivor will be when the charge ends and blink there ----
CTL.blink = {
  // one blink plan per charge: { x, y, s } — re-aimed while the survivor stays tracked
  always(ai, g) {
    const k = ai.k, pw = k.power, inp = k.input, P = ai.P;
    if (pw.state !== 'charging') return false;
    const plan = ai.mem.blinkPlan; if (!plan) { inp.rmb = false; return true; }
    if (plan.s) {
      const b = ai.per.belief(plan.s);
      if (b.conf > 0.3) {
        const max = (pw.blinks ? 12 : 20) * M, rate = (max - 1.5 * M) / (pw.blinks ? 1.2 : 2);
        const left = Math.max(0, (dist(k.x, k.y, b.x, b.y) - pw.blinkDist) / rate);
        const p = H.lead(ai, b, left + 0.12); plan.x = p.x; plan.y = p.y;
      }
    }
    H.aimAt(ai, plan); ai.steer.stop();
    const need = dist(k.x, k.y, plan.x, plan.y) - (plan.s ? 0.9 : 1.5) * M;
    inp.rmb = pw.blinkDist < need && pw.blinkDist < (pw.blinks ? 12 : 20) * M - 2;
    if (!inp.rmb) ai.mem.blinkPlan = null;
    return true;
  },
  start(ai, x, y, s = null) { ai.mem.blinkPlan = { x, y, s }; ai.k.input.rmb = true; H.aimAt(ai, { x, y }); },
  chase(ai, b, d) {
    const m = ai.m, k = ai.k, pw = k.power, inp = k.input, P = ai.P;
    if (pw.state === 'fatigue') return false;
    if (pw.state === 'chain') {
      ai.steer.goTo(b.x, b.y, { arrive: 0.3 * M });
      if ((b.visible || b.conf > 0.8) && d < 2.7 * M) { H.aimAt(ai, b); inp.lmbP = true; inp.lmb = true; return true; }
      if (pw.tokens >= 1 && d > 3 * M && d < 13 * M && b.conf > 0.5 && H.roll(ai, 1.2)) CTL.blink.start(ai, b.x, b.y, b.s);
      return true;
    }
    if (pw.state !== 'idle' || pw.tokens < 1) return false;
    // blink when the target is out of reach or behind a wall — not when a basic hit is coming
    const ok = b.visible ? d > 5 * M && d < 21 * M : b.conf > 0.55 && d > 4 * M && d < 15 * M;
    if (ok && H.roll(ai, b.visible ? 0.8 : 0.4 * P.predict)) { CTL.blink.start(ai, b.x, b.y, b.s); return true; }
    return false;
  },
  travel(ai, x, y) {
    const k = ai.k, pw = k.power; const d = dist(k.x, k.y, x, y);
    if (pw.state === 'chain' && pw.tokens >= 1 && d > 10 * M) { CTL.blink.start(ai, x, y); return; }
    if (pw.state === 'idle' && pw.tokens >= 2 && d > 12 * M && H.roll(ai, 0.5)) CTL.blink.start(ai, x, y);
  },
};

// ---- Unknown: UVX at the target (bank shots off walls), hallucinations on gens, teleports ----
CTL.uvx = {
  chase(ai, b, d) {
    const m = ai.m, k = ai.k, pw = k.power, inp = k.input, P = ai.P;
    if (pw.state === 'charging') { H.aimAt(ai, H.lead(ai, b, d / (35 * M) + 0.1)); inp.rmb = pw.charge < 1.02; return false; }
    if (pw.state !== 'idle' || pw.cd('uvx') > 0) return false;
    const weak = b.s.status.has('weakened');
    if (b.visible && d > 3.5 * M && d < 18 * M && H.clear(ai, b.s) && H.roll(ai, weak ? 0.7 : 0.4)) { inp.rmb = true; H.aimAt(ai, b); }
    return false;
  },
  patrol(ai) {
    const m = ai.m, k = ai.k, pw = k.power;
    if (pw.state !== 'idle' || pw.cd('hal') > 0) return false;
    const g = H.nearestGen(ai); if (!g || dist(g.x, g.y, k.x, k.y) > 4 * M) return false;
    if (!pw.hallucinations.some((h) => dist(h.x, h.y, g.x, g.y) < 15 * M) && H.roll(ai, 0.6)) { k.input.eP = true; ai.note('Left a hallucination at a generator'); }
    return false;
  },
  travel(ai, x, y) {
    const k = ai.k, pw = k.power; if (pw.state !== 'idle' || pw.cd('tp') > 0) return;
    const h = pw.hallucinations.filter((q) => dist(q.x, q.y, x, y) < 12 * M).sort((a, b) => dist(a.x, a.y, x, y) - dist(b.x, b.y, x, y))[0];
    if (h && dist(k.x, k.y, x, y) > 28 * M && H.roll(ai, 0.6)) { H.aimAt(ai, h); k.input.cycleP = true; ai.note('Teleporting to a hallucination'); }
  },
};

// ---- Nemesis: tentacle at the edge of basic range, through pallets at MR 2+ ----
CTL.tentacle = {
  chase(ai, b, d) {
    const m = ai.m, k = ai.k, pw = k.power, inp = k.input, P = ai.P;
    if (pw.state === 'charging') { H.aimAt(ai, H.lead(ai, b, 0.3)); inp.rmb = pw.charge < 0.36 + 0.15 * (1 - P.powerIQ); return false; }
    if (pw.state !== 'idle' || pw.cd('tentacle') > 0) return false;
    const reach = pw.reach - 0.4 * M;
    const palletInWay = !H.clear(ai, b.s) ? false : m.map.pallets.some((q) => q.state === 'down' && dist(q.x, q.y, (k.x + b.x) / 2, (k.y + b.y) / 2) < d / 2);
    if (b.visible && d > 2.2 * M && d < reach && (H.lane(ai, b.x, b.y) || (palletInWay && pw.mr >= 2)) && H.roll(ai, 0.8)) { inp.rmb = true; H.aimAt(ai, b); }
    return false;
  },
};

// ---- Ghoul: leap to latch, leap again to grab; cling off walls to cut corners ----
CTL.kagune = {
  chase(ai, b, d) {
    const m = ai.m, k = ai.k, pw = k.power, inp = k.input, P = ai.P;
    if (pw.state === 'leap') return true;
    if (pw.state === 'latch') { const s = pw.latchedOn; if (s && pw.tokens >= 1 && pw.winT < 1.6 - 0.8 * P.powerIQ) { H.aimAt(ai, H.lead(ai, ai.per.belief(s), 0.2)); inp.rmbP = true; ai.note('Grab attack'); } else if (s) H.aimAt(ai, s); return true; }
    if (pw.state === 'cling') { if (pw.tokens >= 1 && b.conf > 0.4 && d < 14 * M && H.lane(ai, b.x, b.y)) { H.aimAt(ai, H.lead(ai, b, d / (22 * M))); inp.rmbP = true; } return true; }
    if (pw.state !== 'idle' || pw.tokens < 1) return false;
    const marked = b.s.status.has('kaguneMark');
    if (b.visible && d > (marked ? 2.5 : 3.5) * M && d < 13 * M && H.roll(ai, marked ? 0.9 : 0.6)) {
      const p = H.lead(ai, b, d / (22 * M)); if (H.lane(ai, p.x, p.y)) { H.aimAt(ai, p); inp.rmbP = true; }
    }
    return false;
  },
  travel(ai, x, y) {
    const k = ai.k, pw = k.power, st = ai.steer; const p = st.path?.[st.idx];
    if (!p || pw.state !== 'idle' || pw.tokens < pw.maxTokens) return;
    if (dist(p.x, p.y, k.x, k.y) > 10 * M && H.lane(ai, p.x, p.y) && H.roll(ai, 0.4)) { H.aimAt(ai, p); k.input.rmbP = true; }
  },
};
