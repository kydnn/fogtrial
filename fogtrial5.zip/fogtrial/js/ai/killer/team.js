// 2v8 killer coordination. Both killer bots (and a human killer, whose state is read but never
// steered) share a board: sightings, who is chasing whom, which generators each one covers,
// pickups in progress and requests for help. Information is shared with a delay/quality that
// depends on each bot's coordination skill — teammates talk, they don't share a brain.
import { M, dist } from '../../core/util.js';

const ROLE = {
  // mobile chasers
  hillbilly: 'chaser', blight: 'chaser', nurse: 'chaser', legion: 'chaser', mastermind: 'chaser', ghoul: 'chaser', cannibal: 'chaser', wraith: 'chaser', ghostface: 'chaser',
  // area control / information
  trapper: 'zoner', hag: 'zoner', knight: 'zoner', singularity: 'zoner', skull_merchant: 'zoner', dredge: 'zoner', cenobite: 'zoner', houndmaster: 'zoner',
  // ranged pressure
  huntress: 'ranged', deathslinger: 'ranged', unknown: 'ranged', executioner: 'ranged', nemesis: 'ranged', clown: 'ranged', lich: 'ranged',
};

export class KillerTeam {
  static for(m) { if (!m.killerTeam) m.killerTeam = new KillerTeam(m); return m.killerTeam; }
  constructor(m) {
    this.m = m; this.sightings = new Map(); this.chasing = new Map(); this.pickups = new Map(); this.help = null;
    // split the generators: each killer covers the half nearer its spawn (re-balanced as gens pop)
    this.regions = new Map(); this.assignRegions();
  }
  roleFor(k) { return ROLE[k.def.id] || 'chaser'; }
  assignRegions() {
    const ks = this.m.killers; if (ks.length < 2) return;
    const [a, b] = ks; const ax = a.x, ay = a.y, bx = b.x, by = b.y;
    for (const g of this.m.map.gens) this.regions.set(g, dist(g.x, g.y, ax, ay) < dist(g.x, g.y, bx, by) ? a : b);
  }
  regionOwner(g) { return this.regions.get(g); }
  share(k, s, b) { this.sightings.set(s, { x: b.x, y: b.y, vx: b.vx, vy: b.vy, t: this.m.time, by: k }); }
  claim(k, goal) {
    for (const [s, c] of this.chasing) if (c.k === k) this.chasing.delete(s);
    if (goal.type === 'CHASE') this.chasing.set(goal.target, { k, t: this.m.time });
    if (goal.type === 'PICKUP') this.pickups.set(goal.target, k);
  }
  chaserOf(s, me) { const c = this.chasing.get(s); if (!c || c.k === me || this.m.time - c.t > 30) return null; return c.k; }
  claimedPickup(s, me) { const k = this.pickups.get(s); return k && k !== me && s.health === 'dying' && dist(k.x, k.y, s.x, s.y) < 20 * M; }
  // Assist when the partner's chase has dragged on and we are close enough to cut the target off.
  shouldAssist(me, mate, s) {
    const c = this.chasing.get(s); if (!c) return false;
    const long = this.m.time - c.t > 18; const near = dist(me.x, me.y, s.x, s.y) < 24 * M;
    return long && near && (me.bot?.P.coordination ?? 0.5) > Math.random();
  }
  // Teammate sightings flow into each bot's perception (quality-gated).
  feed(ai) {
    const P = ai.P, now = this.m.time;
    for (const [s, sg] of this.sightings) {
      if (sg.by === ai.k || now - sg.t > 6 || !s.standing) continue;
      if (Math.random() > P.coordination) continue;
      const b = ai.per.belief(s); if (b.visible || b.t >= sg.t) continue;
      b.x = sg.x; b.y = sg.y; b.vx = sg.vx; b.vy = sg.vy; b.t = sg.t; b.conf = Math.max(b.conf, 0.7 * Math.exp(-(now - sg.t) / 6)); b.src = 'team';
    }
  }
}
