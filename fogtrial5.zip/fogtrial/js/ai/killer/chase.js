// Killer bot chase controller. Runs every frame while the strategist has chosen CHASE.
// It decides where to run (prediction, loop cuts, mindgames), when to swing (lunge timing,
// Dead Hard / endurance reads), how to deal with pallets (respect, bait, break, go around)
// and hands control to the killer's power controller when the power is the better tool.
import { M, dist, angleDiff, clamp } from '../../core/util.js';

export class ChaseController {
  constructor(ai) { this.ai = ai; this.m = ai.m; this.k = ai.k; this.reset(null); }
  reset(target) {
    this.target = target; this.startT = this.m.time; this.lastHitT = -99; this.mind = null; this.swingHold = 0; this.baitT = 0;
    this.hits = 0; this.lostT = 0; this.palletWaits = 0; this.loopT = 0; this.lastTile = null;
  }
  get elapsed() { return this.m.time - this.startT; }

  // Main chase step (every frame). Returns 'lost' when the target can no longer be followed.
  step(tick) {
    const ai = this.ai, m = this.m, k = this.k, P = ai.P, inp = k.input;
    const s = this.target; if (!s || !s.alive) return 'lost';
    if (s.health === 'dying') return 'downed';
    if (!s.standing) return 'lost';
    const b = ai.per.belief(s);
    if (!b.visible) this.lostT += 1 / 60; else this.lostT = 0;
    if (b.conf < 0.18 || this.lostT > 4 + 4 * P.predict) return 'lost';
    const d = dist(k.x, k.y, b.x, b.y);
    // --- power first: the power controller may want to take over this frame
    const pc = ai.powerCtl;
    if (pc?.chase && pc.chase(ai, b, d, tick)) return 'ok';
    // --- where to run
    // Lead the target only where the lead point is actually reachable from them (no cutting
    // through walls); around a loop the killer follows the real route instead.
    const lead = b.visible ? (d < 5 * M ? 0.15 : clamp(d / (4.6 * M), 0, 1.2) * P.predict) : 0.4 + 1.0 * P.predict;
    let aim = ai.per.pos(b, lead);
    if (!m.world.sweepClear(b.x, b.y, aim.x, aim.y, s.r)) aim = b.visible ? { x: b.x, y: b.y } : ai.per.pos(b, 0.3);
    // stay inside the map and on walkable ground
    aim = { x: clamp(aim.x, 2 * M, m.map.w - 2 * M), y: clamp(aim.y, 2 * M, m.map.h - 2 * M) };
    const tile = m.map.tileAt?.(s.x, s.y);
    if (tile && tile === this.lastTile) this.loopT += 1 / 60; else { this.loopT = 0; this.lastTile = tile; }
    // Mindgame at a loop: decided once each time line of sight breaks around a structure
    const losBreak = this.wasVisible && !b.visible; this.wasVisible = b.visible;
    if (losBreak && tile && d < 10 * M && !this.mind && Math.random() < P.mindgame) {
      const back = { x: tile.x + (tile.x - k.x), y: tile.y + (tile.y - k.y) };
      this.mind = { x: back.x, y: back.y, until: m.time + 1.1 + Math.random() * 0.6 };
      ai.note('Mindgame at the loop');
    }
    if (this.mind && m.time < this.mind.until && !b.visible) aim = this.mind; else this.mind = null;
    // --- pallet respect / bait: don't run into a stun when the target is standing at an up pallet
    const pal = this.threatPallet(s);
    if (pal && pal !== this.baited && d < 4.5 * M && dist(s.x, s.y, pal.x, pal.y) < 1.8 * M) {
      if (this.baitRoll?.p !== pal) this.baitRoll = { p: pal, yes: Math.random() < P.stunAvoid * 0.7 };
      const side = pal.sideOf(k), sSide = pal.sideOf(s);
      if (this.baitRoll.yes && side !== sSide) {
        // hold just outside stun range for a moment to bait the drop
        this.baitT += 1 / 60;
        if (this.baitT > 0.5 + 0.5 * P.palletIQ) { this.baited = pal; this.baitT = 0; }
        else {
          const away = Math.atan2(k.y - pal.y, k.x - pal.x);
          const hx = pal.x + Math.cos(away) * 3.0 * M, hy = pal.y + Math.sin(away) * 3.0 * M;
          ai.steer.goTo(hx, hy, { arrive: 0.5 * M }); ai.steer.faceTo(s.x, s.y);
          return 'ok';
        }
      }
    } else this.baitT = Math.max(0, this.baitT - 1 / 30);
    ai.steer.goTo(aim.x, aim.y, { arrive: 0.3 * M, repath: 0.25 });
    // --- swing
    if (b.visible) this.trySwing(s, b, d, tick); else inp.lmb = false;
    return 'ok';
  }

  // An up pallet the target can throw on us in the next moment
  threatPallet(s) {
    let best = null, bd = 2.6 * M;
    for (const p of this.m.map.pallets) { if (p.state !== 'up') continue; const d = dist(p.x, p.y, s.x, s.y); if (d < bd) { bd = d; best = p; } }
    return best;
  }

  trySwing(s, b, d, tick) {
    const ai = this.ai, m = this.m, k = this.k, P = ai.P, inp = k.input;
    const at = k.attack;
    if (at.state === 'lunge') {
      // keep the blade on the target; hold longer for distant lunges
      inp.aim = Math.atan2(s.y - k.y, s.x - k.x); this.swingHold -= 1 / 60; inp.lmb = this.swingHold > 0; return;
    }
    if (at.state !== 'ready' || !k.power.canAttack(m) || k.carrying || k.status.has('cannotAttack')) { inp.lmb = false; return; }
    if (!tick) return;
    // closing speed: survivors running straight away eat lunge distance
    const rx = s.x - k.x, ry = s.y - k.y; const rl = Math.hypot(rx, ry) || 1;
    const away = (s.vx * rx + s.vy * ry) / rl; // + = moving away
    const reach = k.r + 1.0 * M + s.r;
    const lungeGain = (4.6 * 1.55 - 4.0) * M * 0.45; // ~ what a full lunge gains on a runner
    const swingAt = reach + (away > 1 * M ? lungeGain * P.lungeSkill : 1.6 * M);
    const clear = m.world.losClear(k.x, k.y, s.x, s.y);
    if (!clear || d > swingAt) {
      // occasional bad swing at low skill (whiffs into pallets / out of range)
      if (clear && d < swingAt + 1.5 * M && Math.random() < P.swingNoise * 0.3) this.swing(s, 0.12);
      return;
    }
    // Perk reads: Dead Hard (seen before or likely) — wait out the dodge window when it's up
    if (s.health === 'injured' && !s.status.has('exhausted') && ai.knowsPerk(s, 'dead_hard') && Math.random() < P.perkIQ) {
      if (s.dodgeT && s.dodgeT > m.time) return; // let the i-frames run out
      if (!this.dhBait) { this.dhBait = m.time; ai.note(`Baiting ${s.name}'s Dead Hard`); }
      if (m.time - this.dhBait < 0.35 && d > reach * 0.9) return;
    }
    this.dhBait = null;
    const hold = d > reach + 0.6 * M ? 0.45 : 0.18;
    this.swing(s, hold);
  }
  swing(s, hold) {
    const k = this.k, inp = k.input;
    inp.aim = Math.atan2(s.y - k.y, s.x - k.x); inp.lmbP = true; inp.lmb = true; this.swingHold = hold;
  }
}
