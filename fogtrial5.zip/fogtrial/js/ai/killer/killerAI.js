// Killer bot brain. Layers (each at its own rate):
//   perception (10 Hz)  → beliefs about survivors, generator knowledge, anonymous clues
//   strategy   (1–2 Hz) → utility over goals with commitment timers (no frame-to-frame flip-flop)
//   behavior   (every frame) → a small behavior tree / state machine executing the goal:
//                CHASING, SEARCHING, INVESTIGATING, PATROLLING, DEFENDING_OBJECTIVE,
//                DAMAGING_GENERATOR, BREAKING_PALLET, PICKING_UP_SURVIVOR, CARRYING_SURVIVOR,
//                HOOKING_SURVIVOR, INTERRUPTING_RESCUE, REPOSITIONING, ENDGAME_PRESSURE, USING_POWER
//   power controller (per killer, see powers.js) → plays the killer's actual power
// It only writes the killer's input — exactly what a human player could do.
import { M, dist, clamp } from '../../core/util.js';
import { EV } from '../../core/events.js';
import { killerParams } from './params.js';
import { KillerPerception } from './perception.js';
import { KillerSteering } from './steering.js';
import { ChaseController } from './chase.js';
import { powerControllerFor } from './powers.js';
import { KillerTeam } from './team.js';

// Survivor perks a killer can recognise when they trigger in front of it.
const VISIBLE_PERKS = new Set(['dead_hard', 'decisive_strike', 'sprint_burst', 'lithe', 'overcome', 'borrowed_time', 'unbreakable', 'adrenaline', 'smash_hit', 'background_player', 'for_the_people', 'off_the_record', 'deliverance', 'flashlight']);

export class KillerAI {
  constructor(k, m, difficulty = 5) {
    this.k = k; this.m = m; this.setDifficulty(difficulty);
    this.per = new KillerPerception(this);
    this.steer = new KillerSteering(this);
    this.chase = new ChaseController(this);
    this.powerCtl = powerControllerFor(k.power.id);
    this.team = m.killers.length > 1 ? KillerTeam.for(m) : null;
    this.goal = null; this.commitUntil = 0; this.state = 'PATROLLING';
    this.pT = Math.random() * 0.1; this.tT = 0; this.sT = 0.3; this.tick = false;
    this.knownPerks = new Set(); this.log = []; this.options = [];
    this.patrolGen = null; this.visited = new Map(); this.search = null; this.guardHook = null; this.lastHookT = -99;
    this.role = this.team ? this.team.roleFor(k) : 'solo';
    this.mem = {}; // scratch space for power controllers
    m.events.on('perkProc', (d) => {
      const p = d.perk; if (p.owner?.kind !== 'survivor' || !VISIBLE_PERKS.has(p.id)) return;
      if (dist(p.owner.x, p.owner.y, k.x, k.y) < 22 * M) { if (!this.knownPerks.has(p.owner.id + ':' + p.id)) this.note(`Saw ${p.owner.name} use ${p.def.name}`); this.knownPerks.add(p.owner.id + ':' + p.id); }
    });
    m.events.on(EV.KILLER_HIT, (d) => { if (d.result === 'endurance' && d.killer === k) this.knownPerks.add(d.survivor.id + ':borrowed_time'); });
    m.events.on(EV.SURVIVOR_UNHOOKED, (d) => {
      // the hook HUD changes: the killer knows where the rescue happened
      const h = d.survivor; this.per.addLead(h.x, h.y, m.time, 'unhook', 2.4);
      this.lastUnhook = { s: d.survivor, rescuer: d.rescuer, t: m.time, x: h.x, y: h.y };
    });
    m.events.on(EV.GENERATOR_REPAIRED, (d) => { this.per.addLead(d.gen.x, d.gen.y, m.time, 'gen-done', 0.8); });
    m.events.on(EV.SURVIVOR_HOOKED, (d) => { if (d.killer === k) { this.lastHookT = m.time; this.lastHooked = d.survivor; } });
  }
  setDifficulty(d) { this.difficulty = d; this.P = killerParams(d); this.k.botDifficulty = d; }
  knowsPerk(s, id) { return this.knownPerks.has(s.id + ':' + id); }
  hasPerk(id) { return this.k.hasPerk(id); }
  note(text) { this.log.push({ t: this.m.time, text }); if (this.log.length > 30) this.log.shift(); this.m.killerLog?.push({ t: this.m.time, who: this.k.def.short, text }); }

  // ------------------------------------------------------------------ main
  update(dt) {
    const m = this.m, k = this.k, inp = k.input;
    if (m.state === 'MATCH_START' || m.aiPaused) { inp.mx = inp.my = 0; return; }
    inp.lmb = false; inp.rmb = false; inp.aimDist = inp.aimDist ?? 8 * M;
    this.pT -= dt; if (this.pT <= 0) { this.pT = 0.1; this.per.update(0.1); this.team?.feed(this); }
    this.tT -= dt; this.tick = this.tT <= 0; if (this.tick) this.tT = 1 / (this.P.tacticalHz * (m.thinkScale || 1));
    this.sT -= dt; if (this.sT <= 0) { this.sT = this.P.strategicEvery * (0.8 + Math.random() * 0.4); this.strategize(); }
    if (k.stunT > 0) { this.state = 'STUNNED'; return; }
    if (k.action) {
      this.state = { break: 'BREAKING_PALLET', kick: 'DAMAGING_GENERATOR', pickup: 'PICKING_UP_SURVIVOR', hook: 'HOOKING_SURVIVOR', vault: 'VAULTING', custom: 'USING_POWER' }[k.action.type] || 'ACTING';
      return;
    }
    this.execute();
  }

  // ------------------------------------------------------------------ strategy
  strategize() {
    const m = this.m, k = this.k, P = this.P, per = this.per;
    const opts = []; const add = (type, target, score, why = '') => opts.push({ type, target, score, why, key: type + ':' + (target?.id ?? target?.x ?? '') });
    const myD = (x, y) => dist(x, y, k.x, k.y) / M;
    const gensLeft = m.gensNeeded - m.gensDone;
    const aliveN = m.aliveCount();
    if (k.carrying) { add('CARRY', k.carrying, 1000); this.commit(opts[0], 0); return; }
    // --- downed survivors: pick up (or slug) ---
    for (const s of m.survivors) {
      if (s.health !== 'dying' || m.carrier(s) || this.team?.claimedPickup(s, k)) continue;
      const b = per.belief(s); const d = myD(b.x, b.y); if (b.conf < 0.3 && d > 30) continue;
      let sc = 120 / (1 + d / 30);
      // Decisive Strike read: freshly unhooked survivor might have it
      if (m.time - s.unhookedAt < 40 && (this.knowsPerk(s, 'decisive_strike') || Math.random() < 0.3 * P.perkIQ)) sc *= 0.35;
      add('PICKUP', s, sc, `${d.toFixed(0)}m`);
    }
    // --- chase candidates (visible or strongly believed standing survivors) ---
    for (const b of per.known(0.3)) {
      const s = b.s; if (!s.standing) continue;
      const p = per.pos(b); const d = myD(p.x, p.y);
      let sc = 95 * (b.visible ? 1 : 0.55 * b.conf) / (1 + d / 18);
      if (s.health === 'injured' || b.seenHealth === 'injured') sc *= 1.3;
      if (s.status.has('exposed') || s.status.has('marked')) sc *= 1.4;
      if (s.hookStage >= 2) sc *= 1 + 0.25 * P.patrolIQ; // one hook from death
      // recently unhooked: protected by endurance / Borrowed Time; tunnelling is a late-game choice
      const fresh = m.time - s.unhookedAt < 15;
      if (fresh) sc *= gensLeft <= 2 ? 0.6 + P.tunnel : 0.35 + P.tunnel * 0.5;
      // strong loop read: an expert avoids long chases at god tiles when gens are flying
      const tile = m.map.tileAt?.(s.x, s.y);
      if (tile && tile.safety > 0.6) sc *= 1 - 0.25 * P.abandon * tile.safety;
      // the current chase: commitment, but reconsider after the patience window
      if (this.goal?.type === 'CHASE' && this.goal.target === s) {
        const t = this.chase.elapsed; const over = Math.max(0, t - P.chasePatience * (gensLeft <= 1 ? 1.6 : 1));
        sc *= 1.6 - Math.min(1.2, over / 25 * P.abandon);
      }
      // 2v8: someone else is already on them
      const mate = this.team?.chaserOf(s, k);
      if (mate) sc *= this.team.shouldAssist(k, mate, s) ? 0.9 : 0.35;
      add('CHASE', s, sc, `${d.toFixed(0)}m ${b.visible ? 'seen' : b.src}`);
    }
    // --- rescue reads: someone is going for the hook ---
    for (const s of m.survivors) {
      if (s.health !== 'hooked') continue;
      const near = per.known(0.4).filter((b) => b.s !== s && b.s.standing && dist(b.x, b.y, s.x, s.y) < 16 * M);
      const d = myD(s.x, s.y);
      if (near.length && d < 36) add('INTERRUPT_RESCUE', s, (60 + 30 * P.hookIQ) / (1 + d / 25), 'rescuer spotted');
      // low skill: camping
      if (this.guardHook === s && m.time - this.lastHookT < 25) add('GUARD_HOOK', s, 45 * (1 - P.hookIQ), 'camping');
    }
    if (this.lastUnhook && m.time - this.lastUnhook.t < 6) {
      const u = this.lastUnhook; const d = myD(u.x, u.y);
      if (d < 40) add('INVESTIGATE', { x: u.x, y: u.y, id: 'unhook' }, (70 + 40 * P.hookIQ) / (1 + d / 30), 'unhook');
    }
    // --- clues: scratch marks, noises, grunts ---
    const L = per.bestLead();
    if (L) add('INVESTIGATE', { x: L.x, y: L.y, id: 'lead', ref: L.ref }, 70 * L.score + 8, L.kind);
    // --- search where the chase was lost ---
    if (this.search && m.time < this.search.until) add('SEARCH', this.search, 55 + 10 * P.predict, 'lost them');
    // --- generators: defend / patrol ---
    const gens = m.map.gens.filter((g) => !g.done);
    if (!m.gatesPowered && gens.length) {
      for (const g of gens) {
        const gi = per.genInfo(g); const d = myD(g.x, g.y);
        const recent = m.time - gi.t < 30;
        const prog = recent ? gi.progress : 0.25 + 0.2 * P.patrolIQ * Math.min(1, m.gensDone / 3);
        let sc = (14 + 34 * prog * P.patrolIQ + (gi.repairing && m.time - gi.t < 8 ? 40 : 0)) / (1 + d / (30 + 30 * P.patrolIQ));
        // 3-gen awareness: keep the cluster of remaining gens together
        if (P.patrolIQ > 0.5 && gens.length <= gensLeft + 2) { const dens = gens.filter((o) => o !== g && dist(o.x, o.y, g.x, g.y) < 32 * M).length; sc *= 1 + 0.15 * dens * P.patrolIQ; }
        if (this.hasPerk('pop') && m.time - this.lastHookT < 45 && prog > 0.4) sc *= 1.5;
        // keep walking to the gen we picked; once checked, rotate away from it for a while
        if (this.goal && (this.goal.type === 'PATROL' || this.goal.type === 'DEFEND_GEN') && this.goal.target === g) sc *= 1.6;
        const seenAt = this.visited.get(g); if (seenAt !== undefined) sc *= Math.min(1, 0.25 + (m.time - seenAt) / 40);
        if (this.team && this.team.regionOwner(g) !== this.k && Math.random() < this.P.coordination) sc *= 0.6;
        add(gi.repairing && recent ? 'DEFEND_GEN' : 'PATROL', g, sc + Math.random() * 6 * P.temperature, `${Math.round(prog * 100)}%`);
      }
    }
    // --- endgame ---
    if (m.gatesPowered) for (const gt of m.map.gates) { const d = myD(gt.x, gt.y); add('ENDGAME', gt, (gt.user ? 70 : 30) / (1 + d / 40) + (gt.open ? 10 : 0), gt.user ? 'gate being opened' : 'patrol gates'); }
    if (m.hatch.state === 'open' && aliveN === 1 && myD(m.hatch.x, m.hatch.y) < 40) add('HATCH', m.hatch, 80, 'close the hatch');
    if (!opts.length) add('PATROL', gens[0] || m.map.gates[0], 1);
    // --- pick, with commitment + noise ---
    for (const o of opts) o.score *= 1 + (Math.random() - 0.5) * P.temperature;
    opts.sort((a, b) => b.score - a.score);
    let pick = opts[0];
    if (Math.random() < P.mistakes && opts.length > 1) pick = opts[1 + Math.floor(Math.random() * Math.min(3, opts.length - 1))];
    const cur = this.goal && opts.find((o) => o.key === this.goal.key);
    if (cur && m.time < this.commitUntil && cur.score * 1.3 >= pick.score && pick.type !== 'PICKUP' && pick.type !== 'CHASE') pick = cur;
    // never hop between chase targets on a whim: a new target must be clearly better
    if (cur && cur.type === 'CHASE' && pick.type === 'CHASE' && pick !== cur && cur.score * 1.6 > pick.score && cur.target.standing) pick = cur;
    this.options = opts.slice(0, 6);
    this.commit(pick);
  }
  commit(o, hold = 2.5) {
    const changed = !this.goal || this.goal.key !== o.key;
    this.goal = o;
    if (changed) {
      this.commitUntil = this.m.time + hold;
      if (o.type === 'CHASE') { if (this.chase.target !== o.target) { this.chase.reset(o.target); this.note(`Chasing ${o.target.name}`); } }
      if (o.type === 'PATROL' || o.type === 'DEFEND_GEN') this.patrolGen = o.target;
      if (o.type === 'INVESTIGATE' && o.target.ref) o.target.ref.investigated = true;
      this.team?.claim(this.k, o);
    }
  }

  // ------------------------------------------------------------------ behavior
  execute() {
    const m = this.m, k = this.k, g = this.goal, inp = k.input, P = this.P;
    if (!g) { this.steer.stop(); return; }
    const t = g.target;
    const ctx = m.killerContext(k);
    // Modal powers (biopod control, mid-teleport…) own the frame whatever the goal is
    if (this.powerCtl?.always?.(this, g)) return;
    // Between chases the power controller may take the wheel (setting traps, pods, guards…)
    if (!['CARRY', 'PICKUP', 'CHASE'].includes(g.type) && this.powerCtl?.patrol?.(this)) return;
    switch (g.type) {
      case 'CARRY': {
        this.state = 'CARRYING_SURVIVOR';
        const h = this.chooseHook();
        if (!h) { this.steer.stop(); return; }
        if (ctx?.type === 'hook') { inp.spaceP = true; this.guardHook = Math.random() < 1 - this.P.hookIQ ? k.carrying : null; return; }
        this.steer.goTo(h.x, h.y, { arrive: 1.2 * M });
        return;
      }
      case 'PICKUP': {
        this.state = 'PICKING_UP_SURVIVOR';
        if (t.health !== 'dying' || m.carrier(t)) { this.goal = null; return; }
        if (ctx?.type === 'pickup' && ctx.target === t) { inp.spaceP = true; return; }
        this.steer.goTo(t.x, t.y, { arrive: 1.2 * M });
        return;
      }
      case 'CHASE': {
        this.state = 'CHASING';
        if (ctx?.type === 'break' && this.palletBlocks(ctx.target, t)) { inp.spaceP = true; return; }
        const r = this.chase.step(this.tick);
        if (r === 'lost') { const b = this.per.belief(t); this.search = { x: b.x, y: b.y, until: m.time + 5 + 10 * P.predict, t0: m.time, id: 'search' }; this.note(`Lost ${t.name}`); this.goal = null; this.sT = 0; }
        else if (r === 'downed') { this.goal = null; this.sT = 0; }
        return;
      }
      case 'INTERRUPT_RESCUE': case 'GUARD_HOOK': {
        this.state = g.type === 'GUARD_HOOK' ? 'DEFENDING_OBJECTIVE' : 'INTERRUPTING_RESCUE';
        if (t.health !== 'hooked') { this.goal = null; this.sT = 0; return; }
        const d = this.steer.goTo(t.x, t.y, { arrive: (g.type === 'GUARD_HOOK' ? 7 : 3) * M });
        if (this.powerCtl?.travel && d > 25 * M) this.powerCtl.travel(this, t.x, t.y);
        return;
      }
      case 'INVESTIGATE': case 'SEARCH': {
        this.state = g.type === 'SEARCH' ? 'SEARCHING' : 'INVESTIGATING';
        let tx = t.x, ty = t.y;
        if (g.type === 'SEARCH') {
          // sweep around the last known spot: check nearby cover in a widening spiral
          const a = (m.time - t.t0) * 1.3, r = (2 + (m.time - t.t0) * 0.9) * M;
          tx = t.x + Math.cos(a) * Math.min(r, 9 * M); ty = t.y + Math.sin(a) * Math.min(r, 9 * M);
        }
        const d = this.steer.goTo(tx, ty, { arrive: 1.0 * M });
        if (d < 1.3 * M && g.type === 'INVESTIGATE') { this.goal = null; this.sT = Math.min(this.sT, 0.2); }
        if (this.powerCtl?.travel && d > 25 * M) this.powerCtl.travel(this, tx, ty);
        return;
      }
      case 'PATROL': case 'DEFEND_GEN': {
        this.state = g.type === 'DEFEND_GEN' ? 'DEFENDING_OBJECTIVE' : 'PATROLLING';
        if (t.done) { this.goal = null; this.sT = 0; return; }
        const d = this.steer.goTo(t.x, t.y, { arrive: 1.9 * M });
        if (this.powerCtl?.travel && d > 25 * M) this.powerCtl.travel(this, t.x, t.y);
        if (ctx?.type === 'kick' && ctx.target === t && Math.random() < 0.4 + 0.6 * P.pressure) { inp.spaceP = true; this.visited.set(t, m.time); this.goal = null; this.sT = Math.min(this.sT, 0.5); return; }
        if (d < 2.2 * M) { this.visited.set(t, m.time); this.goal = null; this.sT = 0; }
        return;
      }
      case 'ENDGAME': {
        this.state = 'ENDGAME_PRESSURE';
        const d = this.steer.goTo(t.x, t.y, { arrive: 3 * M });
        if (this.powerCtl?.travel && d > 25 * M) this.powerCtl.travel(this, t.x, t.y);
        if (d < 4 * M && !t.user) { this.goal = null; this.sT = Math.min(this.sT, 1); }
        return;
      }
      case 'HATCH': {
        this.state = 'ENDGAME_PRESSURE';
        if (ctx?.type === 'closeHatch') { inp.spaceP = true; return; }
        this.steer.goTo(t.x, t.y, { arrive: 1.2 * M }); return;
      }
    }
  }
  // Break a dropped pallet when it separates us from a target who keeps looping it.
  palletBlocks(p, s) { return p.state === 'down' && s && p.sideOf(this.k) !== p.sideOf(s) && dist(s.x, s.y, p.x, p.y) < 8 * M; }
  chooseHook() {
    const m = this.m, k = this.k, P = this.P;
    let best = null, bs = Infinity;
    for (const h of m.map.hooks) {
      if (h.survivor || h.broken) continue;
      let c = dist(h.x, h.y, k.x, k.y);
      // smarter killers avoid hooks right next to known survivors (easy rescues) when close alternatives exist
      for (const b of this.per.known(0.5)) if (b.s !== k.carrying && b.s.standing && dist(b.x, b.y, h.x, h.y) < 12 * M) c += 10 * M * P.hookIQ;
      if (c < bs) { bs = c; best = h; }
    }
    return best;
  }
}
