// Killer bot perception. The bot gets exactly what a human killer's screen and HUD give:
//  • survivors inside its view (≈ the camera area) with line of sight, after a reaction delay
//  • scratch marks, blood and grunts of pain near it
//  • loud-noise notifications, generator completions, hook / unhook / dying states (HUD)
//  • aura reveals from its own perks / power (m.reveals)
// It never reads a survivor's true position otherwise — beliefs decay and are predicted.
import { M, dist, gauss } from '../../core/util.js';

export const SRC = { SIGHT: 'sight', AURA: 'aura', SCRATCH: 'scratch', BLOOD: 'blood', GRUNT: 'grunt', NOISE: 'noise', HUD: 'hud', TEAM: 'team', PREDICT: 'predicted' };

export class KillerPerception {
  constructor(ai) {
    this.ai = ai; this.m = ai.m; this.k = ai.k;
    this.beliefs = new Map();   // survivor -> belief
    this.leads = [];            // anonymous clues { x, y, t, kind, w }
    this.gens = new Map();      // gen -> { progress, repairing, t, kicked }
    this.lastNoiseT = 0; this.lastScratchT = 0;
    this.events = [];           // recent notable events (unhook, gen done…) for the strategist
  }
  belief(s) {
    let b = this.beliefs.get(s);
    if (!b) { b = { s, x: s.x, y: s.y, vx: 0, vy: 0, t: -999, conf: 0, src: null, visible: false, noticeAt: Infinity, seenHealth: 'healthy', lastSeenT: -999, firstSeenT: -999, lastAction: null }; this.beliefs.set(s, b); }
    return b;
  }
  pos(b, lead = 0) {
    const age = Math.min(3, this.m.time - b.t), k = (b.visible ? lead : age + lead) * 0.85;
    return { x: b.x + b.vx * k, y: b.y + b.vy * k };
  }
  canSee(s, d) {
    const m = this.m, k = this.k, P = this.ai.P;
    // remote eyes (biopod control): the pod sees what is within its range and sight line
    const vp = k.power.viewPoint?.(m);
    if (vp && !s.hiddenIn && dist(vp.x, vp.y, s.x, s.y) < 20 * M && m.world.losClear(vp.x, vp.y, s.x, s.y)) return true;
    if (k.blindT > 0 && d > 3 * M) return false;
    if (d > P.viewRange * M) return false;
    if (s.hiddenIn) return false;
    if (s.moveMode === 'crouch' && m.map.isGrass(s.x, s.y) && d > 5 * M && !s.action) return false;
    if (m.nightfallFor?.(k) && d > 14 * M) return false;
    return m.world.losClear(k.x, k.y, s.x, s.y);
  }
  update(dt) {
    const m = this.m, k = this.k, P = this.ai.P, now = m.time;
    for (const s of m.survivors) {
      const b = this.belief(s);
      if (!s.alive) { b.conf = 0; b.visible = false; b.gone = true; continue; }
      // HUD states are always known (hooked / dying / carried icons)
      if (s.health === 'hooked' || s.health === 'carried') { b.x = s.x; b.y = s.y; b.vx = b.vy = 0; b.t = now; b.conf = 1; b.src = SRC.HUD; b.visible = false; b.seenHealth = s.health; continue; }
      const d = dist(k.x, k.y, s.x, s.y);
      const inView = this.canSee(s, d);
      if (inView) {
        if (!b.visible) {
          if (b.noticeAt === Infinity) {
            const far = d > 12 * M ? (1 - P.attention) * 1.2 : 0;
            // re-acquiring someone tracked a moment ago (around a corner, after a blink) is near-instant
            const tracking = now - b.lastSeenT < 1.5 && b.conf > 0.5 && dist(b.x, b.y, s.x, s.y) < 6 * M;
            b.noticeAt = now + (tracking ? P.reaction * 0.25 : P.reaction * (0.7 + Math.random() * 0.6) + far);
          }
          if (now >= b.noticeAt) { b.visible = true; if (now - b.lastSeenT > 6) b.firstSeenT = now; }
        }
        if (b.visible) {
          b.x = s.x; b.y = s.y; b.vx = s.vx; b.vy = s.vy; b.t = now; b.conf = 1; b.src = SRC.SIGHT; b.lastSeenT = now;
          b.seenHealth = s.health; b.lastAction = s.action?.type ?? (s.vault ? 'vault' : null); b.moveMode = s.moveMode;
          this.ai.team?.share(this.k, s, b);
        }
      } else { b.visible = false; b.noticeAt = Infinity; }
      if (s.health === 'dying') b.seenHealth = 'dying';
      // decay
      if (!b.visible) b.conf *= Math.exp(-dt / P.memory);
    }
    // Aura reveals produced by this killer's perks / power (and the 2v8 team's Revealed status)
    for (const r of m.reveals) {
      const t = r.target; if (!t || r.until < now) continue;
      if (t.kind === 'survivor') { const b = this.belief(t); if (!b.visible) { b.x = t.x; b.y = t.y; b.vx = t.vx; b.vy = t.vy; b.t = now; b.conf = Math.max(b.conf, 0.95); b.src = SRC.AURA; b.seenHealth = t.health; } }
      else if (t.kind === 'generator' || t.charges !== undefined) { const g = this.genInfo(t); g.repairing = true; g.t = now; g.progress = t.progress ?? g.progress; }
    }
    // Killer Instinct-style power reveals live in m.instinct (Legion, Unknown, Houndmaster…)
    for (const r of m.instinct || []) if (r.until > now && (!r.killer || r.killer === k)) { const b = this.belief(r.target); if (!b.visible) { b.x = r.target.x; b.y = r.target.y; b.t = now; b.conf = Math.max(b.conf, 0.9); b.src = SRC.AURA; } }
    // Scratch marks / blood / grunts — anonymous leads, attributed to the most plausible belief
    if (Math.random() < P.scratchUse) {
      for (const sc of m.scratches) {
        if (sc.t <= this.lastScratchT || now - sc.t > 2.5) continue;
        if (dist(sc.x, sc.y, k.x, k.y) > 16 * M) continue;
        this.addLead(sc.x, sc.y, sc.t, 'scratch', 1);
      }
      for (const bl of m.blood) if (now - bl.t < 2 && dist(bl.x, bl.y, k.x, k.y) < 10 * M && m.world.losClear(k.x, k.y, bl.x, bl.y)) this.addLead(bl.x, bl.y, bl.t, 'blood', 0.8);
    }
    this.lastScratchT = now;
    if (Math.random() < P.gruntUse) for (const g of m.grunts) if (now - g.t < 0.2 && dist(g.x, g.y, k.x, k.y) < 22 * M) this.addLead(g.x + gauss() * 1.5 * M, g.y + gauss() * 1.5 * M, now, 'grunt', 1.2);
    // Loud noises (fast vaults, pallets, failed skill checks, gens, gates)
    for (const n of m.loudNoises) {
      if (n.t <= this.lastNoiseT) continue;
      const d = dist(n.x, n.y, k.x, k.y);
      if (n.kind !== 'gen' && n.kind !== 'gate' && d > 48 * M) continue;
      if (Math.random() < P.noiseUse) this.addLead(n.x, n.y, n.t, 'noise:' + n.kind, n.kind === 'skillcheck' ? 2.2 : n.kind === 'gen' ? 0.6 : 1.5);
    }
    this.lastNoiseT = now;
    // Generators: progress is readable only when the gen is on screen
    for (const g of m.map.gens) {
      const gi = this.genInfo(g);
      if (g.done) { gi.done = true; continue; }
      const d = dist(g.x, g.y, k.x, k.y);
      if (d < P.viewRange * M && m.world.losClear(k.x, k.y, g.x, g.y)) { gi.progress = g.progress; gi.repairing = g.repairers.size > 0; gi.t = now; gi.regressing = g.regressing; }
      else if (d < 16 * M && g.repairers.size > 0) { gi.repairing = true; gi.t = now; } // generator noise carries a short way
    }
    // Attribute fresh leads to beliefs
    for (const L of this.leads) {
      if (L.used || now - L.t > 1.0) continue;
      let best = null, bd = 7 * M;
      for (const b of this.beliefs.values()) { if (b.visible || b.gone || b.conf < 0.08) continue; const p = this.pos(b); const dd = dist(p.x, p.y, L.x, L.y); if (dd < bd) { bd = dd; best = b; } }
      if (best) { const p0 = { x: best.x, y: best.y }; best.vx = (L.x - p0.x) / Math.max(0.3, L.t - best.t); best.vy = (L.y - p0.y) / Math.max(0.3, L.t - best.t); best.x = L.x; best.y = L.y; best.t = L.t; best.conf = Math.max(best.conf, 0.6); best.src = L.kind.startsWith('noise') ? SRC.NOISE : SRC.SCRATCH; L.used = true; }
    }
    this.leads = this.leads.filter((L) => now - L.t < 8);
  }
  addLead(x, y, t, kind, w) {
    for (const L of this.leads) if (L.kind === kind && dist(L.x, L.y, x, y) < 1.5 * M && Math.abs(L.t - t) < 0.6) { L.t = Math.max(L.t, t); return; }
    this.leads.push({ x, y, t, kind, w, used: false });
  }
  genInfo(g) { let gi = this.gens.get(g); if (!gi) { gi = { g, progress: 0, repairing: false, t: -999, done: false, regressing: false }; this.gens.set(g, gi); } return gi; }
  // Best uninvestigated clue (weighted by freshness, weight and distance)
  bestLead() {
    const m = this.m, k = this.k; let best = null, bs = 0;
    for (const L of this.leads) {
      if (L.investigated) continue;
      const age = m.time - L.t, d = dist(L.x, L.y, k.x, k.y) / M;
      const sc = L.w * Math.exp(-age / 4) / (1 + d / 25);
      if (sc > bs) { bs = sc; best = L; }
    }
    return best ? { ...best, score: bs, ref: best } : null;
  }
  // Visible survivors right now
  visible() { const out = []; for (const b of this.beliefs.values()) if (b.visible && b.s.standing) out.push(b); return out; }
  known(minConf = 0.25) { const out = []; for (const b of this.beliefs.values()) if (!b.gone && b.conf >= minConf && (b.s.standing || b.s.health === 'dying')) out.push(b); return out; }
}
