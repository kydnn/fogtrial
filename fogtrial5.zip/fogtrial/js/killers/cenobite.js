// THE CENOBITE — Summons of Pain.
//  • Possessed Chain (hold RMB): a chain shoots out, starting slow and accelerating to
//    40 m/s, steered with the mouse while RMB is held (max 24 m). It stops on walls. A hit
//    binds the survivor with 3 chains: slowed, cannot run or interact, and blocked from
//    the exit gates. Each chain takes 1 s to break free.
//  • Gateway (E): conjure a gateway up to 16 m away and possess it for 6 s; your next
//    chain shot comes out of the gateway.
//  • Lament Configuration: the puzzle box lies on the map. If nobody picks it up within
//    90 s, a Chain Hunt starts — chains hunt every survivor until someone takes the box.
//    The holder is Oblivious and hunted by chains until they solve it (6 s). The Cenobite
//    can summon himself to a survivor who is solving (E, 3.25 s), or pick the box up
//    himself (SPACE): every survivor is bound with 3 chains and screams.
import { M, dist, angleDiff, normAngle, clamp, rr } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, Device } from './framework.js';

const CHAIN_RANGE = 24 * M;
export class CenobitePower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'lament'; this.name = 'Summons of Pain'; this.state = 'idle';
    this.chain = null; this.hunters = []; this.box = null; this.boxCharge = 0; this.boxHolder = null; this.respawnT = 0; this.hunt = false; this.huntT = 0;
    this.huntCharge = this.has('impaling_wire') ? 80 : 90; this.gateway = null; this.summonT = 0;
    this.aiProfile = { type: 'chains_box', label: 'Chains & the Lament Configuration', counter: ['break line of sight from chains', 'pick up and solve the box when safe', 'break chains quickly'] };
  }
  speedMult() { if (this.state === 'chain') return 0.25; if (this.state === 'gateway' || this.state === 'summon') return 0; return 1; }
  canAttack() { return this.state === 'idle'; }
  noContext() { return this.state !== 'idle'; }
  onInit(m) { this._m = m; this.spawnBox(m); }
  spawnBox(m) {
    // the box appears somewhere away from the Cenobite
    const spots = m.map.openSpots(8, 6, []); const k = this.k;
    const p = spots.sort((a, b) => dist(b.x, b.y, k.x, k.y) - dist(a.x, a.y, k.x, k.y))[Math.floor(Math.random() * Math.min(3, spots.length))] || { x: m.map.w / 2, y: m.map.h / 2 };
    this.box = m.addDevice(new Device({ kind: 'lament', x: p.x, y: p.y, r: 0.4 * M, label: 'Lament Configuration', useTime: 1.0, survivorUsable: true, seenRange: 60 * M,
      usable: (s) => !s.box && !s.status.has('chained'), onUse: (s, mm) => this.pickBox(mm, s) }));
    this.boxCharge = 0; this.hunt = false;
    for (const s of m.survivors) s.ai?.memory.devices.set(this.box.id, this.box); // survivors always know where the box is (white aura)
  }
  pickBox(m, s) {
    m.removeDevice(this.box); this.box = null; this.boxHolder = s; s.box = true; this.hunt = false; this.huntT = 4;
    s.status.add('oblivious', { source: 'box' });
    m.notifyK(`${s.name} picked up the Lament Configuration`, '#e0b65a'); s.ai?.note('Picked up the Lament Configuration', 'box');
    m.events.emit('boxPicked', { survivor: s });
  }
  solveBox(s, m) {
    if (this.boxHolder !== s) return;
    s.box = false; s.status.remove('oblivious', 'box'); this.boxHolder = null; this.respawnT = 45;
    m.reveal(s, 3, 'Box solved'); m.notifyK(`${s.name} solved the box`, '#e0b65a'); m.audio?.play('bell');
    s.ai?.note('Solved the Lament Configuration', 'boxsolve'); m.events.emit('boxSolved', { survivor: s });
    for (const h of this.hunters) h.dead = true;
  }
  update(dt, m, inp, locked) {
    this.tickCooldowns(dt);
    const k = this.k;
    // chains also snap on their own: one every 5 s (breaking them by hand is faster)
    for (const s of m.survivors) {
      const c = s.status.get('chained'); if (!c) { s._chainT = 0; continue; }
      s._chainT = (s._chainT || 0) + dt;
      if (s._chainT > 5) { s._chainT = 0; c.value = (c.value ?? 3) - 1; if (c.value <= 0) { s.status.remove('chained'); m.events.emit('chainsBroken', { survivor: s }); } }
    }
    if (this.state === 'summon') { this.summonT -= dt; if (this.summonT <= 0) this.finishSummon(m); return; }
    if (this.state === 'gateway') { this.gwT -= dt; if (this.gwT <= 0) { this.state = 'idle'; this.gateway = null; this.setCd('gateway', 3); } }
    if (this.chain) this.updateChain(dt, m, inp);
    // Locked (stunned, vaulting, picking up…): a chain in flight is cancelled through the normal
    // end path so the power leaves the 'chain' state (it used to be dropped silently, leaving
    // the Cenobite stuck at chain speed with attacks disabled).
    if (locked) { if (this.chain || this.state === 'chain') this.endChain(); return; }
    if ((this.state === 'idle' || this.state === 'gateway') && inp.rmb && !this.chain && !k.carrying && this.cd('chain') <= 0) this.shoot(m);
    if (inp.eP && !k.carrying) {
      const solver = m.survivors.find((s) => s.action?.type === 'solveBox');
      if (solver && this.state === 'idle') { this.state = 'summon'; this.summonT = 3.25; this.summonTo = solver; m.sound('power_warn', solver.x, solver.y, 14 * M, { what: 'summon', note: 'The Cenobite is coming for the box' }); }
      else if (this.state === 'idle' && this.cd('gateway') <= 0) this.placeGateway(m, inp);
    }
  }
  placeGateway(m, inp) {
    const k = this.k; const d = clamp(inp.aimDist ?? 10 * M, 1.5 * M, 16 * M);
    let x = k.x, y = k.y; const st = 0.5 * M;
    for (let t = st; t <= d; t += st) { const nx = k.x + Math.cos(k.facing) * t, ny = k.y + Math.sin(k.facing) * t; if (m.world.pointBlocked(nx, ny, 0.3 * M)) break; x = nx; y = ny; }
    this.gateway = { x, y, a: k.facing }; this.state = 'gateway'; this.gwT = 6; m.audio?.play('teleport');
    m.events.emit(EV.POWER_USED, { killer: k, power: 'gateway' });
  }
  shoot(m) {
    const k = this.k, g = this.gateway; const ox = g ? g.x : k.x + Math.cos(k.facing) * k.r, oy = g ? g.y : k.y + Math.sin(k.facing) * k.r;
    this.chain = { x: ox, y: oy, ox, oy, dir: k.facing, v: 10 * M, t: 0, len: 0, fromGateway: !!g }; this.state = 'chain';
    m.sound('power_windup', ox, oy, 24 * M, { what: 'chain', dir: k.facing });
    m.events.emit(EV.POWER_USED, { killer: k, power: 'chain' }); m.audio?.play('throw');
  }
  updateChain(dt, m, inp) {
    const c = this.chain; c.t += dt;
    c.v = c.t < 0.4 ? 10 * M : c.t < 0.7 ? 15 * M + (c.t - 0.4) / 0.3 * 22.5 * M : Math.min(40 * M, 37.5 * M + (c.t - 0.7) * 0.8 * M);
    // steer toward the mouse (from the chain head), limited turn rate
    const k = this.k; const ax = k.x + Math.cos(inp.aim) * (inp.aimDist ?? 10 * M), ay = k.y + Math.sin(inp.aim) * (inp.aimDist ?? 10 * M);
    const want = Math.atan2(ay - c.y, ax - c.x); c.dir += clamp(normAngle(want - c.dir), -4.2 * dt, 4.2 * dt);
    const step = c.v * dt; const nx = c.x + Math.cos(c.dir) * step, ny = c.y + Math.sin(c.dir) * step;
    const hit = m.world.firstHit(c.x, c.y, nx, ny, 0.15 * M, (s) => s.blocksLOS);
    for (const s of m.survivors) {
      if (!s.standing) continue;
      if (dist(s.x, s.y, nx, ny) < s.r + 0.25 * M || dist(s.x, s.y, (c.x + nx) / 2, (c.y + ny) / 2) < s.r + 0.25 * M) { this.bind(m, s, 3, 'Possessed Chain'); this.endChain(); return; }
    }
    if (hit) { m.fx.sparks(c.x, c.y); this.endChain(); return; }
    c.x = nx; c.y = ny; c.len += step;
    if (c.len >= CHAIN_RANGE || !inp.rmb && c.t > 0.15) this.endChain();
  }
  // A chain always returns control to the Cenobite's body: a chain fired from a Gateway closes
  // the Gateway (it used to drop him back into the motionless 'gateway' state for the rest of
  // its 6 s, which looked like being stuck after every hit).
  endChain() {
    const fromGateway = this.chain?.fromGateway || this.state === 'gateway';
    this.chain = null;
    if (this.state === 'chain' || this.state === 'gateway') this.state = 'idle';
    if (fromGateway && this.gateway) { this.gateway = null; this.setCd('gateway', 3); }
    this.setCd('chain', this.has('chatterer_tooth') ? 4 : 5);
  }
  bind(m, s, n, label) {
    if (s.dodgeT && s.dodgeT > m.time) { m.fx.text(s.x, s.y - 30, 'DODGED', '#ffd27a'); return; }
    const cur = s.status.get('chained'); const v = Math.min(3, (cur?.value ?? 0) + n);
    s.status.add('chained', { value: v, source: 'cenobite' }); const c2 = s.status.get('chained'); c2.value = v; c2.expiration = Infinity;
    s.stopAction(m); s.vault = null; s.gateBlockUntil = m.time + 5; if (!cur) m.events.emit('powerTriggered', { survivor: s, x: s.x, y: s.y }); 
    m.fx.burst(s.x, s.y, 14, '#b8b8c0', 80, 0.6, 2, 2); m.audio?.play('clang');
    m.addScore('deviousness', 200, label); this.k.stats.powerHits++;
    s.ai?.note(`Bound by ${label}`, 'chained'); m.events.emit('survivorChained', { survivor: s });
  }
  finishSummon(m) {
    const s = this.summonTo, k = this.k; this.state = 'idle';
    if (!s || !s.standing) return;
    const a = Math.random() * Math.PI * 2; let best = null;
    for (let i = 0; i < 12; i++) { const r = rr(Math.random, 9, 12) * M; const x = s.x + Math.cos(a + i) * r, y = s.y + Math.sin(a + i) * r; if (!m.world.pointBlocked(x, y, k.r) && x > 0 && y > 0 && x < m.map.w && y < m.map.h) { best = { x, y }; break; } }
    if (best) { k.x = best.x; k.y = best.y; m.world.resolve(k, k.r); k.facing = Math.atan2(s.y - k.y, s.x - k.x); }
    if (s.action?.type === 'solveBox') s.stopAction(m);
    this.bind(m, s, 1, 'Summons'); m.audio?.play('teleport');
  }
  // Space near the box: the Cenobite claims it — every survivor is chained and screams.
  context(m) {
    if (!this.box || this.state !== 'idle' || this.k.carrying) return null;
    if (dist(this.k.x, this.k.y, this.box.x, this.box.y) > 1.8 * M) return null;
    return { type: 'custom', label: 'Take the Lament Configuration', target: { dur: 1.0, label: 'Claiming the box', done: (mm) => this.claimBox(mm) } };
  }
  claimBox(m) {
    if (!this.box) return; m.removeDevice(this.box); this.box = null; this.respawnT = 10;
    for (const s of m.survivors) if (s.standing) { this.bind(m, s, 3, 'Lament'); m.reveal(s, 3, 'Scream'); m.addGrunt(s); }
    m.audio?.play('scream'); m.notifyK('Every survivor is bound', '#e0b65a');
  }
  // Always-running clocks: box charge, Chain Hunt, hunting chains, respawns.
  tick(dt, m) {
    if (!this.box && !this.boxHolder && this.respawnT > 0) { this.respawnT -= dt; if (this.respawnT <= 0) this.spawnBox(m); }
    if (this.boxHolder && !this.boxHolder.standing) {
      // downing (or losing) the holder: everyone is bound, the box comes back soon
      const h = this.boxHolder; h.box = false; h.status.remove('oblivious', 'box'); this.boxHolder = null; this.respawnT = 10;
      if (h.health === 'dying') for (const s of m.survivors) if (s.standing) { this.bind(m, s, 3, 'Lament'); m.reveal(s, 3, 'Scream'); }
    }
    if (this.box) { this.boxCharge += dt; if (this.boxCharge >= this.huntCharge && !this.hunt) { this.hunt = true; this.huntT = 2; m.notifyK('CHAIN HUNT', '#e0b65a'); m.events.emit('chainHunt', {}); for (const s of m.survivors) s.ai?.note('Chain Hunt started — someone must get the box', 'chainhunt'); } }
    const targets = this.hunt ? m.survivors.filter((s) => s.standing) : this.boxHolder ? [this.boxHolder] : [];
    if (targets.length && m.aliveCount() > 1) {
      this.huntT -= dt;
      if (this.huntT <= 0) { this.huntT = rr(Math.random, 9, 12) / (this.hunt ? 1 : 1.2); for (const s of targets) this.spawnHunter(m, s); }
    }
    for (const h of this.hunters) this.updateHunter(dt, m, h);
    this.hunters = this.hunters.filter((h) => !h.dead);
  }
  spawnHunter(m, s) {
    const a = Math.random() * Math.PI * 2; const x = clamp(s.x + Math.cos(a) * 14 * M, 4 * M, m.map.w - 4 * M), y = clamp(s.y + Math.sin(a) * 14 * M, 4 * M, m.map.h - 4 * M);
    const h = { x, y, ox: x, oy: y, target: s, dir: Math.atan2(s.y - y, s.x - x), v: 11 * M, t: 0, dead: false };
    this.hunters.push(h); m.sound('power_windup', x, y, 18 * M, { what: 'hunt_chain', dir: h.dir });
  }
  updateHunter(dt, m, h) {
    const s = h.target; h.t += dt; if (!s.standing || h.t > 3) { h.dead = true; return; }
    const want = Math.atan2(s.y - h.y, s.x - h.x); h.dir += clamp(normAngle(want - h.dir), -1.6 * dt, 1.6 * dt);
    const nx = h.x + Math.cos(h.dir) * h.v * dt, ny = h.y + Math.sin(h.dir) * h.v * dt;
    if (h.t > 0.6 && m.world.firstHit(h.x, h.y, nx, ny, 0.15 * M, (q) => q.blocksLOS)) { h.dead = true; m.fx.sparks(h.x, h.y); return; }
    h.x = nx; h.y = ny;
    if (dist(s.x, s.y, h.x, h.y) < s.r + 0.3 * M) { h.dead = true; this.bind(m, s, 1, 'Chain Hunt'); }
  }
  drawDevice(ctx, d, m) {
    if (d.kind !== 'lament') return;
    ctx.save(); ctx.translate(d.x, d.y); ctx.rotate(m.time * 0.6); ctx.fillStyle = '#c9a23a'; ctx.fillRect(-7, -7, 14, 14); ctx.strokeStyle = '#3a2a10'; ctx.lineWidth = 1.5; ctx.strokeRect(-7, -7, 14, 14); ctx.beginPath(); ctx.arc(0, 0, 3, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
    if (this.hunt) { ctx.strokeStyle = 'rgba(224,182,90,0.5)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(d.x, d.y, 18 + Math.sin(m.time * 6) * 4, 0, Math.PI * 2); ctx.stroke(); }
  }
  drawGround(ctx, m) {
    if (this.gateway) { const g = this.gateway; ctx.strokeStyle = 'rgba(224,182,90,0.9)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(g.x, g.y, 14, 0, Math.PI * 2); ctx.stroke(); ctx.fillStyle = 'rgba(60,30,10,0.6)'; ctx.fill(); }
  }
  drawOver(ctx, m) {
    const k = this.k; const draw = (c, ox, oy) => { ctx.strokeStyle = '#c8c8d0'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(ox, oy); ctx.lineTo(c.x, c.y); ctx.stroke(); ctx.fillStyle = '#e0e0e8'; ctx.beginPath(); ctx.arc(c.x, c.y, 4, 0, Math.PI * 2); ctx.fill(); };
    if (this.chain) draw(this.chain, this.chain.ox, this.chain.oy);
    for (const h of this.hunters) draw(h, h.ox, h.oy);
    if (this.boxHolder) { const s = this.boxHolder; ctx.fillStyle = '#c9a23a'; ctx.fillRect(s.x - 4, s.y - s.r - 14, 8, 8); }
    if (this.state === 'summon') { ctx.strokeStyle = 'rgba(224,182,90,0.8)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(k.x, k.y, k.r + 10, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (1 - this.summonT / 3.25)); ctx.stroke(); }
  }
  drawBody(ctx) { ctx.fillStyle = '#d8d0c8'; ctx.beginPath(); ctx.arc(5, 0, 6, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = '#555'; ctx.lineWidth = 1; for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) { ctx.beginPath(); ctx.arc(5 + i * 3, j * 3, 0.8, 0, Math.PI * 2); ctx.stroke(); } }
  drawWeapon(ctx) { const k = this.k; ctx.strokeStyle = '#9a9aa2'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(k.r - 4, 6); ctx.quadraticCurveTo(k.r + 10, 14, k.r + 18, 8); ctx.stroke(); return true; }
  prompt(m) { const solver = m.survivors.find((s) => s.action?.type === 'solveBox'); return solver && this.state === 'idle' ? { key: 'E', label: `Summon to ${solver.name} (solving the box)` } : null; }
  hud(m) {
    const st = this.state === 'summon' ? 'Summoning…' : this.state === 'gateway' ? `Gateway ${Math.ceil(this.gwT)}s` : this.hunt ? 'CHAIN HUNT' : this.boxHolder ? `${this.boxHolder.name} holds the box` : this.box ? `Chain Hunt in ${Math.ceil(this.huntCharge - this.boxCharge)}s` : 'Box respawning';
    return { title: 'Summons of Pain', value: this.cd('chain') > 0 ? Math.ceil(this.cd('chain')) + 's' : 'Ready', meter: this.box ? this.boxCharge / this.huntCharge : 1 - this.cd('chain') / 5, state: st,
      hints: [['Q / RMB', 'Hold: Possessed Chain (steer with mouse)'], ['E', 'Gateway · Summon to a box solver'], ['SPACE', 'Take the box']] };
  }
}
