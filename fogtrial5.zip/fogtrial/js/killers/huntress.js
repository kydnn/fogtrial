// THE HUNTRESS — Hunting Hatchets. Hold the power to wind up, release to throw.
// Longer wind-ups throw faster and further. Hatchets fly over pallets and windows but
// stop on walls, rocks and trees. Limited hatchets; reload at lockers (E).
import { M, dist, clamp } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, Projectile, Device, nearestOf } from './framework.js';

export class HuntressPower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'hatchets'; this.name = 'Hunting Hatchets'; this.state = 'idle';
    this.max = this.has('leather_loop') ? 7 : 5; this.count = this.max; this.charge = 0;
    this.minWind = 0.35; this.maxWind = this.has('shiny_pin') ? 1.0 : 1.3; this.range = (this.has('flower_babushka') ? 36 : 30) * M;
    this.aiProfile = { type: 'ranged', label: 'Hatchet throws', counter: ['break line of sight', 'avoid long open runs', 'dodge when she winds up'] };
  }
  speedMult() { return this.state === 'winding' ? 0.62 : this.state === 'recover' ? 0.5 : 1; }
  canAttack() { return this.state === 'idle'; }
  onInit(m) {
    for (const p of m.map.openSpots(5, 24, m.map.gens)) m.addDevice(new Device({ kind: 'locker', x: p.x, y: p.y, r: 0.7 * M, label: 'Locker', seenRange: 20 * M }));
  }
  update(dt, m, inp, locked) {
    this.tickCooldowns(dt);
    const k = this.k;
    if (locked) { if (this.state === 'winding') this.state = 'idle'; return; }
    if (this.state === 'recover') { if (this.cd('recover') <= 0) this.state = 'idle'; }
    if (this.state === 'idle' && inp.rmb && !k.carrying && this.count > 0) {
      this.state = 'winding'; this.charge = 0;
      m.sound('power_windup', k.x, k.y, 26 * M, { what: 'hatchet' });
    }
    if (this.state === 'winding') {
      this.charge = Math.min(this.maxWind, this.charge + dt);
      if (!inp.rmb) { if (this.charge >= this.minWind) this.throw(m); this.state = this.charge >= this.minWind ? 'recover' : 'idle'; this.setCd('recover', 0.55); }
    }
    if (inp.eP && !k.carrying && this.count < this.max) {
      const locker = nearestOf(m.devices.filter((d) => d.kind === 'locker'), k.x, k.y, 1.9 * M);
      if (locker) k.startAction('custom', { dur: 2.4, label: 'Reloading hatchets', done: () => { this.count = this.max; m.audio?.play('reload'); } }, m);
    }
  }
  throw(m) {
    const k = this.k, f = (this.charge - this.minWind) / (this.maxWind - this.minWind);
    const speed = (22 + 20 * clamp(f, 0, 1)) * M; this.count--;
    const a = k.facing; const sx = k.x + Math.cos(a) * k.r, sy = k.y + Math.sin(a) * k.r;
    m.spawnProjectile(new Projectile({
      kind: 'hatchet', owner: k, x: sx, y: sy, vx: Math.cos(a) * speed, vy: Math.sin(a) * speed, r: 0.22 * M, range: this.range, color: '#cfd3d6',
      onHit: (p, s, mm) => {
        if (s.dodgeT && s.dodgeT > mm.time) { mm.fx.text(s.x, s.y - 30, 'DODGED', '#ffd27a'); return; }
        const res = s.takeHit(mm, { source: 'hatchet' }); k.stats.hits++; k.stats.powerHits++; k.bloodlust = 0;
        mm.events.emit(EV.KILLER_HIT, { killer: k, survivor: s, result: res, power: true }); mm.fx.hit(s, res);
        mm.addScore('hunter', 300, 'Hatchet hit'); s.ai?.note('Hit by a hatchet', 'hatchet');
      },
      onWall: (p, mm) => { mm.fx.sparks(p.x, p.y); },
    }));
    m.audio?.play('throw'); m.events.emit(EV.POWER_USED, { killer: k, power: 'hatchet' });
  }
  prompt(m) {
    const locker = nearestOf(m.devices.filter((d) => d.kind === 'locker'), this.k.x, this.k.y, 1.9 * M);
    return locker && this.count < this.max ? { key: 'E', label: 'Reload hatchets' } : null;
  }
  hud() {
    return { title: 'Hunting Hatchets', value: `${this.count}/${this.max}`, meter: this.state === 'winding' ? this.charge / this.maxWind : this.count / this.max,
      state: this.state === 'winding' ? (this.charge >= this.minWind ? 'Release to throw' : 'Winding up…') : this.count ? 'Ready' : 'Out of hatchets — find a locker',
      hints: [['Q / RMB', 'Hold to wind up, release to throw'], ['E', 'Reload at a locker']] };
  }
}
