// THE HOUNDMASTER — Hunting. Her dog, Snug, is a real entity with its own pathfinding.
//  • Chase Command (hold RMB to plot, release): Snug charges along the plotted line at
//    high speed. Tap RMB again while it runs to take control and redirect it once.
//  • Search Command (E): aim the cane 5–40 m away; Snug paths there with a lullaby that
//    grows as it travels, giving Killer Instinct on survivors near it. A survivor it spots
//    is pursued. While the search runs and she stays near Snug's route, the Houndmaster
//    moves at 6 m/s.
//  • A dog that reaches a survivor pounces and drags them toward the Houndmaster for up to
//    8 s (2 s with Endurance): Incapacitated, Hindered, aura revealed, gates blocked.
//    Dropping a pallet on Snug stuns it for 3 s and frees the survivor.
import { M, dist, angleDiff, normAngle, clamp } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, Minion } from './framework.js';

class Dog extends Minion {
  constructor(power) {
    super({ kind: 'dog', owner: power.k, x: power.k.x, y: power.k.y, r: 0.36 * M, color: '#8a6a4a', label: 'dog', threat: 1, visRange: 30 * M });
    this.p = power; this.state = 'follow'; this.stunnable = true; this.stunTime = 3; this.repath = 0;
  }
  onStun(m) { if (this.grabbed) this.p.releaseGrab(m, 'pallet'); this.state = 'return'; this.path = null; }
  update(dt, m) {
    const k = this.p.k; this.t += dt;
    switch (this.state) {
      case 'follow': {
        const bx = k.x - Math.cos(k.facing) * 1.1 * M, by = k.y - Math.sin(k.facing) * 1.1 * M; const d = dist(bx, by, this.x, this.y);
        if (d > 6 * M) { this.x = bx; this.y = by; } else if (d > 0.3 * M) this.moveDir(dt, m, (bx - this.x) / d, (by - this.y) / d, Math.min(6 * M, d * 4));
        break;
      }
      case 'chase': {
        this.left -= this.speed * dt;
        const hit = this.moveDir(dt, m, Math.cos(this.dir), Math.sin(this.dir), 8.2 * M);
        if (this.tryGrab(m)) return;
        if (hit || this.left <= 0) { this.state = 'return'; this.path = null; }
        break;
      }
      case 'search': {
        this.travel += Math.hypot(this.vx, this.vy) * dt; this.radius = Math.min(14 * M, 4 * M + this.travel * 0.3);
        if (this.followPath(dt, m, 6.2 * M) || this.t > 9) { this.state = 'return'; this.path = null; break; }
        for (const s of m.survivors) {
          if (!s.standing) continue; const d = dist(s.x, s.y, this.x, this.y);
          if (d < this.p.lullaby) m.reveal(s, 0.4, 'Lullaby', true);
          if (d < this.radius && m.world.losClear(this.x, this.y, s.x, s.y)) { this.state = 'pursue'; this.target = s; this.pursueT = 5; m.reveal(s, 2, 'Snug'); s.ai?.onDogPursuit?.(this); break; }
        }
        break;
      }
      case 'pursue': {
        const s = this.target; this.pursueT -= dt;
        if (!s.standing || this.pursueT <= 0) { this.state = 'return'; this.path = null; break; }
        this.repath -= dt; if (this.repath <= 0) { this.repath = 0.3; this.pathTo(m, s.x, s.y); }
        this.followPath(dt, m, 7.4 * M);
        this.tryGrab(m);
        break;
      }
      case 'grab': {
        // dragging the survivor toward the Houndmaster
        const s = this.grabbed; this.grabT -= dt;
        if (!s || !s.standing || this.grabT <= 0) { this.p.releaseGrab(m, 'time'); break; }
        const d = dist(k.x, k.y, this.x, this.y);
        if (d > 1.6 * M) {
          if (!this.path || (this.repath -= dt) <= 0) { this.repath = 0.4; this.pathTo(m, k.x, k.y); }
          this.followPath(dt, m, 2.6 * M);
        }
        s.x = this.x - Math.cos(this.facing) * (this.r + s.r * 0.8); s.y = this.y - Math.sin(this.facing) * (this.r + s.r * 0.8); m.world.resolve(s, s.r);
        m.reveal(s, 0.3, 'Grabbed', true);
        // dragged across a dropped pallet: survivor can slam it on the dog (handled by match stun)
        break;
      }
      case 'return': {
        const d = dist(k.x, k.y, this.x, this.y);
        if (d < 1.5 * M) { this.state = 'follow'; this.p.setCd('dog', 3); break; }
        this.repath -= dt; if (this.repath <= 0 || !this.path) { this.repath = 0.6; this.pathTo(m, k.x, k.y); }
        if (this.followPath(dt, m, 7 * M) && d > 1.5 * M) this.path = null;
        if (this.t > 12) { this.x = k.x; this.y = k.y; this.state = 'follow'; }
        break;
      }
    }
  }
  tryGrab(m) {
    for (const s of m.survivors) {
      if (!s.standing || s.vault) continue;
      if (dist(s.x, s.y, this.x, this.y) > s.r + this.r + 0.25 * M) continue;
      if (s.dodgeT && s.dodgeT > m.time) continue;
      this.p.grab(m, s); return true;
    }
    return false;
  }
}

export class HoundmasterPower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'hound'; this.name = 'Hunting'; this.state = 'idle'; this.dog = null; this.plot = 0; this.lullaby = 32 * M;
    this.chaseLen = (this.has('training_whistle') ? 24 : 20) * M; this.grabTime = this.has('rope_leash') ? 9 : 8;
    this.aiProfile = { type: 'dog', label: 'The dog', counter: ['track the dog separately', 'use windows (the dog cannot vault)', 'drop pallets on the dog', 'leave the dog\'s lane'] };
  }
  onInit(m) { this.dog = m.addMinion(new Dog(this)); }
  speedMult(m) {
    if (this.state === 'plotting') return 0.75;
    const d = this.dog; if (d && (d.state === 'search' || d.state === 'pursue') && dist(this.k.x, this.k.y, d.x, d.y) < 14 * M) return 6 / this.k.def.speed;
    return 1;
  }
  canAttack() { return this.state === 'idle'; }
  update(dt, m, inp, locked) {
    this.tickCooldowns(dt);
    const k = this.k, d = this.dog;
    if (locked) { if (this.state === 'plotting') this.state = 'idle'; return; }
    const ready = d && d.state === 'follow' && this.cd('dog') <= 0 && !k.carrying;
    if (this.state === 'idle' && inp.rmb && ready) { this.state = 'plotting'; this.plot = 0; }
    if (this.state === 'plotting') {
      this.plot = Math.min(1, this.plot + dt / 0.6);
      if (!inp.rmb) { this.sendChase(m); this.state = 'idle'; }
      return;
    }
    if (d && d.state === 'chase' && inp.rmbP && !d.redirected) { d.redirected = true; d.dir = k.facing; d.left = Math.max(d.left, 8 * M); m.audio?.play('ui'); }
    if (inp.eP && ready) this.sendSearch(m, inp);
  }
  sendChase(m) {
    const d = this.dog, k = this.k; d.state = 'chase'; d.t0 = m.time; d.dir = k.facing; d.left = this.chaseLen * (0.5 + 0.5 * this.plot); d.speed = 8.2 * M; d.redirected = false; d.t = 0;
    d.x = k.x + Math.cos(k.facing) * 0.8 * M; d.y = k.y + Math.sin(k.facing) * 0.8 * M; m.world.resolve(d, d.r);
    m.audio?.play('swing'); m.sound('power_windup', d.x, d.y, 26 * M, { what: 'dog_chase', dir: d.dir });
    m.events.emit(EV.POWER_USED, { killer: k, power: 'chase_command' });
  }
  sendSearch(m, inp) {
    const d = this.dog, k = this.k; const r = clamp(inp.aimDist ?? 15 * M, 5 * M, 40 * M);
    const tx = k.x + Math.cos(k.facing) * r, ty = k.y + Math.sin(k.facing) * r;
    if (!d.pathTo(m, tx, ty)) return;
    d.state = 'search'; d.travel = 0; d.radius = 4 * M; d.t = 0; this.searchGoal = { x: tx, y: ty };
    m.sound('dog_lullaby', d.x, d.y, this.lullaby, { what: 'search', tx, ty });
    m.events.emit(EV.POWER_USED, { killer: k, power: 'search_command' });
  }
  grab(m, s) {
    const d = this.dog; d.state = 'grab'; d.grabbed = s; d.grabT = s.status.has('endurance') ? 2 : this.grabTime; d.path = null; d.repath = 0;
    s.stopAction(m); s.vault = null; s.status.add('grabbed', { source: 'dog' }); m.events.emit('powerTriggered', { survivor: s, x: s.x, y: s.y });  s.status.add('hindered', { value: 0.1, duration: d.grabT, source: 'dog' });
    s.gateBlockUntil = m.time + d.grabT + 1.5; s.ai?.note('Grabbed by the dog!', 'doggrab');
    const self = this; s.control = { kind: 'dog', allow: ['dropPallet'], update: () => self.dog?.grabbed === s };
    m.addScore('hunter', 300, 'Dog grab'); this.k.stats.powerHits++; m.audio?.play('hit'); m.fx.burst(s.x, s.y, 12, '#8a6a4a', 70, 0.5, 2, 2);
    m.events.emit('dogGrab', { survivor: s });
  }
  releaseGrab(m, why) {
    const d = this.dog; const s = d.grabbed; d.grabbed = null; d.state = 'return'; d.path = null; d.t = 0;
    if (s) { s.status.remove('grabbed', 'dog'); if (s.control?.kind === 'dog') s.control = null; if (why === 'pallet') s.ai?.note('Freed myself — pallet on the dog', 'dogpal'); }
  }
  // a basic hit on the grabbed survivor releases the dog's hold
  tick(dt, m) { const d = this.dog; if (d?.grabbed && d.grabbed.lastHitT === m.time) this.releaseGrab(m, 'hit'); }
  drawMinion(ctx, n, m) {
    if (n.kind !== 'dog') return false;
    if (n.state === 'search' || n.state === 'pursue') { ctx.strokeStyle = 'rgba(200,170,120,0.25)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(n.x, n.y, n.radius || 4 * M, 0, Math.PI * 2); ctx.stroke(); }
    ctx.save(); ctx.translate(n.x, n.y); ctx.rotate(n.facing);
    ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.ellipse(2, 3, 13, 7, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#7a5a3c'; ctx.beginPath(); ctx.ellipse(0, 0, 12, 6.5, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#5a3f28'; ctx.beginPath(); ctx.ellipse(11, 0, 5, 4.5, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#5a3f28'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-11, 0); ctx.lineTo(-17, Math.sin(m.time * 14) * 3); ctx.stroke();
    ctx.restore();
    if (n.stunT > 0) { ctx.fillStyle = '#ffd27a'; ctx.beginPath(); ctx.arc(n.x, n.y - 14, 3, 0, Math.PI * 2); ctx.fill(); }
    return true;
  }
  drawOver(ctx, m) {
    const k = this.k;
    if (this.state === 'plotting') { const L = this.chaseLen * (0.5 + 0.5 * this.plot); ctx.strokeStyle = 'rgba(200,170,120,0.8)'; ctx.setLineDash([6, 5]); ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.lineTo(k.x + Math.cos(k.facing) * L, k.y + Math.sin(k.facing) * L); ctx.stroke(); ctx.setLineDash([]); }
    const d = this.dog; if (d?.state === 'search' && this.searchGoal) { ctx.strokeStyle = 'rgba(200,170,120,0.5)'; ctx.beginPath(); ctx.arc(this.searchGoal.x, this.searchGoal.y, 10, 0, Math.PI * 2); ctx.stroke(); }
    if (d?.grabbed) { ctx.strokeStyle = 'rgba(255,90,90,0.6)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.lineTo(d.x, d.y); ctx.stroke(); }
  }
  drawWeapon(ctx) { const k = this.k; ctx.strokeStyle = '#6a4a2a'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(k.r - 4, 6); ctx.lineTo(k.r + 20, 10); ctx.stroke(); return true; }
  hud() {
    const d = this.dog; const ds = d ? { follow: this.cd('dog') > 0 ? `Snug ready in ${Math.ceil(this.cd('dog'))}s` : 'Snug ready', chase: 'Chase Command', search: 'Search Command', pursue: `Pursuing ${d.target?.name}`, grab: `Dragging ${d.grabbed?.name}`, return: 'Snug returning' }[d.state] : '';
    return { title: 'Hunting', value: d?.state === 'grab' ? Math.ceil(d.grabT) + 's' : d?.state === 'follow' ? 'Ready' : '…', meter: this.state === 'plotting' ? this.plot : d?.state === 'follow' ? 1 - this.cd('dog') / 3 : 0.3, state: ds,
      hints: [['Q / RMB', 'Hold to plot, release: Chase Command · tap again to redirect'], ['E', 'Search Command at the aimed spot']] };
  }
}
