// GHOST FACE — Night Shroud. Activate to become undetectable and hard to spot.
// Hold the power while shrouded to stalk survivors in view; a fully stalked survivor is
// Marked (Exposed: one hit downs). Survivors who look straight at him long enough reveal
// him, which breaks the shroud and puts it on cooldown. E toggles a crouch.
import { M, dist, angleDiff, clamp } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower } from './framework.js';

export class GhostFacePower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'shroud'; this.name = 'Night Shroud'; this.state = 'visible';
    this.crouched = false; this.stalking = false; this.markTime = this.has('philly') ? 50 : 35;
    this.revealCd = this.has('outdoor_rope') ? 14 : 20; this.stalkRate = this.has('drop_leg_sheath') ? 1.25 : 1;
    this.revealRange = 14 * M; this.stalkTarget = null;
    this.aiProfile = { type: 'stalker', label: 'Stalk & expose', counter: ['look at him to reveal', 'break line of sight when stalked', 'play safe when marked'] };
  }
  get shrouded() { return this.state === 'shrouded'; }
  speedMult() { if (this.stalking) return 0.45; if (this.crouched) return 0.7; return 1; }
  canAttack() { return true; }
  // Survivors' visual detection range multiplier while shrouded.
  visibilityTo(s, m) {
    if (!this.shrouded) return 1;
    let v = this.crouched ? 0.32 : 0.55;
    if (m.map.isGrass(this.k.x, this.k.y) && this.crouched) v *= 0.6;
    return v;
  }
  onAttack(m) { if (this.shrouded) this.breakShroud(m, null, 6); }
  onStun(m) { if (this.shrouded) this.breakShroud(m, null, this.revealCd); }
  breakShroud(m, by, cd) {
    this.state = 'cooldown'; this.setCd('shroud', cd); this.stalking = false; this.crouched = false;
    this.k.status.remove('undetectable', 'shroud');
    if (by) {
      m.notifyK(`${by.name} revealed you`, '#e05a5a'); m.loudNoise(this.k.x, this.k.y, 'reveal');
      m.sound('killer_action', this.k.x, this.k.y, 40 * M, { what: 'revealed' });
      m.bb.report(by, this.k.x, this.k.y, this.k.vx, this.k.vy, this.k);
      by.ai?.note('Revealed Ghost Face by watching him', 'gfreveal');
      m.events.emit(EV.POWER_USED, { killer: this.k, power: 'revealed', by });
    }
  }
  update(dt, m, inp, locked) {
    this.tickCooldowns(dt);
    const k = this.k;
    if (this.state === 'cooldown' && this.cd('shroud') <= 0) this.state = 'visible';
    for (const s of m.survivors) if (s.alive && s.stalk > 0 && !this.stalking) s.stalk = Math.max(0, s.stalk - dt * 0.05);
    if (locked) { this.stalking = false; return; }
    if (inp.eP) this.crouched = !this.crouched;
    if (this.state === 'visible' && inp.rmbP && !k.carrying) {
      this.state = 'shrouded'; k.status.add('undetectable', { source: 'shroud' });
      m.events.emit(EV.POWER_USED, { killer: k, power: 'shroud' });
      return;
    }
    if (!this.shrouded) { this.stalking = false; return; }
    // Stalking
    this.stalking = inp.rmb && !k.carrying; this.stalkTarget = null;
    if (this.stalking) {
      for (const s of m.survivors) {
        if (!s.standing) continue;
        const d = dist(k.x, k.y, s.x, s.y); if (d > 26 * M) continue;
        if (angleDiff(Math.atan2(s.y - k.y, s.x - k.x), k.facing) > 0.55) continue;
        if (!m.world.losClear(k.x, k.y, s.x, s.y)) continue;
        if (s.status.has('marked')) continue;
        const rate = (d < 10 * M ? 1 / 3.5 : 1 / 6.5) * this.stalkRate * (this.crouched ? 1.25 : 1);
        s.stalk = clamp(s.stalk + rate * dt, 0, 1); this.stalkTarget = s; s.lastStalkedT = m.time;
        if (s.stalk >= 1) {
          s.stalk = 0; s.status.add('marked', { duration: this.markTime, source: 'ghostface' });
          m.fx.text(s.x, s.y - 30, 'MARKED', '#ff4b5c'); m.notifyK(`${s.name} is marked`, '#ff4b5c');
          m.events.emit(EV.POWER_USED, { killer: k, power: 'marked', survivor: s }); m.addScore('deviousness', 300, 'Marked');
        }
      }
    }
    // Reveal: survivors staring at him from close range
    for (const s of m.survivors) {
      if (!s.standing) { s.revealT = 0; continue; }
      const d = dist(k.x, k.y, s.x, s.y);
      const range = this.revealRange * (this.crouched ? 0.6 : 1);
      const looking = d < range && angleDiff(s.facing, Math.atan2(k.y - s.y, k.x - s.x)) < 0.7 && m.world.losClear(s.x, s.y, k.x, k.y);
      s.revealT = looking ? (s.revealT || 0) + dt : Math.max(0, (s.revealT || 0) - dt * 2);
      if (s.revealT > 1.3) { s.revealT = 0; this.breakShroud(m, s, this.revealCd); break; }
    }
  }
  hud() {
    const st = { visible: 'Ready', shrouded: this.stalking ? (this.stalkTarget ? `Stalking ${this.stalkTarget.name}` : 'Stalking…') : 'Night Shroud', cooldown: 'Revealed' }[this.state];
    return { title: 'Night Shroud', value: this.state === 'cooldown' ? Math.ceil(this.cd('shroud')) + 's' : this.crouched ? 'Crouch' : this.state === 'shrouded' ? 'Shroud' : 'Ready',
      meter: this.state === 'cooldown' ? 1 - this.cd('shroud') / this.revealCd : this.stalkTarget ? this.stalkTarget.stalk : this.state === 'shrouded' ? 1 : 0, state: st,
      hints: [['Q / RMB', 'Shroud · hold to stalk'], ['E', 'Crouch']] };
  }
}
