// THE BLIGHT — Blighted Corruption (adapted to top-down).
//  • 5 rush tokens; one token refills every 2 s while he isn't rushing (tokens refill one at a time).
//  • Press RMB to start a BLIGHTED RUSH (1 token): 9.2 m/s for up to 3 s, turning slowly.
//    Running into a survivor during a normal rush only bumps them (no damage) and ends it.
//  • RUSH SLAM: hitting a wall / obstacle head-on (≥ 45°) stops him. With a token left he has a
//    1.25 s window to press RMB again for the next rush. Glancing hits slide along the wall.
//  • LETHAL RUSH: any rush started after a slam. LMB during a lethal rush is the special attack:
//    a long, fast lunge that injures.
//  • Dropped pallets: a lethal rush slamming into one breaks it (costs 3 tokens if he has them).
//  • FATIGUE when the chain ends (no token, window missed, or after the special attack): 2.5 s,
//    slowed and unable to attack.
import { M, dist, normAngle, clamp } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, strike } from './framework.js';

const RUSH = 9.2, RUSH_T = 3, TURN = 1.6, WINDOW = 1.25, FATIGUE = 2.5, TOKEN_T = 2;
export class BlightPower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'rush'; this.name = 'Blighted Corruption'; this.state = 'idle';
    this.maxTokens = this.has('compound_33') ? 6 : 5; this.tokens = this.maxTokens; this.tokenT = 0; this.rushT = 0; this.winT = 0; this.fatT = 0; this.lethal = false; this.slams = 0;
    this.turn = this.has('alchemists_ring') ? TURN * 1.25 : TURN;
    this.aiProfile = { type: 'rush', label: 'Blighted Rush', counter: ['side-step at the last moment (he turns slowly)', 'tall loops force him to slam', 'pre-drop pallets only if he has few tokens', 'punish fatigue'] };
  }
  speedMult() {
    const base = this.k.def.speed * M;
    if (this.state === 'rush') return RUSH * M / base;
    if (this.state === 'window') return 0.15;
    if (this.state === 'special') return RUSH * 0.9 * M / base;
    if (this.state === 'fatigue') return 0.45;
    return 1;
  }
  canAttack() { return this.state === 'idle'; }
  noContext() { return this.state === 'rush' || this.state === 'window' || this.state === 'special'; }
  overrideMove() { return this.state === 'rush' || this.state === 'special' ? { x: Math.cos(this.dir), y: Math.sin(this.dir) } : null; }
  update(dt, m, inp, locked) {
    this.tickCooldowns(dt);
    const k = this.k;
    if (this.state === 'idle' && this.tokens < this.maxTokens) { this.tokenT += dt; if (this.tokenT >= TOKEN_T) { this.tokenT = 0; this.tokens++; } }
    if (this.state === 'fatigue') { this.fatT -= dt; if (this.fatT <= 0) this.state = 'idle'; return; }
    if (locked) { if (this.state !== 'idle') this.fatigue(m); return; }
    switch (this.state) {
      case 'idle':
        if (inp.rmbP && this.tokens >= 1 && !k.carrying) this.startRush(m, false);
        break;
      case 'rush': {
        this.rushT -= dt; k.facing = this.dir;
        this.dir += clamp(normAngle(inp.aim - this.dir), -this.turn * dt, this.turn * dt);
        if (this.lethal && inp.lmbP) { this.startSpecial(m); break; }
        // bump survivors (normal rush) — a lethal rush lets him use the special attack instead
        for (const s of m.survivors) {
          if (!s.standing || dist(s.x, s.y, k.x, k.y) > k.r + s.r + 0.2 * M) continue;
          if (this.lethal) { this.startSpecial(m); return; }
          s.ai?.note('Bumped by the Blight', 'bump'); this.fatigue(m); return;
        }
        // dropped pallet ahead: a lethal rush smashes it, otherwise it's a slam
        const fx = k.x + Math.cos(this.dir) * 0.9 * M, fy = k.y + Math.sin(this.dir) * 0.9 * M;
        for (const p of m.map.pallets) if (p.state === 'down' && p.stunZone({ x: fx, y: fy })) {
          if (this.lethal && this.tokens >= 3) { this.tokens -= 3; m.breakPallet(p, k); m.fx.text(p.x, p.y - 30, 'SMASHED', '#c7a04a'); }
          this.slam(m); return;
        }
        if (this.rushT <= 0) this.fatigue(m);
        if (this.soundT === undefined || (this.soundT -= dt) <= 0) { this.soundT = 0.25; m.sound('killer_action', k.x, k.y, 30 * M, { what: 'rush', dir: this.dir }); }
        break;
      }
      case 'window':
        this.winT -= dt;
        if (inp.rmbP && this.tokens >= 1) { this.dir = inp.aim; this.startRush(m, true); break; }
        if (this.winT <= 0) this.fatigue(m);
        break;
      case 'special': {
        this.spT -= dt; k.facing = this.dir; this.dir += clamp(normAngle(inp.aim - this.dir), -this.turn * 1.5 * dt, this.turn * 1.5 * dt);
        for (const s of m.survivors) {
          if (!s.standing || dist(s.x, s.y, k.x + Math.cos(this.dir) * 0.6 * M, k.y + Math.sin(this.dir) * 0.6 * M) > k.r + s.r + 0.5 * M || !m.world.losClear(k.x, k.y, s.x, s.y)) continue;
          const r = strike(m, k, s, { source: 'rush', score: 'brutality', label: 'Lethal Rush' }); if (r && r !== 'dodged') { m.fx.shake(8); s.ai?.note('Hit by the Blight\'s lethal rush', 'lethal'); }
          this.fatigue(m, 0.5); return;
        }
        if (this.spT <= 0) this.fatigue(m);
        break;
      }
    }
  }
  startRush(m, chained) {
    const k = this.k; this.tokens--; this.tokenT = 0; this.state = 'rush'; this.rushT = RUSH_T; this.lethal = chained; this.lockFacing = true;
    if (!chained) { this.dir = k.facing; this.slams = 0; }
    m.audio?.play('swing'); m.events.emit(EV.POWER_USED, { killer: k, power: chained ? 'lethal_rush' : 'rush' });
    m.sound('power_windup', k.x, k.y, 30 * M, { what: 'rush', dir: this.dir });
  }
  startSpecial(m) { this.state = 'special'; this.spT = 0.45; m.fx.swing(this.k); m.audio?.play('swing'); }
  onCollide(m) {
    if (this.state !== 'rush' && this.state !== 'special') return;
    const k = this.k, sp = Math.hypot(k.vx, k.vy) || 0;
    const along = sp > 0 ? (k.vx * Math.cos(this.dir) + k.vy * Math.sin(this.dir)) / (RUSH * M) : 0;
    if (this.state === 'special') { this.fatigue(m); return; }
    if (along < 0.7) this.slam(m); // head-on (≥ 45°): slam; glancing hits slide along the wall
  }
  slam(m) {
    const k = this.k; this.slams++; m.fx.shake(6); m.audio?.play('clang'); m.fx.burst(k.x + Math.cos(this.dir) * k.r, k.y + Math.sin(this.dir) * k.r, 10, '#c7a04a', 80, 0.4, 2, 2);
    m.sound('killer_action', k.x, k.y, 26 * M, { what: 'slam' });
    if (this.tokens >= 1) { this.state = 'window'; this.winT = WINDOW; this.lockFacing = false; }
    else this.fatigue(m);
  }
  fatigue(m, extra = 0) { this.state = 'fatigue'; this.fatT = FATIGUE + extra; this.lockFacing = false; this.lethal = false; }
  drawOver(ctx, m) {
    const k = this.k;
    if (this.state === 'rush') { ctx.strokeStyle = this.lethal ? 'rgba(255,90,60,0.7)' : 'rgba(199,160,74,0.6)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.lineTo(k.x + Math.cos(this.dir) * 3 * M, k.y + Math.sin(this.dir) * 3 * M); ctx.stroke(); }
    if (this.state === 'window') { ctx.strokeStyle = 'rgba(255,200,90,0.8)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(k.x, k.y, k.r + 8, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * this.winT / WINDOW); ctx.stroke(); }
    if (this.state === 'fatigue') { ctx.fillStyle = 'rgba(199,160,74,0.5)'; ctx.font = '600 12px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('fatigued', k.x, k.y - k.r - 10); }
  }
  drawBody(ctx) { ctx.fillStyle = '#c7a04a'; ctx.beginPath(); ctx.arc(6, 0, 5, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#5a4a2a'; ctx.fillRect(-4, -9, 3, 18); }
  hud() {
    const st = { idle: 'Ready', rush: this.lethal ? 'LETHAL RUSH — LMB to strike' : 'Rushing', window: `Slam! RMB to chain (${this.winT.toFixed(1)}s)`, special: 'Lethal strike', fatigue: `Fatigue ${this.fatT.toFixed(1)}s` }[this.state];
    return { title: 'Blighted Corruption', value: `${this.tokens}/${this.maxTokens}`, meter: this.state === 'fatigue' ? 1 - this.fatT / FATIGUE : this.tokens / this.maxTokens, state: st,
      hints: [['Q / RMB', 'Rush (1 token) · after a slam: chain a lethal rush'], ['Mouse', 'Steer (slow turn)'], ['LMB', 'Special attack during a lethal rush']] };
  }
}
