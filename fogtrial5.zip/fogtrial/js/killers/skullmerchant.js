// THE SKULL MERCHANT — Eyes in the Sky (live design, adapted to top-down).
//  • Hold RMB (0.5 s) to deploy a DRONE at the aimed spot (≤ 10 m). Up to 6 drones; deploying
//    a 7th recycles the oldest. 7 s between deployments.
//  • Every drone has a 10 m detection zone swept by a scan line turning 105°/s. A survivor the
//    line crosses is DETECTED unless they are crouching or standing still (or the drone has no
//    line of sight to them).
//  • Detection: +1 LOCK-ON stack and the survivor shows on her radar (32 m) for 4 s.
//    At 3 stacks: healthy → injured, injured → Deep Wound; Broken 20 s and a CLAW TRAP (45 s
//    battery). A claw-trapped survivor detected again is Hindered 10% for 6 s and revealed.
//  • Survivors can HACK a drone (3 s): it is disabled for 45 s and their claw trap comes off.
//    A botched hack (failed skill check) gives a lock-on stack instead.
//  • E recalls the drone nearest your aim (1 s): Undetectable for 8 s.
import { M, dist, angleDiff, normAngle, clamp } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, Device } from './framework.js';

const ZONE = 10 * M, SWEEP = 105 * Math.PI / 180, MAX_DRONES = 6, DEPLOY_CD = 7, RADAR = 32 * M;
export class SkullMerchantPower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'drones'; this.name = 'Eyes in the Sky'; this.state = 'idle'; this.deployT = 0; this.recallT = 0;
    this.maxDrones = this.has('ultrasonic_speaker') ? 7 : MAX_DRONES;
    this.aiProfile = { type: 'surveillance', label: 'Drones', counter: ['crouch or stand still when the scan line comes', 'hack drones near objectives (removes claw traps)', 'avoid stacking lock-ons', 'stay out of overlapping zones'] };
  }
  get drones() { return this._m ? this._m.devices.filter((d) => d.kind === 'drone' && d.owner === this.k) : []; }
  active(d, m) { return !d.dead && (d.data.disabledUntil || 0) <= m.time; }
  speedMult() { return this.state === 'deploying' ? 0.5 : this.state === 'recall' ? 0.4 : 1; }
  canAttack() { return this.state === 'idle'; }
  onInit(m) { this._m = m; }
  update(dt, m, inp, locked) {
    this._m = m; this.tickCooldowns(dt);
    const k = this.k;
    if (locked) { if (this.state !== 'idle') this.state = 'idle'; return; }
    if (this.state === 'idle') {
      if (inp.rmb && !k.carrying && this.cd('deploy') <= 0) { this.state = 'deploying'; this.deployT = 0; }
      else if (inp.eP && this.drones.length) {
        const ax = k.x + Math.cos(k.facing) * (inp.aimDist ?? 10 * M), ay = k.y + Math.sin(k.facing) * (inp.aimDist ?? 10 * M);
        const d = this.drones.filter((q) => dist(q.x, q.y, k.x, k.y) < 24 * M).sort((a, b) => dist(a.x, a.y, ax, ay) - dist(b.x, b.y, ax, ay))[0];
        if (d) { this.state = 'recall'; this.recallT = 1; this.recallD = d; }
      }
    }
    if (this.state === 'deploying') {
      this.deployT += dt;
      if (!inp.rmb) { this.state = 'idle'; return; }
      if (this.deployT >= 0.5) { this.deploy(m, inp); this.state = 'idle'; }
    }
    if (this.state === 'recall') {
      this.recallT -= dt;
      if (this.recallT <= 0) { m.removeDevice(this.recallD); this.state = 'idle'; k.status.add('undetectable', { duration: 8, source: 'drone_recall' }); m.fx.text(k.x, k.y - 40, 'UNDETECTABLE', '#9fd0a0'); m.events.emit(EV.POWER_USED, { killer: k, power: 'recall' }); }
    }
  }
  deploy(m, inp) {
    const k = this.k; const r = clamp(inp.aimDist ?? 6 * M, 1.5 * M, 10 * M);
    let x = k.x, y = k.y;
    for (let t = 0.5 * M; t <= r; t += 0.5 * M) { const nx = k.x + Math.cos(k.facing) * t, ny = k.y + Math.sin(k.facing) * t; if (m.world.pointBlocked(nx, ny, 0.3 * M)) break; x = nx; y = ny; }
    const ds = this.drones; if (ds.length >= this.maxDrones) m.removeDevice(ds[0]);
    const d = m.addDevice(new Device({ kind: 'drone', x, y, r: 0.45 * M, owner: k, label: 'Drone', useLabel: 'Hack the drone', useTime: 3, survivorUsable: true, seenRange: 22 * M, dangerRadius: ZONE, aiCost: 3,
      data: { a: k.facing, disabledUntil: 0, placedT: m.time, scanned: new Map() } }));
    d.usable = (s, mm) => this.active(d, mm || m);
    d.onUse = (s, mm) => this.hacked(mm, s, d);
    this.setCd('deploy', DEPLOY_CD);
    m.fx.burst(x, y, 10, '#8fd06a', 60, 0.5, 2, 2); m.audio?.play('ui');
    m.sound('killer_action', x, y, 16 * M, { what: 'drone' });
    m.events.emit(EV.POWER_USED, { killer: k, power: 'drone' });
  }
  hacked(m, s, d) {
    // AI hack quality: a botched hack (failed check) adds a stack and leaves the drone running
    if (!s.isPlayer && Math.random() < (s.ai ? 0.25 - 0.2 * (s.ai.params?.skill ?? 0.5) : 0.1)) { this.addStack(m, s, d, 'botched hack'); s.ai?.note('Botched the drone hack', 'hackfail'); return; }
    d.data.disabledUntil = m.time + 45; m.fx.sparks(d.x, d.y);
    if (s.status.has('clawTrap')) { s.status.remove('clawTrap'); s.ai?.note('Removed my claw trap by hacking a drone', 'clawoff'); m.warn(s, 'Claw trap removed'); }
    s.ai?.note('Hacked a drone (45 s)', 'hack'); m.notifyK(`${s.name} hacked a drone`, '#8fd06a');
  }
  // player hack checks: the controller fires a skill check halfway through; a miss = botched
  onPlayerCheck(m, s, d, res) { if (res === 'fail') { s.stopAction(m); this.addStack(m, s, d, 'botched hack'); } }
  addStack(m, s, d, why) {
    const cur = s.status.get('lockOn')?.value ?? 0; const v = cur + 1;
    if (v >= 3) {
      s.status.remove('lockOn');
      if (s.health === 'healthy') { s.lastHitBy = this.k; s.lastHitT = m.time; s.health = 'injured'; s.healProgress = 0; m.events.emit(EV.SURVIVOR_INJURED, { survivor: s, source: 'drone' }); m.fx.hit(s, 'injured'); }
      else if (s.health === 'injured') { s.status.add('deepWound', { duration: 20 }); s.mend = 0; }
      s.status.add('broken', { duration: 20, source: 'drone' });
      s.status.add('clawTrap', { duration: 45, source: 'drone' });
      m.addScore('deviousness', 300, 'Claw Trap'); this.k.stats.powerHits++;
      m.notifyK(`${s.name}: claw trap attached`, '#8fd06a'); s.ai?.note('3 lock-ons: claw trap!', 'claw'); m.warn(s, 'Claw trap! Hack a drone to remove it');
      m.events.emit('powerTriggered', { survivor: s, x: s.x, y: s.y, killer: this.k });
    } else { s.status.add('lockOn', { value: v, duration: 999, source: 'drone' }); const c = s.status.get('lockOn'); c.value = v; m.warn(s, `Lock-on ${v}/3`); }
  }
  // scanning runs every frame, also while the Skull Merchant is busy
  tick(dt, m) {
    this._m = m;
    for (const d of this.drones) {
      if (!this.active(d, m)) continue;
      const a0 = d.data.a; d.data.a = normAngle(a0 + SWEEP * dt);
      for (const s of m.survivors) {
        if (!s.standing || s.hiddenIn) continue;
        const r = dist(s.x, s.y, d.x, d.y); if (r > ZONE) continue;
        const b = Math.atan2(s.y - d.y, s.x - d.x);
        // did the line pass over the survivor this frame (plus a small width)?
        const width = Math.atan2(s.r, Math.max(r, 1));
        if (angleDiff(b, d.data.a) > SWEEP * dt + width) continue;
        const last = d.data.scanned.get(s) || -9; if (m.time - last < 1.2) continue;
        if (!m.world.losClear(d.x, d.y, s.x, s.y)) continue;
        d.data.scanned.set(s, m.time);
        const still = Math.hypot(s.vx || 0, s.vy || 0) < 0.3 * M;
        if (s.moveMode === 'crouch' || still) { s.ai?.note('The scan line passed — stayed undetected', 'scanok'); continue; }
        this.detect(m, s, d);
      }
    }
  }
  detect(m, s, d) {
    m.fx.ring(s.x, s.y, 'rgba(143,208,106,0.9)', 30, 0.5); m.audio?.play('ui');
    if (dist(s.x, s.y, this.k.x, this.k.y) < RADAR) m.reveal(s, 4, 'Radar');
    else m.notifyK(`Drone detected ${s.name}`, '#8fd06a');
    if (s.status.has('clawTrap')) { s.status.add('hindered', { duration: 6, value: 0.1, source: 'claw' }); m.reveal(s, 6, 'Claw Trap'); s.ai?.note('Detected with a claw trap: hindered', 'clawscan'); return; }
    m.warn(s, 'Detected by a drone'); s.ai?.note('Detected by a drone', 'scanned');
    this.addStack(m, s, d, 'scan');
  }
  drawDevice(ctx, d, m) {
    if (d.kind !== 'drone' || d.owner !== this.k) return;
    const on = this.active(d, m);
    if (on) {
      ctx.fillStyle = 'rgba(143,208,106,0.06)'; ctx.beginPath(); ctx.arc(d.x, d.y, ZONE, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = 'rgba(143,208,106,0.25)'; ctx.lineWidth = 1; ctx.stroke();
      const g = ctx.createLinearGradient(d.x, d.y, d.x + Math.cos(d.data.a) * ZONE, d.y + Math.sin(d.data.a) * ZONE);
      ctx.fillStyle = 'rgba(143,208,106,0.22)'; ctx.beginPath(); ctx.moveTo(d.x, d.y); ctx.arc(d.x, d.y, ZONE, d.data.a - 0.3, d.data.a); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(190,255,140,0.9)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(d.x, d.y); ctx.lineTo(d.x + Math.cos(d.data.a) * ZONE, d.y + Math.sin(d.data.a) * ZONE); ctx.stroke(); void g;
    }
    ctx.fillStyle = '#2a3a2a'; ctx.beginPath(); ctx.arc(d.x, d.y, d.r + 2, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = on ? '#8fd06a' : '#7a3a3a'; ctx.beginPath(); ctx.arc(d.x, d.y, d.r * 0.55, 0, Math.PI * 2); ctx.fill();
    for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + Math.PI / 4 + m.time * (on ? 20 : 0); ctx.strokeStyle = '#4a5a4a'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(d.x + Math.cos(a) * d.r, d.y + Math.sin(a) * d.r); ctx.lineTo(d.x + Math.cos(a) * (d.r + 6), d.y + Math.sin(a) * (d.r + 6)); ctx.stroke(); }
  }
  drawOver(ctx, m) {
    const k = this.k;
    if (this.state === 'deploying') { const r = clamp(k.input.aimDist ?? 6 * M, 1.5 * M, 10 * M); ctx.strokeStyle = 'rgba(143,208,106,0.6)'; ctx.setLineDash([4, 5]); ctx.beginPath(); ctx.arc(k.x + Math.cos(k.facing) * r, k.y + Math.sin(k.facing) * r, ZONE, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]); }
  }
  drawBody(ctx) { ctx.fillStyle = '#d8d0c0'; ctx.beginPath(); ctx.arc(5, 0, 6, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#2a2a2a'; ctx.fillRect(7, -4, 3, 8); }
  hud(m) {
    const n = this.drones.length, act = m ? this.drones.filter((d) => this.active(d, m)).length : n;
    const trapped = m ? m.survivors.filter((s) => s.status.has('clawTrap')).length : 0;
    return { title: 'Eyes in the Sky', value: `${act}/${n} drones`, meter: this.state === 'deploying' ? this.deployT / 0.5 : 1 - this.cd('deploy') / DEPLOY_CD,
      state: this.state === 'recall' ? 'Recalling…' : this.cd('deploy') > 0 ? `Deploy in ${Math.ceil(this.cd('deploy'))}s · ${trapped} claw-trapped` : `Ready · ${trapped} claw-trapped`,
      hints: [['Q / RMB', 'Hold: deploy a drone at the aimed spot (≤10 m)'], ['E', 'Recall the drone nearest your aim → Undetectable 8 s']] };
  }
}
