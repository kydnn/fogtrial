// THE CANNIBAL — Bubba's Chainsaw (current design, adapted to top-down).
//  • 3 chainsaw charges, refilling at 0.25 charge/s while the saw is idle.
//  • Hold RMB to REV (2 s, slowed). Releasing early cancels for free. Releasing a full rev
//    starts the CHAINSAW SWEEP (costs 1 charge): Bubba carves forward in a wide arc, accelerating over
//    2.5 s up to 5.35 m/s. Mouse steers (slowly). Every survivor the blade touches is downed —
//    one sweep can down several.
//  • Press LMB during a sweep to DASH: spend another charge for a burst of top speed and
//    more sweep time.
//  • Holding the full rev too long (3 s total) without letting the saw go, or ramming a wall, rock or other
//    solid obstacle, throws him into a TANTRUM: 3 s + 1 s per remaining charge, Hindered 90%,
//    flailing around him (anyone right next to him is still hit). All charges are lost.
//  • Dropped pallets and breakable walls in the sweep's path are sawn through (1 s cooldown).
//  • Cooldowns after the sweep ends: hit 2 s · miss 1.5 s + 1 s per charge spent · pallet 1 s.
// Unlike the Hillbilly (long, fast, straight sprint with overheat), Bubba is short range,
// wide and slow to turn: survivors beat him by keeping distance, forcing the sweep into
// walls and windows, and by spreading out so one sweep can't catch two.
import { M, dist, angleDiff, normAngle, clamp } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, strike } from './framework.js';

const REV = 2.0, OVERREV = 3.0, RAMP = 2.5, TOP = 5.35, START = 3.6;
export class CannibalPower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'bubba'; this.name = "Bubba's Chainsaw"; this.state = 'idle';
    this.maxCharges = this.has('award_winning_chili') ? 4 : 3; this.charges = this.maxCharges; this.rev = 0; this.revHeld = 0;
    this.revTime = this.has('primer_bulb') ? 1.7 : REV; this.turn = this.has('light_chassis') ? 1.6 : 1.25;
    this.reach = (this.has('long_guide_bar') ? 2.6 : 2.2) * M; this.tantrumT = 0; this.sweepT = 0; this.downed = new Set(); this.soundT = 0;
    this.regenRate = this.has('knife_scratches') ? 0.33 : 0.25; this.cdT = 0; this.spent = 0; this.speedNow = START;
    this.aiProfile = { type: 'sweep', label: 'Chainsaw sweep', counter: ['keep more than 6 m away', 'make him sweep into walls (tantrum)', 'windows — he can\'t vault while sawing', 'spread out: one sweep downs everyone it touches'] };
  }
  speedMult() {
    const base = this.k.def.speed * M;
    if (this.state === 'revving') return 0.6;
    if (this.state === 'sweep') return this.speedNow * M / base;
    if (this.state === 'tantrum') return 1; // Hindered 90% status does the slowing
    return 1;
  }
  canAttack() { return this.state === 'idle' || this.state === 'cooldown'; }
  canInteract() { return this.state === 'idle' || this.state === 'cooldown'; }
  overrideMove() { return this.state === 'sweep' ? { x: Math.cos(this.dir), y: Math.sin(this.dir) } : null; }
  noContext() { return this.state === 'sweep' || this.state === 'tantrum'; }
  update(dt, m, inp, locked) {
    this.tickCooldowns(dt);
    const k = this.k; this.soundT -= dt;
    if ((this.state === 'idle' || this.state === 'cooldown') && this.charges < this.maxCharges) this.charges = Math.min(this.maxCharges, this.charges + this.regenRate * dt);
    if (this.state === 'cooldown') { this.cdT -= dt; if (this.cdT <= 0) this.state = 'idle'; }
    if (this.state === 'tantrum') { // runs even while "locked" by the tantrum itself
      this.tantrumT -= dt; k.facing += dt * 9; this.sawHits(m, Math.PI, 1.4 * M);
      if (this.tantrumT <= 0) { this.state = 'cooldown'; this.cdT = 3; this.lockFacing = false; }
      return;
    }
    if (locked) { if (this.state === 'revving' || this.state === 'sweep') this.endSweep(m, 'interrupted'); return; }
    switch (this.state) {
      case 'idle':
        if (inp.rmb && !k.carrying && this.charges >= 1) { this.state = 'revving'; this.rev = 0; this.revHeld = 0; m.events.emit(EV.POWER_USED, { killer: k, power: 'rev' }); }
        break;
      case 'revving':
        this.rev += dt / this.revTime; this.revHeld += dt;
        if (this.soundT <= 0) { this.soundT = 0.3; m.sound('chainsaw_rev', k.x, k.y, 36 * M, { charge: Math.min(1, this.rev), bubba: true }); m.audio?.play('rev', { charge: Math.min(1, this.rev) }); }
        if (!inp.rmb) { if (this.rev >= 1) this.startSweep(m); else { this.state = 'idle'; this.rev = 0; } break; } // early release: free cancel
        if (this.revHeld >= OVERREV) this.tantrum(m, 'overrev'); // held the full rev too long
        break;
      case 'sweep': {
        this.sweepT += dt; k.facing = this.dir;
        this.speedNow = this.dashT > 0 ? TOP : START + (TOP - START) * Math.min(1, this.sweepT / RAMP); this.dashT = Math.max(0, (this.dashT || 0) - dt);
        const d = normAngle(inp.aim - this.dir); this.dir += clamp(d, -this.turn * dt, this.turn * dt);
        if (this.soundT <= 0) { this.soundT = 0.2; m.sound('chainsaw_sprint', k.x, k.y, 36 * M, { dir: this.dir, bubba: true }); }
        this.sawHits(m, Math.PI * 0.42);
        // dash: spend another charge for top speed and more sweep time
        if (inp.lmbP && this.charges >= 1) { this.charges -= 1; this.spent++; this.dashT = 0.8; this.left += 1.2; m.fx.text(k.x, k.y - 40, 'DASH', '#ff8a4a'); m.events.emit(EV.POWER_USED, { killer: k, power: 'dash' }); }
        // saw through dropped pallets / breakable walls in front
        const fx = k.x + Math.cos(this.dir) * 0.9 * M, fy = k.y + Math.sin(this.dir) * 0.9 * M;
        for (const p of m.map.pallets) if (p.state === 'down' && p.stunZone({ x: fx, y: fy })) { m.breakPallet(p, k); this.endSweep(m, 'pallet'); return; }
        this.left -= dt;
        if (this.left <= 0 || (inp.rmbP && this.sweepT > 0.3)) this.endSweep(m, this.downed.size ? 'hit' : 'miss');
        break;
      }
    }
  }
  startSweep(m) {
    const k = this.k; this.state = 'sweep'; this.dir = k.facing; this.lockFacing = true; this.sweepT = 0; this.left = 2.6; this.dashT = 0;
    this.charges -= 1; this.spent = 1; this.downed = new Set(); this.speedNow = START;
    m.audio?.play('saw'); m.events.emit(EV.POWER_USED, { killer: k, power: 'sweep' });
  }
  endSweep(m, why) {
    this.lockFacing = false; this.state = 'cooldown';
    this.cdT = why === 'hit' ? 2 : why === 'pallet' ? 1 : why === 'interrupted' ? 1 : 1.5 + this.spent;
    if (this.downed.size) this.cdT = 2;
    this.lastEnd = { why, t: m.time, hits: this.downed.size };
  }
  sawHits(m, arc, reach = this.reach) {
    const k = this.k;
    for (const s of m.survivors) {
      if (!s.standing || this.downed.has(s)) continue;
      const d = dist(k.x, k.y, s.x, s.y); if (d > reach + s.r) continue;
      if (angleDiff(Math.atan2(s.y - k.y, s.x - k.x), k.facing) > arc && d > k.r + s.r + 6) continue;
      if (!m.world.losClear(k.x, k.y, s.x, s.y)) continue;
      const r = strike(m, k, s, { instadown: true, source: 'chainsaw', score: 'brutality', label: 'Chainsaw' });
      if (r && r !== 'dodged') { this.downed.add(s); m.fx.shake(10); s.ai?.note('Sawed by the Cannibal', 'bubbasaw'); if (this.downed.size > 1) m.fx.text(k.x, k.y - 50, `MULTI-DOWN ×${this.downed.size}`, '#ff5b3b'); }
    }
  }
  onCollide(m) { if (this.state === 'sweep' && this.sweepT > 0.15) this.tantrum(m, 'wall'); }
  tantrum(m, what) {
    const k = this.k;
    this.tantrumT = (this.has('the_beast_marks') ? 2.2 : 3) + Math.floor(this.charges); this.charges = 0;
    this.state = 'tantrum'; this.lockFacing = true;
    k.status.add('hindered', { duration: this.tantrumT, value: 0.9, source: 'tantrum' });
    m.fx.shake(12); m.audio?.play('clang'); m.fx.text(k.x, k.y - 40, 'TANTRUM', '#ff8a4a');
    m.sound('killer_action', k.x, k.y, 30 * M, { what: 'tantrum' });
    m.events.emit(EV.POWER_USED, { killer: k, power: 'tantrum', what });
    for (const s of m.survivors) if (s.standing && dist(s.x, s.y, k.x, k.y) < 16 * M) s.ai?.note(what === 'overrev' ? 'Bubba over-revved into a tantrum' : 'Made Bubba tantrum on the wall', 'tantrum');
  }
  onStun() { this.state = 'idle'; this.lockFacing = false; }
  drawWeapon(ctx) {
    const k = this.k, on = this.state === 'sweep' || this.state === 'revving' || this.state === 'tantrum';
    const j = on ? (Math.random() - 0.5) * 2 : 0;
    ctx.fillStyle = on ? '#d06a2a' : '#6b6e72'; ctx.fillRect(k.r - 6, -5 + j, 30, 10); ctx.fillStyle = '#3a2a1e'; ctx.fillRect(k.r - 10, -8, 10, 16);
    if (on) { ctx.strokeStyle = 'rgba(255,170,80,0.85)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(k.r + 24, -5); ctx.lineTo(k.r + 24, 5); ctx.stroke(); }
    return true;
  }
  drawBody(ctx) { ctx.fillStyle = '#d8c8a8'; ctx.beginPath(); ctx.arc(6, 0, 6, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#7a3a2a'; ctx.fillRect(8, -3, 3, 6); }
  drawOver(ctx) {
    const k = this.k; if (this.state !== 'sweep' && this.state !== 'tantrum' && this.state !== 'revving') return;
    if (this.state === 'revving') { // rev meter ring + exhaust
      ctx.strokeStyle = this.revHeld > 2.3 ? '#ff5b3b' : '#d06a2a'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(k.x, k.y, k.r + 8, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * Math.min(1, this.rev)); ctx.stroke();
    }
    ctx.fillStyle = this.state === 'revving' ? 'rgba(208,106,42,0.08)' : this.state === 'tantrum' ? 'rgba(255,90,60,0.22)' : 'rgba(208,106,42,0.18)';
    ctx.beginPath(); ctx.moveTo(k.x, k.y); const arc = this.state === 'tantrum' ? Math.PI : Math.PI * 0.42; const r = this.state === 'tantrum' ? 1.4 * M : this.reach;
    ctx.arc(k.x, k.y, r, k.facing - arc, k.facing + arc); ctx.closePath(); ctx.fill();
  }
  hud() {
    const label = { idle: 'Ready', revving: this.revHeld > 2.3 ? 'OVER-REVVING!' : 'Revving', sweep: this.dashT > 0 ? 'DASH' : `SWEEP ${this.speedNow.toFixed(2)} m/s`, tantrum: `TANTRUM ${Math.ceil(this.tantrumT)}s`, cooldown: `Cooldown ${this.cdT.toFixed(1)}s` }[this.state];
    return { title: "Bubba's Chainsaw", value: `${Math.floor(this.charges)}/${this.maxCharges}`, meter: this.state === 'revving' ? Math.min(1, this.rev) : this.charges / this.maxCharges, state: label,
      hints: [['Q / RMB', 'Hold 2 s to rev, release to sweep (early release cancels, 3 s = tantrum)'], ['Mouse', 'Steer the sweep'], ['LMB (sweeping)', 'Dash: spend a charge for top speed'], ['RMB (sweeping)', 'Stop the sweep']] };
  }
}
