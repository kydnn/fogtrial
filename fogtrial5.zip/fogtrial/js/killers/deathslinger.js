// THE DEATHSLINGER — The Redeemer. Hold RMB to aim down the sights (slowed, shown as a
// laser line), LMB fires a harpoon: a real projectile with travel time (not hitscan),
// stopped by walls. A speared survivor is chained to him and reeled in while he holds
// LMB; up close he can strike them normally. The chain snaps if it is pulled against an
// obstacle (the survivor is injured with Deep Wound), if the reel runs too long, or if he
// is stunned. After every shot he has to reload (about 2 s, slowed).
import { M, dist, clamp } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, Projectile, strike } from './framework.js';

export class DeathslingerPower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'redeemer'; this.name = 'The Redeemer'; this.state = 'idle'; this.loaded = true;
    this.range = (this.has('rusted_spike') ? 20 : 18) * M; this.speed = 55 * M; this.reelSpeed = 3.6 * M;
    this.reloadTime = this.has('speed_loader') ? 1.5 : 2.0; this.reelMax = this.has('chewing_tobacco') ? 8 : 6; this.speared = null;
    this.aiProfile = { type: 'harpoon', label: 'Harpoon gun', counter: ['break line of sight', 'zig-zag when he aims', 'pull the chain against obstacles'] };
  }
  speedMult() { if (this.state === 'aiming') return 0.7; if (this.state === 'reload') return 0.55; if (this.state === 'reel') return 0.5; return 1; }
  canAttack() { return this.state === 'idle' || (this.state === 'reel' && this.speared && dist(this.k.x, this.k.y, this.speared.x, this.speared.y) < 2.6 * M); }
  update(dt, m, inp, locked) {
    this.tickCooldowns(dt);
    const k = this.k;
    if (this.state === 'reel') this.updateReel(dt, m, inp, locked);
    if (locked) { if (this.state === 'aiming') this.state = 'idle'; return; }
    if (this.state === 'reload') { if (this.cd('reload') <= 0) { this.loaded = true; this.state = 'idle'; m.audio?.play('reload'); } return; }
    if (this.state === 'idle' && inp.rmb && !k.carrying && this.loaded) { this.state = 'aiming'; m.sound('power_windup', k.x, k.y, 20 * M, { what: 'aim', dir: k.facing }); }
    if (this.state === 'aiming') {
      if (!inp.rmb) { this.state = 'idle'; return; }
      this.aimT = (this.aimT || 0) + dt;
      if (inp.lmbP) this.fire(m);
    } else this.aimT = 0;
    if (this.state === 'idle' && !this.loaded) { this.state = 'reload'; this.setCd('reload', this.reloadTime); }
  }
  fire(m) {
    const k = this.k, a = k.facing; this.loaded = false; this.state = 'flying';
    k.attack.state = 'hit'; k.attack.t = 2.0; // no immediate slash after the shot
    m.spawnProjectile(new Projectile({ kind: 'harpoon', owner: k, x: k.x + Math.cos(a) * k.r, y: k.y + Math.sin(a) * k.r, vx: Math.cos(a) * this.speed, vy: Math.sin(a) * this.speed, r: 0.18 * M, range: this.range, color: '#b9a37a',
      onHit: (p, s, mm) => { if (s.dodgeT && s.dodgeT > mm.time) { mm.fx.text(s.x, s.y - 30, 'DODGED', '#ffd27a'); this.toReload(); return; } this.spear(mm, s); },
      onWall: (p, mm) => { mm.fx.sparks(p.x, p.y); this.toReload(); }, onEnd: () => this.toReload() }));
    m.audio?.play('throw'); m.fx.shake(4); m.sound('killer_action', k.x, k.y, 32 * M, { what: 'shot' });
    m.events.emit(EV.POWER_USED, { killer: k, power: 'harpoon' });
  }
  toReload() { if (this.state === 'flying') { this.state = 'reload'; this.setCd('reload', this.reloadTime); } }
  spear(m, s) {
    const k = this.k; this.state = 'reel'; this.speared = s; this.reelT = 0;
    s.stopAction(m); s.vault = null; s.status.add('grabbed', { source: 'harpoon' }); m.events.emit('powerTriggered', { survivor: s, x: s.x, y: s.y }); 
    m.fx.hit(s, 'injured'); m.addScore('hunter', 300, 'Speared'); k.stats.powerHits++;
    s.ai?.note('Speared by the Deathslinger', 'speared');
    const self = this;
    s.control = { kind: 'harpoon', allow: ['dropPallet'], update(dt, mm, sv) {
      if (self.speared !== sv) return false;
      // the survivor fights the pull: moves away at walking pace while being reeled
      const dx = k.x - sv.x, dy = k.y - sv.y, d = Math.hypot(dx, dy) || 1;
      let ux = dx / d * self.reelSpeed, uy = dy / d * self.reelSpeed;
      if (sv.moveTo) { const ax = sv.moveTo.x - sv.x, ay = sv.moveTo.y - sv.y, al = Math.hypot(ax, ay) || 1; ux += ax / al * 1.6 * M; uy += ay / al * 1.6 * M; }
      if (d > 1.6 * M) mm.world.move(sv, ux * dt, uy * dt, sv.r);
      sv.facing = Math.atan2(-dy, -dx);
      return true;
    } };
  }
  updateReel(dt, m, inp, locked) {
    const s = this.speared, k = this.k; this.reelT += dt;
    if (!s || !s.standing) return this.release(m, null);
    if (locked && k.stunT > 0) return this.release(m, 'stunned');
    // chain snaps against obstacles between them
    if (!m.world.losClear(k.x, k.y, s.x, s.y)) return this.release(m, 'snapped');
    if (this.reelT > this.reelMax || dist(k.x, k.y, s.x, s.y) > this.range + 4 * M) return this.release(m, 'snapped');
    if (k.attack.state === 'hit' && k.attack.t < 0.1 && this.reelT > 0.3) { /* basic hit landed — release */ }
  }
  onBasicHit(m, s) { if (s === this.speared) this.release(m, null); }
  release(m, why) {
    const s = this.speared; this.speared = null; this.state = 'reload'; this.setCd('reload', this.reloadTime);
    if (!s) return;
    if (s.control?.kind === 'harpoon') s.control = null; s.status.remove('grabbed', 'harpoon');
    if (why === 'snapped' && s.standing) {
      // breaking free tears the spear out: injured + Deep Wound
      if (s.health === 'healthy') { s.health = 'injured'; m.events.emit(EV.SURVIVOR_INJURED, { survivor: s, source: 'harpoon' }); }
      s.status.add('deepWound', { duration: 20 }); s.status.add('haste', { duration: 1.5, value: 0.3, source: 'snap' });
      m.fx.text(s.x, s.y - 30, 'CHAIN SNAPPED', '#ffd27a'); s.ai?.note('Broke the harpoon chain on an obstacle', 'snap');
    }
  }
  onStun(m) { if (this.state === 'reel') this.release(m, 'stunned'); if (this.state === 'aiming') this.state = 'idle'; }
  // basic attack while reeling: hooked into the killer's attack via onAttack
  onAttack(m) { if (this.state === 'reel') { this._releaseAfterSwing = true; } }
  tick(dt, m) { if (this._releaseAfterSwing && this.k.attack.state !== 'lunge') { this._releaseAfterSwing = false; if (this.state === 'reel') this.release(m, null); } }
  drawWeapon(ctx) {
    const k = this.k; ctx.fillStyle = '#5a4a36'; ctx.fillRect(k.r - 6, -3, 30, 6); ctx.fillStyle = '#9a9ca0'; ctx.fillRect(k.r + 18, -2, 10, 4);
    if (this.loaded) { ctx.fillStyle = '#b9a37a'; ctx.beginPath(); ctx.moveTo(k.r + 28, -3); ctx.lineTo(k.r + 34, 0); ctx.lineTo(k.r + 28, 3); ctx.fill(); }
    return true;
  }
  drawOver(ctx, m) {
    const k = this.k;
    if (this.state === 'aiming') { ctx.strokeStyle = 'rgba(255,60,60,0.55)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.lineTo(k.x + Math.cos(k.facing) * this.range, k.y + Math.sin(k.facing) * this.range); ctx.stroke(); }
    const s = this.speared; if (s) { ctx.strokeStyle = '#b9a37a'; ctx.lineWidth = 2; ctx.setLineDash([5, 3]); ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.lineTo(s.x, s.y); ctx.stroke(); ctx.setLineDash([]); }
    for (const p of m.projectiles) if (p.kind === 'harpoon') { ctx.strokeStyle = 'rgba(185,163,122,0.7)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.lineTo(p.x, p.y); ctx.stroke(); }
  }
  hud() {
    const st = { idle: this.loaded ? 'Loaded' : 'Empty', aiming: 'Aiming — LMB to fire', flying: 'Harpoon in flight', reel: 'Reeling — LMB to strike up close', reload: 'Reloading…' }[this.state];
    return { title: 'The Redeemer', value: this.loaded ? '1/1' : '0/1', meter: this.state === 'reload' ? 1 - this.cd('reload') / this.reloadTime : this.loaded ? 1 : 0, state: st,
      hints: [['Q / RMB', 'Hold to aim down sights'], ['LMB', 'While aiming: fire the harpoon'], ['LMB', 'While reeling: strike']] };
  }
}
