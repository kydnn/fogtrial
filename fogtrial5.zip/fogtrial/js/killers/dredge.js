// THE DREDGE — Reign of Darkness. Tap RMB to enter the Gloaming: a Remnant is left
// where you stood, you move slower and cannot attack. In the Gloaming, aim at any locker
// on the map and tap RMB to teleport into it (costs a token); LMB snaps you back to the
// Remnant; E leaves the Gloaming. Teleports travel through the dark at 19 m/s (38 m/s at
// Nightfall) and survivors near the destination locker hear it rattle. Survivors can
// lock lockers: a locked locker takes much longer to burst out of and the lock breaks.
// Nightfall builds from hits, hooks, locker time and the injured; when full, the map goes
// dark for 60 s: survivors see almost nothing, the Dredge is Undetectable and teleports
// faster with a short cooldown.
import { M, dist } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, Device } from './framework.js';

const NIGHT_MAX = 300;
export class DredgePower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'nightfall'; this.name = 'Reign of Darkness'; this.state = 'idle';
    this.tokens = this.has('boat_key') ? 4 : 3; this.maxTokens = this.tokens; this.remnant = null; this.target = null;
    this.night = 0; this.nightfall = false; this.nightT = 0; this.travel = null; this.tokenT = 0;
    this.nightLen = this.has('malthinkers_skull') ? 70 : 60;
    this.aiProfile = { type: 'lockers', label: 'Locker teleports & Nightfall', counter: ['lock lockers near objectives', 'watch lockers', 'play safe during Nightfall'] };
  }
  get lockers() { return this._m ? this._m.devices.filter((d) => d.kind === 'locker') : []; }
  onInit(m) {
    this._m = m;
    for (const p of m.map.openSpots(14, 12, [...m.map.gens, ...m.map.hooks])) m.addDevice(new Device({ kind: 'locker', x: p.x, y: p.y, r: 0.7 * M, label: 'Locker', seenRange: 22 * M, useTime: 1.5, survivorUsable: true, data: { locked: false } }));
    m.events.on(EV.SURVIVOR_HOOKED, () => { if (!this.nightfall) this.night += 20; });
    m.events.on(EV.KILLER_HIT, (d) => { if (!this.nightfall && d.result === 'injured' && !d.power) this.night += 20; });
    // bind usable/onUse to each locker instance
    for (const d of this.lockers) { d.usable = () => !d.data.locked && !(this.travel?.to === d); d.onUse = (s, mm) => { d.data.locked = true; mm.fx.text(d.x, d.y - 26, 'LOCKED', '#cfd3d6'); s.ai?.note('Locked a locker against the Dredge', 'lock'); mm.events.emit('lockerLocked', { locker: d, survivor: s }); }; }
  }
  speedMult() { if (this.state === 'gloaming') return 4.0 / this.k.def.speed; if (this.state === 'travel' || this.state === 'exit') return 0; return 1; }
  canAttack() { return this.state === 'idle'; }
  noContext() { return this.state !== 'idle'; }
  alpha() { return this.state === 'travel' ? 0 : this.state === 'gloaming' ? 0.35 : this.state === 'exit' ? 0.6 : 1; }
  visibilityTo() { return this.state === 'gloaming' ? 0.4 : 1; }
  get cooldown() { return this.nightfall ? 4 : 10; }
  // a locker the player is pointing at: nearest locker to the aim point
  aimLocker(m, inp) {
    const k = this.k; const d = Math.min(inp.aimDist ?? 10 * M, 60 * M) * 2.2;
    const ax = k.x + Math.cos(k.facing) * d, ay = k.y + Math.sin(k.facing) * d;
    let best = null, bd = Infinity;
    for (const l of this.lockers) { const dd = dist(l.x, l.y, ax, ay) + dist(l.x, l.y, k.x, k.y) * 0.15; if (dist(l.x, l.y, k.x, k.y) < 3 * M) continue; if (dd < bd) { bd = dd; best = l; } }
    return best;
  }
  update(dt, m, inp, locked) {
    this._m = m; this.tickCooldowns(dt);
    const k = this.k;
    if (this.tokens < this.maxTokens) { this.tokenT += dt; if (this.tokenT > 20) { this.tokenT = 0; this.tokens++; } }
    if (this.state === 'travel') {
      const t = this.travel; t.t += dt; const f = Math.min(1, t.t / t.dur);
      k.x = t.fx + (t.to.x - t.fx) * f; k.y = t.fy + (t.to.y - t.fy) * f;
      if (f >= 1) { this.state = 'exit'; this.exitT = t.to.data.locked ? 2.25 : 0.45; this.night += 0; k.x = t.to.x; k.y = t.to.y; }
      return;
    }
    if (this.state === 'exit') {
      this.exitT -= dt; this.night += dt * 6;
      if (this.exitT <= 0) this.emerge(m);
      return;
    }
    if (locked) { if (this.state === 'gloaming') this.leaveGloaming(m); return; }
    if (this.state === 'idle' && inp.rmbP && !k.carrying) { this.enterGloaming(m); return; }
    if (this.state === 'gloaming') {
      this.gloamT += dt; this.target = this.aimLocker(m, inp);
      if (inp.lmbP && this.remnant) { this.returnToRemnant(m); return; }
      if (inp.eP || this.gloamT > 15) { this.leaveGloaming(m); return; }
      if (inp.rmbP && this.target && this.tokens > 0 && this.cd('tp') <= 0) this.teleport(m, this.target);
    }
  }
  enterGloaming(m) {
    const k = this.k; this.state = 'gloaming'; this.gloamT = 0;
    this.remnant = { x: k.x, y: k.y, t: m.time };
    m.events.emit(EV.POWER_USED, { killer: k, power: 'gloaming' }); m.audio?.play('teleport');
  }
  leaveGloaming() { this.state = 'idle'; this.remnant = null; this.target = null; }
  returnToRemnant(m) {
    const k = this.k, r = this.remnant; this.remnant = null; this.state = 'idle';
    m.fx.burst(k.x, k.y, 16, '#20202a', 80, 0.6, 3, 2); k.x = r.x; k.y = r.y; m.world.resolve(k, k.r);
    this.night += 10; m.audio?.play('teleport'); m.sound('killer_action', k.x, k.y, 20 * M, { what: 'remnant' });
  }
  teleport(m, l) {
    const k = this.k; this.tokens--; this.setCd('tp', this.cooldown); this.remnant = null; this.target = null;
    const d = dist(k.x, k.y, l.x, l.y);
    this.travel = { to: l, t: 0, dur: Math.max(0.5, d / ((this.nightfall ? 38 : 19) * M)), fx: k.x, fy: k.y };
    this.state = 'travel'; k.hidden = true;
    m.sound('power_warn', l.x, l.y, 12 * M, { what: 'locker', note: 'A locker nearby rattles — the Dredge is coming' });
    m.events.emit(EV.POWER_USED, { killer: k, power: 'teleport' }); this.night += 0;
  }
  emerge(m) {
    const k = this.k, l = this.travel.to; this.travel = null; this.state = 'idle'; k.hidden = false;
    if (l.data.locked) { l.data.locked = false; m.fx.text(l.x, l.y - 26, 'LOCK BROKEN', '#ffd27a'); }
    // step out in front of the locker toward open ground
    let best = null; for (let a = 0; a < 8; a++) { const x = l.x + Math.cos(a * Math.PI / 4) * 1.1 * M, y = l.y + Math.sin(a * Math.PI / 4) * 1.1 * M; if (!m.world.pointBlocked(x, y, k.r)) { best = { x, y, a: a * Math.PI / 4 }; break; } }
    if (best) { k.x = best.x; k.y = best.y; k.facing = best.a; }
    m.world.resolve(k, k.r); m.audio?.play('kick');
    m.sound('killer_action', k.x, k.y, 24 * M, { what: 'locker' });
    // anyone right at the locker is grabbed straight out of the dark
    for (const s of m.survivors) if (s.standing && dist(s.x, s.y, l.x, l.y) < 1.2 * M) { m.reveal(s, 2, 'Locker'); }
  }
  // Nightfall clock (runs even while stunned / acting)
  tick(dt, m) {
    const injured = m.survivors.filter((s) => s.health === 'injured').length;
    if (this.nightfall) {
      this.nightT -= dt;
      for (const s of m.survivors) if (s.alive) s.status.add('nightfall', { duration: 0.5, source: 'dredge' });
      this.k.status.add('undetectable', { duration: 0.5, source: 'nightfall' });
      if (this.state === 'exit' || this.state === 'travel') for (const s of m.survivors) if (s.standing && dist(s.x, s.y, this.k.x, this.k.y) < 16 * M) m.reveal(s, 0.5, 'Nightfall', true);
      if (this.nightT <= 0) { this.nightfall = false; this.night = 0; m.notifyK('Daylight returns', '#cfd3d6'); m.events.emit('nightfallEnd', {}); }
      return;
    }
    this.night += dt * (0.25 + Math.min(4, injured));
    if (this.night >= NIGHT_MAX) {
      this.nightfall = true; this.nightT = this.nightLen;
      m.notifyK('NIGHTFALL — the map is plunged into darkness', '#9a8fe0'); m.audio?.play('collapse'); m.fx.shake(6);
      m.events.emit('nightfall', {}); m.sound('power_warn', this.k.x, this.k.y, 1e9, { what: 'nightfall', note: 'Nightfall!' });
      for (const s of m.survivors) s.ai?.note('Nightfall — it is pitch black', 'nightfall');
    }
  }
  drawDevice(ctx, d) {
    if (d.kind !== 'locker') return;
  }
  drawGround(ctx, m) {
    for (const l of this.lockers) {
      if (l === this.target) { ctx.strokeStyle = 'rgba(154,143,224,0.95)'; ctx.lineWidth = 3; ctx.strokeRect(l.x - 16, l.y - 20, 32, 40); }
      if (l.data.locked) { ctx.fillStyle = '#cfd3d6'; ctx.fillRect(l.x - 4, l.y - 3, 8, 7); ctx.strokeStyle = '#cfd3d6'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(l.x, l.y - 4, 3, Math.PI, 0); ctx.stroke(); }
    }
    if (this.remnant) { const r = this.remnant; ctx.fillStyle = 'rgba(30,26,46,0.85)'; ctx.beginPath(); ctx.arc(r.x, r.y, this.k.r, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = 'rgba(154,143,224,0.6)'; ctx.lineWidth = 2; ctx.stroke(); }
  }
  drawOver(ctx, m) {
    const k = this.k;
    if (this.state === 'gloaming' && this.target) { ctx.strokeStyle = 'rgba(154,143,224,0.5)'; ctx.setLineDash([6, 6]); ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.lineTo(this.target.x, this.target.y); ctx.stroke(); ctx.setLineDash([]); }
    if (this.travel) { const t = this.travel; ctx.strokeStyle = 'rgba(80,70,140,0.6)'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(t.fx, t.fy); ctx.lineTo(k.x, k.y); ctx.stroke(); }
  }
  drawBody(ctx) { const k = this.k; ctx.fillStyle = '#121218'; ctx.beginPath(); ctx.arc(2, 0, k.r * 0.75, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#9a8fe0'; ctx.beginPath(); ctx.arc(7, -3, 1.6, 0, Math.PI * 2); ctx.arc(7, 3, 1.6, 0, Math.PI * 2); ctx.fill(); }
  drawWeapon(ctx) { const k = this.k; ctx.strokeStyle = '#3a3448'; ctx.lineWidth = 4; for (const y of [-7, 7]) { ctx.beginPath(); ctx.moveTo(k.r - 4, y); ctx.lineTo(k.r + 14, y * 1.3); ctx.stroke(); } return true; }
  prompt() { return this.state === 'gloaming' ? { key: 'Q', label: this.target ? (this.tokens ? (this.cd('tp') > 0 ? `Teleport in ${Math.ceil(this.cd('tp'))}s` : 'Teleport to locker') : 'No tokens') : 'Aim at a locker' } : null; }
  hud() {
    const st = this.nightfall ? `NIGHTFALL ${Math.ceil(this.nightT)}s` : { idle: 'Daytime', gloaming: 'The Gloaming', travel: 'Travelling…', exit: 'Emerging' }[this.state];
    return { title: 'Reign of Darkness', value: `${this.tokens}◆`, meter: this.nightfall ? this.nightT / this.nightLen : this.night / NIGHT_MAX, state: st,
      hints: [['Q / RMB', 'Gloaming · then Q: teleport to aimed locker'], ['LMB', 'In Gloaming: return to Remnant'], ['E', 'Leave the Gloaming']] };
  }
}
