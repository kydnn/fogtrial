// THE KNIGHT — Guardia Compagnia. Tap RMB to start drawing a patrol path (walk it out),
// tap RMB again to summon the current Guard at the start of the path (a path drawn shorter
// than 4 m sends the Guard straight toward where you aim instead). E cycles the Guard;
// after each summon the order also rotates Carnifex → Assassin → Jailer.
// The Guard patrols the path with a 180° vision cone. When it spots a survivor it moves to
// that spot (phasing through obstacles), plants a Standard and HUNTS the survivor: it
// chases with its own pathfinding, breaks pallets in its way and injures on contact. The
// hunt ends when its timer runs out (drains 3× faster while the Knight is within 8 m), when
// the survivor grabs the Standard, or when the survivor is downed.
//   Carnifex — breaks pallets/generators fast.  Assassin — fastest hunter, Deep Wound.
//   Jailer — 16 m detection, long patrol and hunt.
import { M, dist, angleDiff, clamp } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, Minion, Device, strike } from './framework.js';

export const GUARDS = {
  carnifex: { id: 'carnifex', name: 'The Carnifex', color: '#b04a3a', patrolSpeed: 3.4, huntSpeed: 4.1, patrolTime: 12, huntTime: 12, detect: 10, breakTime: 1.8, standardDelay: 5, deepWound: false },
  assassin: { id: 'assassin', name: 'The Assassin', color: '#4a6ab0', patrolSpeed: 3.4, huntSpeed: 4.4, patrolTime: 12, huntTime: 12, detect: 10, breakTime: 5, standardDelay: 5, deepWound: true },
  jailer: { id: 'jailer', name: 'The Jailer', color: '#c09a3a', patrolSpeed: 4.1, huntSpeed: 4.1, patrolTime: 24, huntTime: 24, detect: 16, breakTime: 3, standardDelay: 10, deepWound: false },
};
const ORDER = ['carnifex', 'assassin', 'jailer'];

class Guard extends Minion {
  constructor(power, type, path) {
    super({ kind: 'guard', owner: power.k, x: path[0].x, y: path[0].y, r: 0.5 * M, color: type.color, label: type.name, threat: 1, visRange: 34 * M });
    this.p = power; this.type = type; this.patrol = path; this.pi = 1; this.dirSign = 1; this.state = 'patrol'; this.time = type.patrolTime;
    this.stunnable = true; this.stunTime = 2; this.breaking = null; this.kicked = new Set();
  }
  update(dt, m) {
    const T = this.type, k = this.p.k;
    if (this.breaking) { this.breaking.t -= dt; if (this.breaking.t <= 0) { if (this.breaking.p.state === 'down') m.breakPallet(this.breaking.p); this.breaking = null; } return; }
    if (this.state === 'patrol') {
      this.time -= dt; if (this.time <= 0) return this.p.endGuard(m, 'patrol over');
      const tgt = this.patrol[this.pi]; const dx = tgt.x - this.x, dy = tgt.y - this.y, d = Math.hypot(dx, dy);
      if (d < 0.3 * M) { this.pi += this.dirSign; if (this.pi >= this.patrol.length || this.pi < 0) { this.dirSign *= -1; this.pi = clamp(this.pi + this.dirSign * 2, 0, this.patrol.length - 1); } }
      else this.moveDir(dt, m, dx / d, dy / d, T.patrolSpeed * M);
      // generators along the patrol take a kick
      for (const g of m.map.gens) if (!g.done && g.charges > 0 && !this.kicked.has(g) && g.repairers.size === 0 && dist(g.x, g.y, this.x, this.y) < 2.4 * M) { this.kicked.add(g); m.kickGenerator(g); }
      this.breakAhead(m);
      // vision: 180° cone in the walking direction
      for (const s of m.survivors) {
        if (!s.standing) continue; const sd = dist(s.x, s.y, this.x, this.y);
        if (sd > T.detect * M || (sd > 2 * M && angleDiff(Math.atan2(s.y - this.y, s.x - this.x), this.facing) > Math.PI / 2)) continue;
        if (!m.world.losClear(this.x, this.y, s.x, s.y)) continue;
        this.state = 'spotted'; this.target = s; this.spot = { x: s.x, y: s.y }; this.spotT = 2.5;
        m.notifyK(`${T.name} spotted ${s.name}`, T.color); m.reveal(s, 2.5, T.name);
        m.sound('power_warn', this.x, this.y, 20 * M, { what: 'guard', note: `${T.name} spotted ${s.name}` });
        s.ai?.onGuardSpotted?.(this);
        break;
      }
    } else if (this.state === 'spotted') {
      // move to where the survivor was seen, phasing through obstacles
      this.spotT -= dt; const dx = this.spot.x - this.x, dy = this.spot.y - this.y, d = Math.hypot(dx, dy);
      if (d > 0.2 * M) { const st = Math.min(d, Math.max(d / Math.max(this.spotT, 0.1), 3 * M) * dt); this.x += dx / d * st; this.y += dy / d * st; this.facing = Math.atan2(dy, dx); }
      if (this.spotT <= 0) {
        this.state = 'hunt'; this.time = T.huntTime; this.huntRepath = 0;
        this.p.plantStandard(m, this.spot, T.standardDelay, this);
        m.world.resolve(this, this.r);
      }
    } else if (this.state === 'hunt') {
      const s = this.target; const near = dist(k.x, k.y, this.x, this.y) < 8 * M;
      this.time -= dt * (near ? 3 : 1);
      if (!s || !s.standing || this.time <= 0) return this.p.endGuard(m, this.time <= 0 ? 'hunt over' : 'target down');
      this.huntRepath -= dt;
      if (this.huntRepath <= 0) { this.huntRepath = 0.35; this.pathTo(m, s.x, s.y); }
      if (!this.followPath(dt, m, T.huntSpeed * M) && this.path) this.breakAhead(m);
      if (dist(s.x, s.y, this.x, this.y) < this.r + s.r + 0.5 * M && m.world.losClear(this.x, this.y, s.x, s.y)) {
        const res = strike(m, k, s, { source: 'guard', score: 'brutality', label: `${T.name} hit` });
        if (res && res !== 'dodged') { if (T.deepWound && s.health === 'injured') s.status.add('deepWound', { duration: 20 }); s.ai?.note(`Caught by ${T.name}`, 'guardhit'); }
        m.events.emit('powerTriggered', { survivor: s, x: s.x, y: s.y }); return this.p.endGuard(m, 'caught');
      }
    }
  }
  breakAhead(m) {
    for (const p of m.map.pallets) if (p.state === 'down' && dist(p.x, p.y, this.x, this.y) < Math.max(p.len / 2, 1) + 1.0 * M && this.path?.length) {
      const ahead = { x: this.x + Math.cos(this.facing) * 0.9 * M, y: this.y + Math.sin(this.facing) * 0.9 * M };
      if (p.stunZone(ahead) || dist(p.x, p.y, ahead.x, ahead.y) < 1.2 * M) { this.breaking = { p, t: this.type.breakTime }; return; }
    }
  }
}

export class KnightPower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'guardia'; this.name = 'Guardia Compagnia'; this.state = 'idle'; this.order = 0; this.drawn = []; this.guard = null; this.standards = [];
    this.maxLen = (this.has('broken_hilt') ? 36 : 30) * M; this.recharge = this.has('ironworks_tongs') ? 6 : 8;
    this.aiProfile = { type: 'guards', label: 'Guard patrols', counter: ['leave a guard\'s patrol area', 'grab the Standard', 'break line of sight from the patrol', 'drop pallets on guards'] };
  }
  get type() { return GUARDS[ORDER[this.order % 3]]; }
  speedMult() { return this.state === 'drawing' ? 1.0 : 1; }
  pathLen() { let L = 0; for (let i = 1; i < this.drawn.length; i++) L += dist(this.drawn[i].x, this.drawn[i].y, this.drawn[i - 1].x, this.drawn[i - 1].y); return L; }
  update(dt, m, inp, locked) {
    this.tickCooldowns(dt);
    const k = this.k;
    for (const st of this.standards) { if (st.materializeT > 0) { st.materializeT -= dt; if (st.materializeT <= 0) this.spawnStandard(m, st); } }
    if (locked) return;
    if (inp.eP && this.state !== 'drawing' && !this.guard) { this.order++; m.audio?.play('ui'); }
    if (this.state === 'idle' && inp.rmbP && !k.carrying && !this.guard && this.cd('power') <= 0) { this.state = 'drawing'; this.drawn = [{ x: k.x, y: k.y }]; this.aimAtStart = k.facing; m.events.emit(EV.POWER_USED, { killer: k, power: 'draw' }); return; }
    if (this.state === 'drawing') {
      const last = this.drawn[this.drawn.length - 1];
      if (dist(last.x, last.y, k.x, k.y) > 1 * M) this.drawn.push({ x: k.x, y: k.y });
      if (inp.rmbP || this.pathLen() >= this.maxLen) this.summon(m);
    }
  }
  summon(m) {
    const k = this.k; let path = this.drawn;
    if (this.pathLen() < 4 * M) {
      // Guard Order: walk straight toward the aim point
      const d = Math.min(14 * M, Math.max(5 * M, k.input.aimDist ?? 8 * M)); const tx = k.x + Math.cos(k.facing) * d, ty = k.y + Math.sin(k.facing) * d;
      const p = m.map.nav.findPath(k.x, k.y, tx, ty, {}, 4000); path = p ? m.map.nav.smooth(m.world, p.pts, 0.5 * M).map((q) => ({ x: q.x, y: q.y })) : [{ x: k.x, y: k.y }, { x: tx, y: ty }];
    }
    const T = this.type; this.order++;
    this.guard = m.addMinion(new Guard(this, T, path)); this.state = 'idle'; this.drawn = [];
    m.fx.burst(path[0].x, path[0].y, 24, T.color, 90, 0.8, 3, 2); m.audio?.play('bell');
    m.sound('power_warn', path[0].x, path[0].y, 24 * M, { what: 'guard', note: `${T.name} summoned` });
    m.notifyK(`${T.name} patrols`, T.color); m.events.emit(EV.POWER_USED, { killer: this.k, power: 'guard', guard: T.id });
  }
  plantStandard(m, spot, delay, guard) { this.standards.push({ x: spot.x, y: spot.y, materializeT: delay, guard }); }
  spawnStandard(m, st) {
    if (this.guard !== st.guard || st.guard.state !== 'hunt') { this.standards = this.standards.filter((q) => q !== st); return; }
    st.device = m.addDevice(new Device({ kind: 'standard', x: st.x, y: st.y, r: 0.5 * M, label: 'Standard', useTime: 0.5, survivorUsable: true, seenRange: 30 * M,
      usable: (s) => st.guard.target === s && this.guard === st.guard,
      onUse: (s, mm) => { s.status.add('haste', { duration: 3, value: 0.5, source: 'standard' }); s.status.add('endurance', { duration: 3, source: 'standard' }); s.ai?.note('Grabbed the Standard — hunt over', 'standard'); this.endGuard(mm, 'standard'); } }));
    st.guard.target?.ai?.onStandard?.(st.device);
  }
  endGuard(m, why) {
    const g = this.guard; if (!g) return; this.guard = null;
    m.removeMinion(g); m.fx.burst(g.x, g.y, 18, g.type.color, 80, 0.6, 3, 2);
    for (const st of this.standards) if (st.device) m.removeDevice(st.device);
    this.standards = []; this.setCd('power', this.recharge);
    m.events.emit(EV.POWER_USED, { killer: this.k, power: 'guard_end', why });
  }
  // unhooking someone ends a hunt on the rescuer
  onInit(m) { m.events.on(EV.SURVIVOR_UNHOOKED, (d) => { if (this.guard?.state === 'hunt' && this.guard.target === d.rescuer) this.endGuard(m, 'unhook'); }); }
  drawMinion(ctx, n, m) {
    if (n.kind !== 'guard') return false;
    ctx.save(); ctx.translate(n.x, n.y);
    if (n.state === 'patrol') { ctx.fillStyle = 'rgba(255,255,255,0.05)'; ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, n.type.detect * M, n.facing - Math.PI / 2, n.facing + Math.PI / 2); ctx.closePath(); ctx.fill(); }
    ctx.rotate(n.facing); ctx.globalAlpha = n.state === 'spotted' ? 0.6 : 1;
    ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.ellipse(3, 4, n.r + 2, n.r, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = n.type.color; ctx.beginPath(); ctx.arc(0, 0, n.r, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#c8ccd2'; ctx.fillRect(n.r - 2, -2, 14, 4);
    ctx.fillStyle = '#2a2a2a'; ctx.beginPath(); ctx.arc(4, 0, 5, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    if (n.state === 'hunt') { ctx.fillStyle = '#ff5a5a'; ctx.font = '700 12px sans-serif'; ctx.textAlign = 'center'; ctx.fillText(`HUNT ${Math.ceil(n.time)}`, n.x, n.y - n.r - 8); if (n.target) { ctx.strokeStyle = 'rgba(255,90,90,0.35)'; ctx.setLineDash([4, 6]); ctx.beginPath(); ctx.moveTo(n.x, n.y); ctx.lineTo(n.target.x, n.target.y); ctx.stroke(); ctx.setLineDash([]); } }
    if (n.breaking) { ctx.fillStyle = '#ffd27a'; ctx.fillText('BREAKING', n.x, n.y - n.r - 8); }
    return true;
  }
  drawDevice(ctx, d) {
    if (d.kind !== 'standard') return;
    ctx.strokeStyle = '#8a7a5a'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(d.x, d.y + 10); ctx.lineTo(d.x, d.y - 18); ctx.stroke();
    ctx.fillStyle = '#a03a2a'; ctx.beginPath(); ctx.moveTo(d.x, d.y - 18); ctx.lineTo(d.x + 14, d.y - 13); ctx.lineTo(d.x, d.y - 8); ctx.fill();
  }
  drawGround(ctx, m) {
    const pts = this.state === 'drawing' ? [...this.drawn, { x: this.k.x, y: this.k.y }] : this.guard?.patrol;
    if (pts && pts.length > 1) { ctx.strokeStyle = this.state === 'drawing' ? 'rgba(230,200,120,0.7)' : `${this.guard.type.color}88`; ctx.lineWidth = 3; ctx.setLineDash([8, 6]); ctx.beginPath(); ctx.moveTo(pts[0].x, pts[0].y); for (const p of pts) ctx.lineTo(p.x, p.y); ctx.stroke(); ctx.setLineDash([]); }
    for (const st of this.standards) if (st.materializeT > 0) { ctx.strokeStyle = 'rgba(160,58,42,0.6)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(st.x, st.y, 12, 0, Math.PI * 2 * (1 - st.materializeT / st.guard.type.standardDelay)); ctx.stroke(); }
  }
  drawWeapon(ctx) { const k = this.k; ctx.fillStyle = '#b8bcc2'; ctx.fillRect(k.r - 4, -3, 34, 6); ctx.fillStyle = '#5a4a36'; ctx.fillRect(k.r - 6, -7, 4, 14); return true; }
  hud(m) {
    const T = this.type; const g = this.guard;
    const st = g ? `${g.type.name}: ${g.state === 'patrol' ? 'patrolling' : g.state === 'spotted' ? 'spotted!' : `HUNTING ${g.target?.name}`} ${Math.ceil(g.time)}s` : this.state === 'drawing' ? `Drawing path ${Math.round(this.pathLen() / M)} m — Q to summon` : this.cd('power') > 0 ? `Recharging ${Math.ceil(this.cd('power'))}s` : `Next: ${T.name}`;
    return { title: 'Guardia Compagnia', value: T.name.replace('The ', ''), meter: this.state === 'drawing' ? this.pathLen() / this.maxLen : g ? g.time / (g.state === 'patrol' ? g.type.patrolTime : g.type.huntTime) : 1 - this.cd('power') / this.recharge, state: st,
      hints: [['Q / RMB', 'Start a patrol path · again to summon'], ['E', 'Cycle guard (Carnifex / Assassin / Jailer)']] };
  }
}
