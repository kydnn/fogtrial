// Killer registry. Data-driven: a new killer is a def + a power class (see framework.js).
// cost/unlocked are ready for a future currency system; all eight are free for now.
import { POWER_DATA } from './powerData.js';
import { TrapperPower } from './trapper.js';
import { HillbillyPower } from './hillbilly.js';
import { WraithPower } from './wraith.js';
import { GhostFacePower } from './ghostface.js';
import { ClownPower } from './clown.js';
import { ExecutionerPower } from './executioner.js';
import { SingularityPower } from './singularity.js';
import { HuntressPower } from './huntress.js';
import { LegionPower } from './legion.js';
import { HagPower } from './hag.js';
import { CannibalPower } from './cannibal.js';
import { DeathslingerPower } from './deathslinger.js';
import { DredgePower } from './dredge.js';
import { KnightPower } from './knight.js';
import { CenobitePower } from './cenobite.js';
import { MastermindPower } from './mastermind.js';
import { HoundmasterPower } from './houndmaster.js';
import { LichPower } from './lich.js';
import { SkullMerchantPower } from './skullmerchant.js';
import { BlightPower } from './blight.js';
import { NursePower } from './nurse.js';
import { UnknownPower } from './unknown.js';
import { NemesisPower } from './nemesis.js';
import { GhoulPower } from './ghoul.js';

export const KILLERS = {
  trapper: {
    id: 'trapper', name: 'The Trapper', short: 'Trapper', speed: 4.6, terror: 32, color: '#b8a48a', accent: '#d1b37a',
    power: 'Bear Trap', powerDesc: 'Set bear traps that snare survivors who step on them. Traps in tall grass are hard to spot.',
    Power: TrapperPower, cost: 0, unlocked: true, difficulty: 'Easy', signature: ['brutal_strength', 'agitation', 'unnerving'],
    addons: {
      trapper_bag: { name: 'Trapper Bag', desc: 'Carry one extra trap.' },
      fast_set: { name: 'Lengthened Jaws', desc: 'Set traps 30% faster.' },
      serrated_jaws: { name: 'Serrated Jaws', desc: 'Trapped survivors suffer Mangled and Hemorrhage.' },
      iron_coil: { name: 'Coil Spring', desc: 'Escaping a trap is harder.' },
    },
  },
  hillbilly: {
    id: 'hillbilly', name: 'The Hillbilly', short: 'Hillbilly', speed: 4.6, terror: 32, color: '#a87a5a', accent: '#e07a3a',
    power: 'Chainsaw', powerDesc: 'Rev the chainsaw to sprint at high speed. A chainsaw hit downs instantly; obstacles stop you hard.',
    Power: HillbillyPower, cost: 0, unlocked: true, difficulty: 'Hard', signature: ['enduring', 'lightborn', 'tinkerer'],
    addons: {
      primer_bulb: { name: 'Primer Bulb', desc: 'Rev 20% faster.' },
      heavy_clutch: { name: 'Heavy Clutch', desc: 'Sharper sprint turning.' },
      speed_limiter: { name: 'Speed Limiter', desc: 'Chainsaw heats up slower.' },
    },
  },
  wraith: {
    id: 'wraith', name: 'The Wraith', short: 'Wraith', speed: 4.6, terror: 32, color: '#8e9a9a', accent: '#9fd0d0',
    power: 'Wailing Bell', powerDesc: 'Cloak to move fast and unseen. The bell rings when you cloak and uncloak.',
    Power: WraithPower, cost: 0, unlocked: true, difficulty: 'Intermediate', signature: ['predator', 'bloodhound', 'shadowborn'],
    addons: {
      shadow_dance: { name: 'Shadow Dance', desc: 'Longer speed boost after uncloaking.' },
      bone_clapper: { name: 'Bone Clapper', desc: 'Bell range halved.' },
      blind_warrior: { name: 'Blind Warrior', desc: 'Cloak and uncloak 25% faster.' },
    },
  },
  ghostface: {
    id: 'ghostface', name: 'Ghost Face', short: 'Ghost Face', speed: 4.6, terror: 32, color: '#2b2b30', accent: '#e8e8ea',
    power: 'Night Shroud', powerDesc: 'Become undetectable and hard to spot. Hold the power to stalk survivors in view until they are Marked — then one hit downs them. Survivors who stare at you reveal you.',
    Power: GhostFacePower, cost: 0, unlocked: true, difficulty: 'Intermediate', signature: ['insidious', 'trail_of_torment', 'starstruck'],
    addons: {
      philly: { name: '"Philly"', desc: 'Marked lasts 50 s instead of 35 s.' },
      outdoor_rope: { name: 'Outdoor Rope', desc: 'Shroud recovers faster after a reveal.' },
      drop_leg_sheath: { name: 'Drop-Leg Sheath', desc: 'Stalk 25% faster.' },
    },
  },
  clown: {
    id: 'clown', name: 'The Clown', short: 'Clown', speed: 4.4, terror: 32, color: '#8a5a6a', accent: '#c28ee0',
    power: 'Afterpiece Tonic', powerDesc: 'Lob bottles of gas. Tonic slows and intoxicates survivors; antidote speeds up anyone inside, including you.',
    Power: ClownPower, cost: 0, unlocked: true, difficulty: 'Easy', signature: ['coulrophobia', 'pop', 'bamboozle'],
    addons: {
      fingerless_parade: { name: 'Fingerless Parade Gloves', desc: 'Carry 8 bottles.' },
      robin_feather: { name: 'Robin Feather', desc: 'Reload faster.' },
      redheads_pinkie: { name: "Redhead's Pinky Finger", desc: 'Bigger gas clouds.' },
      ether: { name: 'Ether 15 Vol%', desc: 'Stronger slow inside the gas.' },
    },
  },
  executioner: {
    id: 'executioner', name: 'The Executioner', short: 'Executioner', speed: 4.6, terror: 32, color: '#6a5444', accent: '#e2683c',
    power: 'Rites of Judgement', powerDesc: 'Enter Punishment mode to lay Torment Trails and fire a ground wave that passes through walls. Send Tormented downed survivors to a Cage.',
    Power: ExecutionerPower, cost: 0, unlocked: true, difficulty: 'Intermediate', signature: ['deathbound', 'forced_penance', 'trail_of_torment'],
    addons: {
      burning_man: { name: 'Burning Man Painting', desc: 'Faster wave wind-up.' },
      lead_ring: { name: 'Lead Ring', desc: 'Wave travels further.' },
      rust_shackles: { name: 'Rust-Coloured Egg', desc: 'Trails last 80 s.' },
    },
  },
  singularity: {
    id: 'singularity', name: 'The Singularity', short: 'Singularity', speed: 4.6, terror: 32, color: '#3c4a56', accent: '#5fe0e0',
    power: 'Quantum Instantiation', powerDesc: 'Place biopods that watch the map and Slipstream survivors. Teleport to a pod next to any Slipstreamed survivor. Survivors can print EMPs to wipe pods.',
    Power: SingularityPower, cost: 0, unlocked: true, difficulty: 'Hard', signature: ['genetic_limits', 'forced_hesitation', 'machine_learning'],
    addons: {
      cold_dirt: { name: 'Cold Dirt', desc: 'Carry 5 biopods.' },
      denied_requisition: { name: 'Denied Requisition Form', desc: 'Pods watch a wider area.' },
      nanomachine: { name: 'Nanomachine Gel', desc: 'Slipstream lasts 60 s.' },
      crew_manifest: { name: 'Crew Manifest', desc: 'Teleport recharges faster.' },
    },
  },
  huntress: {
    id: 'huntress', name: 'The Huntress', short: 'Huntress', speed: 4.4, terror: 40, color: '#7a6248', accent: '#cfd3d6',
    power: 'Hunting Hatchets', powerDesc: 'Wind up and throw hatchets across the map. Limited supply — reload at lockers.',
    Power: HuntressPower, cost: 0, unlocked: true, difficulty: 'Hard', signature: ['bbq', 'territorial', 'beast_of_prey'],
    addons: {
      leather_loop: { name: 'Leather Loop', desc: 'Carry 7 hatchets.' },
      shiny_pin: { name: 'Shiny Pin', desc: 'Faster full wind-up.' },
      flower_babushka: { name: 'Flower Babushka', desc: 'Hatchets fly further.' },
    },
  },
  legion: {
    id: 'legion', name: 'The Legion', short: 'Legion', speed: 4.6, terror: 32, color: '#5a5048', accent: '#d8e05a',
    power: 'Feral Frenzy', powerDesc: 'Enter a Frenzy: run faster, vault windows and dropped pallets, and slash survivors to inflict Deep Wound. Hits refill the gauge and reveal nearby survivors so you can chain. A miss ends in Fatigue.',
    Power: LegionPower, cost: 0, unlocked: true, difficulty: 'Easy', signature: ['discordance', 'mad_grit', 'iron_maiden'],
    addons: {
      stab_wounds: { name: 'Stab Wounds Study', desc: 'Frenzy speed 5.4 m/s.' },
      mural_sketch: { name: 'Mural Sketch', desc: 'Frenzy lasts longer.' },
      never_sleep: { name: 'Never-Sleep Pills', desc: 'Gauge recharges faster.' },
      cold_dirt: { name: 'Cold Dirt', desc: 'Shorter Fatigue.' },
      filthy_blade: { name: 'Filthy Blade', desc: 'Deep Wound timer 16 s.' },
    },
  },
  hag: {
    id: 'hag', name: 'The Hag', short: 'Hag', speed: 4.4, terror: 32, color: '#4a5a3a', accent: '#a9c27a',
    power: 'Blackened Catalyst', powerDesc: 'Draw Phantasm Traps on the ground. A survivor who walks over one triggers it (crouching avoids it) — teleport to it with E if you are within 40 m.',
    Power: HagPower, cost: 0, unlocked: true, difficulty: 'Hard', signature: ['third_seal', 'devour_hope', 'ruin'],
    addons: {
      rusty_shackles: { name: 'Rusty Shackles', desc: '12 traps.' },
      bloodied_mud: { name: 'Bloodied Mud', desc: 'Draw traps faster.' },
      mint_rag: { name: 'Mint Rag', desc: 'Teleport range 50 m.' },
      dried_cicada: { name: 'Dried Cicada', desc: 'Longer teleport window.' },
      scarred_hand: { name: 'Scarred Hand', desc: 'Traps are harder to spot.' },
    },
  },
  cannibal: {
    id: 'cannibal', name: 'The Cannibal', short: 'Cannibal', speed: 4.6, terror: 32, color: '#7a6048', accent: '#d06a2a',
    power: "Bubba's Chainsaw", powerDesc: 'Rev and sweep the chainsaw in a wide arc in front of you — downs instantly, can down several survivors. Three charges. Sawing into walls or dropped pallets throws you into a Tantrum.',
    Power: CannibalPower, cost: 0, unlocked: true, difficulty: 'Easy', signature: ['knock_out', 'bbq', 'franklins_demise'],
    addons: {
      award_winning_chili: { name: 'Award-Winning Chili', desc: '4 chainsaw charges.' },
      primer_bulb: { name: 'Primer Bulb', desc: 'Rev faster.' },
      long_guide_bar: { name: 'Long Guide Bar', desc: 'Wider sweep reach.' },
      knife_scratches: { name: 'Knife Scratches', desc: 'Charges recover faster.' },
      the_beast_marks: { name: "The Beast's Marks", desc: 'Shorter Tantrums.' },
    },
  },
  deathslinger: {
    id: 'deathslinger', name: 'The Deathslinger', short: 'Deathslinger', speed: 4.4, terror: 24, color: '#6a5a40', accent: '#b9a37a',
    power: 'The Redeemer', powerDesc: 'Aim down the sights and fire a harpoon. A speared survivor is reeled in until the chain snaps on an obstacle (Deep Wound). Reload after every shot.',
    Power: DeathslingerPower, cost: 0, unlocked: true, difficulty: 'Hard', signature: ['dead_mans_switch', 'retribution', 'gearhead'],
    addons: {
      rusted_spike: { name: 'Rusted Spike', desc: 'Range 20 m.' },
      speed_loader: { name: 'Speed Loader', desc: 'Reload in 1.5 s.' },
      chewing_tobacco: { name: 'Chewing Tobacco', desc: 'Reel for longer before the chain snaps.' },
    },
  },
  dredge: {
    id: 'dredge', name: 'The Dredge', short: 'Dredge', speed: 4.6, terror: 32, color: '#2a2834', accent: '#9a8fe0',
    power: 'Reign of Darkness', powerDesc: 'Enter the Gloaming and teleport into any locker on the map, or snap back to your Remnant. Build up Nightfall: 60 s of darkness where survivors can barely see.',
    Power: DredgePower, cost: 0, unlocked: true, difficulty: 'Intermediate', signature: ['dissolution', 'darkness_revealed', 'septic_touch'],
    addons: {
      boat_key: { name: 'Boat Key', desc: '4 teleport tokens.' },
      malthinkers_skull: { name: "Malthinker's Skull", desc: 'Nightfall lasts 70 s.' },
    },
  },
  knight: {
    id: 'knight', name: 'The Knight', short: 'Knight', speed: 4.6, terror: 32, color: '#5a5a64', accent: '#e6c878',
    power: 'Guardia Compagnia', powerDesc: 'Draw a patrol path and summon a Guard — Carnifex, Assassin or Jailer. Guards patrol, spot survivors and hunt them down, breaking pallets on the way.',
    Power: KnightPower, cost: 0, unlocked: true, difficulty: 'Intermediate', signature: ['nowhere_to_hide', 'face_the_darkness', 'hubris'],
    addons: {
      broken_hilt: { name: 'Broken Hilt', desc: 'Longer patrol paths.' },
      ironworks_tongs: { name: 'Ironworks Tongs', desc: 'Power recharges faster.' },
    },
  },
  cenobite: {
    id: 'cenobite', name: 'The Cenobite', short: 'Cenobite', speed: 4.6, terror: 32, color: '#3a3438', accent: '#e0b65a',
    power: 'Summons of Pain', powerDesc: 'Shoot steerable Possessed Chains (also from Gateways) that bind survivors. The Lament Configuration starts a Chain Hunt if nobody solves it.',
    Power: CenobitePower, cost: 0, unlocked: true, difficulty: 'Hard', signature: ['deadlock', 'plaything', 'gift_of_pain'],
    addons: {
      impaling_wire: { name: 'Impaling Wire', desc: 'Chain Hunt charges in 80 s.' },
      chatterer_tooth: { name: "Chatterer's Tooth", desc: 'Chain cooldown 4 s.' },
    },
  },
  mastermind: {
    id: 'mastermind', name: 'The Mastermind', short: 'Mastermind', speed: 4.6, terror: 32, color: '#2a2a2e', accent: '#7fae3a',
    power: 'Virulent Bound', powerDesc: 'Charge and bound forward; chain a second, longer bound. Grab survivors, carry them and slam them into walls. Bounds spread the Uroboros infection.',
    Power: MastermindPower, cost: 0, unlocked: true, difficulty: 'Intermediate', signature: ['superior_anatomy', 'awakened_awareness', 'terminus'],
    addons: { cell_divider: { name: 'Cell Divider', desc: 'Charge bounds faster.' } },
  },
  houndmaster: {
    id: 'houndmaster', name: 'The Houndmaster', short: 'Houndmaster', speed: 4.6, terror: 32, color: '#6a4a3a', accent: '#c8a878',
    power: 'Hunting', powerDesc: 'Command your dog: Chase Command sends it charging down a plotted line; Search Command sends it to sniff out an area. Snug drags caught survivors back to you.',
    Power: HoundmasterPower, cost: 0, unlocked: true, difficulty: 'Intermediate', signature: ['all_shaking_thunder', 'no_quarter', 'jagged_compass'],
    addons: {
      training_whistle: { name: 'Training Whistle', desc: 'Chase Command reaches 24 m.' },
      rope_leash: { name: 'Rope Leash', desc: 'Drag lasts 9 s.' },
    },
  },
  lich: {
    id: 'lich', name: 'The Lich', short: 'Lich', speed: 4.6, terror: 32, color: '#3a3044', accent: '#c8b0ff',
    power: 'Vile Darkness', powerDesc: 'Four spells on the wheel: Flight of the Damned, Fly, Mage Hand and Dispelling Sphere. Survivors loot Magic Items that each counter one spell.',
    Power: LichPower, cost: 0, unlocked: true, difficulty: 'Hard', signature: ['dark_arrogance', 'languid_touch', 'weave_attunement'],
    addons: {
      ornate_horn: { name: 'Ornate Horn', desc: 'One more damned entity.' },
      pewter_wings: { name: 'Pewter Wings', desc: 'Fly for 6 s.' },
    },
  },
  skull_merchant: {
    id: 'skull_merchant', name: 'The Skull Merchant', short: 'Skull Merchant', speed: 4.6, terror: 32, color: '#c8c0b0', accent: '#8fd06a',
    power: 'Eyes in the Sky', powerDesc: 'Deploy drones whose rotating scan lines detect moving survivors. Three lock-ons inflict a claw trap; claw-trapped survivors are tracked and hindered. Survivors can hack drones.',
    Power: SkullMerchantPower, cost: 0, unlocked: true, difficulty: 'Intermediate', signature: ['game_afoot', 'leverage', 'thwack'],
    addons: { ultrasonic_speaker: { name: 'Ultrasonic Speaker', desc: 'One more drone.' } },
  },
  blight: {
    id: 'blight', name: 'The Blight', short: 'Blight', speed: 4.6, terror: 32, color: '#5a4a3a', accent: '#c7a04a',
    power: 'Blighted Corruption', powerDesc: 'Rush at 9.2 m/s with 5 tokens. Slamming into walls lets you chain another rush; chained rushes are lethal and allow a special attack. Fatigue when the chain ends.',
    Power: BlightPower, cost: 0, unlocked: true, difficulty: 'Very Hard', signature: ['dragons_grip', 'blood_favour', 'undying'],
    addons: { compound_33: { name: 'Compound Thirty-Three', desc: 'One more rush token.' }, alchemists_ring: { name: "Alchemist's Ring", desc: 'Turn 25% tighter while rushing.' } },
  },
  nurse: {
    id: 'nurse', name: 'The Nurse', short: 'Nurse', speed: 3.85, terror: 32, color: '#c8c0b8', accent: '#c8d8e8',
    power: "Spencer's Last Breath", powerDesc: 'Charge and blink up to 20 m through walls, chain a second blink, attack out of a blink. Slow walker, cannot vault, fatigued after blinking.',
    Power: NursePower, cost: 0, unlocked: true, difficulty: 'Very Hard', signature: ['nurses_calling', 'stridor', 'thanatophobia'],
    addons: { anxious_gasp: { name: 'Anxious Gasp', desc: 'One more blink token.' } },
  },
  unknown: {
    id: 'unknown', name: 'The Unknown', short: 'Unknown', speed: 4.6, terror: 32, color: '#4a3a5a', accent: '#b0ff80',
    power: 'UVX', powerDesc: 'Fire bouncing UVX bursts that Weaken survivors (and hurt the Weakened). Leave hallucinations and teleport to them. Survivors stare to recover and dispel.',
    Power: UnknownPower, cost: 0, unlocked: true, difficulty: 'Intermediate', signature: ['unforeseen', 'undone', 'unbound'],
    addons: {},
  },
  nemesis: {
    id: 'nemesis', name: 'The Nemesis', short: 'Nemesis', speed: 4.6, terror: 32, color: '#3a3030', accent: '#c05050',
    power: 'T-Virus', powerDesc: 'Tentacle Strike contaminates (and hurts the contaminated); Mutation Rate grows its reach and lets it smash pallets. Two zombies roam the map. Survivors cure with vaccines.',
    Power: NemesisPower, cost: 0, unlocked: true, difficulty: 'Intermediate', signature: ['lethal_pursuer', 'lethal_power', 'eruption'],
    addons: {},
  },
  ghoul: {
    id: 'ghoul', name: 'The Ghoul', short: 'Ghoul', speed: 4.6, terror: 32, color: '#3a3a3e', accent: '#c02030',
    power: 'Kagune Leap', powerDesc: 'Leap 14 m: latch onto a survivor, then leap again for a grab attack (injury, Deep Wound, Kagune Mark). Cling to walls to redirect. Enraged while anyone is marked.',
    Power: GhoulPower, cost: 0, unlocked: true, difficulty: 'Intermediate', signature: ['forever_entwined', 'none_are_free', 'haywire'],
    addons: {},
  },
};
for (const k of Object.values(KILLERS)) k.powerData = POWER_DATA[k.id];
export const KILLER_LIST = Object.values(KILLERS);
