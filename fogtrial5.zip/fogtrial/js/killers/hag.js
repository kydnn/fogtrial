// THE HAG — Blackened Catalyst. Hold RMB to draw a Phantasm Trap on the ground (max 10).
// A survivor who walks or runs over a trap (crouching does not trigger it) sets it off:
// a mud phantasm rises, the survivor screams and is revealed, and for a few seconds the Hag
// can press E to teleport to it if she is within 40 m. Triggered traps are consumed.
// Survivors can burn traps with a flashlight or sneak past by crouching.
import { M, dist } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, Device, nearestOf } from './framework.js';

export class HagPower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'phantasm'; this.name = 'Blackened Catalyst'; this.state = 'idle';
    this.maxTraps = this.has('rusty_shackles') ? 12 : 10; this.drawT = 0; this.drawTime = this.has('bloodied_mud') ? 1.1 : 1.5;
    this.tpRange = (this.has('mint_rag') ? 50 : 40) * M; this.tpWindow = this.has('dried_cicada') ? 6 : 4;
    this.triggered = []; this.aiProfile = { type: 'traps_teleport', label: 'Phantasm traps', counter: ['crouch over known traps', 'burn traps with a flashlight', 'avoid trapped loops'] };
  }
  get traps() { return this._m ? this._m.devices.filter((d) => d.kind === 'phantasm') : []; }
  speedMult() { return this.state === 'drawing' ? 0 : 1; }
  canAttack() { return this.state === 'idle'; }
  onInit(m) { this._m = m; }
  update(dt, m, inp, locked) {
    this._m = m; this.tickCooldowns(dt);
    const k = this.k;
    this.triggered = this.triggered.filter((t) => m.time - t.t < this.tpWindow);
    if (locked) { if (this.state === 'drawing') this.state = 'idle'; return; }
    if (this.state === 'idle' && inp.rmb && !k.carrying) { this.state = 'drawing'; this.drawT = 0; }
    if (this.state === 'drawing') {
      this.drawT += dt;
      if (!inp.rmb) { this.state = 'idle'; return; }
      if (this.drawT >= this.drawTime) { this.placeTrap(m, k.x, k.y); this.state = 'cooldown'; this.setCd('draw', 0.6); }
    }
    if (this.state === 'cooldown' && this.cd('draw') <= 0 && !inp.rmb) this.state = 'idle';
    if (inp.eP && !k.carrying) {
      const t = this.teleportTarget(m);
      if (t) this.teleport(m, t);
    }
  }
  placeTrap(m, x, y) {
    const traps = this.traps; if (traps.length >= this.maxTraps) m.removeDevice(traps[0]);
    m.addDevice(new Device({ kind: 'phantasm', x, y, r: 0.9 * M, owner: this.k, label: 'Phantasm Trap', seenRange: (this.has('scarred_hand') ? 4 : 6) * M, aiCost: 10, dangerRadius: 1.4 * M,
      data: { t0: m.time, armed: false } }));
    m.events.emit(EV.POWER_USED, { killer: this.k, power: 'trap' }); m.audio?.play('trapset');
  }
  // Called from the match each frame: survivors stepping over a trap trigger it.
  tick(dt, m) {
    for (const d of this.traps) {
      if (m.time - d.data.t0 < 1) continue;
      for (const s of m.survivors) {
        if (!s.standing || s.moveMode === 'crouch' && !s.vault) continue;
        if (dist(s.x, s.y, d.x, d.y) > d.r) continue;
        this.trigger(m, d, s); break;
      }
    }
  }
  trigger(m, d, s) {
    m.removeDevice(d);
    this.triggered.push({ x: d.x, y: d.y, t: m.time, s });
    m.reveal(s, 3, 'Phantasm'); m.addGrunt(s, '#7a9a5a'); m.audio?.play('scream');
    m.fx.burst(d.x, d.y, 26, '#4a5a3a', 90, 1.2, 3, 1.5);
    m.notifyK(`${s.name} triggered a Phantasm Trap — E to teleport`, '#a9c27a');
    m.sound('power_warn', d.x, d.y, 18 * M, { what: 'hag', note: 'Triggered a Phantasm — she can teleport here' });
    m.events.emit(EV.TRAP_TRIGGERED, { trap: d, survivor: s, phantasm: true });
    s.ai?.onPhantasm?.(d);
    (s.ai?.memory.devices)?.delete(d.id);
  }
  teleportTarget(m) {
    const k = this.k; let best = null, bt = -1;
    for (const t of this.triggered) { const d = dist(k.x, k.y, t.x, t.y); if (d <= this.tpRange && t.t > bt) { bt = t.t; best = t; } }
    return best;
  }
  teleport(m, t) {
    const k = this.k; this.triggered = this.triggered.filter((q) => q !== t);
    // appear just behind the phantasm (away from where she came from)
    const a = Math.atan2(t.y - k.y, t.x - k.x); let x = t.x + Math.cos(a) * 0.6 * M, y = t.y + Math.sin(a) * 0.6 * M;
    if (m.world.pointBlocked(x, y, k.r)) { x = t.x; y = t.y; }
    m.fx.burst(k.x, k.y, 20, '#3a4a2a', 80, 0.8, 3, 2);
    k.x = x; k.y = y; m.world.resolve(k, k.r); k.facing = a;
    m.fx.burst(k.x, k.y, 30, '#5a6a3a', 120, 0.9, 3, 2); m.audio?.play('teleport'); m.fx.shake(5);
    m.sound('killer_action', k.x, k.y, 24 * M, { what: 'teleport' });
    m.events.emit(EV.POWER_USED, { killer: k, power: 'teleport' });
  }
  // flashlights burn Phantasm Traps
  burnAt(m, x, y, r) { for (const d of this.traps) if (dist(d.x, d.y, x, y) < r) { m.removeDevice(d); m.fx.burst(d.x, d.y, 12, '#e8e0a0', 60, 0.6, 2, 2); return true; } return false; }
  drawDevice(ctx, d, m) {
    if (d.kind !== 'phantasm') return;
    const a = m.time - d.data.t0 < 1 ? 0.35 : 0.8; ctx.strokeStyle = `rgba(120,150,90,${a})`; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(d.x, d.y, d.r * 0.8, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); for (let i = 0; i < 5; i++) { const q = i * 2.513 - Math.PI / 2; const x = d.x + Math.cos(q) * d.r * 0.8, y = d.y + Math.sin(q) * d.r * 0.8; if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); } ctx.closePath(); ctx.stroke();
  }
  drawGround(ctx, m) {
    for (const t of this.triggered) {
      const f = 1 - (m.time - t.t) / this.tpWindow; ctx.fillStyle = `rgba(60,70,40,${0.8 * f})`;
      ctx.beginPath(); ctx.ellipse(t.x, t.y, 10, 16, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = `rgba(169,194,122,${f})`; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(t.x, t.y, 22, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * f); ctx.stroke();
    }
  }
  drawOver(ctx) {
    if (this.state !== 'drawing') return; const k = this.k;
    ctx.strokeStyle = 'rgba(169,194,122,0.8)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(k.x, k.y, 0.8 * M, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * this.drawT / this.drawTime); ctx.stroke();
  }
  drawWeapon(ctx) { const k = this.k; ctx.strokeStyle = '#6a5a40'; ctx.lineWidth = 2; for (let i = -1; i <= 1; i++) { ctx.beginPath(); ctx.moveTo(k.r - 2, i * 4); ctx.lineTo(k.r + 12, i * 6); ctx.stroke(); } return true; }
  prompt(m) { const t = this.teleportTarget(m); return t ? { key: 'E', label: `Teleport to ${t.s.name}'s phantasm` } : null; }
  hud(m) {
    const n = m ? this.traps.length : 0; const t = m ? this.teleportTarget(m) : null;
    return { title: 'Blackened Catalyst', value: `${n}/${this.maxTraps}`, meter: this.state === 'drawing' ? this.drawT / this.drawTime : n / this.maxTraps,
      state: this.state === 'drawing' ? 'Drawing trap…' : t ? 'TRIGGERED — E to teleport' : 'Draw traps with Q / RMB',
      hints: [['Q / RMB', 'Hold to draw a Phantasm Trap'], ['E', 'Teleport to a triggered trap (40 m)']] };
  }
}
