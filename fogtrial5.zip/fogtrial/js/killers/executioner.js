// THE EXECUTIONER — Rites of Judgement. Toggle the power to enter Punishment mode:
// slower, leaving Torment Trails that Torment any survivor who steps on them.
// In Punishment mode LMB fires Punishment of the Damned: a telegraphed ground wave that
// travels through walls in a straight line and injures/tortures survivors it touches.
// A dying, Tormented survivor can be sent to a Cage of Atonement (SPACE) on a far hook.
import { M, dist, clamp } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, Zone } from './framework.js';

export class ExecutionerPower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'judgement'; this.name = 'Rites of Judgement'; this.state = 'normal';
    this.windT = 0; this.wave = null; this.lastTrail = null; this.windup = this.has('burning_man') ? 0.85 : 1.1;
    this.waveLen = (this.has('lead_ring') ? 19 : 16) * M; this.trailLife = this.has('rust_shackles') ? 80 : 60;
    this.aiProfile = { type: 'zone_ranged', label: 'Torment trails & ground wave', counter: ['avoid torment trails', 'side-step the wave telegraph', 'walls do not block the wave'] };
  }
  speedMult() { if (this.state === 'windup' || this.state === 'recover') return 0.15; if (this.state === 'punish') return 0.82; return 1; }
  canAttack() { return this.state === 'normal'; }
  update(dt, m, inp, locked) {
    this.tickCooldowns(dt);
    const k = this.k;
    if (this.wave) this.updateWave(dt, m);
    if (locked) { if (this.state === 'windup') this.state = 'punish'; return; }
    if (inp.rmbP && !k.carrying && (this.state === 'normal' || this.state === 'punish')) {
      this.state = this.state === 'normal' ? 'punish' : 'normal'; this.lastTrail = null;
      m.events.emit(EV.POWER_USED, { killer: k, power: this.state === 'punish' ? 'rites' : 'rites_end' });
    }
    if (this.state === 'punish') {
      // lay torment trail
      if (!this.lastTrail || dist(this.lastTrail.x, this.lastTrail.y, k.x, k.y) > 0.8 * M) {
        this.lastTrail = { x: k.x, y: k.y };
        m.addZone(new Zone({ kind: 'torment', x: k.x, y: k.y, r: 0.85 * M, t0: m.time, until: m.time + this.trailLife, owner: k, color: 'rgba(200,60,30,0.28)', aiCost: 9, seenRange: 22 * M, label: 'Torment trail',
          effect: (s, dt2, mm) => { if (!s.status.has('tormented')) { s.status.add('tormented', { duration: 60, source: 'exe' }); mm.fx.text(s.x, s.y - 26, 'TORMENTED', '#e2683c'); mm.loudNoise(s.x, s.y, 'torment'); s.ai?.note('Stepped on a torment trail', 'torment'); } } }));
      }
      if (inp.lmbP && this.cd('wave') <= 0) {
        this.state = 'windup'; this.windT = 0; this.windT0 = m.time; this.lockFacing = false; this.dir = k.facing;
        m.sound('power_windup', k.x, k.y, 30 * M, { what: 'wave', dir: k.facing });
      }
    }
    if (this.state === 'windup') {
      this.windT += dt; this.dir = k.facing;
      if (this.windT >= this.windup) { this.fireWave(m); this.state = 'recover'; this.windT = 0; }
    } else if (this.state === 'recover') { this.windT += dt; if (this.windT > 0.6) this.state = 'punish'; }
  }
  fireWave(m) {
    const k = this.k; this.setCd('wave', 2.2);
    this.wave = { x: k.x, y: k.y, dir: this.dir, d: 0, hit: new Set() };
    m.fx.shake(6); m.audio?.play('wave');
    m.sound('killer_action', k.x, k.y, 36 * M, { what: 'wave' });
  }
  updateWave(dt, m) {
    const w = this.wave; const step = 15 * M * dt; w.d += step;
    const hx = w.x + Math.cos(w.dir) * w.d, hy = w.y + Math.sin(w.dir) * w.d;
    // the wave front is a short segment perpendicular to its travel direction
    for (const s of m.survivors) {
      if (!s.standing || w.hit.has(s)) continue;
      const along = (s.x - w.x) * Math.cos(w.dir) + (s.y - w.y) * Math.sin(w.dir);
      const side = Math.abs(-(s.x - w.x) * Math.sin(w.dir) + (s.y - w.y) * Math.cos(w.dir));
      if (along < w.d + 0.3 * M && along > w.d - step - 0.6 * M && side < 1.25 * M) {
        if (s.dodgeT && s.dodgeT > m.time) continue;
        w.hit.add(s);
        const res = s.takeHit(m, { source: 'wave' }); s.status.add('tormented', { duration: 60, source: 'exe' });
        this.k.stats.hits++; this.k.stats.powerHits++;
        m.events.emit(EV.KILLER_HIT, { killer: this.k, survivor: s, result: res, power: true }); m.fx.hit(s, res);
      }
    }
    m.fx.burst(hx, hy, 2, '#e2683c', 40, 0.4, 3, 2);
    if (w.d >= this.waveLen) this.wave = null;
  }
  context(m) {
    const k = this.k; if (k.carrying) return null;
    for (const s of m.survivors) {
      if (s.health === 'dying' && s.status.has('tormented') && dist(s.x, s.y, k.x, k.y) < 2 * M) {
        return { type: 'custom', label: `Cage of Atonement · ${s.name}`, target: { dur: 1.0, label: 'Caging', tick: () => s.health === 'dying', done: (mm) => { if (mm.cageSurvivor(s)) { mm.addScore('sacrifice', 300, 'Caged'); s.status.remove('tormented'); } } } };
      }
    }
    return null;
  }
  hud() {
    const st = { normal: 'Normal', punish: 'Punishment mode', windup: 'Winding up…', recover: 'Recovering' }[this.state];
    return { title: 'Rites of Judgement', value: this.state === 'normal' ? 'Off' : 'Rites', meter: this.state === 'windup' ? this.windT / this.windup : this.state === 'normal' ? 0 : 1 - this.cd('wave') / 2.2, state: st,
      hints: [['Q / RMB', 'Toggle Punishment mode'], ['LMB', 'In mode: Punishment of the Damned'], ['SPACE', 'Cage a Tormented downed survivor']] };
  }
}
