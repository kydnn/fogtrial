// THE NEMESIS — T-Virus (adapted to top-down).
//  • Hold RMB (0.35 s) then release for a TENTACLE STRIKE in a straight line: 5 m at Mutation
//    Rate 1–2, 6.5 m at MR 3. From MR 2 the tentacle smashes dropped pallets in its path.
//  • A tentacle hit CONTAMINATES a survivor (+1 MR point); a hit on someone already Contaminated
//    takes a health state and removes the contamination. Basic attacks work as usual.
//    MR 2 at 1 point, MR 3 at 3 points. Killing a zombie with the tentacle: +0.5 point.
//  • Contaminated survivors cough (killer hears it). 4 VACCINE cases hold 2 vaccines each:
//    grab one (1 s), then inject (3 s) to cure.
//  • Two ZOMBIES shamble around (1 m/s) with a 14 m vision cone. A zombie that sees a survivor
//    lurches after them and swipes: injure + contaminate. Pallets stun zombies; a dead zombie
//    respawns somewhere else after 15 s.
import { M, dist, angleDiff, clamp } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, Device, Minion, strike } from './framework.js';

class Zombie extends Minion {
  constructor(p, x, y) {
    super({ kind: 'zombie', owner: p.k, x, y, r: 0.38 * M, color: '#6a7a5a', label: 'zombie', threat: 0.6, visRange: 22 * M, speed: 1 * M });
    this.p = p; this.state = 'wander'; this.stunnable = true; this.stunTime = 3; this.repath = 0; this.swingT = 0; this.cd = 0;
  }
  onStun(m, s) { this.state = 'wander'; this.path = null; this.target = null; s?.ai?.note('Stunned a zombie', 'zstun'); }
  sees(m, s) {
    const d = dist(this.x, this.y, s.x, s.y); if (d > 14 * M) return false;
    if (d > 2 * M && angleDiff(this.facing, Math.atan2(s.y - this.y, s.x - this.x)) > 0.7) return false;
    if (s.moveMode === 'crouch' && m.map.isGrass(s.x, s.y) && d > 4 * M) return false;
    return m.world.losClear(this.x, this.y, s.x, s.y);
  }
  update(dt, m) {
    this.t += dt; this.cd = Math.max(0, this.cd - dt);
    if (this.state === 'wander') {
      if (!this.path || this.followPath(dt, m, 1 * M)) { const gs = m.map.gens.filter((q) => !q.done); const g = gs.length ? gs[Math.floor(Math.random() * gs.length)] : { x: this.x + (Math.random() - 0.5) * 20 * M, y: this.y + (Math.random() - 0.5) * 20 * M }; const a = Math.random() * 6.28; if (!this.pathTo(m, g.x + Math.cos(a) * 6 * M, g.y + Math.sin(a) * 6 * M)) this.path = [{ x: this.x, y: this.y }]; }
      for (const s of m.survivors) if (s.standing && this.sees(m, s)) { this.state = 'pursue'; this.target = s; this.lostT = 0; this.path = null; s.ai?.note('A zombie spotted me', 'zseen'); m.warn(s, 'A zombie has spotted you'); break; }
      return;
    }
    if (this.state === 'pursue') {
      const s = this.target; if (!s || !s.standing) { this.state = 'wander'; this.path = null; return; }
      if (!this.sees(m, s)) { this.lostT += dt; if (this.lostT > 4) { this.state = 'wander'; this.path = null; return; } } else this.lostT = 0;
      const d = dist(this.x, this.y, s.x, s.y);
      if (d < 1.4 * M && this.cd <= 0) { this.state = 'swing'; this.swingT = 0.8; this.facing = Math.atan2(s.y - this.y, s.x - this.x); m.sound('killer_action', this.x, this.y, 12 * M, { what: 'zombie' }); return; }
      this.repath -= dt; if (this.repath <= 0) { this.repath = 0.5; this.pathTo(m, s.x, s.y); }
      this.followPath(dt, m, 1.3 * M);
      return;
    }
    if (this.state === 'swing') {
      this.swingT -= dt; if (this.swingT > 0) return;
      this.state = 'pursue'; this.cd = 3; const s = this.target;
      if (s && s.standing && dist(this.x, this.y, s.x, s.y) < 1.8 * M && angleDiff(this.facing, Math.atan2(s.y - this.y, s.x - this.x)) < 1.0) {
        const r = strike(m, this.p.k, s, { source: 'zombie', label: 'Zombie' }); this.p.k.stats.hits--; // zombies don't count as the killer's basic hits
        if (r && r !== 'dodged') { this.p.contaminate(m, s, false); s.ai?.note('Hit by a zombie', 'zhit'); }
      }
    }
  }
}

export class NemesisPower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'tentacle'; this.name = 'T-Virus'; this.state = 'idle'; this.charge = 0; this.mrPts = 0; this.zombies = []; this.respawn = [];
    this.aiProfile = { type: 'whip', label: 'Tentacle strike & zombies', counter: ['keep more than 5 m (6.5 m at MR 3)', 'vaccinate when contaminated', 'avoid zombie sightlines and pallet-stun them', 'at MR 2+ pallets don\'t stop the tentacle'] };
  }
  get mr() { return this.mrPts >= 3 ? 3 : this.mrPts >= 1 ? 2 : 1; }
  get reach() { return (this.mr >= 3 ? 6.5 : 5) * M; }
  speedMult() { return this.state === 'charging' ? 0.6 : this.state === 'strike' ? 0.2 : this.state === 'recover' ? 0.6 : 1; }
  canAttack() { return this.state === 'idle'; }
  onInit(m) {
    this._m = m;
    const cand = m.map.openSpots(12, 10, m.map.gens), spots = [];
    while (spots.length < 4 && cand.length) { cand.sort((a, b) => Math.min(...spots.map((q) => dist(q.x, q.y, b.x, b.y)), 1e9) - Math.min(...spots.map((q) => dist(q.x, q.y, a.x, a.y)), 1e9)); spots.push(cand.shift()); }
    for (const p of spots) {
      const d = m.addDevice(new Device({ kind: 'vaccine', x: p.x, y: p.y, r: 0.6 * M, label: 'Vaccine case', useLabel: 'Take a vaccine', useTime: 1, survivorUsable: true, seenRange: 22 * M, data: { vaccines: 2 } }));
      d.usable = (s) => d.data.vaccines > 0 && !(s.vaccines > 0);
      d.onUse = (s, mm) => { d.data.vaccines--; s.vaccines = 1; s.ai?.note('Took a vaccine', 'vaxget'); mm.warn(s, 'Vaccine in hand — Q to inject'); };
    }
    for (let i = 0; i < 2; i++) this.spawnZombie(m);
  }
  spawnZombie(m) {
    const far = m.map.openSpots(6, 6, []).filter((p) => m.survivors.every((s) => dist(s.x, s.y, p.x, p.y) > 12 * M));
    const p = far[0] || m.map.openSpots(1, 4, [])[0]; if (!p) return;
    const z = m.addMinion(new Zombie(this, p.x, p.y)); this.zombies.push(z);
  }
  update(dt, m, inp, locked) {
    this._m = m; this.tickCooldowns(dt);
    const k = this.k;
    if (this.state === 'strike') { this.strikeT -= dt; if (this.strikeT <= 0) { this.resolveStrike(m); this.state = 'recover'; this.recT = 0.7; } return; }
    if (this.state === 'recover') { this.recT -= dt; if (this.recT <= 0) this.state = 'idle'; }
    if (locked) { if (this.state === 'charging') this.state = 'idle'; return; }
    if (this.state === 'idle' && inp.rmb && !k.carrying && this.cd('tentacle') <= 0) { this.state = 'charging'; this.charge = 0; m.sound('power_windup', k.x, k.y, 20 * M, { what: 'tentacle', dir: k.facing }); }
    if (this.state === 'charging') {
      this.charge += dt;
      if (!inp.rmb && this.charge >= 0.35) { this.state = 'strike'; this.strikeT = 0.15; this.dir = k.facing; m.audio?.play('swing'); m.events.emit(EV.POWER_USED, { killer: k, power: 'tentacle' }); }
      else if (!inp.rmb) this.state = 'idle';
    }
  }
  resolveStrike(m) {
    const k = this.k, a = this.dir, R = this.reach; this.setCd('tentacle', 1.2);
    let end = R;
    // walls stop the tentacle; at MR 2+ dropped pallets are smashed instead
    const h = m.world.firstHit(k.x, k.y, k.x + Math.cos(a) * R, k.y + Math.sin(a) * R, 0.15 * M, (q) => q.blocksLOS);
    if (h) end = h.t * R;
    for (let t = 0.3 * M; t < end; t += 0.3 * M) {
      const px = k.x + Math.cos(a) * t, py = k.y + Math.sin(a) * t;
      const pal = m.map.pallets.find((q) => q.state === 'down' && q.stunZone({ x: px, y: py }) && Math.abs((px - q.x) * q.nx + (py - q.y) * q.ny) < 0.3 * M);
      if (!pal) continue;
      if (this.mr >= 2) { m.breakPallet(pal, k); m.fx.text(pal.x, pal.y - 30, 'SMASHED', '#c05050'); }
      else end = t;
      break;
    }
    this.lastStrike = { x: k.x, y: k.y, a, len: end, t: m.time };
    // zombies on the line die (+0.5)
    for (const z of this.zombies) if (!z.dead && this.onLine(k, a, end, z, z.r)) { m.removeMinion(z); this.mrPts += 0.5; this.respawn.push(m.time + 15); m.fx.burst(z.x, z.y, 14, '#6a7a5a', 80, 0.5, 2, 2); }
    let best = null, bd = Infinity;
    for (const s of m.survivors) { if (!s.standing || !this.onLine(k, a, end, s, s.r)) continue; const d = dist(k.x, k.y, s.x, s.y); if (d < bd) { bd = d; best = s; } }
    if (!best) return;
    if (best.dodgeT && best.dodgeT > m.time) { m.fx.text(best.x, best.y - 30, 'DODGED', '#ffd27a'); return; }
    if (best.status.has('contaminated')) { const r = strike(m, k, best, { source: 'tentacle', score: 'brutality', label: 'Tentacle Strike' }); if (r && r !== 'dodged') { best.status.remove('contaminated'); best.ai?.note('Tentacle hit while contaminated', 'tent'); } }
    else { this.contaminate(m, best, true); best.ai?.note('Contaminated by the tentacle', 'contam'); }
  }
  onLine(k, a, len, e, r) {
    const dx = e.x - k.x, dy = e.y - k.y, along = dx * Math.cos(a) + dy * Math.sin(a); if (along < 0 || along > len + r) return false;
    return Math.abs(-dx * Math.sin(a) + dy * Math.cos(a)) < r + 0.45 * M;
  }
  contaminate(m, s, byTentacle) {
    if (s.status.has('contaminated')) return;
    s.status.add('contaminated', { duration: 999, source: 'tvirus' }); s._coughT = 2;
    if (byTentacle) { const before = this.mr; this.mrPts += 1; this.k.stats.powerHits++; if (this.mr > before) { m.fx.text(this.k.x, this.k.y - 50, `MUTATION RATE ${this.mr}`, '#c05050'); m.notifyK(`Mutation Rate ${this.mr}`, '#c05050'); } }
    m.addScore('deviousness', 200, 'Contamination'); m.warn(s, 'Contaminated — find a vaccine');
    m.events.emit('powerTriggered', { survivor: s, x: s.x, y: s.y, killer: this.k });
  }
  tick(dt, m) {
    this.zombies = this.zombies.filter((z) => !z.dead);
    this.respawn = this.respawn.filter((t) => { if (m.time >= t) { this.spawnZombie(m); return false; } return true; });
    for (const s of m.survivors) {
      if (!s.standing || !s.status.has('contaminated')) continue;
      s._coughT = (s._coughT || 0) - dt;
      if (s._coughT <= 0) { s._coughT = 3.5 + Math.random() * 2; m.addGrunt?.(s); m.sound('cough', s.x, s.y, 14 * M, { survivor: s }); }
    }
  }
  drawMinion(ctx, n, m) {
    if (n.kind !== 'zombie') return false;
    ctx.save(); ctx.translate(n.x, n.y); ctx.rotate(n.facing);
    ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.arc(2, 3, 11, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = n.state === 'swing' ? '#9aa070' : '#5a6a4a'; ctx.beginPath(); ctx.arc(0, 0, 10, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#c8c0a0'; ctx.beginPath(); ctx.arc(6, 0, 4, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#5a6a4a'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(2, -8); ctx.lineTo(12 + (n.state === 'swing' ? 6 : 0), -9); ctx.moveTo(2, 8); ctx.lineTo(12, 9); ctx.stroke();
    ctx.restore();
    // vision cone (faint)
    ctx.fillStyle = n.state === 'pursue' ? 'rgba(200,80,60,0.08)' : 'rgba(150,170,120,0.05)'; ctx.beginPath(); ctx.moveTo(n.x, n.y); ctx.arc(n.x, n.y, 14 * M, n.facing - 0.7, n.facing + 0.7); ctx.closePath(); ctx.fill();
    if (n.stunT > 0) { ctx.fillStyle = '#ffd27a'; ctx.beginPath(); ctx.arc(n.x, n.y - 14, 3, 0, Math.PI * 2); ctx.fill(); }
    return true;
  }
  drawDevice(ctx, d) {
    if (d.kind !== 'vaccine') return;
    ctx.fillStyle = '#3a4a5a'; ctx.fillRect(d.x - 13, d.y - 9, 26, 18); ctx.fillStyle = d.data.vaccines > 0 ? '#7fe0ff' : '#445'; ctx.fillRect(d.x - 3, d.y - 6, 6, 12); ctx.fillRect(d.x - 6, d.y - 2, 12, 4);
  }
  drawOver(ctx, m) {
    const k = this.k;
    if (this.state === 'charging') { ctx.strokeStyle = 'rgba(192,80,80,0.5)'; ctx.setLineDash([4, 5]); ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.lineTo(k.x + Math.cos(k.facing) * this.reach, k.y + Math.sin(k.facing) * this.reach); ctx.stroke(); ctx.setLineDash([]); }
    const L = this.lastStrike; if (L && m.time - L.t < 0.35) { ctx.strokeStyle = `rgba(160,40,60,${1 - (m.time - L.t) / 0.35})`; ctx.lineWidth = 6; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(L.x, L.y); ctx.lineTo(L.x + Math.cos(L.a) * L.len, L.y + Math.sin(L.a) * L.len); ctx.stroke(); ctx.lineCap = 'butt'; }
  }
  drawBody(ctx) { ctx.fillStyle = '#3a3030'; ctx.beginPath(); ctx.arc(3, 0, 8, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#a04050'; ctx.fillRect(6, 4, 8, 3); }
  hud(m) {
    const c = m ? m.survivors.filter((s) => s.standing && s.status.has('contaminated')).length : 0;
    const next = this.mr === 1 ? 1 : this.mr === 2 ? 3 : 3;
    return { title: 'T-Virus', value: `MR ${this.mr}`, meter: this.mr >= 3 ? 1 : this.mrPts / next, state: `${c} contaminated · ${this.zombies.length} zombies · reach ${(this.reach / M).toFixed(1)} m`,
      hints: [['Q / RMB', 'Hold 0.35 s, release: Tentacle Strike'], ['MR 2+', 'Tentacle smashes dropped pallets']] };
  }
}
