// THE NURSE — Spencer's Last Breath (adapted to top-down).
//  • Slow walker (3.85 m/s), cannot vault windows.
//  • 2 blink tokens; each recharges in 3 s while she isn't blinking.
//  • Hold RMB to charge a BLINK (2 s): the distance grows from 1.5 m to 20 m. Release to
//    teleport straight ahead THROUGH walls and obstacles (not off the map).
//  • After a blink, a 1.5 s CHAIN window: hold RMB again for a second, shorter blink (up to
//    12 m, charges faster), or LMB to attack out of the blink.
//  • FATIGUE when the chain ends: 2 s after one blink, 2.5 s after two, +1 s if she attacked.
//    Slowed and unable to attack.
import { M, dist, clamp } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower } from './framework.js';

const CHARGE = 2, MIN_D = 1.5, MAX_D = 20, CHAIN_MAX = 12, CHAIN_WIN = 1.5, TOKEN_T = 3;
export class NursePower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'blink'; this.name = "Spencer's Last Breath"; this.state = 'idle';
    this.maxTokens = this.has('anxious_gasp') ? 3 : 2; this.tokens = this.maxTokens; this.tokenT = 0; this.charge = 0; this.blinks = 0; this.attacked = false; this.fatT = 0; this.winT = 0; this.fatigueT = 0;
    this.aiProfile = { type: 'blink', label: 'Blinks through walls', counter: ['change direction when her blink charge sound stops', 'double back behind tall walls', 'distance — she is slow while fatigued', 'pallets and windows do little'] };
  }
  noVault() { return true; }
  speedMult() {
    if (this.state === 'charging') return 0.35;
    if (this.state === 'chain') return 0.5;
    if (this.state === 'fatigue') return 0.3;
    return 1;
  }
  canAttack() { return this.state === 'idle' || this.state === 'chain'; }
  onAttack(m) { if (this.state === 'chain') { this.attacked = true; this.fatigueT = 0.45; } }
  get blinkDist() { const max = this.blinks ? CHAIN_MAX : MAX_D; return (MIN_D + (max - MIN_D) * clamp(this.charge, 0, 1)) * M; }
  update(dt, m, inp, locked) {
    this.tickCooldowns(dt);
    const k = this.k;
    if ((this.state === 'idle') && this.tokens < this.maxTokens) { this.tokenT += dt; if (this.tokenT >= TOKEN_T) { this.tokenT = 0; this.tokens++; } }
    if (this.state === 'fatigue') { this.fatT -= dt; if (this.fatT <= 0) this.state = 'idle'; return; }
    if (this.fatigueT > 0) { this.fatigueT -= dt; if (this.fatigueT <= 0 && this.state === 'chain') { this.fatigue(m); return; } }
    if (locked) { if (this.state === 'charging') { this.state = this.blinks ? 'chain' : 'idle'; } return; }
    switch (this.state) {
      case 'idle':
        if (inp.rmb && this.tokens >= 1 && !k.carrying) { this.state = 'charging'; this.charge = 0; this.blinks = 0; this.attacked = false; this.fatigueT = 0; }
        break;
      case 'charging':
        this.charge += dt / (this.blinks ? CHARGE * 0.6 : CHARGE);
        if (this.soundT === undefined || (this.soundT -= dt) <= 0) { this.soundT = 0.35; m.sound('blink_charge', k.x, k.y, 22 * M, { what: 'blink', charge: this.charge }); }
        if (!inp.rmb) this.blink(m);
        else if (this.charge >= 1.35) this.blink(m); // auto-release after holding at full
        break;
      case 'chain':
        this.winT -= dt;
        if (inp.rmb && this.tokens >= 1 && !this.attacked) { this.state = 'charging'; this.charge = 0; }
        else if (this.winT <= 0 && k.attack.state !== 'lunge') this.fatigue(m);
        break;
    }
  }
  blink(m) {
    const k = this.k, d = this.blinkDist; this.tokens--; this.tokenT = 0; this.blinks++;
    // straight ahead through everything; land on the furthest free point not past the map edge
    let tx = k.x, ty = k.y; const step = 0.25 * M;
    for (let t = step; t <= d; t += step) {
      const x = k.x + Math.cos(k.facing) * t, y = k.y + Math.sin(k.facing) * t;
      if (x < 1.5 * M || y < 1.5 * M || x > m.map.w - 1.5 * M || y > m.map.h - 1.5 * M) break;
      if (!m.world.pointBlocked(x, y, k.r)) { tx = x; ty = y; }
    }
    m.fx.burst(k.x, k.y, 18, '#c8d8e8', 100, 0.5, 2, 2);
    this.from = { x: k.x, y: k.y, t: m.time }; k.x = tx; k.y = ty;
    m.fx.burst(k.x, k.y, 22, '#c8d8e8', 140, 0.6, 2, 2); m.audio?.play('teleport');
    m.sound('killer_action', k.x, k.y, 24 * M, { what: 'blink' });
    m.events.emit(EV.POWER_USED, { killer: k, power: 'blink', n: this.blinks });
    this.state = 'chain'; this.winT = CHAIN_WIN; this.charge = 0;
  }
  fatigue(m) { this.state = 'fatigue'; this.fatT = (this.blinks >= 2 ? 2.5 : 2) + (this.attacked ? 1 : 0); this.blinks = 0; this.attacked = false; this.fatigueT = 0; }
  drawOver(ctx, m) {
    const k = this.k;
    if (this.state === 'charging') {
      const d = this.blinkDist, x = k.x + Math.cos(k.facing) * d, y = k.y + Math.sin(k.facing) * d;
      ctx.strokeStyle = 'rgba(200,216,232,0.5)'; ctx.setLineDash([4, 6]); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.lineTo(x, y); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = 'rgba(200,216,232,0.35)'; ctx.beginPath(); ctx.arc(x, y, k.r, 0, Math.PI * 2); ctx.fill();
    }
    if (this.from && m.time - this.from.t < 0.6) { const a = 1 - (m.time - this.from.t) / 0.6; ctx.strokeStyle = `rgba(200,216,232,${a * 0.6})`; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(this.from.x, this.from.y); ctx.lineTo(k.x, k.y); ctx.stroke(); }
    if (this.state === 'fatigue') { ctx.fillStyle = 'rgba(200,216,232,0.6)'; ctx.font = '600 12px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('fatigued', k.x, k.y - k.r - 10); }
  }
  drawBody(ctx) { ctx.fillStyle = '#e8e0d0'; ctx.beginPath(); ctx.arc(5, 0, 6, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#5a2a2a'; ctx.fillRect(4, -2, 4, 4); }
  hud() {
    const st = { idle: this.tokens ? 'Ready' : 'Recharging', charging: `Blink ${(this.blinkDist / M).toFixed(1)} m`, chain: `Chain window ${this.winT.toFixed(1)}s — RMB blink / LMB attack`, fatigue: `Fatigue ${this.fatT.toFixed(1)}s` }[this.state];
    return { title: "Spencer's Last Breath", value: `${this.tokens}/${this.maxTokens}`, meter: this.state === 'charging' ? clamp(this.charge, 0, 1) : this.tokens / this.maxTokens, state: st,
      hints: [['Q / RMB', 'Hold to charge a blink (1.5–20 m, through walls), release to blink'], ['RMB again', 'Chain a second blink (≤12 m)'], ['LMB', 'Attack out of a blink']] };
  }
}
