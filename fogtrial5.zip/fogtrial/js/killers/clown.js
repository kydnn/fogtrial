// THE CLOWN — The Afterpiece Tonic. Hold the power to aim, release to lob a bottle.
// Tonic (purple) gas Intoxicates survivors: Hindered while inside and briefly after,
// and they cough. Antidote (yellow) gas arms after a moment and gives everyone inside
// (the Clown too) a burst of speed. E switches bottle type. Bottles reload when empty.
import { M, dist, clamp } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, Projectile, Zone } from './framework.js';

export class ClownPower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'tonic'; this.name = 'Afterpiece Tonic'; this.state = 'idle';
    this.max = this.has('fingerless_parade') ? 8 : 6; this.bottles = this.max; this.type = 'tonic';
    this.aimT = 0; this.reloadT = 0; this.reloadTime = this.has('robin_feather') ? 2.4 : 3.2;
    this.cloudR = (this.has('redheads_pinkie') ? 3.8 : 3.2) * M; this.slow = this.has('ether') ? 0.26 : 0.2;
    this.aiProfile = { type: 'area', label: 'Gas clouds', counter: ['avoid purple gas', 'reroute when herded', 'use pallets before the gas lands'] };
  }
  speedMult() { if (this.state === 'aiming') return 0.85; if (this.state === 'reloading') return 0.55; return 1; }
  canAttack() { return this.state !== 'reloading'; }
  update(dt, m, inp, locked) {
    this.tickCooldowns(dt);
    if (locked) { if (this.state === 'aiming') this.state = 'idle'; return; }
    if (this.state === 'reloading') { this.reloadT += dt; if (this.reloadT >= this.reloadTime) { this.bottles = this.max; this.state = 'idle'; } return; }
    if (inp.eP) this.type = this.type === 'tonic' ? 'antidote' : 'tonic';
    if (this.state === 'idle' && inp.rmb && !this.k.carrying && this.bottles > 0 && this.cd('throw') <= 0) { this.state = 'aiming'; this.aimT = 0; }
    if (this.state === 'aiming') {
      this.aimT += dt;
      if (!inp.rmb) { if (this.aimT > 0.25) this.throw(m, inp); this.state = 'idle'; }
    }
    if (this.bottles <= 0 && this.state === 'idle') { this.state = 'reloading'; this.reloadT = 0; }
  }
  target(inp) {
    const k = this.k; const d = clamp(inp.aimDist ?? 10 * M, 3 * M, 16 * M);
    return { x: k.x + Math.cos(k.facing) * d, y: k.y + Math.sin(k.facing) * d, d };
  }
  throw(m, inp) {
    const k = this.k, t = this.target(inp), type = this.type;
    this.bottles--; this.setCd('throw', 0.5);
    m.sound('power_windup', k.x, k.y, 24 * M, { what: 'bottle' });
    m.spawnProjectile(new Projectile({
      kind: 'bottle', owner: k, x: k.x, y: k.y, arc: { sx: k.x, sy: k.y, tx: t.x, ty: t.y, dur: 0.25 + t.d / (18 * M) }, color: type === 'tonic' ? '#b07ad8' : '#e8c35a',
      data: { type }, onEnd: (p, mm) => this.burst(mm, p.x, p.y, type),
    }));
    m.events.emit(EV.POWER_USED, { killer: k, power: 'bottle', type });
  }
  burst(m, x, y, type) {
    m.audio?.play('glass'); m.fx.burst(x, y, 24, type === 'tonic' ? '#b07ad8' : '#e8c35a', 120, 0.8, 3, 3);
    m.sound('gas_cloud', x, y, 28 * M, { type });
    if (type === 'tonic') {
      m.addZone(new Zone({ kind: 'tonic', x, y, r: this.cloudR, t0: m.time, until: m.time + 8, owner: this.k, color: 'rgba(150,80,200,0.32)', aiCost: 14, label: 'Tonic gas',
        effect: (s, dt, mm) => {
          s.status.add('intoxicated', { duration: 2.5, value: this.slow, source: 'clown' });
          s._coughT = (s._coughT ?? 0) - dt; if (s._coughT <= 0) { s._coughT = 1.2 + Math.random(); mm.addGrunt(s, '#b07ad8'); }
        } }));
    } else {
      m.addZone(new Zone({ kind: 'antidote', x, y, r: this.cloudR * 0.9, t0: m.time, until: m.time + 8, armT: 1.5, owner: this.k, color: 'rgba(230,195,90,0.28)', aiCost: -2, label: 'Antidote gas',
        effect: (s) => { s.status.remove('intoxicated'); s.status.add('haste', { duration: 4, value: 0.1, source: 'antidote' }); },
        killerEffect: (kk) => kk.status.add('haste', { duration: 6, value: 0.12, source: 'antidote' }) }));
    }
  }
  hud() {
    const label = this.state === 'reloading' ? `Reloading ${Math.round(this.reloadT / this.reloadTime * 100)}%` : this.state === 'aiming' ? 'Aiming…' : this.type === 'tonic' ? 'Tonic ready' : 'Antidote ready';
    return { title: this.type === 'tonic' ? 'Afterpiece Tonic' : 'Antidote', value: `${this.bottles}/${this.max}`, meter: this.state === 'reloading' ? this.reloadT / this.reloadTime : this.bottles / this.max, state: label,
      hints: [['Q / RMB', 'Hold to aim, release to throw'], ['E', 'Switch tonic / antidote']] };
  }
}
