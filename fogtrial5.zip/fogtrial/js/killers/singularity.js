// THE SINGULARITY — Quantum Instantiation (adapted to top-down from the current DBD power).
//  • Biopods: hold RMB to charge (0.15 s) and release to SHOOT a biopod (50 m/s, 22 m). It
//    sticks to the first wall / obstacle it hits; missing everything wastes the shot. 8 pods,
//    the 9th recycles the oldest. Reload 0.5 s. A shot that hits a survivor Slipstreams them;
//    hitting someone already Slipstreamed teleports you straight to them.
//  • Pod control: E jumps into the nearest pod to your aim (F cycles pods). Your body stands
//    still. Aim the reticle at a survivor the pod can see (20 m): 0.8 s of lock Slipstreams
//    them (10× slower near a hooked survivor). Locked on an already Slipstreamed survivor,
//    LMB Quantum-Instantiates you to the pod. E leaves the pod (0.5 s wake-up).
//  • Temporal Slipstream lasts until an EMP removes it and spreads to anyone within 6 m for 2 s.
//  • Overclock (5.7 s after a teleport): +3% speed, +75% break/kick/vault speed, immune to
//    pallet stuns — a stun attempt breaks the pallet and Overheats you instead.
//  • Overheat (3 s): Hindered 50%, pods unusable.
//  • EMP printers (4 supply cases): they print slowly by themselves up to 97%; a survivor
//    finishes them (×4). An EMP takes 2.5 s to arm (Hindered 10%) and in 10 m removes
//    Slipstream and disables every pod for 45 s. A disabled pod can be destroyed from inside
//    by holding LMB for 0.75 s.
import { M, dist, angleDiff, clamp } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, Device, Projectile } from './framework.js';

const POD_RANGE = 22 * M, LOCK_RANGE = 20 * M, LOCK_TIME = 0.8, SPREAD_R = 6 * M, SPREAD_T = 2, OVERCLOCK = 5.7, OVERHEAT = 3;
export class SingularityPower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'quantum'; this.name = 'Quantum Instantiation'; this.state = 'idle';
    this.maxPods = this.has('cold_dirt') ? 10 : 8; this.charge = 0; this.lock = null; this.ctrl = null; this.overclockT = 0; this.overheatT = 0;
    this.spread = new Map(); this.lockCdT = 0; this.wakeT = 0;
    this.lockMult = this.has('denied_requisition') ? 1.25 : 1;
    this.aiProfile = { type: 'surveillance', label: 'Biopods, Slipstream & teleports', counter: ['stay out of pod sightlines', 'spread out (Slipstream spreads)', 'print and use EMPs', 'pallets break on Overclock'] };
  }
  get pods() { return this._m ? this._m.devices.filter((d) => d.kind === 'biopod' && d.owner === this.k) : []; }
  get podsCarried() { return this.maxPods - this.pods.length; } // compatibility (HUD / older AI)
  podActive(p, m) { return !p.dead && (p.data.disabledUntil || 0) <= m.time; }
  speedMult() {
    if (this.state === 'control' || this.state === 'teleporting' || this.wakeT > 0) return 0;
    if (this.state === 'aiming') return 0.85;
    return 1;
  }
  canAttack() { return this.state === 'idle' && this.wakeT <= 0; }
  noContext() { return this.state === 'control'; }
  stunImmune() { return this.overclockT > 0; }
  onStunImmune(m, pallet) { m.breakPallet(pallet, this.k); this.overheat(m); }
  actionMult(type) { return this.overclockT > 0 && ['kick', 'break', 'vault'].includes(type) ? 1 / 1.75 : 1; }
  // pod-control view: the camera and line of sight move to the pod
  viewPoint() { return this.state === 'control' && this.ctrl && !this.ctrl.dead ? { x: this.ctrl.x, y: this.ctrl.y } : null; }
  onInit(m) {
    this._m = m;
    // four supply cases spread across the map
    const cand = m.map.openSpots(16, 8, m.map.gens), spots = [];
    while (spots.length < 4 && cand.length) { cand.sort((a, b) => Math.min(...spots.map((q) => dist(q.x, q.y, b.x, b.y)), 1e9) - Math.min(...spots.map((q) => dist(q.x, q.y, a.x, a.y)), 1e9)); spots.push(cand.shift()); }
    for (const p of spots) {
      const pr = m.addDevice(new Device({ kind: 'printer', x: p.x, y: p.y, r: 0.7 * M, label: 'EMP printer', useLabel: 'Print an EMP', survivorUsable: true, seenRange: 28 * M, useTime: 25, manualComplete: true, data: { charge: Math.random() * 40 } }));
      pr.usable = (s) => !s.emp && !this.disabledPrinter(pr);
      pr.onUse = (s, mm) => { pr.data.charge = 0; s.emp = true; mm.notifyK(`${s.name} printed an EMP`, '#9fd0d0'); s.ai?.note('Printed an EMP', 'emp'); mm.warn(s, 'EMP ready — Q to arm it'); };
    }
  }
  disabledPrinter() { return false; }
  // ------------------------------------------------------------------ per frame
  update(dt, m, inp, locked) {
    this._m = m; this.tickCooldowns(dt);
    const k = this.k;
    this.overclockT = Math.max(0, this.overclockT - dt); this.overheatT = Math.max(0, this.overheatT - dt); this.lockCdT = Math.max(0, this.lockCdT - dt); this.wakeT = Math.max(0, this.wakeT - dt);
    if (this.overclockT > 0) k.status.add('haste', { duration: 0.2, value: 0.03, source: 'overclock' });
    if (this.state === 'teleporting') { this.tpT -= dt; if (this.tpT <= 0) this.finishTeleport(m); return; }
    if (locked) { if (this.state === 'aiming') this.state = 'idle'; if (this.state === 'control') this.leaveControl(m); return; }
    if (this.state === 'control') return this.updateControl(dt, m, inp);
    // shoot pods
    if (this.state === 'idle' && inp.rmb && !k.carrying && this.overheatT <= 0 && this.cd('reload') <= 0) { this.state = 'aiming'; this.charge = 0; }
    if (this.state === 'aiming') {
      this.charge += dt;
      if (!inp.rmb) { if (this.charge >= 0.15) this.shoot(m); this.state = 'idle'; }
    }
    if (inp.eP && !k.carrying && this.overheatT <= 0 && this.state === 'idle') this.enterControl(m, inp);
  }
  // Always-running clocks (also while stunned / acting): printers, Slipstream spread, pods.
  tick(dt, m) {
    for (const pr of m.devices) if (pr.kind === 'printer') {
      const users = m.survivors.filter((s) => s.action?.type === 'device' && s.action.target === pr).length;
      const c = pr.data.charge; pr.data.charge = users ? Math.min(100, c + 4 * dt) : c < 97 ? Math.min(97, c + dt) : c;
      pr.useTime = Math.max(0.3, (100 - pr.data.charge) / 4); // remaining time (AI estimates)
      if (users && pr.data.charge >= 100) { const s = m.survivors.find((q) => q.action?.type === 'device' && q.action.target === pr); s.stopAction(m); pr.onUse(s, m); m.events.emit('deviceUsed', { survivor: s, device: pr }); }
    }
    // Slipstream spreads to survivors standing near a Slipstreamed one for 2 s
    const slipped = m.survivors.filter((s) => s.standing && s.status.has('slipstream'));
    for (const s of m.survivors) {
      if (!s.standing || s.status.has('slipstream') || (s.slipImmuneUntil || 0) > m.time) { this.spread.delete(s); continue; }
      if (slipped.some((o) => dist(o.x, o.y, s.x, s.y) < SPREAD_R)) {
        const t = (this.spread.get(s) || 0) + dt; this.spread.set(s, t);
        if (t >= SPREAD_T) { this.slipstream(m, s, 'spread'); this.spread.delete(s); }
      } else this.spread.delete(s);
    }
  }
  // ------------------------------------------------------------------ pods
  shoot(m) {
    const k = this.k; this.setCd('reload', 0.5); const a = k.facing;
    m.audio?.play('throw'); m.sound('killer_action', k.x, k.y, 20 * M, { what: 'biopod' });
    m.spawnProjectile(new Projectile({
      kind: 'biopod_shot', owner: k, x: k.x + Math.cos(a) * k.r, y: k.y + Math.sin(a) * k.r, vx: Math.cos(a) * 50 * M, vy: Math.sin(a) * 50 * M, r: 0.15 * M, range: POD_RANGE, color: '#5fe0e0',
      onHit: (p, s, mm) => { if (s.status.has('slipstream')) this.teleportTo(mm, s, null); else this.slipstream(mm, s, 'shot'); },
      onWall: (p, mm) => this.attachPod(mm, p.x - Math.cos(a) * 0.35 * M, p.y - Math.sin(a) * 0.35 * M),
      onEnd: (p, mm) => { mm.fx.text(p.x, p.y - 20, 'no surface', '#7fb8b8'); },
    }));
    m.events.emit(EV.POWER_USED, { killer: k, power: 'pod' });
  }
  attachPod(m, x, y) {
    // spacing rules: not on top of generators, windows or other pods
    if (m.map.gens.some((g) => dist(g.x, g.y, x, y) < 2.5 * M) || m.map.windows.some((w) => dist(w.x, w.y, x, y) < 2.5 * M) || this.pods.some((p) => dist(p.x, p.y, x, y) < 5 * M)) { m.fx.text(x, y - 20, 'too close', '#7fb8b8'); return; }
    const pods = this.pods; if (pods.length >= this.maxPods) m.removeDevice(pods[0]);
    m.addDevice(new Device({ kind: 'biopod', x, y, r: 0.35 * M, owner: this.k, label: 'Biopod', seenRange: 18 * M, dangerRadius: LOCK_RANGE * 0.6, aiCost: 4, data: { placedT: m.time, disabledUntil: 0 } }));
    m.fx.burst(x, y, 10, '#5fe0e0', 60, 0.5, 2, 2);
  }
  enterControl(m, inp) {
    const pods = this.pods.filter((p) => !p.dead); if (!pods.length) { m.fx.text(this.k.x, this.k.y - 40, 'No biopods', '#9fd0d0'); return; }
    const ax = inp.aimX ?? this.k.x + Math.cos(this.k.facing) * (inp.aimDist ?? 10 * M), ay = inp.aimY ?? this.k.y + Math.sin(this.k.facing) * (inp.aimDist ?? 10 * M);
    this.ctrl = pods.sort((a, b) => dist(a.x, a.y, ax, ay) - dist(b.x, b.y, ax, ay))[0];
    this.state = 'control'; this.lock = null; this.ctrlT = 0; this.k.vx = this.k.vy = 0;
    m.events.emit(EV.POWER_USED, { killer: this.k, power: 'pod_control' });
  }
  leaveControl(m) { this.state = 'idle'; this.ctrl = null; this.lock = null; this.wakeT = 0.5; }
  cyclePod(dir = 1) { const pods = this.pods; if (pods.length < 2) return; const i = pods.indexOf(this.ctrl); this.ctrl = pods[(i + dir + pods.length) % pods.length]; this.lock = null; }
  // reticle: what the pod is pointing at (mouse in world space for the player, aim for bots)
  reticle(inp) {
    const c = this.ctrl;
    if (inp.aimX !== undefined) return { x: inp.aimX, y: inp.aimY };
    return { x: this.k.x + Math.cos(inp.aim) * (inp.aimDist ?? 10 * M), y: this.k.y + Math.sin(inp.aim) * (inp.aimDist ?? 10 * M), c };
  }
  updateControl(dt, m, inp) {
    const c = this.ctrl; this.ctrlT += dt;
    if (!c || c.dead || inp.eP) { this.leaveControl(m); return; }
    if (inp.cycleP || inp.wheel) this.cyclePod(inp.wheel > 0 ? 1 : -1);
    const r = this.reticle(inp);
    // disabled pod: hold LMB 0.75 s to destroy it from inside
    if (!this.podActive(c, m)) {
      this.lock = null; c.data.destroyT = inp.lmb ? (c.data.destroyT || 0) + dt : 0;
      if (c.data.destroyT >= 0.75) { m.removeDevice(c); this.leaveControl(m); }
      return;
    }
    // candidate: survivor nearest the reticle that the pod can see
    let best = null, bd = 1.8 * M;
    for (const s of m.survivors) {
      if (!s.standing) continue;
      const dr = dist(s.x, s.y, r.x, r.y); if (dr > bd) continue;
      if (dist(s.x, s.y, c.x, c.y) > LOCK_RANGE || !m.world.losClear(c.x, c.y, s.x, s.y)) continue;
      bd = dr; best = s;
    }
    if (this.lockCdT > 0) best = null;
    if (best) {
      const nearHook = m.survivors.some((h) => h.health === 'hooked' && dist(h.x, h.y, best.x, best.y) < 10 * M);
      if (!this.lock || this.lock.s !== best) this.lock = { s: best, t: 0, lost: 0 };
      this.lock.t += dt * this.lockMult / (nearHook ? 10 : 1); this.lock.lost = 0;
      if (this.lock.t >= LOCK_TIME && !best.status.has('slipstream')) { this.slipstream(m, best, 'pod'); this.lockCdT = 3; this.lock = null; }
      else if (this.lock && this.lock.t >= LOCK_TIME && best.status.has('slipstream') && inp.lmbP) this.teleportTo(m, best, c);
    } else if (this.lock) {
      this.lock.lost += dt; if (this.lock.lost > 0.25) { this.lock.t -= dt / 0.5 * LOCK_TIME; if (this.lock.t <= 0) this.lock = null; }
    }
  }
  slipstream(m, s, how) {
    if (s.status.has('slipstream')) return;
    s.status.add('slipstream', { source: 'sing' });
    m.reveal(s, 3, 'Killer Instinct'); // Killer Instinct for 3 s
    m.fx.ring(s.x, s.y, 'rgba(95,224,224,0.9)', 40, 0.6); m.addScore('deviousness', 200, 'Slipstream');
    s.ai?.note(how === 'spread' ? 'Slipstream spread to me' : how === 'shot' ? 'Shot with a biopod — Slipstreamed' : 'Tagged by a biopod — Slipstreamed', 'slip');
    m.warn(s, 'You are Slipstreamed — the Singularity can teleport to you');
    m.events.emit('powerTriggered', { survivor: s, x: s.x, y: s.y, killer: this.k });
  }
  // Quantum Instantiation: to the controlled pod (pod lock) or to the survivor (direct shot)
  teleportTo(m, s, pod) {
    const k = this.k; const at = pod || s;
    this.tpDest = { x: at.x, y: at.y, s }; this.tpT = 0.3; this.state = 'teleporting'; this.ctrl = null; this.lock = null;
    m.sound('teleport_warn', at.x, at.y, 26 * M, { pod, killer: k });
    m.fx.ring(at.x, at.y, 'rgba(95,224,224,0.9)', 3 * M, 0.5);
  }
  finishTeleport(m) {
    const k = this.k, d = this.tpDest; this.state = 'idle';
    // land on open ground next to the destination, facing the target
    let x = d.x, y = d.y; const s = d.s;
    for (let i = 0; i < 12; i++) { const a = (s ? Math.atan2(k.y - s.y, k.x - s.x) : 0) + i * 0.5; const tx = d.x + Math.cos(a) * 1.4 * M, ty = d.y + Math.sin(a) * 1.4 * M; if (!m.world.pointBlocked(tx, ty, k.r)) { x = tx; y = ty; break; } }
    m.fx.burst(k.x, k.y, 20, '#5fe0e0', 120, 0.5, 2, 2);
    k.x = x; k.y = y; m.world.resolve(k, k.r); if (s) k.facing = Math.atan2(s.y - k.y, s.x - k.x);
    this.wakeT = 0.6; this.overclockT = OVERCLOCK; this.lockCdT = 3; this.setCd('tp', 2);
    m.fx.burst(k.x, k.y, 40, '#5fe0e0', 220, 0.8, 3, 3); m.audio?.play('teleport'); m.fx.shake(6);
    m.sound('killer_action', k.x, k.y, 36 * M, { what: 'teleport' });
    m.events.emit(EV.POWER_USED, { killer: k, power: 'teleport' });
  }
  overheat(m) { this.overclockT = 0; this.overheatT = OVERHEAT; this.k.status.add('hindered', { duration: OVERHEAT, value: 0.5, source: 'overheat' }); m.fx.text(this.k.x, this.k.y - 40, 'OVERHEAT', '#ff8a4a'); if (this.state === 'control') this.leaveControl(m); }
  // ------------------------------------------------------------------ EMP
  useEmp(s, m) {
    let n = 0;
    for (const pod of this.pods) if (dist(pod.x, pod.y, s.x, s.y) < 10 * M && this.podActive(pod, m)) { pod.data.disabledUntil = m.time + (this.has('broken_key') ? 38 : 45); n++; m.fx.sparks(pod.x, pod.y); if (pod === this.ctrl) this.leaveControl(m); }
    for (const o of m.survivors) if (dist(o.x, o.y, s.x, s.y) < 10 * M) { o.status.remove('slipstream'); o.slipImmuneUntil = m.time + 1; }
    m.fx.ring(s.x, s.y, 'rgba(160,240,255,0.9)', 10 * M, 0.8); m.audio?.play('emp');
    m.notifyK(`EMP disabled ${n} biopod${n === 1 ? '' : 's'}`, '#9fd0d0'); s.ai?.note(`Used an EMP (${n} pods disabled)`, 'empuse');
    s.status.remove('hindered', 'emp');
  }
  // compatibility for the survivor AI (pod knowledge / threat of a teleport)
  teleportTarget(m) { const s = m.survivors.find((q) => q.standing && q.status.has('slipstream')); return s ? { s, pod: this.pods[0] } : null; }
  // ------------------------------------------------------------------ drawing
  drawDevice(ctx, d, m) {
    if (d.kind === 'biopod' && d.owner === this.k) {
      const on = this.podActive(d, m);
      ctx.fillStyle = '#20343c'; ctx.beginPath(); ctx.arc(d.x, d.y, d.r + 3, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = on ? (d === this.ctrl ? '#d8ffff' : '#5fe0e0') : '#a03a3a'; ctx.beginPath(); ctx.arc(d.x, d.y, d.r * 0.6, 0, Math.PI * 2); ctx.fill();
      if (on) { ctx.strokeStyle = 'rgba(95,224,224,0.10)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(d.x, d.y, LOCK_RANGE, 0, Math.PI * 2); ctx.stroke(); }
    } else if (d.kind === 'printer') {
      ctx.fillStyle = '#2c3a40'; ctx.fillRect(d.x - 14, d.y - 10, 28, 20); ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(d.x - 12, d.y + 12, 24, 4);
      ctx.fillStyle = d.data.charge >= 97 ? '#ffd27a' : '#9fe8ff'; ctx.fillRect(d.x - 12, d.y + 12, 24 * d.data.charge / 100, 4); ctx.fillRect(d.x - 8, d.y - 4, 16, 3);
    }
  }
  drawOver(ctx, m) {
    const k = this.k;
    if (this.state === 'aiming') { ctx.strokeStyle = 'rgba(95,224,224,0.5)'; ctx.setLineDash([5, 6]); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.lineTo(k.x + Math.cos(k.facing) * POD_RANGE, k.y + Math.sin(k.facing) * POD_RANGE); ctx.stroke(); ctx.setLineDash([]); }
    if (this.state === 'control' && this.ctrl) {
      const c = this.ctrl; ctx.strokeStyle = 'rgba(95,224,224,0.35)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(c.x, c.y, LOCK_RANGE, 0, Math.PI * 2); ctx.stroke();
      const r = this.reticle(k.input);
      ctx.strokeStyle = this.lock ? '#ff5b6b' : '#d8ffff'; ctx.beginPath(); ctx.arc(r.x, r.y, 16, 0, Math.PI * 2); ctx.moveTo(r.x - 24, r.y); ctx.lineTo(r.x + 24, r.y); ctx.moveTo(r.x, r.y - 24); ctx.lineTo(r.x, r.y + 24); ctx.stroke();
      if (this.lock) { const s = this.lock.s; ctx.strokeStyle = '#ff5b6b'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(s.x, s.y, s.r + 10, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * Math.min(1, this.lock.t / LOCK_TIME)); ctx.stroke(); }
    }
    if (this.state === 'teleporting' && this.tpDest) { ctx.strokeStyle = 'rgba(95,224,224,0.8)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.lineTo(this.tpDest.x, this.tpDest.y); ctx.stroke(); }
  }
  hud(m) {
    const slip = m ? m.survivors.filter((s) => s.standing && s.status.has('slipstream')).length : 0;
    const st = this.state === 'control' ? (this.ctrl && !this.podActive(this.ctrl, m) ? 'Pod disabled — hold LMB to destroy' : this.lock ? (this.lock.s.status.has('slipstream') && this.lock.t >= LOCK_TIME ? `LMB: teleport to ${this.lock.s.name}` : `Locking ${this.lock.s.name}…`) : 'Pod view — aim at a survivor')
      : this.overheatT > 0 ? `OVERHEAT ${Math.ceil(this.overheatT)}s` : this.overclockT > 0 ? `OVERCLOCK ${this.overclockT.toFixed(1)}s` : `${slip} slipstreamed`;
    return { title: 'Quantum Instantiation', value: `${this.podsCarried}/${this.maxPods}`, meter: this.overheatT > 0 ? 1 - this.overheatT / OVERHEAT : this.state === 'control' && this.lock ? Math.min(1, this.lock.t / LOCK_TIME) : this.podsCarried / this.maxPods, state: st,
      hints: this.state === 'control' ? [['Aim', 'Lock on (0.8 s)'], ['LMB', 'Teleport to a locked Slipstreamed survivor'], ['F / Wheel', 'Next pod'], ['E', 'Leave the pod']]
        : [['Q / RMB', 'Hold & release: shoot a biopod onto a wall'], ['E', 'Control a biopod']] };
  }
}
