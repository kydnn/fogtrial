// THE TRAPPER — Bear Traps. Hold power to set a carried trap; E picks up / resets a trap.
import { M, dist } from '../core/util.js';
import { EV } from '../core/events.js';
import { Trap } from '../entities/objects.js';
import { BALANCE } from '../core/balance.js';

export class TrapperPower {
  constructor(killer, addons = []) {
    this.k = killer; this.id = 'traps'; this.name = 'Bear Trap';
    this.maxCarry = 2 + (addons.includes('trapper_bag') ? 1 : 0);
    this.carried = 2; this.setting = null; this.picking = null;
    this.setTime = addons.includes('fast_set') ? 1.4 : 2.0;
    this.serrated = addons.includes('serrated_jaws'); this.ironCoil = addons.includes('iron_coil');
    this.aiProfile = { type: 'trap', label: 'Bear traps', counter: ['avoid known traps', 'disarm near loops', 'avoid tall grass near tiles'] };
  }
  speedMult() { return this.setting || this.picking ? 0 : 1; }
  canAttack() { return !this.setting && !this.picking; }
  onInit(m) {
    // Map trap spawns: traps lying on the ground, unset.
    for (const p of m.map.trapSpawns || []) m.traps.push(new Trap(p.x, p.y, 'unset'));
  }
  frontPoint() { return { x: this.k.x + Math.cos(this.k.facing) * 1.1 * M, y: this.k.y + Math.sin(this.k.facing) * 1.1 * M }; }
  update(dt, m, inp, locked) {
    if (locked) { this.setting = null; this.picking = null; return; }
    const k = this.k;
    if (this.setting) {
      this.setting.t += dt;
      if (!inp.rmb) { this.setting = null; }
      else if (this.setting.t >= this.setTime) {
        const p = this.setting.p; const t = new Trap(p.x, p.y, 'set'); t.inGrass = m.map.isGrass(p.x, p.y); t.setT = m.time;
        m.traps.push(t); this.carried--; this.setting = null;
        m.events.emit(EV.TRAP_SET, { trap: t }); m.audio?.play('trapset');
        // Balance: Haste after a successful placement (refreshes, never stacks unless configured).
        const B = BALANCE.trapper; if (!B.trapSetHasteStacks) k.status.remove('haste', 'trap_set');
        k.status.add('haste', { duration: B.trapSetHasteDuration, value: B.trapSetHaste, source: 'trap_set' }); m.fx.text(k.x, k.y - 40, 'HASTE', '#9fd0a0');
      }
      return;
    }
    if (this.picking) {
      this.picking.t += dt;
      if (this.picking.t >= 1.0) {
        const t = this.picking.trap; const i = m.traps.indexOf(t); if (i >= 0 && t.state !== 'triggered') { m.traps.splice(i, 1); this.carried++; }
        this.picking = null;
      }
      return;
    }
    if (inp.rmbP && !k.carrying && this.carried > 0) {
      const p = this.frontPoint();
      if (!m.world.pointBlocked(p.x, p.y, 0.4 * M) && !m.traps.some((t) => dist(t.x, t.y, p.x, p.y) < 1.2 * M)) this.setting = { t: 0, p };
      else m.fx.text(k.x, k.y - 40, 'No room', '#cfc6b8');
    }
    if (inp.eP && !k.carrying && this.carried < this.maxCarry) {
      const t = this.nearTrap(m); if (t) this.picking = { t: 0, trap: t };
    }
  }
  nearTrap(m) {
    let best = null, bd = 1.8 * M;
    for (const t of m.traps) { if (t.state === 'triggered') continue; const d = dist(t.x, t.y, this.k.x, this.k.y); if (d < bd) { bd = d; best = t; } }
    return best;
  }
  hud(m) {
    const st = this.setting ? `Setting ${Math.round(this.setting.t / this.setTime * 100)}%` : this.picking ? 'Picking up…' : this.carried ? 'Ready' : 'No traps carried';
    return { title: 'Bear Trap', value: `${this.carried}/${this.maxCarry}`, meter: this.setting ? this.setting.t / this.setTime : this.picking ? this.picking.t : this.carried / this.maxCarry, state: st,
      hints: [['Q / RMB', 'Hold to set trap'], ['E', 'Pick up / reset trap']] };
  }
  prompt(m) { const t = this.nearTrap(m); return t && this.carried < this.maxCarry ? { key: 'E', label: t.state === 'set' ? 'Pick up set trap' : 'Pick up trap' } : null; }
}
