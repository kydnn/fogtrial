// THE HILLBILLY — Chainsaw. Hold power to rev; at full charge he sprints at high speed
// with limited turning. Hitting a survivor downs them instantly; hitting an obstacle stuns him.
import { M, clamp, normAngle, dist } from '../core/util.js';
import { EV } from '../core/events.js';

export class HillbillyPower {
  constructor(killer, addons = []) {
    this.k = killer; this.id = 'chainsaw'; this.name = 'Chainsaw';
    this.state = 'idle'; this.charge = 0; this.heat = 0; this.t = 0; this.dir = 0; this.overheatT = 0;
    this.revTime = addons.includes('primer_bulb') ? 2.0 : 2.5;
    this.turnRate = addons.includes('heavy_clutch') ? 1.9 : 1.35;
    this.heatRate = addons.includes('speed_limiter') ? 0.07 : 0.1;
    this.sprintSpeed = 9.2 * M; this.maxSprint = 3.2;
    this.soundT = 0; this.lockFacing = false;
    this.aiProfile = { type: 'chainsaw', label: 'Chainsaw sprint', counter: ['break line of sight when revving', 'avoid long straight runs', 'sidestep the sprint'] };
  }
  speedMult() {
    if (this.state === 'revving') return 0.7;
    if (this.state === 'sprint') return this.sprintSpeed / (this.k.def.speed * M);
    if (this.state === 'recover') return 0.35;
    if (this.state === 'collide') return 0;
    return 1;
  }
  canAttack() { return this.state === 'idle' || this.state === 'overheat'; }
  overrideMove() {
    if (this.state !== 'sprint') return null;
    return { x: Math.cos(this.dir), y: Math.sin(this.dir) };
  }
  update(dt, m, inp, locked) {
    const k = this.k;
    if (this.overheatT > 0) { this.overheatT -= dt; if (this.overheatT <= 0) { this.state = 'idle'; this.heat = 0; } }
    else this.heat = Math.max(0, this.heat - dt * 0.04);
    if (locked) { if (this.state === 'revving' || this.state === 'sprint') this.state = 'idle'; this.charge = 0; this.lockFacing = false; return; }
    this.soundT -= dt;
    switch (this.state) {
      case 'idle':
        this.charge = Math.max(0, this.charge - dt);
        if (inp.rmb && !k.carrying && this.overheatT <= 0) { this.state = 'revving'; m.events.emit(EV.POWER_USED, { killer: k, power: 'rev' }); }
        break;
      case 'revving':
        this.charge += dt / this.revTime; this.heat += dt * this.heatRate * 0.5;
        if (this.soundT <= 0) { this.soundT = 0.3; m.sound('chainsaw_rev', k.x, k.y, 40 * M, { charge: this.charge }); m.audio?.play('rev', { charge: this.charge }); }
        if (!inp.rmb) { this.state = 'idle'; break; }
        if (this.charge >= 1) { this.state = 'sprint'; this.t = 0; this.dir = k.facing; this.lockFacing = true; m.events.emit(EV.POWER_USED, { killer: k, power: 'sprint' }); m.audio?.play('saw'); }
        if (this.heat >= 1) this.overheat(m);
        break;
      case 'sprint': {
        this.t += dt; this.heat += dt * this.heatRate;
        if (this.soundT <= 0) { this.soundT = 0.2; m.sound('chainsaw_sprint', k.x, k.y, 40 * M, { dir: this.dir }); }
        // limited steering toward aim
        const d = normAngle(inp.aim - this.dir); this.dir += clamp(d, -this.turnRate * dt, this.turnRate * dt);
        k.facing = this.dir;
        // survivor hit check: instant down
        for (const s of m.survivors) {
          if (!s.standing) continue;
          if (dist(s.x, s.y, k.x + Math.cos(this.dir) * 0.6 * M, k.y + Math.sin(this.dir) * 0.6 * M) < s.r + k.r + 0.25 * M) {
            if (s.dodgeT && s.dodgeT > m.time) continue;
            const res = s.takeHit(m, { instadown: true, source: 'chainsaw' }); k.stats.hits++; k.bloodlust = 0;
            m.events.emit(EV.KILLER_HIT, { killer: k, survivor: s, result: res, power: true }); m.fx.hit(s, res); m.fx.shake(10);
            this.state = 'recover'; this.t = 0; this.lockFacing = false; this.charge = 0; return;
          }
        }
        if (!inp.rmb || this.t > this.maxSprint) { this.state = 'recover'; this.t = 0; this.lockFacing = false; this.charge = 0; }
        if (this.heat >= 1) this.overheat(m);
        break;
      }
      case 'recover': this.t += dt; if (this.t > 1.4) this.state = 'idle'; break;
      case 'collide': this.t += dt; if (this.t > 2.5) this.state = 'idle'; break;
    }
  }
  onCollide(m) {
    if (this.state !== 'sprint') return;
    this.state = 'collide'; this.t = 0; this.lockFacing = false; this.charge = 0;
    m.fx.shake(14); m.fx.sparks(this.k.x + Math.cos(this.dir) * 20, this.k.y + Math.sin(this.dir) * 20); m.audio?.play('clang');
    m.events.emit(EV.POWER_USED, { killer: this.k, power: 'collide' });
  }
  overheat(m) { this.state = 'overheat'; this.overheatT = 12; this.lockFacing = false; this.charge = 0; m.fx.text(this.k.x, this.k.y - 40, 'OVERHEAT', '#ff8a4a'); }
  onStun() { this.state = 'idle'; this.charge = 0; this.lockFacing = false; }
  hud() {
    const label = { idle: 'Ready', revving: 'Revving', sprint: 'SPRINTING', recover: 'Recovering', collide: 'Collision!', overheat: 'Overheated' }[this.state];
    return { title: 'Chainsaw', value: this.state === 'overheat' ? Math.ceil(this.overheatT) + 's' : Math.round(this.heat * 100) + '° heat', meter: this.state === 'revving' ? this.charge : this.state === 'overheat' ? 1 - this.overheatT / 12 : 1 - this.heat, state: label,
      hot: this.heat, hints: [['Q / RMB', 'Hold to rev, keep holding to sprint'], ['Mouse', 'Steer the sprint']] };
  }
  prompt() { return null; }
}
