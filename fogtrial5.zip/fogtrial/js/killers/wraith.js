// THE WRAITH — Wailing Bell. Toggle cloak: while cloaked he is fast, undetectable and
// nearly invisible, but cannot attack. Cloaking and uncloaking ring a bell survivors can hear.
import { M } from '../core/util.js';
import { EV } from '../core/events.js';

export class WraithPower {
  constructor(killer, addons = []) {
    this.k = killer; this.id = 'cloak'; this.name = 'Wailing Bell';
    this.state = 'visible'; this.t = 0;
    const f = addons.includes('blind_warrior') ? 0.75 : 1;
    this.cloakTime = 1.5 * f; this.uncloakTime = 1.6 * f;
    this.bellRange = (addons.includes('bone_clapper') ? 12 : 24) * M;
    this.shadowDance = addons.includes('shadow_dance');
    this.aiProfile = { type: 'stealth', label: 'Cloaking', counter: ['react to the bell', 'watch for the shimmer', 'stay near tiles while repairing'] };
  }
  get cloaked() { return this.state === 'cloaked' || this.state === 'uncloaking'; }
  speedMult() {
    if (this.state === 'cloaked') return 6.0 / 4.6;
    if (this.state === 'cloaking') return 0.6;
    if (this.state === 'uncloaking') return 0.75;
    return 1;
  }
  canAttack() { return this.state === 'visible'; }
  canInteract() { return this.state === 'visible'; }
  update(dt, m, inp, locked) {
    if (this.state === 'cloaking') { this.t += dt; if (this.t >= this.cloakTime) { this.state = 'cloaked'; this.k.status.add('undetectable', { source: 'cloak' }); } }
    else if (this.state === 'uncloaking') { this.t += dt; if (this.t >= this.uncloakTime) {
      this.state = 'visible'; this.k.status.remove('undetectable', 'cloak');
      this.k.status.add('haste', { duration: this.shadowDance ? 1.5 : 0.8, value: this.shadowDance ? 0.2 : 0.12, source: 'uncloak' });
      m.events.emit(EV.POWER_USED, { killer: this.k, power: 'uncloaked' });
    } }
    if (locked) return;
    if (inp.rmbP && !this.k.carrying) {
      if (this.state === 'visible') { this.state = 'cloaking'; this.t = 0; this.bell(m, 'cloak'); }
      else if (this.state === 'cloaked') { this.state = 'uncloaking'; this.t = 0; this.bell(m, 'uncloak'); }
    }
  }
  bell(m, kind) {
    m.sound('wraith_bell', this.k.x, this.k.y, this.bellRange, { kind });
    m.audio?.play('bell');
    m.events.emit(EV.POWER_USED, { killer: this.k, power: kind });
  }
  onStun() { if (this.state !== 'visible') { this.state = 'visible'; this.k.status.remove('undetectable', 'cloak'); } }
  hud() {
    const label = { visible: 'Visible', cloaking: 'Cloaking…', cloaked: 'CLOAKED', uncloaking: 'Uncloaking…' }[this.state];
    const meter = this.state === 'cloaking' ? this.t / this.cloakTime : this.state === 'uncloaking' ? 1 - this.t / this.uncloakTime : this.state === 'cloaked' ? 1 : 0;
    return { title: 'Wailing Bell', value: label, meter, state: this.state === 'cloaked' ? 'Undetectable · cannot attack' : 'Press to cloak', hints: [['Q / RMB', 'Cloak / uncloak (rings bell)']] };
  }
  prompt() { return null; }
}
