// THE LICH (Vecna) — Vile Darkness: four spells, chosen with the mouse wheel, 1–4 or F,
// and cast with Q / RMB. Each spell has its own cooldown.
//  1 Flight of the Damned (30 s): five spectral entities sweep forward in a fan, passing
//    through walls; they injure survivors they touch — but not crouching survivors.
//  2 Fly (20 s): levitate for up to 5 s at 8 m/s over pallets and windows (not walls).
//    After landing he cannot attack for 2.75 s. Tap Q again to land early.
//  3 Mage Hand (35 s): an invisible hand grabs the pallet you aim at (7 m): a dropped
//    pallet is lifted back up; a standing pallet is held so it cannot be dropped for 4 s.
//  4 Dispelling Sphere (30 s): an invisible sphere rolls forward (9.75 → 6.5 m/s) through
//    walls; survivors it touches trigger Killer Instinct and their Magic Items are
//    disabled for 45 s.
// Magic Items come from six treasure chests and each counters one spell:
//    Skyguard (see him while he flies) · Nightwatch (see the damned through walls)
//    Archivist (see the sphere) · Interloper (warned of Mage Hand + haste).
import { M, dist, angleDiff, clamp } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, Projectile, Device, killerInstinct } from './framework.js';

export const SPELLS = [
  { id: 'fotd', name: 'Flight of the Damned', icon: '☠', cd: 30 },
  { id: 'fly', name: 'Fly', icon: '⇡', cd: 20 },
  { id: 'magehand', name: 'Mage Hand', icon: '✋', cd: 35 },
  { id: 'sphere', name: 'Dispelling Sphere', icon: '◉', cd: 30 },
];
export const MAGIC_ITEMS = {
  skyguard: { name: 'Boots of Skyguard', counters: 'fly' },
  nightwatch: { name: 'Gauntlets of Nightwatch', counters: 'fotd' },
  archivist: { name: 'Boots of the Archivist', counters: 'sphere' },
  interloper: { name: 'Gauntlets of the Interloper', counters: 'magehand' },
};

export class LichPower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'vecna'; this.name = 'Vile Darkness'; this.state = 'idle'; this.sel = 0; this.selectable = true;
    this.flyT = 0; this.sphere = null; this.hand = null; this.castLog = [];
    this.aiProfile = { type: 'spells', label: 'Four spells', counter: ['crouch against Flight of the Damned', 'do not rely on dropped pallets while Mage Hand is up', 'step out of the sphere\'s path', 'loot chests for Magic Items'] };
  }
  get spell() { return SPELLS[this.sel]; }
  ready(id) { return this.cd(id) <= 0; }
  onInit(m) {
    for (const p of m.map.openSpots(6, 16, m.map.gens)) m.addDevice(new Device({ kind: 'magic_chest', x: p.x, y: p.y, r: 0.6 * M, label: 'Treasure chest', useTime: 6, survivorUsable: true, seenRange: 18 * M, data: { opened: false } }));
    for (const d of m.devices) if (d.kind === 'magic_chest') {
      d.usable = (s) => !d.data.opened && !s.magic;
      d.onUse = (s, mm) => { d.data.opened = true; const ids = Object.keys(MAGIC_ITEMS); s.magic = ids[Math.floor(Math.random() * ids.length)]; s.ai?.note(`Found ${MAGIC_ITEMS[s.magic].name}`, 'magic'); mm.events.emit('magicItem', { survivor: s, item: s.magic }); };
    }
  }
  speedMult() { if (this.state === 'fly') return 8 / this.k.def.speed; if (this.state === 'casting') return 0.3; return 1; }
  canAttack() { return this.state === 'idle'; }
  noContext() { return this.state === 'fly'; }
  moveFilter() { return this.state === 'fly' ? (s) => s.kind !== 'pallet' && s.kind !== 'window' : null; }
  update(dt, m, inp, locked) {
    this.tickCooldowns(dt);
    const k = this.k;
    if (inp.slot) this.sel = inp.slot - 1;
    if (inp.wheel) this.sel = (this.sel + (inp.wheel > 0 ? 1 : 3)) % 4;
    if (inp.cycleP) this.sel = (this.sel + 1) % 4;
    if (this.state === 'fly') {
      this.flyT -= dt;
      if (this.flyT <= 0 || (inp.rmbP && this.flyT < 4.7) || locked) this.land(m);
      return;
    }
    if (this.state === 'casting') { this.castT -= dt; if (this.castT <= 0) { this.state = 'idle'; this.castFn?.(); this.castFn = null; } return; }
    if (locked || k.carrying) return;
    if (inp.rmbP && this.state === 'idle') {
      const sp = this.spell; if (!this.ready(sp.id)) { m.fx.text(k.x, k.y - 40, `${sp.name} — ${Math.ceil(this.cd(sp.id))}s`, '#888'); return; }
      this.cast(m, sp);
    }
  }
  cast(m, sp) {
    const k = this.k; this.setCd(sp.id, sp.cd);
    m.sound('lich_cast', k.x, k.y, 40 * M, { spell: sp.id, dir: k.facing });
    m.events.emit(EV.POWER_USED, { killer: k, power: sp.id });
    m.fx.ring(k.x, k.y, 'rgba(170,120,255,0.9)', 2 * M, 0.5);
    if (sp.id === 'fly') { this.state = 'fly'; this.flyT = this.has('pewter_wings') ? 6 : 5; m.audio?.play('teleport'); return; }
    this.state = 'casting'; this.castT = sp.id === 'magehand' ? 0.5 : 0.35;
    if (sp.id === 'fotd') this.castFn = () => this.flightOfTheDamned(m);
    if (sp.id === 'sphere') this.castFn = () => this.dispel(m);
    if (sp.id === 'magehand') { const p = this.handTarget(m); this.castFn = () => this.mageHand(m, p); if (!p) { this.setCd('magehand', 2); } }
  }
  land(m) {
    this.state = 'idle'; this.k.status.add('cannotAttack', { duration: 2.75, source: 'fly' }); m.world.resolve(this.k, this.k.r);
    m.fx.burst(this.k.x, this.k.y, 14, '#a878ff', 80, 0.5, 2, 2);
  }
  flightOfTheDamned(m) {
    const k = this.k;
    const n = this.has('ornate_horn') ? 6 : 5;
    for (let i = 0; i < n; i++) {
      const a = k.facing + (i - (n - 1) / 2) * 0.16; const sp = 7.5 * M;
      m.spawnProjectile(new Projectile({ kind: 'damned', owner: k, x: k.x + Math.cos(a) * k.r, y: k.y + Math.sin(a) * k.r, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, r: 0.35 * M, range: 22 * M, passWalls: true, pierce: true, color: '#c8b0ff',
        filter: (s) => s.moveMode !== 'crouch' || !!s.vault,
        onHit: (p, s, mm) => { if (s.dodgeT && s.dodgeT > mm.time) return; const res = s.takeHit(mm, { source: 'damned' }); k.stats.hits++; k.stats.powerHits++; mm.events.emit(EV.KILLER_HIT, { killer: k, survivor: s, result: res, power: true }); mm.fx.hit(s, res); if (res === 'downed') killerInstinct(mm, s, 5); s.ai?.note('Hit by Flight of the Damned', 'fotd'); mm.addScore('brutality', 300, 'Flight of the Damned'); p.dead = true; } }));
    }
    m.audio?.play('scream');
  }
  handTarget(m) {
    const k = this.k; let best = null, bs = Infinity;
    for (const p of m.map.pallets) {
      if (p.state === 'broken') continue; const d = dist(p.x, p.y, k.x, k.y); if (d > 7 * M) continue;
      const ang = angleDiff(Math.atan2(p.y - k.y, p.x - k.x), k.facing); if (ang > 0.8) continue;
      const sc = d + ang * 4 * M; if (sc < bs) { bs = sc; best = p; }
    }
    return best;
  }
  mageHand(m, p) {
    if (!p) return;
    if (p.state === 'down') {
      p.state = 'up'; m.world.remove(p.solid); p.respectCounted = false; m.fx.text(p.x, p.y - 26, 'LIFTED', '#c8b0ff');
      m.events.emit('mageHand', { pallet: p, lifted: true });
    } else if (p.state === 'up') {
      p.blockedUntil = m.time + 4; m.fx.text(p.x, p.y - 26, 'HELD', '#c8b0ff');
      m.events.emit('mageHand', { pallet: p, lifted: false });
    }
    this.hand = { p, t: m.time };
    for (const s of m.survivors) if (s.magic === 'interloper' && !s.status.has('dispelled') && dist(s.x, s.y, p.x, p.y) < 24 * M) { s.status.add('haste', { duration: 4, value: 0.1, source: 'interloper' }); s.ai?.note('Interloper: Mage Hand on a pallet nearby', 'interloper'); }
  }
  dispel(m) { const k = this.k; this.sphere = { x: k.x, y: k.y, dir: k.facing, t: 0, r: 3 * M, hit: new Set(), len: 0 }; }
  tick(dt, m) {
    const sp = this.sphere; if (!sp) return;
    sp.t += dt; const v = (sp.t < 1 ? 9.75 : 6.5) * M; sp.x += Math.cos(sp.dir) * v * dt; sp.y += Math.sin(sp.dir) * v * dt; sp.len += v * dt;
    for (const s of m.survivors) if (s.standing && !sp.hit.has(s) && dist(s.x, s.y, sp.x, sp.y) < sp.r) { sp.hit.add(s); killerInstinct(m, s, 3, 'Dispelling Sphere'); s.status.add('dispelled', { duration: 45 }); s.ai?.note('Caught by the Dispelling Sphere', 'sphere'); }
    if (sp.len > 34 * M || sp.x < 0 || sp.y < 0 || sp.x > m.map.w || sp.y > m.map.h) this.sphere = null;
  }
  alpha() { return this.state === 'fly' ? 0.85 : 1; }
  drawOver(ctx, m) {
    const k = this.k;
    if (this.sphere) { const s = this.sphere; ctx.strokeStyle = 'rgba(170,120,255,0.55)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2); ctx.stroke(); ctx.fillStyle = 'rgba(170,120,255,0.08)'; ctx.fill(); }
    if (this.state === 'fly') { ctx.strokeStyle = 'rgba(168,120,255,0.6)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(k.x, k.y, k.r + 6, 0, Math.PI * 2 * this.flyT / 5); ctx.stroke(); }
    if (this.spell.id === 'magehand' && this.state === 'idle' && this.ready('magehand')) { const p = this.handTarget(m); if (p) { ctx.strokeStyle = 'rgba(200,176,255,0.8)'; ctx.setLineDash([4, 4]); ctx.strokeRect(p.x - 18, p.y - 18, 36, 36); ctx.setLineDash([]); } }
    if (this.spell.id === 'fotd' && this.state === 'idle') { ctx.fillStyle = 'rgba(200,176,255,0.05)'; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.arc(k.x, k.y, 22 * M, k.facing - 0.32, k.facing + 0.32); ctx.closePath(); ctx.fill(); }
  }
  drawGround(ctx, m) {
    for (const p of m.map.pallets) if ((p.blockedUntil || 0) > m.time) { ctx.strokeStyle = 'rgba(200,176,255,0.7)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(p.x, p.y, 16, 0, Math.PI * 2); ctx.stroke(); }
  }
  drawDevice(ctx, d) {
    if (d.kind !== 'magic_chest') return;
    ctx.fillStyle = d.data.opened ? '#3a3020' : '#6a4a20'; ctx.fillRect(d.x - 13, d.y - 9, 26, 18); ctx.fillStyle = '#c8a040'; ctx.fillRect(d.x - 13, d.y - 2, 26, 3); if (!d.data.opened) { ctx.fillStyle = '#a878ff'; ctx.beginPath(); ctx.arc(d.x, d.y, 3, 0, Math.PI * 2); ctx.fill(); }
  }
  drawWeapon(ctx, m) { const k = this.k; ctx.fillStyle = this.state === 'casting' ? '#c8b0ff' : '#6a5aa0'; ctx.beginPath(); ctx.arc(k.r + 6, 7, 5, 0, Math.PI * 2); ctx.fill(); return true; }
  drawBody(ctx) { ctx.fillStyle = '#d8d0b8'; ctx.beginPath(); ctx.arc(5, 0, 5.5, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#c03a3a'; ctx.beginPath(); ctx.arc(8, -2, 1.3, 0, Math.PI * 2); ctx.fill(); }
  hud() {
    return { title: 'Vile Darkness', value: this.spell.name.split(' ').map((w) => w[0]).join(''), meter: this.ready(this.spell.id) ? 1 : 1 - this.cd(this.spell.id) / this.spell.cd,
      state: this.state === 'fly' ? `Flying ${this.flyT.toFixed(1)}s — Q to land` : `${this.spell.name}${this.ready(this.spell.id) ? '' : ` · ${Math.ceil(this.cd(this.spell.id))}s`}`,
      spells: SPELLS.map((q) => ({ name: q.name, icon: q.icon, cd: this.cd(q.id) })), sel: this.sel,
      hints: [['Wheel / 1-4 / F', 'Select spell'], ['Q / RMB', 'Cast the selected spell']] };
  }
}
