// Killer power profiles: a data description of every power — its abilities, cooldowns and
// charges, how survivors interact with it and which statuses it applies. The UI shows these
// in the loadout; the survivor AI's matching counter profile lives in ai/killerProfiles.js
// (joined here as aiCounterProfile by powerProfile()). Numbers mirror the power modules.
export const POWER_DATA = {
  trapper: {
    abilities: [{ key: 'Q/RMB', name: 'Set Bear Trap', desc: 'Set a trap in front of you; tall grass hides it.' }, { key: 'E', name: 'Pick up / reset', desc: 'Re-arm or collect a trap.' }],
    cooldowns: { carried: '2 traps (3 with Trapper Bag)', setTime: '2.5 s' },
    survivorInteractions: ['Step on a trap → trapped until escape attempts succeed', 'Disarm a seen trap', 'Teammates free trapped survivors'],
    statuses: [],
  },
  hillbilly: {
    abilities: [{ key: 'Q/RMB', name: 'Chainsaw', desc: 'Rev, then sprint; a hit downs instantly.' }],
    cooldowns: { rev: '~1.6 s', overheat: 'heat builds while revving; overheat locks the saw' },
    survivorInteractions: ['Break line of sight while he revs', 'Tight loops make him collide'],
    statuses: [],
  },
  wraith: {
    abilities: [{ key: 'Q/RMB', name: 'Wailing Bell', desc: 'Cloak (fast, undetectable, cannot attack); uncloak rings the bell.' }],
    cooldowns: { cloak: '~1.5 s', uncloak: '~1.5 s' },
    survivorInteractions: ['Hear the bell', 'Spot the shimmer up close'],
    statuses: ['undetectable'],
  },
  ghostface: {
    abilities: [{ key: 'RMB', name: 'Night Shroud', desc: 'Undetectable and hard to spot.' }, { key: 'Hold RMB', name: 'Stalk', desc: 'Stalk survivors in view to Mark them.' }, { key: 'E', name: 'Crouch', desc: 'Lower profile.' }],
    cooldowns: { reveal: '20 s after being revealed', marked: '35 s' },
    survivorInteractions: ['Stare at him for ~1.3 s within 14 m to reveal him', 'Break line of sight to deny stalk'],
    statuses: ['marked', 'exposed', 'undetectable'],
  },
  clown: {
    abilities: [{ key: 'Hold RMB', name: 'Afterpiece Tonic', desc: 'Lob a bottle; the gas slows and intoxicates.' }, { key: 'E', name: 'Antidote', desc: 'Switch to speed gas.' }],
    cooldowns: { bottles: '6', reload: '3.2 s', cloud: '8 s' },
    survivorInteractions: ['Leave the gas', 'Route around clouds on loops'],
    statuses: ['intoxicated', 'haste'],
  },
  executioner: {
    abilities: [{ key: 'RMB', name: 'Rites of Judgement', desc: 'Punishment mode: Torment Trails.' }, { key: 'LMB', name: 'Punishment of the Damned', desc: 'Ground wave through walls.' }, { key: 'SPACE', name: 'Cage of Atonement', desc: 'Cage a Tormented downed survivor.' }],
    cooldowns: { windup: '1.1 s', wave: '2.2 s', trail: '60 s' },
    survivorInteractions: ['Side-step the wave', 'Avoid trails', 'Rescue caged survivors'],
    statuses: ['tormented'],
  },
  singularity: {
    abilities: [
      { key: 'Hold & release RMB', name: 'Biopod', desc: 'Shoot a biopod (50 m/s, 22 m). It sticks to the first wall or obstacle; a survivor hit is Slipstreamed, or teleported to if already Slipstreamed.' },
      { key: 'E', name: 'Biopod control', desc: 'View through the pod nearest your aim (F / wheel: next pod). Hold the reticle on a survivor in 20 m for 0.8 s to Slipstream them.' },
      { key: 'LMB (in a pod)', name: 'Quantum Instantiation', desc: 'Locked on a Slipstreamed survivor: teleport to the pod, then Overclock for 5.7 s.' },
    ],
    cooldowns: { pods: '8 active (the 9th recycles the oldest)', reload: '0.5 s', lock: '0.8 s · 3 s between locks · 10× slower near hooks', overclock: '5.7 s: +3% speed, +75% kick/break/vault, pallet stun → pallet breaks + 3 s Overheat' },
    survivorInteractions: ['Print EMPs at the 4 printers (they fill to 97% by themselves)', 'An EMP (2.5 s to arm) clears Slipstream and disables pods in 10 m for 45 s', 'Slipstream spreads in 6 m after 2 s — spread out', 'Break pod sightlines; pallets still work after Overclock ends'],
    statuses: ['slipstream'],
  },
  huntress: {
    abilities: [{ key: 'Hold RMB', name: 'Hunting Hatchets', desc: 'Wind up and throw.' }, { key: 'E', name: 'Reload', desc: 'Restock at a locker.' }],
    cooldowns: { hatchets: '5', windup: '0.35–1.3 s', reload: '2.4 s' },
    survivorInteractions: ['Dodge thrown hatchets', 'Break line of sight', 'Use cover on long runs'],
    statuses: [],
  },
  legion: {
    abilities: [{ key: 'RMB', name: 'Feral Frenzy', desc: '5.2 m/s, fast vaults, survivors in the terror radius are revealed.' }, { key: 'LMB', name: 'Feral Slash', desc: 'Inflicts Deep Wound and refills the gauge; a miss ends Frenzy.' }],
    cooldowns: { frenzy: '~10 s', recharge: '~20 s', fatigue: '4 s' },
    survivorInteractions: ['Mend Deep Wound before it bleeds out (20 s)', 'Spread out to deny chains', 'Frenzy cannot down — only a Deep Wound bleed-out or a basic hit can'],
    statuses: ['deepWound', 'deepWoundFrenzy'],
  },
  hag: {
    abilities: [{ key: 'Hold RMB', name: 'Phantasm Trap', desc: 'Draw a trap on the ground (max 10).' }, { key: 'E', name: 'Teleport', desc: 'Teleport to a triggered trap within 40 m.' }],
    cooldowns: { draw: '1.5 s', teleportWindow: '4 s', maxTraps: '10' },
    survivorInteractions: ['Crouch through traps to avoid triggering them', 'Wipe known traps', 'Leave the area after triggering one'],
    statuses: [],
  },
  cannibal: {
    abilities: [
      { key: 'Hold RMB', name: 'Rev', desc: '2 s rev (slowed). Release a full rev to sweep; release early to cancel for free. Holding the rev 3 s = tantrum.' },
      { key: '(auto)', name: 'Chainsaw Sweep', desc: 'Costs 1 charge. Accelerates to 5.35 m/s over 2.5 s, downs everyone in the wide arc (multi-downs). Mouse steers slowly; press RMB again to stop.' },
      { key: 'LMB while sweeping', name: 'Dash', desc: 'Spend another charge: top speed instantly and more sweep time.' },
    ],
    cooldowns: { charges: '3, refilling 0.25/s while idle', hit: '2 s', miss: '1.5 s + 1 s per charge spent', pallet: '1 s (the sweep saws through dropped pallets)', tantrum: '3 s + 1 s per remaining charge, Hindered 90%, all charges lost, then 3 s' },
    survivorInteractions: ['Keep more than 6 m away when you hear the rev', 'Turn tight around walls so the sweep rams them (tantrum)', 'Windows: he cannot vault while sawing', 'Spread out — one sweep downs everyone it touches', 'Dropping a pallet ends the sweep'],
    statuses: ['hindered'],
  },
  deathslinger: {
    abilities: [{ key: 'Hold RMB', name: 'Aim', desc: 'Slower while aiming.' }, { key: 'LMB', name: 'Fire harpoon', desc: 'Projectile; a hit spears and reels the survivor in.' }],
    cooldowns: { range: '18 m', reload: '2 s', reel: 'up to 6 s' },
    survivorInteractions: ['Juke the aim', 'Break the chain on obstacles (Deep Wound)', 'Avoid open sightlines'],
    statuses: ['grabbed', 'deepWound'],
  },
  dredge: {
    abilities: [{ key: 'RMB', name: 'Gloaming', desc: 'Leave a Remnant and pick a locker.' }, { key: 'RMB again', name: 'Teleport', desc: 'Travel to the locker.' }, { key: 'LMB', name: 'Return', desc: 'Snap back to the Remnant.' }],
    cooldowns: { tokens: '3', teleport: '10 s (4 s in Nightfall)', nightfall: '60 s of darkness' },
    survivorInteractions: ['Lock lockers near objectives', 'Avoid lockers during Nightfall', 'Track the Remnant'],
    statuses: ['nightfall', 'undetectable'],
  },
  knight: {
    abilities: [{ key: 'RMB', name: 'Patrol Path', desc: 'Draw a path up to 30 m.' }, { key: 'RMB again', name: 'Summon Guard', desc: 'The guard patrols and hunts.' }, { key: 'E', name: 'Cycle Guard', desc: 'Carnifex · Assassin · Jailer.' }],
    cooldowns: { recharge: '8 s', carnifex: 'breaks pallets in 1.8 s', assassin: 'hunts at 4.4 m/s, Deep Wound', jailer: '24 s patrol, 16 m detection' },
    survivorInteractions: ['Grab the Standard to end a hunt', 'Outlast the hunt timer', 'Lead guards through pallets'],
    statuses: ['deepWound'],
  },
  cenobite: {
    abilities: [{ key: 'Hold RMB', name: 'Possessed Chain', desc: 'Steerable chain that binds survivors.' }, { key: 'E', name: 'Gateway / Summon', desc: 'Teleport to a survivor solving the box.' }],
    cooldowns: { chain: '5 s', chainHunt: 'after 90 s without a solve' },
    survivorInteractions: ['Break chains (or tear them on obstacles)', 'Pick up and solve the Lament Configuration', 'Solve where it is safe'],
    statuses: ['chained', 'oblivious'],
  },
  mastermind: {
    abilities: [{ key: 'Hold RMB', name: 'Virulent Bound', desc: 'Charge and leap at 14 m/s.' }, { key: 'RMB within 2 s', name: 'Second Bound', desc: 'Longer chained leap.' }],
    cooldowns: { tokens: '2', recharge: '5 s per token' },
    survivorInteractions: ['Stay out of dash lanes', 'Use First Aid Spray from supply cases to cure infection', 'Grabbed survivors are slammed into walls'],
    statuses: ['infected', 'grabbed', 'hindered'],
  },
  houndmaster: {
    abilities: [{ key: 'Hold RMB', name: 'Chase Command', desc: 'Plot a line and send the dog; it grabs survivors and drags them to you.' }, { key: 'E', name: 'Search Command', desc: 'Send the dog to search an area.' }],
    cooldowns: { dog: '3 s', drag: 'up to 8 s' },
    survivorInteractions: ['Drop a pallet on the dog (stun)', 'Break line of sight from the dog', 'Track the dog separately'],
    statuses: ['grabbed', 'hindered', 'incapacitated'],
  },
  lich: {
    abilities: [{ key: 'Wheel/1-4', name: 'Select spell', desc: 'Choose one of four spells.' }, { key: 'RMB', name: 'Flight of the Damned', desc: 'Five flying entities; crouch to avoid.' }, { key: 'RMB', name: 'Fly', desc: 'Fly over pallets and windows; no attack for 2.75 s after.' }, { key: 'RMB', name: 'Mage Hand', desc: 'Lift a dropped pallet or block a standing one.' }, { key: 'RMB', name: 'Dispelling Sphere', desc: 'Slow orb that reveals and dispels Magic Items.' }],
    cooldowns: { flightOfTheDamned: '30 s', fly: '20 s', mageHand: '35 s', dispellingSphere: '30 s' },
    survivorInteractions: ['Crouch under Flight of the Damned', 'Loot Magic Items that counter each spell', 'Watch which spell is held'],
    statuses: ['dispelled', 'cannotAttack'],
  },
  skull_merchant: {
    abilities: [{ key: 'Hold RMB', name: 'Deploy drone', desc: 'Place a drone ≤10 m ahead (7 s cooldown, 6 max). Its scan line sweeps a 10 m zone at 105°/s.' }, { key: 'E', name: 'Recall', desc: 'Recall the drone nearest your aim (1 s): Undetectable 8 s.' }],
    cooldowns: { deploy: '7 s', lockOn: '3 stacks → injure / Deep Wound + Broken + Claw Trap (45 s)', hack: 'disables a drone 45 s' },
    survivorInteractions: ['Crouch or stand still as the scan line passes', 'Hack drones (3 s) — removes your claw trap', 'A botched hack adds a lock-on'],
    statuses: ['lockOn', 'clawTrap', 'broken', 'hindered'],
  },
  blight: {
    abilities: [{ key: 'RMB', name: 'Blighted Rush', desc: '9.2 m/s for up to 3 s (1 token). Slow turning.' }, { key: 'RMB after a slam', name: 'Lethal Rush', desc: 'Chain within 1.25 s of a head-on slam (≥45°).' }, { key: 'LMB', name: 'Special attack', desc: 'Lunge out of a lethal rush.' }],
    cooldowns: { tokens: '5, one per 2 s', fatigue: '2.5 s when the chain ends', pallet: 'a lethal rush smashes dropped pallets (3 tokens)' },
    survivorInteractions: ['Side-step late — he turns slowly', 'Loops with tall walls force slams', 'Punish fatigue'],
    statuses: [],
  },
  nurse: {
    abilities: [{ key: 'Hold RMB', name: 'Blink', desc: 'Charge 2 s: 1.5–20 m straight ahead through walls.' }, { key: 'RMB in the chain window', name: 'Chain blink', desc: 'Second blink, up to 12 m (1.5 s window).' }, { key: 'LMB', name: 'Blink attack', desc: 'Attack out of a blink.' }],
    cooldowns: { tokens: '2, 3 s recharge each', fatigue: '2 s (1 blink) / 2.5 s (2 blinks), +1 s after an attack' },
    survivorInteractions: ['Change direction when her charge sound stops', 'Double back behind walls', 'Windows/pallets do little — she ignores them', 'Run during her fatigue'],
    statuses: [],
  },
  unknown: {
    abilities: [{ key: 'Hold RMB', name: 'UVX', desc: '1 s charge; bouncing shot, 2.25 m burst. Weakens, hurts the Weakened.' }, { key: 'E', name: 'Hallucination', desc: 'Leave a hallucination (max 4).' }, { key: 'F', name: 'Teleport', desc: 'Teleport to a hallucination (25 s cooldown).' }],
    cooldowns: { uvx: '1.5 s', teleport: '25 s' },
    survivorInteractions: ['Look at him 10 s (≤25 m) to clear Weakened', 'Dispel hallucinations by staring 4 s (≤12 m)', 'Walking into one: Weakened + revealed'],
    statuses: ['weakened'],
  },
  nemesis: {
    abilities: [{ key: 'Hold RMB', name: 'Tentacle Strike', desc: '0.35 s charge: 5 m line (6.5 m at MR 3). MR 2+ smashes dropped pallets.' }, { key: '—', name: 'Zombies', desc: 'Two zombies roam; they injure and contaminate on sight.' }],
    cooldowns: { tentacle: '1.2 s', mutation: 'MR 2 at 1 point, MR 3 at 3 points (+1 contamination, +0.5 zombie kill)', zombie: 'respawn 15 s' },
    survivorInteractions: ['Stay out of tentacle range', 'Take a vaccine (1 s) and inject (3 s, Q)', 'Avoid zombie sight cones; stun them with pallets'],
    statuses: ['contaminated'],
  },
  ghoul: {
    abilities: [{ key: 'RMB', name: 'Kagune Leap', desc: '14 m leap. Latch onto a survivor or cling to a wall, then leap again.' }, { key: 'RMB while latched', name: 'Grab attack', desc: 'Injure + Deep Wound + Kagune Mark (40 s).' }],
    cooldowns: { tokens: '2 (4 s) · Enraged: 3 (2.5 s)', latch: '2 s window', cling: '1.5 s window' },
    survivorInteractions: ['Mend to clear the Kagune Mark', 'Tight corners beat straight leaps', 'Break away fast after a latch'],
    statuses: ['latched', 'kaguneMark', 'deepWound'],
  },
};

export function powerProfile(def, counterProfiles = {}) {
  const d = POWER_DATA[def.id] || { abilities: [], cooldowns: {}, survivorInteractions: [], statuses: [] };
  const cp = counterProfiles[def.id];
  return { id: def.id, power: { name: def.power, ...d, aiCounterProfile: cp ? { strengths: cp.strengths, weaknesses: cp.weaknesses, avoid: cp.avoid, exploit: cp.exploit, knobs: cp.knobs } : null } };
}
