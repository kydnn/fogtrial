// THE MASTERMIND — Virulent Bound. Hold RMB to charge (1.5 s, slowed), release to bound
// forward at 14 m/s. With a second token you can bound again within 2 s of the first,
// further (1 s). A bound that hits a survivor infects them with Uroboros (+20) and grabs
// them: he carries them through the rest of the bound and throws them. Slamming the
// survivor into a wall or rock while carrying (or when thrown) injures them. A fully
// infected survivor is Hindered, and a bound into them deals double damage (downs).
// Infection grows slowly on its own. Six supply cases hold First Aid Sprays that cure it
// (using one makes the survivor scream for 4 s of Killer Instinct).
import { M, dist, clamp } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, Device, killerInstinct } from './framework.js';

export class MastermindPower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'virulent'; this.name = 'Virulent Bound'; this.state = 'idle'; this.tokens = 2; this.maxTokens = 2;
    this.charge = 0; this.chargeTime = this.has('cell_divider') ? 1.25 : 1.5; this.boundSpeed = 14 * M; this.chainWin = 0; this.held = null; this.tokenT = 0;
    this.aiProfile = { type: 'dash', label: 'Virulent Bound', counter: ['stay out of straight dash lanes', 'hug obstacles and windows', 'cure infection with sprays'] };
  }
  speedMult() {
    if (this.state === 'charging') return 3.68 / this.k.def.speed;
    if (this.state === 'bound') return this.boundSpeed / (this.k.def.speed * M);
    if (this.state === 'recover') return 0.35;
    return 1;
  }
  canAttack() { return this.state === 'idle'; }
  noContext() { return this.state === 'bound' || this.state === 'charging'; }
  overrideMove() { return this.state === 'bound' ? { x: Math.cos(this.dir), y: Math.sin(this.dir) } : null; }
  onInit(m) {
    for (const p of m.map.openSpots(6, 18, m.map.gens)) m.addDevice(new Device({ kind: 'supply', x: p.x, y: p.y, r: 0.6 * M, label: 'Supply case', useTime: 1.2, survivorUsable: true, seenRange: 20 * M, data: { sprays: 2 },
      usable: (s, mm) => true, onUse: () => {} }));
    for (const d of m.devices) if (d.kind === 'supply') { d.usable = (s) => d.data.sprays > 0 && (s.sprays || 0) < 1; d.onUse = (s, mm) => { d.data.sprays--; s.sprays = (s.sprays || 0) + 1; s.ai?.note('Took a First Aid Spray', 'spray'); }; }
  }
  update(dt, m, inp, locked) {
    this.tickCooldowns(dt);
    const k = this.k;
    if (this.tokens < this.maxTokens && this.state === 'idle') { this.tokenT += dt; if (this.tokenT > 5) { this.tokenT = 0; this.tokens++; } }
    if (this.state === 'bound') return this.updateBound(dt, m);
    if (this.state === 'recover') { this.t += dt; if (this.t > 1.1) this.state = 'idle'; return; }
    if (this.chainWin > 0) this.chainWin -= dt;
    if (locked) { if (this.state === 'charging') this.state = 'idle'; return; }
    const canStart = this.tokens > 0 && !k.carrying && (this.state === 'idle' || this.state === 'between');
    if (canStart && inp.rmb && this.state === 'idle') { this.state = 'charging'; this.charge = 0; this.second = false; m.sound('power_windup', k.x, k.y, 24 * M, { what: 'bound', dir: k.facing }); }
    if (this.state === 'between') {
      if (this.chainWin <= 0) { this.state = 'recover'; this.t = 0; return; }
      if (inp.rmbP && this.tokens > 0) this.startBound(m, 1.0, true);
      return;
    }
    if (this.state === 'charging') {
      this.charge += dt / this.chargeTime;
      if (!inp.rmb) { if (this.charge >= 1) this.startBound(m, 0.5, false); else this.state = 'idle'; }
    }
  }
  startBound(m, dur, second) {
    const k = this.k; this.tokens--; this.state = 'bound'; this.dir = k.facing; this.boundT = dur; this.second = second; this.lockFacing = true; this.hitThisBound = false;
    m.audio?.play('swing'); m.fx.shake(4); m.events.emit(EV.POWER_USED, { killer: k, power: 'bound', second });
    m.sound('killer_action', k.x, k.y, 24 * M, { what: 'bound' });
  }
  updateBound(dt, m) {
    const k = this.k; this.boundT -= dt; k.facing = this.dir;
    if (this.held) { const s = this.held; s.x = k.x + Math.cos(this.dir) * (k.r + s.r); s.y = k.y + Math.sin(this.dir) * (k.r + s.r); }
    else for (const s of m.survivors) {
      if (!s.standing || s.vault) continue;
      if (dist(s.x, s.y, k.x + Math.cos(this.dir) * k.r, k.y + Math.sin(this.dir) * k.r) > s.r + k.r * 0.8 + 0.2 * M) continue;
      if (!m.world.losClear(k.x, k.y, s.x, s.y)) continue;
      if (s.dodgeT && s.dodgeT > m.time) { m.fx.text(s.x, s.y - 30, 'DODGED', '#ffd27a'); continue; }
      this.collide(m, s); break;
    }
    if (this.boundT <= 0) this.endBound(m);
  }
  infect(m, s, n) {
    const st = s.status.get('infected'); const v = Math.min(100, (st?.value ?? 0) + n);
    s.status.add('infected', { value: v, source: 'uroboros' }); const c = s.status.get('infected'); c.value = v; c.expiration = Infinity;
  }
  collide(m, s) {
    const k = this.k; this.hitThisBound = true;
    const crit = (s.status.get('infected')?.value ?? 0) >= 100;
    this.infect(m, s, 20); m.addScore('brutality', 300, 'Virulent Bound'); k.stats.powerHits++;
    if (crit || s.health === 'injured') {
      // infected & injured, or critically infected: the bound itself downs them
      const res = s.takeHit(m, { source: 'bound', instadown: crit }); k.stats.hits++;
      m.events.emit(EV.KILLER_HIT, { killer: k, survivor: s, result: res, power: true }); m.fx.hit(s, res);
      this.state = 'recover'; this.t = 0; this.lockFacing = false; return;
    }
    if (s.action) {
      // interacting survivors are not grabbed — they take the hit where they stand
      const res = s.takeHit(m, { source: 'bound' }); k.stats.hits++; m.events.emit(EV.KILLER_HIT, { killer: k, survivor: s, result: res, power: true }); m.fx.hit(s, res);
      this.state = 'recover'; this.t = 0; this.lockFacing = false; return;
    }
    // grab and carry
    this.held = s; s.stopAction(m); s.status.add('grabbed', { source: 'wesker' }); m.events.emit('powerTriggered', { survivor: s, x: s.x, y: s.y }); 
    const self = this; s.control = { kind: 'wesker', allow: [], update: () => self.held === s || self.thrown?.s === s };
    m.fx.burst(s.x, s.y, 10, '#7fae3a', 60, 0.4, 2, 2); s.ai?.note('Grabbed by the Mastermind', 'wesker');
    this.boundT = Math.max(this.boundT, 0.35);
  }
  onCollide(m) {
    if (this.state !== 'bound') return;
    if (this.held) this.slam(m, this.held, 'wall'); else this.endBound(m, true);
  }
  slam(m, s, why) {
    const k = this.k; this.held = null; this.release(m, s);
    const res = s.takeHit(m, { source: 'bound' }); k.stats.hits++;
    if (res === 'injured') s.status.add('deepWound', { duration: 20 });
    m.events.emit(EV.KILLER_HIT, { killer: k, survivor: s, result: res, power: true }); m.fx.hit(s, res); m.fx.shake(10); m.audio?.play('clang');
    s.ai?.note('Slammed into a wall by the Mastermind', 'slam');
    this.state = 'recover'; this.t = 0; this.lockFacing = false;
  }
  release(m, s) { s.status.remove('grabbed', 'wesker'); if (s.control?.kind === 'wesker') s.control = null; }
  endBound(m, hitWall = false) {
    const k = this.k; this.lockFacing = false;
    if (this.held) {
      // throw: the survivor flies 3 m forward; hitting something on the way hurts
      const s = this.held; this.held = null; this.release(m, s);
      const tx = s.x + Math.cos(this.dir) * 3 * M, ty = s.y + Math.sin(this.dir) * 3 * M;
      if (!m.world.sweepClear(s.x, s.y, tx, ty, s.r)) { this.slam(m, s, 'throw'); return; }
      s.x = tx; s.y = ty; m.world.resolve(s, s.r);
      // being grabbed and thrown costs a health state (like DBD), a wall slam adds Deep Wound
      const res = s.takeHit(m, { source: 'bound' }); k.stats.hits++; m.events.emit(EV.KILLER_HIT, { killer: k, survivor: s, result: res, power: true }); m.fx.hit(s, res);
      if (res === 'injured') s.status.add('haste', { duration: 1.5, value: 0.2, source: 'thrown' });
      m.fx.text(s.x, s.y - 30, 'THROWN', '#9fd06a'); this.state = 'recover'; this.t = 0; return;
    }
    if (!this.second && !this.hitThisBound && this.tokens > 0 && !hitWall) { this.state = 'between'; this.chainWin = 2; return; }
    this.state = 'recover'; this.t = 0;
  }
  // infection creep and the supply-case sprays
  tick(dt, m) {
    for (const s of m.survivors) {
      const st = s.status.get('infected'); if (!st) continue;
      if (s.health === 'hooked') { st.value = 1; continue; }
      if (s.standing && st.value < 100) st.value = Math.min(100, st.value + dt * 0.8);
    }
  }
  onSpray(s, m) { killerInstinct(m, s, 4, 'First Aid Spray'); s.ai?.note('Cured the infection with a spray', 'cure'); }
  onStun(m) { if (this.held) { const s = this.held; this.held = null; this.release(m, s); } this.state = 'idle'; this.lockFacing = false; }
  drawDevice(ctx, d) {
    if (d.kind !== 'supply') return;
    ctx.fillStyle = '#2a3a4a'; ctx.fillRect(d.x - 12, d.y - 8, 24, 16); ctx.fillStyle = d.data.sprays ? '#7fd0a0' : '#445'; ctx.fillRect(d.x - 3, d.y - 6, 6, 12); ctx.fillRect(d.x - 6, d.y - 3, 12, 6);
  }
  drawOver(ctx) {
    const k = this.k;
    if (this.state === 'charging' || this.state === 'between') { const len = (this.state === 'between' ? 14 : 7) * M; ctx.fillStyle = `rgba(127,174,58,${this.state === 'charging' ? 0.08 + 0.18 * Math.min(1, this.charge) : 0.22})`; ctx.save(); ctx.translate(k.x, k.y); ctx.rotate(k.facing); ctx.fillRect(0, -0.6 * M, len, 1.2 * M); ctx.restore(); }
  }
  drawWeapon(ctx) { const k = this.k; ctx.fillStyle = '#1a1a1a'; ctx.beginPath(); ctx.arc(k.r + 4, 6, 5, 0, Math.PI * 2); ctx.fill(); return true; }
  drawBody(ctx) { ctx.fillStyle = '#e8d8a0'; ctx.fillRect(2, -6, 6, 12); ctx.fillStyle = '#111'; ctx.fillRect(7, -5, 3, 10); }
  hud() {
    const st = { idle: 'Ready', charging: this.charge >= 1 ? 'Release to bound' : 'Charging…', bound: 'BOUND', between: 'Q again: second bound', recover: 'Recovering' }[this.state];
    return { title: 'Virulent Bound', value: `${this.tokens}/${this.maxTokens}`, meter: this.state === 'charging' ? Math.min(1, this.charge) : this.tokens / this.maxTokens, state: st,
      hints: [['Q / RMB', 'Hold to charge, release to bound'], ['Q / RMB', 'Within 2 s: second, longer bound']] };
  }
}
