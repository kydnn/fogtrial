// THE UNKNOWN — UVX (adapted to top-down).
//  • Hold RMB to charge a UVX shot (1 s, slowed), release to fire. The ball speeds up from
//    25 to 50 m/s, BOUNCES once off walls and bursts (2.25 m) on a survivor, on its second
//    wall hit or at the end of its 24 m flight.
//  • A survivor caught in the burst becomes WEAKENED; a Weakened survivor caught again takes
//    a health state. Weakened wears off by LOOKING at the Unknown (within 25 m, line of sight)
//    for 10 s in total.
//  • E leaves a HALLUCINATION where he stands (max 4; the oldest fades). Survivors DISPEL one
//    by looking at it from within 12 m for 4 s. Walking within 3 m of one undispelled is a
//    failure: Weakened and revealed for 3 s.
//  • F (cycle) TELEPORTS to the hallucination nearest your aim (1.5 s, 25 s cooldown).
import { M, dist, angleDiff, clamp } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, Device, Projectile, strike } from './framework.js';

const BLAST = 2.25 * M, CHARGE = 1, RANGE = 24 * M, LOOK_R = 25 * M, HAL_MAX = 4, TP_CD = 25;
export class UnknownPower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'uvx'; this.name = 'UVX'; this.state = 'idle'; this.charge = 0; this.tpT = 0;
    this.aiProfile = { type: 'projectile', label: 'UVX & hallucinations', counter: ['side-step the UVX (it bounces off walls)', 'look at him to shake off Weakened', 'dispel hallucinations near objectives', 'don\'t stack up — the burst hits everyone near'] };
  }
  get hallucinations() { return this._m ? this._m.devices.filter((d) => d.kind === 'hallucination' && d.owner === this.k) : []; }
  speedMult() { return this.state === 'charging' ? 0.6 : this.state === 'teleporting' ? 0 : this.state === 'recover' ? 0.5 : 1; }
  canAttack() { return this.state === 'idle'; }
  onInit(m) { this._m = m; }
  update(dt, m, inp, locked) {
    this._m = m; this.tickCooldowns(dt);
    const k = this.k;
    if (this.state === 'teleporting') { this.tpT -= dt; if (this.tpT <= 0) this.finishTeleport(m); return; }
    if (this.state === 'recover') { this.recT -= dt; if (this.recT <= 0) this.state = 'idle'; }
    if (locked) { if (this.state === 'charging') this.state = 'idle'; return; }
    if (this.state === 'idle') {
      if (inp.rmb && !k.carrying && this.cd('uvx') <= 0) { this.state = 'charging'; this.charge = 0; m.sound('power_windup', k.x, k.y, 22 * M, { what: 'uvx', dir: k.facing }); }
      else if (inp.eP && !k.carrying && this.cd('hal') <= 0) this.placeHallucination(m, k.x, k.y);
      else if (inp.cycleP && !k.carrying && this.cd('tp') <= 0 && this.hallucinations.length) this.startTeleport(m, inp);
    }
    if (this.state === 'charging') {
      this.charge += dt / CHARGE;
      if (!inp.rmb) { if (this.charge >= 1) this.fire(m); else this.state = 'idle'; }
    }
  }
  fire(m) {
    const k = this.k; this.state = 'recover'; this.recT = 0.6; this.setCd('uvx', 1.5);
    const a = k.facing; this.launch(m, k.x + Math.cos(a) * k.r, k.y + Math.sin(a) * k.r, a, RANGE, 0);
    m.audio?.play('throw'); m.events.emit(EV.POWER_USED, { killer: k, power: 'uvx' });
  }
  launch(m, x, y, a, range, bounces) {
    const sp = bounces ? 50 * M : 25 * M;
    const p = m.spawnProjectile(new Projectile({
      kind: 'uvx', owner: this.k, x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, r: 0.2 * M, range, color: '#b0ff80', data: { bounces },
      onHit: (pr, s, mm) => this.burst(mm, pr.x, pr.y),
      onEnd: (pr, mm) => this.burst(mm, pr.x, pr.y),
      onWall: (pr, mm) => {
        if (pr.data.bounces >= 1) { this.burst(mm, pr.x, pr.y); return; }
        // reflect off the face we hit
        const h = mm.world.firstHit(pr.x - pr.vx / 60, pr.y - pr.vy / 60, pr.x + pr.vx / 60, pr.y + pr.vy / 60, pr.r);
        let vx = pr.vx, vy = pr.vy;
        if (h) { const s = h.solid; const px = pr.x, py = pr.y; const side = px <= s.x + 1 || px >= s.x + s.w - 1; if (side) vx = -vx; else vy = -vy; } else { vx = -vx; vy = -vy; }
        const na = Math.atan2(vy, vx); this.launch(mm, pr.x + Math.cos(na) * 2, pr.y + Math.sin(na) * 2, na, Math.max(4 * M, range - pr.traveled), 1);
        mm.fx.sparks(pr.x, pr.y);
      },
    }));
    // accelerate 25 → 50 m/s over the flight
    const up = p.update.bind(p); p.update = (dt, mm) => { const v = Math.hypot(p.vx, p.vy), nv = Math.min(50 * M, v + 30 * M * dt); p.vx *= nv / v; p.vy *= nv / v; up(dt, mm); };
    return p;
  }
  burst(m, x, y) {
    m.fx.ring(x, y, 'rgba(176,255,128,0.9)', BLAST, 0.5); m.fx.burst(x, y, 24, '#b0ff80', 120, 0.6, 2, 3); m.audio?.play('clang');
    m.sound('killer_action', x, y, 20 * M, { what: 'uvx_burst' });
    for (const s of m.survivors) {
      if (!s.standing || dist(s.x, s.y, x, y) > BLAST + s.r || !m.world.losClear(x, y, s.x, s.y)) continue;
      if (s.status.has('weakened')) { const r = strike(m, this.k, s, { source: 'uvx', score: 'brutality', label: 'UVX' }); if (r && r !== 'dodged') { s.status.remove('weakened'); s.ai?.note('UVX burst while Weakened: hurt', 'uvxhit'); } }
      else { this.weaken(m, s, 'UVX burst'); }
    }
  }
  weaken(m, s, why) {
    s.status.add('weakened', { duration: 999, source: 'uvx' }); s._lookT = 0; this.k.stats.powerHits++; m.addScore('deviousness', 200, 'Weakened');
    s.ai?.note(`Weakened (${why})`, 'weak'); m.warn(s, 'Weakened — look at the Unknown to recover'); m.events.emit('powerTriggered', { survivor: s, x: s.x, y: s.y, killer: this.k });
  }
  placeHallucination(m, x, y) {
    const hs = this.hallucinations; if (hs.length >= HAL_MAX) m.removeDevice(hs[0]);
    m.addDevice(new Device({ kind: 'hallucination', x, y, r: 0.5 * M, owner: this.k, label: 'Hallucination', seenRange: 20 * M, dangerRadius: 3.5 * M, aiCost: 3, data: { placedT: m.time, gaze: new Map() } }));
    this.setCd('hal', 2); m.fx.burst(x, y, 12, '#9a8ab0', 60, 0.6, 2, 2);
    m.events.emit(EV.POWER_USED, { killer: this.k, power: 'hallucination' });
  }
  startTeleport(m, inp) {
    const k = this.k, ax = k.x + Math.cos(k.facing) * (inp.aimDist ?? 20 * M), ay = k.y + Math.sin(k.facing) * (inp.aimDist ?? 20 * M);
    const h = this.hallucinations.slice().sort((a, b) => dist(a.x, a.y, ax, ay) - dist(b.x, b.y, ax, ay))[0];
    this.tpTo = h; this.state = 'teleporting'; this.tpT = 1.5;
    m.sound('teleport_warn', h.x, h.y, 22 * M, { killer: k, what: 'unknown_tp' });
  }
  finishTeleport(m) {
    const k = this.k, h = this.tpTo; this.state = 'idle'; this.setCd('tp', TP_CD);
    if (!h || h.dead) return;
    m.fx.burst(k.x, k.y, 20, '#9a8ab0', 120, 0.5, 2, 2); k.x = h.x; k.y = h.y; m.world.resolve(k, k.r); m.removeDevice(h);
    m.fx.burst(k.x, k.y, 30, '#9a8ab0', 180, 0.6, 2, 3); m.audio?.play('teleport');
    m.events.emit(EV.POWER_USED, { killer: k, power: 'teleport' });
  }
  // gaze mechanics (always running): looking at him clears Weakened; looking at hallucinations dispels
  tick(dt, m) {
    const k = this.k;
    for (const s of m.survivors) {
      if (!s.standing) continue;
      const face = s.isPlayer && s.lookTarget ? Math.atan2(s.lookTarget.y - s.y, s.lookTarget.x - s.x) : s.facing;
      if (s.status.has('weakened')) {
        if (dist(s.x, s.y, k.x, k.y) < LOOK_R && angleDiff(face, Math.atan2(k.y - s.y, k.x - s.x)) < 0.6 && m.world.losClear(s.x, s.y, k.x, k.y)) {
          s._lookT = (s._lookT || 0) + dt; if (s._lookT >= 10) { s.status.remove('weakened'); s._lookT = 0; s.ai?.note('Stared down the Unknown — no longer Weakened', 'unweak'); m.warn(s, 'No longer Weakened'); }
        }
      }
      for (const h of this.hallucinations) {
        const d = dist(s.x, s.y, h.x, h.y); if (d > 12 * M) { h.data.gaze.delete(s); continue; }
        if (d < 3 * M && !h.dead) { // walked into it undispelled
          m.removeDevice(h); if (!s.status.has('weakened')) this.weaken(m, s, 'hallucination'); m.reveal(s, 3, 'Hallucination');
          m.notifyK(`${s.name} walked into a hallucination`, '#9a8ab0'); continue;
        }
        if (angleDiff(face, Math.atan2(h.y - s.y, h.x - s.x)) < 0.45 && m.world.losClear(s.x, s.y, h.x, h.y)) {
          const t = (h.data.gaze.get(s) || 0) + dt; h.data.gaze.set(s, t);
          if (t >= 4) { m.removeDevice(h); m.fx.burst(h.x, h.y, 14, '#d8d0ff', 80, 0.5, 2, 2); s.ai?.note('Dispelled a hallucination', 'dispel'); m.notifyK(`${s.name} dispelled a hallucination`, '#9a8ab0'); }
        }
      }
    }
  }
  drawDevice(ctx, d, m) {
    if (d.kind !== 'hallucination' || d.owner !== this.k) return;
    const t = m.time * 3 + d.x; ctx.globalAlpha = 0.55 + 0.15 * Math.sin(t);
    ctx.fillStyle = '#5a4a6a'; ctx.beginPath(); ctx.arc(d.x, d.y, 0.55 * M, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#b0a0d0'; ctx.beginPath(); ctx.arc(d.x + 5, d.y - 3, 4, 0, Math.PI * 2); ctx.fill(); ctx.globalAlpha = 1;
    const g = [...d.data.gaze.values()].reduce((a, b) => Math.max(a, b), 0);
    if (g > 0) { ctx.strokeStyle = '#d8d0ff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(d.x, d.y, 0.8 * M, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * g / 4); ctx.stroke(); }
  }
  drawOver(ctx, m) {
    const k = this.k;
    if (this.state === 'charging') { ctx.strokeStyle = 'rgba(176,255,128,0.5)'; ctx.setLineDash([5, 6]); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.lineTo(k.x + Math.cos(k.facing) * 10 * M, k.y + Math.sin(k.facing) * 10 * M); ctx.stroke(); ctx.setLineDash([]);
      ctx.strokeStyle = '#b0ff80'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(k.x, k.y, k.r + 8, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * Math.min(1, this.charge)); ctx.stroke(); }
    if (this.state === 'teleporting' && this.tpTo) { ctx.strokeStyle = 'rgba(154,138,176,0.7)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.lineTo(this.tpTo.x, this.tpTo.y); ctx.stroke(); }
  }
  drawBody(ctx) { ctx.fillStyle = '#4a3a5a'; ctx.beginPath(); ctx.ellipse(4, 0, 9, 6, 0, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#e8e0f0'; ctx.beginPath(); ctx.arc(9, -2, 2, 0, Math.PI * 2); ctx.arc(9, 3, 1.6, 0, Math.PI * 2); ctx.fill(); }
  hud(m) {
    const weak = m ? m.survivors.filter((s) => s.standing && s.status.has('weakened')).length : 0;
    return { title: 'UVX', value: `${this.hallucinations.length}/${HAL_MAX} 👁`, meter: this.state === 'charging' ? Math.min(1, this.charge) : 1 - this.cd('tp') / TP_CD,
      state: this.state === 'teleporting' ? 'Teleporting…' : `${weak} Weakened · teleport ${this.cd('tp') > 0 ? Math.ceil(this.cd('tp')) + 's' : 'ready'}`,
      hints: [['Q / RMB', 'Hold 1 s, release: fire UVX (bounces once)'], ['E', 'Leave a hallucination here'], ['F', 'Teleport to the hallucination nearest your aim']] };
  }
}
