// THE LEGION — Feral Frenzy. With a full power gauge, RMB starts a Frenzy: much faster,
// fast vaults over windows AND dropped pallets, and LMB becomes a quick Frenzy slash.
// A Frenzy hit injures a healthy survivor and always inflicts Deep Wound, but never downs —
// on an already injured survivor it eats into their Deep Wound timer instead. Every hit
// refills the gauge and reveals other survivors in the terror radius (Killer Instinct),
// so the Legion chains from survivor to survivor; the same survivor cannot be hit twice
// in a row. A miss, or the gauge running dry, ends the Frenzy in Fatigue.
import { M, dist, angleDiff } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, killerInstinct } from './framework.js';

export class LegionPower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'frenzy'; this.name = 'Feral Frenzy'; this.state = 'ready';
    this.gauge = 1; this.lastHit = null; this.slashT = 0; this.fatigueT = 0;
    this.frenzySpeed = (this.has('stab_wounds') ? 5.4 : 5.2) * M;
    this.drain = this.has('mural_sketch') ? 0.085 : 0.1;          // gauge per second in Frenzy (~10 s)
    this.recharge = this.has('never_sleep') ? 1 / 16 : 1 / 20;   // gauge per second while recharging
    this.fatigueTime = this.has('cold_dirt') ? 3.2 : 4;
    this.aiProfile = { type: 'frenzy', label: 'Feral Frenzy', counter: ['spread out', 'mend deep wounds', 'do not group up while he frenzies'] };
  }
  get frenzy() { return this.state === 'frenzy'; }
  speedMult() {
    if (this.state === 'frenzy') return this.frenzySpeed / (this.k.def.speed * M);
    if (this.state === 'fatigue') return 0.25;
    return 1;
  }
  canAttack() { return this.state === 'ready' || this.state === 'recharge'; }
  actionMult(type, target) { return this.state === 'frenzy' && type === 'vault' ? (target.kind === 'pallet' ? 0.35 : 0.3) : 1; }
  // During Frenzy only vaulting is possible (windows and dropped pallets alike).
  context(m) {
    if (this.state !== 'frenzy') return null;
    const k = this.k;
    for (const p of m.map.pallets) if (p.state === 'down' && dist(k.x, k.y, p.x, p.y) < Math.max(p.len / 2, 1.2 * M) + 0.6 * M && Math.abs((k.x - p.x) * p.nx + (k.y - p.y) * p.ny) < 1.6 * M) return { type: 'vault', target: p, label: 'Vault pallet (Frenzy)' };
    for (const w of m.map.windows) if (dist(k.x, k.y, w.x, w.y) < 1.7 * M && Math.abs((k.x - w.x) * w.nx + (k.y - w.y) * w.ny) > 0.4 * M) return { type: 'vault', target: w, label: 'Vault (Frenzy)' };
    return null;
  }
  noContext() { return this.state === 'frenzy'; }
  update(dt, m, inp, locked) {
    this.tickCooldowns(dt);
    const k = this.k;
    if (this.state === 'fatigue') { this.fatigueT -= dt; if (this.fatigueT <= 0) this.state = 'recharge'; return; }
    if (this.state === 'recharge') { this.gauge = Math.min(1, this.gauge + dt * this.recharge); if (this.gauge >= 1) this.state = 'ready'; }
    if (this.state === 'frenzy') {
      this.gauge -= dt * this.drain;
      // auto-continue through vaults; Frenzy pauses its drain while vaulting
      if (k.action?.type === 'vault') this.gauge += dt * this.drain * 0.8;
      if (this.gauge <= 0) { this.endFrenzy(m, 'Frenzy ended'); return; }
      if (this.slashT > 0) { this.slashT -= dt; this.trySlash(m); if (this.slashT <= 0 && !this.slashHit) this.endFrenzy(m, 'Missed — Fatigue'); }
    }
    if (locked) return;
    if (inp.rmbP && this.state === 'ready' && !k.carrying) {
      this.state = 'frenzy'; this.lastHit = null; this.hits = 0;
      m.sound('power_windup', k.x, k.y, 32 * M, { what: 'frenzy' }); m.sound('killer_action', k.x, k.y, 24 * M, { what: 'frenzy' });
      m.events.emit(EV.POWER_USED, { killer: k, power: 'frenzy' }); m.fx.text(k.x, k.y - 40, 'FERAL FRENZY', '#d8e05a');
      return;
    }
    if (this.state === 'frenzy' && inp.lmbP && this.slashT <= 0 && !k.action) {
      this.slashT = 0.28; this.slashHit = false; this.slashDir = k.facing; m.audio?.play('swing'); m.fx.swing(k);
    }
  }
  trySlash(m) {
    if (this.slashHit) return;
    const k = this.k;
    for (const s of m.survivors) {
      if (!s.standing || s === this.lastHit) continue;
      const d = dist(k.x, k.y, s.x, s.y); if (d > k.r + s.r + 1.15 * M) continue;
      if (angleDiff(Math.atan2(s.y - k.y, s.x - k.x), this.slashDir) > 0.95 && d > k.r + s.r + 4) continue;
      if (!m.world.losClear(k.x, k.y, s.x, s.y)) continue;
      if (s.dodgeT && s.dodgeT > m.time) { m.fx.text(s.x, s.y - 30, 'DODGED', '#ffd27a'); continue; }
      this.frenzyHit(m, s); this.slashHit = true; this.slashT = 0; return;
    }
  }
  frenzyHit(m, s) {
    const k = this.k; this.lastHit = s; this.hits++;
    let res;
    if (s.health === 'healthy' && !s.status.has('exposed')) res = s.takeHit(m, { source: 'frenzy' });
    else {
      // injured (or exposed): never downs — the Deep Wound timer takes the damage instead
      s.stopAction(m); s.vault = null; s.lastHitT = m.time;
      s.status.add('haste', { duration: 1.6, value: 0.5, source: 'hit' });
      if (s.health === 'healthy') { s.health = 'injured'; m.events.emit(EV.SURVIVOR_INJURED, { survivor: s, source: 'frenzy' }); }
      res = 'injured';
    }
    const dw = s.status.get('deepWound');
    if (dw && s.status.has('deepWoundFrenzy')) dw.expiration = Math.max(1.5, dw.expiration - 10);
    else s.status.add('deepWound', { duration: this.has('filthy_blade') ? 16 : 20 });
    s.status.add('deepWoundFrenzy', { duration: 30 }); s.mend = 0;
    k.stats.hits++; k.stats.powerHits++; k.chaseT = 0;
    m.events.emit(EV.KILLER_HIT, { killer: k, survivor: s, result: res, power: true }); m.fx.hit(s, res);
    m.addScore('brutality', 250, 'Frenzy hit');
    s.ai?.note('Hit by the Legion\'s Frenzy — Deep Wound', 'frenzyhit');
    this.gauge = Math.min(1, this.gauge + 0.3);
    // Killer Instinct on everyone else in the terror radius: find the next victim
    for (const o of m.survivors) if (o !== s && o.standing && dist(o.x, o.y, k.x, k.y) < k.terrorRadius) killerInstinct(m, o, 3, 'Frenzy');
    if (this.hits >= 4 && this.has('iridescent_button')) this.gauge = Math.min(1, this.gauge + 0.2);
  }
  endFrenzy(m, why) {
    this.state = 'fatigue'; this.fatigueT = this.fatigueTime; this.gauge = Math.max(0, this.gauge); this.slashT = 0;
    m.fx.text(this.k.x, this.k.y - 40, why.toUpperCase(), '#c9b04a'); m.events.emit(EV.POWER_USED, { killer: this.k, power: 'frenzy_end' });
  }
  onStun(m) { if (this.state === 'frenzy') this.endFrenzy(m, 'Stunned'); }
  drawWeapon(ctx) {
    const k = this.k; ctx.fillStyle = '#c9ccd0'; ctx.beginPath(); ctx.moveTo(k.r - 2, 5); ctx.lineTo(k.r + 13, 8); ctx.lineTo(k.r - 2, 10); ctx.closePath(); ctx.fill();
    if (this.slashT > 0) { ctx.strokeStyle = 'rgba(216,224,90,0.7)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, k.r + 22, -0.8, 0.8); ctx.stroke(); }
    return true;
  }
  drawBody(ctx) { const k = this.k; ctx.fillStyle = '#e8e4d8'; ctx.beginPath(); ctx.arc(6, 0, 5, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#9a2030'; ctx.fillRect(7, -1, 3, 2); if (this.frenzy) { ctx.strokeStyle = 'rgba(216,224,90,0.5)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, 0, k.r + 4, 0, Math.PI * 2); ctx.stroke(); } }
  hud() {
    const st = { ready: 'Ready — RMB for Frenzy', frenzy: `FRENZY · ${this.hits || 0} hit${this.hits === 1 ? '' : 's'}`, fatigue: 'Fatigued', recharge: 'Recharging' }[this.state];
    return { title: 'Feral Frenzy', value: Math.round(this.gauge * 100) + '%', meter: this.gauge, state: st,
      hints: [['Q / RMB', 'Feral Frenzy (full gauge)'], ['LMB', 'In Frenzy: Frenzy slash (Deep Wound, chains)'], ['SPACE', 'In Frenzy: vault windows and dropped pallets']] };
  }
}
