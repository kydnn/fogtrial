// Killer power framework. Every killer power extends BasePower and may use the shared
// world systems below — projectiles, area zones and placeable devices — without the
// match loop knowing anything about a specific killer.
//
// Killer
// ├── Power (BasePower)
// │   ├── activation / update(dt, m, input, locked)
// │   ├── cooldowns + charges (helpers here)
// │   ├── effects        → statuses on survivors / killer
// │   ├── projectiles    → m.spawnProjectile(new Projectile({...}))
// │   ├── area effects   → m.addZone(new Zone({...}))
// │   ├── devices        → m.addDevice(new Device({...}))  (survivors can interact)
// │   └── survivor hooks → visibilityTo(), context(), onSurvivorHit()…
// ├── Add-ons (this.has(id))
// ├── Perks (event driven, see perks/)
// └── AI interactions → this.aiProfile + ai/killerProfiles.js
import { M, dist, uid } from '../core/util.js';

export class BasePower {
  constructor(killer, addons = []) {
    this.k = killer; this.addons = addons; this.state = 'idle'; this.cooldowns = {}; this.lockFacing = false;
  }
  has(id) { return this.addons.includes(id); }
  cd(name) { return this.cooldowns[name] || 0; }
  setCd(name, t) { this.cooldowns[name] = t; }
  tickCooldowns(dt) { for (const k in this.cooldowns) this.cooldowns[k] = Math.max(0, this.cooldowns[k] - dt); }
  // defaults every power may override
  speedMult() { return 1; }
  canAttack() { return true; }
  canInteract() { return true; }
  update() {}
  hud() { return { title: this.name, value: '', meter: 0, state: '', hints: [] }; }
  prompt() { return null; }
}

// Straight-flying projectile. Walls (sight-blocking solids) stop it unless passWalls.
export class Projectile {
  constructor(o) {
    this.id = uid('pr'); this.kind = o.kind; this.owner = o.owner;
    this.x = o.x; this.y = o.y; this.vx = o.vx; this.vy = o.vy; this.r = o.r ?? 0.25 * M;
    this.range = o.range ?? 30 * M; this.traveled = 0; this.dead = false; this.passWalls = !!o.passWalls;
    this.onHit = o.onHit; this.pierce = !!o.pierce; this.onWall = o.onWall; this.onEnd = o.onEnd; this.color = o.color || '#ddd'; this.t = 0;
    this.arc = o.arc || null; // lobbed projectiles: { tx, ty, dur } land at a point, ignore walls
    this.data = o.data || {}; this.filter = o.filter || null; this.hitOnce = o.hitOnce ?? true; this.hitSet = new Set();
  }
  update(dt, m) {
    this.t += dt;
    if (this.arc) {
      const k = Math.min(1, this.t / this.arc.dur);
      this.x = this.arc.sx + (this.arc.tx - this.arc.sx) * k; this.y = this.arc.sy + (this.arc.ty - this.arc.sy) * k;
      this.height = Math.sin(k * Math.PI);
      if (k >= 1) { this.dead = true; this.onEnd?.(this, m); }
      return;
    }
    const ax = this.x, ay = this.y; const bx = ax + this.vx * dt, by = ay + this.vy * dt;
    let endT = 1;
    if (!this.passWalls) { const h = m.world.firstHit(ax, ay, bx, by, this.r, (s) => s.blocksLOS); if (h) endT = h.t; }
    // survivors along the segment
    let hitS = null, hitT = endT;
    for (const s of m.survivors) {
      if (!s.standing || this.hitSet.has(s) || (this.filter && !this.filter(s, m))) continue;
      const t = segCircle(ax, ay, bx, by, s.x, s.y, s.r + this.r);
      if (t >= 0 && t <= hitT) { hitT = t; hitS = s; }
    }
    this.x = ax + (bx - ax) * hitT; this.y = ay + (by - ay) * hitT;
    this.traveled += Math.hypot(bx - ax, by - ay) * hitT;
    if (hitS) { if (this.pierce) { this.hitSet.add(hitS); this.onHit?.(this, hitS, m); } else { this.dead = true; this.onHit?.(this, hitS, m); return; } }
    if (endT < 1) { this.dead = true; this.onWall?.(this, m); return; }
    if (this.traveled >= this.range) { this.dead = true; this.onEnd?.(this, m); }
  }
  // seconds until closest approach to a point, and the miss distance there
  approach(px, py) {
    const sp2 = this.vx * this.vx + this.vy * this.vy; if (!sp2) return { t: Infinity, d: Infinity };
    const t = ((px - this.x) * this.vx + (py - this.y) * this.vy) / sp2;
    const cx = this.x + this.vx * t, cy = this.y + this.vy * t;
    return { t, d: Math.hypot(px - cx, py - cy) };
  }
}

function segCircle(ax, ay, bx, by, cx, cy, r) {
  const dx = bx - ax, dy = by - ay, fx = ax - cx, fy = ay - cy;
  const a = dx * dx + dy * dy, b = 2 * (fx * dx + fy * dy), c = fx * fx + fy * fy - r * r;
  if (c <= 0) return 0;
  if (a < 1e-9) return -1;
  const disc = b * b - 4 * a * c; if (disc < 0) return -1;
  const t = (-b - Math.sqrt(disc)) / (2 * a);
  return t >= 0 && t <= 1 ? t : -1;
}

// Area effect: circle zone with a per-frame effect on survivors (and optionally the killer).
// aiCost tells survivor pathing how much to avoid it; seenRange how far away survivors notice it.
export class Zone {
  constructor(o) {
    this.id = uid('zn'); this.kind = o.kind; this.x = o.x; this.y = o.y; this.r = o.r;
    this.t0 = o.t0; this.until = o.until; this.owner = o.owner; this.color = o.color || 'rgba(160,80,200,0.3)';
    this.effect = o.effect; this.killerEffect = o.killerEffect; this.armT = o.armT || 0; this.aiCost = o.aiCost ?? 8;
    this.seenRange = o.seenRange ?? 30 * M; this.label = o.label || o.kind; this.data = o.data || {};
  }
  armed(m) { return m.time - this.t0 >= this.armT; }
  contains(x, y, pad = 0) { return (x - this.x) ** 2 + (y - this.y) ** 2 < (this.r + pad) ** 2; }
}

// Placeable / interactable world object (pods, lockers, printers…).
export class Device {
  constructor(o) {
    this.id = uid('dv'); this.kind = o.kind; this.x = o.x; this.y = o.y; this.r = o.r ?? 0.5 * M;
    this.owner = o.owner; this.label = o.label || o.kind; this.useTime = o.useTime ?? 2;
    this.survivorUsable = o.survivorUsable ?? false; this.usable = o.usable || (() => this.survivorUsable);
    this.onUse = o.onUse || (() => {}); this.dead = false; this.data = o.data || {}; this.seenRange = o.seenRange ?? 26 * M;
    this.aiCost = o.aiCost ?? 0; this.dangerRadius = o.dangerRadius ?? 0; this.useLabel = o.useLabel || null; this.manualComplete = !!o.manualComplete;
  }
}

// Helper used by several powers: find the best open ground point in front of the killer.
export function frontPoint(k, d = 1.2 * M) { return { x: k.x + Math.cos(k.facing) * d, y: k.y + Math.sin(k.facing) * d }; }
export function nearestOf(list, x, y, max = Infinity) { let best = null, bd = max; for (const o of list) { const d = dist(o.x, o.y, x, y); if (d < bd) { bd = d; best = o; } } return best; }

// Power-controlled AI entity (the Houndmaster's dog, the Knight's guards…). It has its own
// position, nav-grid pathfinding and state; survivors perceive it as a separate threat.
export class Minion {
  constructor(o) {
    this.id = uid('mn'); this.kind = o.kind; this.owner = o.owner; this.x = o.x; this.y = o.y; this.r = o.r ?? 0.4 * M;
    this.vx = 0; this.vy = 0; this.facing = o.facing ?? 0; this.state = o.state || 'idle'; this.speed = o.speed ?? 4 * M;
    this.target = null; this.path = null; this.pathI = 0; this.dead = false; this.t = 0; this.stunT = 0; this.data = o.data || {};
    this.color = o.color || '#ccc'; this.label = o.label || o.kind; this.threat = o.threat ?? 1; this.visRange = o.visRange ?? 30 * M;
  }
  // A* over the nav grid. Minions never vault (no links), dropped pallets block them.
  pathTo(m, x, y) {
    const p = m.map.nav.findPath(this.x, this.y, x, y, {}, 6000);
    this.path = p ? m.map.nav.smooth(m.world, p.pts, this.r) : null; this.pathI = 1; this.pathGoal = { x, y };
    return !!this.path;
  }
  // Follow the current path; returns true when the end is reached (or no path).
  followPath(dt, m, speed = this.speed) {
    if (!this.path || this.pathI >= this.path.length) { this.vx = this.vy = 0; return true; }
    const p = this.path[this.pathI]; const dx = p.x - this.x, dy = p.y - this.y, d = Math.hypot(dx, dy);
    if (d < 0.35 * M) { this.pathI++; return this.pathI >= this.path.length; }
    this.moveDir(dt, m, dx / d, dy / d, speed);
    return false;
  }
  moveDir(dt, m, ux, uy, speed = this.speed) {
    const ox = this.x, oy = this.y;
    const hit = m.world.move(this, ux * speed * dt, uy * speed * dt, this.r, (s) => !(s.kind === 'gate' && s.ref.open));
    this.vx = (this.x - ox) / dt; this.vy = (this.y - oy) / dt; this.facing = Math.atan2(uy, ux);
    return hit;
  }
}

// A power landing a hit on a survivor (respects Dead Hard style dodges). Returns the result.
export function strike(m, k, s, { source = 'power', instadown = false, score = null, label = 'Hit' } = {}) {
  if (!s.standing) return null;
  if (s.dodgeT && s.dodgeT > m.time) { m.fx.text(s.x, s.y - 30, 'DODGED', '#ffd27a'); return 'dodged'; }
  s.lastHitBy = k; const res = s.takeHit(m, { source, instadown }); k.stats.hits++; k.stats.powerHits++; k.bloodlust = 0; k.chaseT = 0;
  m.events.emit('onKillerHit', { killer: k, survivor: s, result: res, power: true }); m.fx.hit(s, res);
  if (score) m.addScore(score, 300, label);
  return res;
}
// Killer Instinct: the killer sees where survivors are (shown like a short aura reveal).
export function killerInstinct(m, s, dur = 2, label = 'Killer Instinct') { m.reveal(s, dur, label); }
