// THE GHOUL — Kagune Leap (adapted to top-down).
//  • 2 leap tokens (4 s to recharge each, while not leaping). Press RMB to KAGUNE LEAP straight
//    ahead (22 m/s, up to 14 m).
//  • Leap into a SURVIVOR: he LATCHES on (no damage, they are briefly slowed). A second leap that
//    lands on the latched survivor within 2 s is a GRAB ATTACK: a health state, Deep Wound and the
//    KAGUNE MARK (40 s).
//  • Leap into a WALL: he clings to it and has 1.5 s to leap again in a new direction.
//  • While any survivor carries the Kagune Mark he is ENRAGED: 3 tokens recharging every 2.5 s,
//    and a leap that lands on a marked survivor is an immediate grab attack.
//  • The mark ends when the 40 s run out, the survivor mends their Deep Wound, or goes down.
import { M, dist, normAngle, clamp } from '../core/util.js';
import { EV } from '../core/events.js';
import { BasePower, strike } from './framework.js';

const LEAP_V = 22, LEAP_D = 14, CHAIN_WIN = 1.5, LATCH_WIN = 2, MARK_T = 40;
export class GhoulPower extends BasePower {
  constructor(killer, addons = []) {
    super(killer, addons);
    this.id = 'kagune'; this.name = 'Kagune Leap'; this.state = 'idle'; this.tokens = 2; this.tokenT = 0; this.latchedOn = null; this.winT = 0;
    this.aiProfile = { type: 'leap', label: 'Kagune Leap', counter: ['tight loops and corners (leaps are straight)', 'mend the Deep Wound to clear the Kagune Mark', 'break line after he latches', 'he is slow to recover after a missed leap'] };
  }
  get enraged() { return !!this._m?.survivors.some((s) => s.standing && s.status.has('kaguneMark')); }
  get maxTokens() { return this.enraged ? 3 : 2; }
  speedMult() {
    if (this.state === 'leap') return LEAP_V / this.k.def.speed;
    if (this.state === 'cling' || this.state === 'latch') return 0.1;
    if (this.state === 'recover') return 0.5;
    return 1;
  }
  canAttack() { return this.state === 'idle' || this.state === 'latch'; }
  noContext() { return this.state === 'leap' || this.state === 'cling'; }
  overrideMove() { return this.state === 'leap' ? { x: Math.cos(this.dir), y: Math.sin(this.dir) } : null; }
  onInit(m) { this._m = m; }
  update(dt, m, inp, locked) {
    this._m = m; this.tickCooldowns(dt);
    const k = this.k;
    if (this.state === 'idle' && this.tokens < this.maxTokens) { this.tokenT += dt; if (this.tokenT >= (this.enraged ? 2.5 : 4)) { this.tokenT = 0; this.tokens++; } }
    if (this.tokens > this.maxTokens) this.tokens = this.maxTokens;
    if (this.state === 'recover') { this.recT -= dt; if (this.recT <= 0) this.state = 'idle'; return; }
    if (locked) { if (this.state !== 'idle') { this.state = 'idle'; this.lockFacing = false; } return; }
    switch (this.state) {
      case 'idle': if (inp.rmbP && this.tokens >= 1 && !k.carrying) this.leap(m, k.facing); break;
      case 'leap': {
        this.leapLeft -= LEAP_V * M * dt; k.facing = this.dir;
        for (const s of m.survivors) {
          if (!s.standing || dist(s.x, s.y, k.x, k.y) > k.r + s.r + 0.3 * M || !m.world.losClear(k.x, k.y, s.x, s.y)) continue;
          this.landOn(m, s); return;
        }
        if (this.leapLeft <= 0) { this.state = 'recover'; this.recT = 0.9; this.lockFacing = false; }
        break;
      }
      case 'cling': case 'latch':
        this.winT -= dt;
        if (this.state === 'latch' && this.latchedOn) { const s = this.latchedOn; k.facing = Math.atan2(s.y - k.y, s.x - k.x); }
        if (inp.rmbP && this.tokens >= 1) { this.leap(m, inp.aim ?? k.facing); break; }
        if (this.winT <= 0) { this.state = 'recover'; this.recT = 0.6; this.latchedOn?.status.remove('latched'); this.latchedOn = null; }
        break;
    }
  }
  leap(m, dir) {
    const k = this.k; this.tokens--; this.tokenT = 0; this.state = 'leap'; this.dir = dir; this.leapLeft = LEAP_D * M; this.lockFacing = true;
    m.audio?.play('swing'); m.sound('power_windup', k.x, k.y, 24 * M, { what: 'leap', dir }); m.events.emit(EV.POWER_USED, { killer: k, power: 'leap' });
  }
  onCollide(m) {
    if (this.state !== 'leap') return;
    const k = this.k;
    const along = (k.vx * Math.cos(this.dir) + k.vy * Math.sin(this.dir)) / (LEAP_V * M);
    if (along > 0.75) return; // glancing: keep flying
    this.state = 'cling'; this.winT = CHAIN_WIN; this.lockFacing = false; this.latchedOn = null;
    m.fx.burst(k.x, k.y, 8, '#c02030', 60, 0.3, 2, 2); m.audio?.play('clang');
  }
  landOn(m, s) {
    const k = this.k;
    const grab = (this.latchedOn === s) || s.status.has('kaguneMark');
    if (grab) {
      this.lockFacing = false; this.state = 'recover'; this.recT = 1.2; this.latchedOn = null; s.status.remove('latched');
      const r = strike(m, k, s, { source: 'kagune', score: 'brutality', label: 'Grab Attack' });
      if (r && r !== 'dodged') {
        if (s.standing) { s.status.add('deepWound', { duration: 20 }); s.mend = 0; }
        if (s.standing && !s.status.has('kaguneMark')) { s.status.add('kaguneMark', { duration: MARK_T, source: 'ghoul' }); m.notifyK(`${s.name} is Kagune-Marked — ENRAGED`, '#c02030'); m.warn(s, 'Kagune Mark — mend to remove it'); }
        s.ai?.note('Grab attack by the Ghoul', 'kgrab'); m.fx.shake(8);
        m.events.emit('powerTriggered', { survivor: s, x: s.x, y: s.y, killer: k });
      }
      return;
    }
    // first contact: latch on (no damage)
    this.latchedOn = s; this.state = 'latch'; this.winT = LATCH_WIN; this.lockFacing = false; k.stats.powerHits++;
    s.status.add('latched', { duration: LATCH_WIN, source: 'ghoul' }); s.status.add('hindered', { duration: 0.8, value: 0.25, source: 'latch' });
    m.fx.ring(s.x, s.y, 'rgba(192,32,48,0.9)', 26, 0.4); s.ai?.note('The Ghoul latched onto me', 'latch'); m.warn(s, 'Latched — break away!');
  }
  drawOver(ctx, m) {
    const k = this.k;
    if (this.state === 'leap') { ctx.strokeStyle = 'rgba(192,32,48,0.7)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.lineTo(k.x - Math.cos(this.dir) * 2 * M, k.y - Math.sin(this.dir) * 2 * M); ctx.stroke(); }
    if (this.latchedOn && this.state === 'latch') { const s = this.latchedOn; ctx.strokeStyle = 'rgba(192,32,48,0.8)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(k.x, k.y); ctx.quadraticCurveTo((k.x + s.x) / 2 + 10, (k.y + s.y) / 2 - 10, s.x, s.y); ctx.stroke(); }
    if (this.state === 'cling' || this.state === 'latch') { ctx.strokeStyle = 'rgba(255,120,120,0.8)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(k.x, k.y, k.r + 8, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * Math.max(0, this.winT) / (this.state === 'latch' ? LATCH_WIN : CHAIN_WIN)); ctx.stroke(); }
    if (this.enraged) { ctx.strokeStyle = 'rgba(192,32,48,0.35)'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(k.x, k.y, k.r + 3, 0, Math.PI * 2); ctx.stroke(); }
  }
  drawBody(ctx) { ctx.fillStyle = '#e8e8e8'; ctx.beginPath(); ctx.arc(5, 0, 6, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = '#c02030'; ctx.lineWidth = 2; for (const a of [-2.4, -2.0, 2.0, 2.4]) { ctx.beginPath(); ctx.moveTo(-4, 0); ctx.lineTo(-4 + Math.cos(a) * 16, Math.sin(a) * 16); ctx.stroke(); } }
  hud(m) {
    const st = { idle: this.enraged ? 'ENRAGED' : 'Ready', leap: 'Leaping', cling: `Clinging — RMB to leap (${this.winT.toFixed(1)}s)`, latch: `Latched on ${this.latchedOn?.name} — RMB: grab attack`, recover: 'Recovering' }[this.state];
    return { title: 'Kagune Leap', value: `${this.tokens}/${this.maxTokens}`, meter: this.tokens / this.maxTokens, state: st,
      hints: [['Q / RMB', 'Kagune Leap (14 m)'], ['RMB after a latch', 'Grab attack: injure + Deep Wound + Kagune Mark'], ['Enraged', '3 tokens; marked survivors are grabbed at once']] };
  }
}
