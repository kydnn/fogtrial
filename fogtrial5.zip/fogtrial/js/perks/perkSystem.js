// Event-driven perk system. A perk def: { id, name, description, icon, rarity, side,
// effects, triggers: { eventName: fn(inst, data, m) }, init, update, cooldown, charges }.
// The match asks the system for multipliers; perks react to bus events.
import { SURVIVOR_PERKS } from './survivorPerks.js';
import { KILLER_PERKS } from './killerPerks.js';
import { CLASS_PERKS } from '../modes/classes.js';

export const ALL_PERKS = { ...SURVIVOR_PERKS, ...KILLER_PERKS, ...CLASS_PERKS };

export function makePerk(id, owner) {
  const def = ALL_PERKS[id]; if (!def) return null;
  return { id, def, owner, cooldownT: 0, charges: def.charges ?? null, tokens: 0, active: false, data: {}, lastProc: -999 };
}

export class PerkSystem {
  constructor(m) { this.m = m; this.instances = []; this.unsubs = []; }
  register(owner, ids) {
    const list = [];
    for (const id of ids) {
      const inst = makePerk(id, owner); if (!inst) continue;
      list.push(inst); this.instances.push(inst);
      const trig = inst.def.triggers || {};
      // A killer perk reacts only to its own killer's actions (2v8 has two killers).
      const own = owner.kind === 'killer';
      for (const ev in trig) this.unsubs.push(this.m.events.on(ev, (d) => { if (own && d && d.killer && d.killer !== owner) return; try { trig[ev](inst, d, this.m); } catch (e) { console.error('perk', id, e); } }));
    }
    owner.perks = list;
    return list;
  }
  init() { for (const p of this.instances) p.def.init?.(p, this.m); }
  update(dt) {
    for (const p of this.instances) { if (p.cooldownT > 0) p.cooldownT -= dt; p.def.update?.(p, this.m, dt); }
    for (const k of this.m.killers) if (k.baseTerror) k.terrorRadius = k.baseTerror * this.killerProduct('terrorMult', k) * (k.terrorScale ?? 1);
  }
  // product of a numeric killer-perk property or function(p, m)
  // k given: only that killer's perks (its own stun/lunge/terror); omitted: every killer's perks
  // (effects on the world, like scratch-mark lifetime).
  killerPerks(k = null) { return k ? k.perks : this.m.killers.flatMap((q) => q.perks); }
  killerProduct(key, k = null) { let v = 1; for (const p of this.killerPerks(k)) { const f = p.def[key]; if (typeof f === 'function') v *= f(p, this.m); else if (typeof f === 'number') v *= f; } return v; }
  anySurvivorHas(id) { return this.m.survivors.some((s) => s.alive && s.hasPerk(id)); }
  killerHas(key, k = null) { return this.killerPerks(k).some((p) => p.def[key]); }
  // Skill check odds: survivor token perks first (stake out), then killer modifiers.
  skillCheckMods(sv, g) {
    const out = { fail: 0, great: 0, failExtra: 0, forceGreat: false };
    for (const p of sv.perks) if (p.def.onSkillCheck?.(p, this.m, g) === 'great') out.forceGreat = true;
    for (const p of this.killerPerks()) { const r = p.def.skillCheckMod?.(p, sv, g, this.m); if (r) { out.fail += r.fail || 0; out.great += r.great || 0; out.failExtra += r.failExtra || 0; } }
    return out;
  }
  proc(inst, label) { inst.lastProc = this.m.time; this.m.events.emit('perkProc', { perk: inst, label }); }
  // multipliers / hooks used by the rules
  actionMult(sv, type) {
    let k = 1;
    for (const p of this.killerPerks()) if (p.def.survivorActionMult) k *= p.def.survivorActionMult(p, sv, type, this.m);
    for (const p of sv.perks) if (p.def.actionMult) k *= p.def.actionMult(p, sv, type, this.m);
    if (['repair', 'heal', 'healSelf', 'unhook', 'openGate'].includes(type)) for (const o of this.m.survivors) if (o !== sv && o.standing) for (const p of o.perks) if (p.def.teamActionMult && Math.hypot(o.x - sv.x, o.y - sv.y) < 8 * 32) k *= p.def.teamActionMult;
    return k;
  }
  healMult(healer, target) {
    let k = 1; for (const p of healer.perks) if (p.def.healMult) k *= p.def.healMult(p, healer, target, this.m);
    for (const p of this.killerPerks()) if (p.def.survivorHealMult) k *= p.def.survivorHealMult(p, healer, target, this.m);
    return k;
  }
  killerActionMult(type, killer = this.m.killer) { let k = 1; for (const p of killer.perks) if (p.def.killerActionMult) k *= p.def.killerActionMult(p, type, this.m); return k; }
  killerCooldownMult(kind, killer = this.m.killer) { let k = 1; for (const p of killer.perks) if (p.def.killerCooldownMult) k *= p.def.killerCooldownMult(p, kind, this.m); return k; }
  survivorStartRun(sv) { for (const p of sv.perks) p.def.onStartRun?.(p, sv, this.m); }
  survivorFastVault(sv) { for (const p of sv.perks) p.def.onFastVault?.(p, sv, this.m); }
  activate(sv, id) { const p = sv.perks.find((q) => q.id === id); if (p && p.def.activate) return p.def.activate(p, sv, this.m); return false; }
  destroy() { for (const u of this.unsubs) u(); }
}
