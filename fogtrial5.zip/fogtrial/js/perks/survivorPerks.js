// Survivor perk pool. Survivors get random loadouts from this pool.
// AI-facing flags (ai: {...}) tell the bots how to value / use each perk.
import { EV } from '../core/events.js';
import { M, dist } from '../core/util.js';

const exhaust = (sv, t = 40) => sv.status.add('exhausted', { duration: t, source: 'perk' });
const notExhausted = (sv) => !sv.status.has('exhausted');

export const SURVIVOR_PERKS = {
  sprint_burst: { id: 'sprint_burst', side: 'survivor', name: 'Sprint Burst', icon: '»', rarity: 'rare', tier: 'strong',
    description: 'Breaking into a run grants 150% speed for 3 s. Causes Exhausted for 40 s.',
    onStartRun: (p, sv, m) => { if (notExhausted(sv) && (sv.isPlayer || sv.ai?.wantsExhaustionPerk(p))) { sv.status.add('haste', { duration: 3, value: 0.5, source: 'sprint_burst' }); exhaust(sv); m.perks.proc(p, 'Sprint Burst'); } } },
  lithe: { id: 'lithe', side: 'survivor', name: 'Lithe', icon: '↯', rarity: 'uncommon', tier: 'strong',
    description: 'After a fast vault, gain 150% speed for 3 s. Causes Exhausted for 40 s.',
    onFastVault: (p, sv, m) => { if (notExhausted(sv) && (sv.isPlayer || sv.ai?.inChase)) { sv.status.add('haste', { duration: 3, value: 0.5, source: 'lithe' }); exhaust(sv); m.perks.proc(p, 'Lithe'); } } },
  dead_hard: { id: 'dead_hard', side: 'survivor', name: 'Dead Hard', icon: '⛨', rarity: 'rare', tier: 'strong',
    description: 'While injured, press to dodge: 0.5 s of invulnerability to one hit. Causes Exhausted for 40 s.',
    activate: (p, sv, m) => { if (!notExhausted(sv) || sv.health !== 'injured') return false; sv.dodgeT = m.time + 0.5; exhaust(sv); m.perks.proc(p, 'Dead Hard'); return true; } },
  adrenaline: { id: 'adrenaline', side: 'survivor', name: 'Adrenaline', icon: '⚡', rarity: 'very rare', tier: 'strong',
    description: 'When the exit gates are powered, heal one health state and gain 150% speed for 5 s.',
    triggers: { [EV.EXIT_GATES_POWERED]: (p, d, m) => { const sv = p.owner; if (!sv.standing && sv.health !== 'dying') return;
      if (sv.health === 'injured') { sv.health = 'healthy'; sv.status.remove('deepWound'); } else if (sv.health === 'dying') sv.health = 'injured';
      sv.status.add('haste', { duration: 5, value: 0.5, source: 'adrenaline' }); m.perks.proc(p, 'Adrenaline'); } } },
  self_care: { id: 'self_care', side: 'survivor', name: 'Self-Care', icon: '✚', rarity: 'common', tier: 'basic',
    description: 'Heal yourself without a med-kit at 50% speed.' },
  borrowed_time: { id: 'borrowed_time', side: 'survivor', name: 'Borrowed Time', icon: '⏳', rarity: 'rare', tier: 'strong',
    description: 'Survivors you unhook get Endurance for 15 s.',
    triggers: { [EV.SURVIVOR_UNHOOKED]: (p, d, m) => { if (d.rescuer === p.owner) { d.survivor.status.add('endurance', { duration: 15, source: 'bt' }); m.perks.proc(p, 'Borrowed Time'); } } } },
  bond: { id: 'bond', side: 'survivor', name: 'Bond', icon: '⚭', rarity: 'uncommon', tier: 'basic',
    description: 'See teammates within 36 m. Bots coordinate better.', ai: { teammateSense: 36 } },
  kindred: { id: 'kindred', side: 'survivor', name: 'Kindred', icon: '◎', rarity: 'uncommon', tier: 'strong',
    description: 'While you are hooked, teammates see the killer when within 16 m of your hook.', ai: { kindred: 16 } },
  resilience: { id: 'resilience', side: 'survivor', name: 'Resilience', icon: '✦', rarity: 'common', tier: 'basic',
    description: 'While injured, repair, heal and vault 9% faster.' },
  prove_thyself: { id: 'prove_thyself', side: 'survivor', name: 'Prove Thyself', icon: '⚙', rarity: 'uncommon', tier: 'strong',
    description: 'Repair 15% faster for each other survivor on your generator.' },
  iron_will: { id: 'iron_will', side: 'survivor', name: 'Iron Will', icon: '◐', rarity: 'rare', tier: 'strong',
    description: 'Grunts of pain are silenced while injured.' },
  urban_evasion: { id: 'urban_evasion', side: 'survivor', name: 'Urban Evasion', icon: '⌄', rarity: 'common', tier: 'basic',
    description: 'Crouch-walking speed nearly doubled. Bots hide more effectively.' },
  spine_chill: { id: 'spine_chill', side: 'survivor', name: 'Spine Chill', icon: '❄', rarity: 'uncommon', tier: 'strong',
    description: 'Warned when the killer is within 36 m and facing you — even when undetectable.', ai: { spineChill: 36 } },
  decisive_strike: { id: 'decisive_strike', side: 'survivor', name: 'Decisive Strike', icon: '✖', rarity: 'very rare', tier: 'strong',
    description: 'For 40 s after being unhooked, escape the killer\'s grasp with a skill check, stunning them for 4 s.' },
  unbreakable: { id: 'unbreakable', side: 'survivor', name: 'Unbreakable', icon: '⬆', rarity: 'rare', tier: 'strong',
    description: 'Once per trial, fully recover from the dying state.' },
  deliverance: { id: 'deliverance', side: 'survivor', name: 'Deliverance', icon: '⛓', rarity: 'rare', tier: 'strong',
    description: 'After a safe unhook, your next first-stage self-unhook succeeds.',
    triggers: { [EV.SURVIVOR_UNHOOKED]: (p, d, m) => { if (d.rescuer === p.owner) { const k = m.nearestKiller(d.survivor.x, d.survivor.y); if (dist(k.x, k.y, d.survivor.x, d.survivor.y) > 24 * M) { p.tokens = 1; m.perks.proc(p, 'Deliverance ready'); } } } } },
  small_game: { id: 'small_game', side: 'survivor', name: 'Small Game', icon: '⚠', rarity: 'uncommon', tier: 'basic',
    description: 'Warned of traps and totems within 8 m ahead.', ai: { smallGame: 8 } },
  calm_spirit: { id: 'calm_spirit', side: 'survivor', name: 'Calm Spirit', icon: '☾', rarity: 'common', tier: 'basic',
    description: 'You do not scream when hit or downed.' },
  windows_of_opportunity: { id: 'windows_of_opportunity', side: 'survivor', name: 'Windows of Opportunity', icon: '⊞', rarity: 'uncommon', tier: 'strong',
    description: 'Know the state of pallets and windows within 24 m. Bots plan chases better.', ai: { windows: 24 } },
  dark_sense: { id: 'dark_sense', side: 'survivor', name: 'Dark Sense', icon: '◉', rarity: 'common', tier: 'basic',
    description: 'Each time a generator is completed, see the killer for 5 s.',
    triggers: { [EV.GENERATOR_REPAIRED]: (p, d, m) => { if (p.owner.alive) { m.revealKillerTo(p.owner, 5, 'Dark Sense'); m.perks.proc(p, 'Dark Sense'); } } } },
  botany: { id: 'botany', side: 'survivor', name: 'Botany Knowledge', icon: '❦', rarity: 'common', tier: 'basic',
    description: 'Heal others 33% faster.', healMult: () => 1.33 },
  well_make_it: { id: 'well_make_it', side: 'survivor', name: 'We\'ll Make It', icon: '❤', rarity: 'uncommon', tier: 'strong',
    description: 'After unhooking someone, heal others 100% faster for 90 s.',
    triggers: { [EV.SURVIVOR_UNHOOKED]: (p, d, m) => { if (d.rescuer === p.owner) p.data.until = m.time + 90; } },
    healMult: (p, h, t, m) => (p.data.until > m.time ? 2 : 1) },
};

// ---------------------------------------------------------------------------------
// Expansion pool. `cat` drives weighted random builds; `ai` tells the perk brain how
// to value a perk (bias multipliers on goals) or when to fire an active one (use).
const tok = (p, n = 1, max = 4) => { p.tokens = Math.min(max, (p.tokens || 0) + n); };
Object.assign(SURVIVOR_PERKS, {
  // ---- Generator / objective ----
  stake_out: { id: 'stake_out', side: 'survivor', cat: 'objective', name: 'Stake Out', icon: '◔', rarity: 'uncommon', tier: 'strong', weight: 2,
    description: 'Gain a token every 15 s near the killer while not in a chase (max 4). Tokens turn good skill checks into great ones.',
    update: (p, m, dt) => { const s = p.owner; if (!s.standing || m.inChase(s)) return; if (m.killerDist(s.x, s.y) < 32 * M) { p.data.t = (p.data.t || 0) + dt; if (p.data.t > 15) { p.data.t = 0; tok(p); } } },
    onSkillCheck: (p) => { if (p.tokens > 0) { p.tokens--; return 'great'; } return null; }, ai: { bias: { repair: 1.05 } } },
  hyperfocus: { id: 'hyperfocus', side: 'survivor', cat: 'objective', name: 'Hyperfocus', icon: '◎', rarity: 'rare', tier: 'strong', weight: 2,
    description: 'Each great skill check in a row adds 4% repair speed (max 6). A missed check resets it.',
    triggers: { [EV.SKILL_CHECK_SUCCESS]: (p, d) => { if (d.survivor !== p.owner) return; if (d.great) { tok(p, 1, 6); p.owner.status.remove('repairSpeed', 'hyperfocus'); p.owner.status.add('repairSpeed', { value: 0.04 * p.tokens, source: 'hyperfocus', duration: 60 }); } },
      [EV.SKILL_CHECK_FAILURE]: (p, d) => { if (d.survivor === p.owner) { p.tokens = 0; p.owner.status.remove('repairSpeed', 'hyperfocus'); } } }, ai: { bias: { repair: 1.08 } } },
  technician: { id: 'technician', side: 'survivor', cat: 'objective', name: 'Technician', icon: '⚙', rarity: 'common', tier: 'basic', weight: 3,
    description: 'Failed skill checks make no loud noise and cost only 5% progress.', ai: { bias: { repair: 1.03 } } },
  deja_vu: { id: 'deja_vu', side: 'survivor', cat: 'objective', name: 'Déjà Vu', icon: '⁂', rarity: 'common', tier: 'basic', weight: 3,
    description: 'See the generators most likely to form a 3-gen. Bots break clusters first.', ai: { bias: { cluster: 1.6 } } },
  repressed_alliance: { id: 'repressed_alliance', side: 'survivor', cat: 'objective', name: 'Repressed Alliance', icon: '⛔', rarity: 'rare', tier: 'strong', weight: 2, charges: 1,
    description: 'After 80 s of repairs, press to block your generator for 30 s.',
    update: (p, m, dt) => { if (p.owner.action?.type === 'repair') p.data.rep = (p.data.rep || 0) + dt; },
    activate: (p, s, m) => { const g = s.action?.type === 'repair' ? s.action.target : p.data.lastGen; if (!g || (p.data.rep || 0) < 80 || p.charges <= 0) return false; g.blockedUntil = m.time + 30; p.charges--; m.notifyK(`Generator ${g.name} was blocked by the Entity`, '#9fd0d0'); m.perks.proc(p, 'Repressed Alliance'); return true; },
    ai: { use: { when: 'leaveGen', value: (p, ai) => { const g = ai.sv.action?.type === 'repair' ? ai.sv.action.target : null; return g && g.progress > 0.45 && ai.threat > 0.5 && (p.data.rep || 0) >= 80 ? 1 : 0; } } } },
  plunderers_instinct: { id: 'plunderers_instinct', side: 'survivor', cat: 'objective', name: "Plunderer's Instinct", icon: '⚿', rarity: 'common', tier: 'basic', weight: 2,
    description: 'Search chests 25% faster and know where unopened chests are.', actionMult: (p, s, type) => (type === 'searchChest' ? 1.25 : 1), ai: { bias: { chest: 2.2 } } },
  // ---- Chase ----
  quick_and_quiet: { id: 'quick_and_quiet', side: 'survivor', cat: 'chase', name: 'Quick & Quiet', icon: '∿', rarity: 'uncommon', tier: 'strong', weight: 2,
    description: 'Every 20 s, a fast vault or pallet drop makes no loud noise.' },
  dance_with_me: { id: 'dance_with_me', side: 'survivor', cat: 'chase', name: 'Dance With Me', icon: '♪', rarity: 'uncommon', tier: 'basic', weight: 2,
    description: 'After a fast vault, leave no scratch marks for 3 s.', onFastVault: (p, s, m) => { s.noScratchUntil = m.time + 3; } },
  lightweight: { id: 'lightweight', side: 'survivor', cat: 'stealth', name: 'Lightweight', icon: '❍', rarity: 'common', tier: 'basic', weight: 3,
    description: 'Your scratch marks fade much faster.' },
  vigil: { id: 'vigil', side: 'survivor', cat: 'chase', name: 'Vigil', icon: '◓', rarity: 'common', tier: 'basic', weight: 2,
    description: 'Recover from Exhausted 25% faster.', update: (p, m, dt) => { const e = p.owner.status.get('exhausted'); if (e) e.expiration -= dt * 0.25; } },
  overcome: { id: 'overcome', side: 'survivor', cat: 'chase', name: 'Overcome', icon: '➹', rarity: 'rare', tier: 'strong', weight: 2, exhaustion: true,
    description: 'When injured, gain 150% speed for 3 s. Causes Exhausted for 60 s.',
    triggers: { [EV.SURVIVOR_INJURED]: (p, d, m) => { const s = p.owner; if (d.survivor === s && notExhausted(s) && s.health === 'injured') { s.status.add('haste', { duration: 3, value: 0.5, source: 'overcome' }); exhaust(s, 60); m.perks.proc(p, 'Overcome'); s.ai?.note('Overcome burst after the hit', 'overcome'); } } } },
  background_player: { id: 'background_player', side: 'survivor', cat: 'rescue', name: 'Background Player', icon: '⇶', rarity: 'uncommon', tier: 'strong', weight: 2, exhaustion: true,
    description: 'When a teammate is picked up within 32 m, gain 150% speed for 5 s. Causes Exhausted for 60 s.',
    triggers: { [EV.SURVIVOR_PICKED_UP]: (p, d, m) => { const s = p.owner; if (d.survivor !== s && s.standing && notExhausted(s) && m.killerDist(s.x, s.y) < 32 * M && (s.isPlayer || s.ai?.perkBrain.wantsBurst('save'))) { s.status.add('haste', { duration: 5, value: 0.5, source: 'bgp' }); exhaust(s, 60); m.perks.proc(p, 'Background Player'); s.ai?.note('Background Player — sprinting to the carry', 'bgp'); } } },
    ai: { bias: { followCarry: 1.7, protect: 1.2 } } },
  smash_hit: { id: 'smash_hit', side: 'survivor', cat: 'chase', name: 'Smash Hit', icon: '✸', rarity: 'uncommon', tier: 'strong', weight: 2, exhaustion: true,
    description: 'After a pallet stun, gain 150% speed for 4 s. Causes Exhausted for 30 s.',
    triggers: { [EV.KILLER_STUNNED]: (p, d, m) => { const s = p.owner; if (d.kind === 'pallet' && m.lastStunner === s && notExhausted(s)) { s.status.add('haste', { duration: 4, value: 0.5, source: 'smash' }); exhaust(s, 30); m.perks.proc(p, 'Smash Hit'); } } },
    ai: { bias: { stunHunt: 1.5 } } },
  // ---- Killer information / stealth ----
  alert: { id: 'alert', side: 'survivor', cat: 'stealth', name: 'Alert', icon: '!', rarity: 'common', tier: 'basic', weight: 3,
    description: 'When the killer breaks a pallet or damages a generator, see them for 4 s.',
    triggers: { [EV.PALLET_DESTROYED]: (p, d, m) => { if (p.owner.alive) m.revealKillerTo(p.owner, 4, 'Alert'); }, [EV.GENERATOR_DAMAGED]: (p, d, m) => { if (p.owner.alive) m.revealKillerTo(p.owner, 4, 'Alert'); } } },
  premonition: { id: 'premonition', side: 'survivor', cat: 'stealth', name: 'Premonition', icon: '◭', rarity: 'common', tier: 'basic', weight: 2,
    description: 'Warned (every 30 s) when the killer is within 36 m in the direction you face.',
    update: (p, m, dt) => { const s = p.owner, k = m.nearestKiller(p.owner.x, p.owner.y); if (!s.standing || p.cooldownT > 0) return; const d = dist(k.x, k.y, s.x, s.y); const a = Math.atan2(k.y - s.y, k.x - s.x); let df = Math.abs(a - s.facing); if (df > Math.PI) df = Math.PI * 2 - df;
      if (d < 36 * M && df < 0.8) { p.cooldownT = 30; m.perks.proc(p, 'Premonition'); if (!s.ai) { m.warn(s, 'Premonition: the killer is ahead', a); return; } const B = s.ai.beliefFor(k); if (!B.observing) { const r = Math.min(d, 25 * M); B.x = s.x + Math.cos(a) * r; B.y = s.y + Math.sin(a) * r; B.vx = B.vy = 0; B.t = m.time; B.conf = Math.max(B.conf, 0.55); B.dirKnown = true; } s.ai.note('Premonition: killer ahead', 'premon'); } } },
  lucky_break: { id: 'lucky_break', side: 'survivor', cat: 'stealth', name: 'Lucky Break', icon: '✤', rarity: 'uncommon', tier: 'basic', weight: 2,
    description: 'While injured you leave no blood for up to 180 s.', update: (p, m, dt) => { if (p.owner.health === 'injured') p.data.used = (p.data.used || 0) + dt; }, ai: { bias: { hide: 0.1 } } },
  detectives_hunch: { id: 'detectives_hunch', side: 'survivor', cat: 'objective', name: "Detective's Hunch", icon: '⌕', rarity: 'common', tier: 'basic', weight: 2,
    description: 'When a generator is finished, learn every totem and chest within 64 m.',
    triggers: { [EV.GENERATOR_REPAIRED]: (p, d, m) => { const s = p.owner; if (!s.ai || !s.alive) return; for (const t of m.map.totems) if (dist(t.x, t.y, s.x, s.y) < 64 * M) s.ai.memory.totems.set(t.id, { totem: t, t: m.time }); } } },
  // ---- Healing ----
  empathy: { id: 'empathy', side: 'survivor', cat: 'healing', name: 'Empathy', icon: '♥', rarity: 'common', tier: 'basic', weight: 3,
    description: 'Know where injured and dying teammates are. Bots heal teammates more.', ai: { bias: { heal: 1.3 } } },
  solidarity: { id: 'solidarity', side: 'survivor', cat: 'healing', name: 'Solidarity', icon: '⊕', rarity: 'uncommon', tier: 'strong', weight: 2,
    description: 'While injured, healing a teammate also heals you by 50% of the progress.', ai: { dynBias: (p, ai) => (ai.sv.health === 'injured' ? { heal: 1.6 } : null) } },
  desperate_measures: { id: 'desperate_measures', side: 'survivor', cat: 'healing', name: 'Desperate Measures', icon: '⚕', rarity: 'uncommon', tier: 'strong', weight: 2,
    description: 'Heal and unhook 10% faster for each injured, hooked or dying teammate (max 40%).',
    healMult: (p, h, t, m) => 1 + 0.1 * Math.min(4, m.survivors.filter((o) => o !== h && ['injured', 'hooked', 'dying'].includes(o.health)).length),
    actionMult: (p, s, type, m) => (type === 'unhook' ? 1 + 0.1 * Math.min(4, m.survivors.filter((o) => o !== s && ['injured', 'hooked', 'dying'].includes(o.health)).length) : 1) },
  resurgence: { id: 'resurgence', side: 'survivor', cat: 'healing', name: 'Resurgence', icon: '↻', rarity: 'common', tier: 'basic', weight: 2,
    description: 'When you are unhooked, start with 50% healing progress.', triggers: { [EV.SURVIVOR_UNHOOKED]: (p, d) => { if (d.survivor === p.owner) p.owner.healProgress = 0.5; } } },
  circle_of_healing: { id: 'circle_of_healing', side: 'survivor', cat: 'healing', name: 'Circle of Healing', icon: '◌', rarity: 'rare', tier: 'strong', weight: 1,
    description: 'Every survivor can heal themselves without a med-kit (at 50% speed).' },
  inner_strength: { id: 'inner_strength', side: 'survivor', cat: 'healing', name: 'Inner Strength', icon: '✧', rarity: 'uncommon', tier: 'basic', weight: 2,
    description: 'Cleansing a totem heals you instantly if injured.',
    triggers: { [EV.TOTEM_CLEANSED]: (p, d, m) => { if (d.survivor === p.owner && p.owner.health === 'injured') { m.healed(p.owner, p.owner); m.perks.proc(p, 'Inner Strength'); } } },
    ai: { dynBias: (p, ai) => (ai.sv.health === 'injured' ? { cleanse: 3 } : null) } },
  // ---- Rescue ----
  breakout: { id: 'breakout', side: 'survivor', cat: 'rescue', name: 'Breakout', icon: '⇱', rarity: 'uncommon', tier: 'strong', weight: 2,
    description: 'Within 6 m of a killer carrying a teammate, that teammate wiggles 20% faster.', ai: { bias: { followCarry: 1.9 } } },
  babysitter: { id: 'babysitter', side: 'survivor', cat: 'rescue', name: 'Babysitter', icon: '☂', rarity: 'common', tier: 'basic', weight: 2,
    description: 'Teammates you unhook get a 4 s burst of speed; the killer sees you for 4 s.',
    triggers: { [EV.SURVIVOR_UNHOOKED]: (p, d, m) => { if (d.rescuer === p.owner) { d.survivor.status.add('haste', { duration: 4, value: 0.5, source: 'babysit' }); m.reveal(p.owner, 4, 'Babysitter'); } } }, ai: { bias: { rescue: 1.1 } } },
  for_the_people: { id: 'for_the_people', side: 'survivor', cat: 'rescue', name: 'For the People', icon: '✚', rarity: 'rare', tier: 'strong', weight: 1, charges: 1,
    description: 'Once per trial, instantly heal a dying teammate you are healing to injured. You become Broken for 80 s.',
    activate: (p, s, m) => { const t = s.action?.type === 'heal' ? s.action.target : null; if (!t || t.health !== 'dying' || p.charges <= 0) return false; m.healed(t, s); s.stopAction(m); s.status.add('broken', { duration: 80 }); p.charges--; m.perks.proc(p, 'For the People'); s.ai?.note('For the People — instant pick-up', 'ftp'); return true; },
    ai: { use: { value: (p, ai) => { const t = ai.sv.action?.type === 'heal' ? ai.sv.action.target : null; return t && t.health === 'dying' && ai.killerDistAt(t.x, t.y) < 26 ? 1 : 0; } } } },
  reassurance: { id: 'reassurance', side: 'survivor', cat: 'rescue', name: 'Reassurance', icon: '✋', rarity: 'uncommon', tier: 'strong', weight: 2, cooldown: 60,
    description: 'Pause a hooked teammate\'s hook timer for 30 s from up to 12 m away (60 s cooldown).',
    activate: (p, s, m) => { if (p.cooldownT > 0) return false; const t = m.survivors.find((o) => o.health === 'hooked' && dist(o.x, o.y, s.x, s.y) < 12 * M); if (!t) return false; t.hookPauseUntil = m.time + 30; p.cooldownT = 60; m.perks.proc(p, 'Reassurance'); s.ai?.note(`Reassured ${t.name} on the hook`, 'reassure'); return true; },
    ai: { use: { value: (p, ai) => { const m = ai.m; const t = m.survivors.find((o) => o.health === 'hooked' && dist(o.x, o.y, ai.sv.x, ai.sv.y) < 12 * M); if (!t) return 0; const left = m.hookStageTime - t.hookTimer; return left < 22 && ai.killerDistAt(t.x, t.y) < 16 ? 1 : 0; } } } },
  off_the_record: { id: 'off_the_record', side: 'survivor', cat: 'rescue', name: 'Off the Record', icon: '⊝', rarity: 'rare', tier: 'strong', weight: 2,
    description: 'After being unhooked, gain Endurance for 80 s. It ends early if you repair or heal.',
    triggers: { [EV.SURVIVOR_UNHOOKED]: (p, d) => { if (d.survivor === p.owner) p.owner.status.add('endurance', { duration: 80, source: 'otr' }); } },
    update: (p) => { const a = p.owner.action?.type; if (a === 'repair' || a === 'heal' || a === 'healSelf') p.owner.status.remove('endurance', 'otr'); } },
  slippery_meat: { id: 'slippery_meat', side: 'survivor', cat: 'rescue', name: 'Slippery Meat', icon: '≈', rarity: 'common', tier: 'basic', weight: 2,
    description: 'Self-unhook attempts are three times as likely to succeed.' },
  // ---- Endgame ----
  hope: { id: 'hope', side: 'survivor', cat: 'endgame', name: 'Hope', icon: '☀', rarity: 'common', tier: 'basic', weight: 3,
    description: 'When the exit gates are powered, gain 7% speed for 120 s.', triggers: { [EV.EXIT_GATES_POWERED]: (p) => p.owner.status.add('haste', { duration: 120, value: 0.07, source: 'hope' }) } },
  wake_up: { id: 'wake_up', side: 'survivor', cat: 'endgame', name: 'Wake Up!', icon: '⚑', rarity: 'uncommon', tier: 'basic', weight: 2,
    description: 'Open exit gates 15% faster and always know where they are.', actionMult: (p, s, type) => (type === 'openGate' ? 1.15 : 1), ai: { bias: { gate: 1.2 } } },
  left_behind: { id: 'left_behind', side: 'survivor', cat: 'endgame', name: 'Left Behind', icon: '⇲', rarity: 'common', tier: 'basic', weight: 2,
    description: 'As the last survivor, you know where the hatch is.', update: (p, m) => { if (p.owner.ai && m.aliveCount() === 1 && m.hatch.state !== 'hidden') p.owner.ai.memory.hatchSeen = true; } },
  no_one_left_behind: { id: 'no_one_left_behind', side: 'survivor', cat: 'endgame', name: 'No One Left Behind', icon: '⇄', rarity: 'uncommon', tier: 'basic', weight: 2,
    description: 'After the gates are powered, heal and unhook 50% faster.',
    healMult: (p, h, t, m) => (m.gatesPowered ? 1.5 : 1), actionMult: (p, s, type, m) => (m.gatesPowered && type === 'unhook' ? 1.5 : 1), ai: { dynBias: (p, ai) => (ai.m.gatesPowered ? { rescue: 1.3, heal: 1.3 } : null) } },
});
// ---------------------------------------------------------------------------------
// Roster expansion (18 killers): more chase/gen/heal/stealth/rescue/endgame perks and a
// handful of anti-power perks. Anti-power perks soften a killer's power, never cancel it.
Object.assign(SURVIVOR_PERKS, {
  distortion: { id: 'distortion', side: 'survivor', cat: 'stealth', name: 'Distortion', icon: '◌', rarity: 'rare', tier: 'strong', weight: 2, charges: 3,
    description: 'Three times per trial, when the killer would see your aura, it is hidden instead and your scratch marks vanish for 10 s.', ai: { bias: { hide: 0.1 } } },
  vigilant_eye: { id: 'vigilant_eye', side: 'survivor', cat: 'anti', name: 'Vigilant Eye', icon: '◉', rarity: 'uncommon', tier: 'strong', weight: 2,
    description: 'You notice killer power objects — traps, Phantasms, pods, gas, trails, guards, lockers — within 12 m even without line of sight.', ai: { bias: { cleanse: 1.05 } } },
  steadfast: { id: 'steadfast', side: 'survivor', cat: 'anti', name: 'Steadfast', icon: '⛉', rarity: 'uncommon', tier: 'strong', weight: 2,
    description: 'Power debuffs on you (Hindered, Intoxicated, Tormented, Slipstream, Infection) wear off 35% faster.',
    update: (p, m, dt) => { const sv = p.owner; for (const id of ['hindered', 'intoxicated', 'tormented', 'slipstream']) { const st = sv.status.get(id); if (st && st.expiration < 1e6) st.expiration -= dt * 0.35; } if (sv.infection) sv.infection = Math.max(0, sv.infection - dt * 0.28); } },
  fogwise: { id: 'fogwise', side: 'survivor', cat: 'objective', name: 'Fogwise', icon: '◎', rarity: 'uncommon', tier: 'basic', weight: 2,
    description: 'Great skill checks on generators show you the killer for 6 s.',
    triggers: { [EV.SKILL_CHECK_SUCCESS]: (p, d, m) => { if (d.survivor === p.owner && d.great) { m.revealKillerTo(p.owner, 6, 'Fogwise'); m.perks.proc(p, 'Fogwise'); } } } },
  leader: { id: 'leader', side: 'survivor', cat: 'objective', name: 'Leader', icon: '⚑', rarity: 'uncommon', tier: 'strong', weight: 2,
    description: 'Teammates within 8 m of you repair, heal, unhook and open gates 12% faster.', teamActionMult: 1.12, ai: { bias: { joinGen: 1.25 } } },
  situational_awareness: { id: 'situational_awareness', side: 'survivor', cat: 'objective', name: 'Situational Awareness', icon: '⊛', rarity: 'common', tier: 'basic', weight: 2,
    description: 'Repairing next to a teammate is 10% faster.', actionMult: (p, sv, type) => (type === 'repair' && sv.action?.target?.repairers?.size > 1 ? 1.1 : 1), ai: { bias: { joinGen: 1.2 } } },
  overzealous: { id: 'overzealous', side: 'survivor', cat: 'objective', name: 'Overzealous', icon: '✶', rarity: 'uncommon', tier: 'basic', weight: 2,
    description: 'Cleansing a totem makes you repair 8% faster (16% after a hex) until you are injured.',
    triggers: { [EV.TOTEM_CLEANSED]: (p, d) => { if (d.survivor === p.owner) p.owner.status.add('repairSpeed', { value: d.hex ? 0.16 : 0.08, source: 'overzealous', duration: 9999 }); },
      [EV.SURVIVOR_INJURED]: (p, d) => { if (d.survivor === p.owner) p.owner.status.remove('repairSpeed', 'overzealous'); } }, ai: { bias: { cleanse: 2.2 } } },
  parental_guidance: { id: 'parental_guidance', side: 'survivor', cat: 'chase', name: 'Parental Guidance', icon: '☂', rarity: 'common', tier: 'basic', weight: 2,
    description: 'After stunning the killer, you leave no scratch marks, blood or grunts for 7 s.',
    triggers: { [EV.KILLER_STUNNED]: (p, d, m) => { if (m.lastStunner === p.owner) { p.owner.noScratchUntil = m.time + 7; p.owner.silentUntil = m.time + 7; m.perks.proc(p, 'Parental Guidance'); } } } },
  self_preservation: { id: 'self_preservation', side: 'survivor', cat: 'stealth', name: 'Self-Preservation', icon: '⇲', rarity: 'common', tier: 'basic', weight: 2,
    description: 'When a teammate is hit within 16 m of you, you leave no scratch marks for 10 s.',
    triggers: { [EV.KILLER_HIT]: (p, d, m) => { const s = p.owner; if (d.survivor !== s && s.standing && dist(s.x, s.y, d.survivor.x, d.survivor.y) < 16 * M) s.noScratchUntil = m.time + 10; } } },
  reactive_healing: { id: 'reactive_healing', side: 'survivor', cat: 'healing', name: 'Reactive Healing', icon: '♥', rarity: 'uncommon', tier: 'basic', weight: 2,
    description: 'When a teammate within 32 m is injured while you are injured, you gain 50% of your missing healing progress.',
    triggers: { [EV.SURVIVOR_INJURED]: (p, d, m) => { const s = p.owner; if (d.survivor !== s && s.health === 'injured' && dist(s.x, s.y, d.survivor.x, d.survivor.y) < 32 * M) { s.healProgress += (1 - s.healProgress) * 0.5; m.perks.proc(p, 'Reactive Healing'); } } } },
  bite_the_bullet: { id: 'bite_the_bullet', side: 'survivor', cat: 'healing', name: 'Bite the Bullet', icon: '◆', rarity: 'common', tier: 'basic', weight: 2,
    description: 'You and the teammate you heal make no grunts while healing, and you heal 6% faster.', healMult: () => 1.06, ai: { bias: { heal: 1.1 } } },
  power_of_two: { id: 'power_of_two', side: 'survivor', cat: 'healing', name: 'Teamwork: Power of Two', icon: '⚭', rarity: 'uncommon', tier: 'basic', weight: 2,
    description: 'After healing a teammate, you both gain 5% haste while within 16 m of each other (until either is injured).',
    triggers: { [EV.SURVIVOR_HEALED]: (p, d, m) => { if (d.healer === p.owner && d.survivor !== p.owner) { p.data.buddy = d.survivor; m.perks.proc(p, 'Power of Two'); } } },
    update: (p, m) => { const b = p.data.buddy, s = p.owner; if (!b) return; if (s.health !== 'healthy' || b.health !== 'healthy') { p.data.buddy = null; return; } if (dist(s.x, s.y, b.x, b.y) < 16 * M) { s.status.add('haste', { duration: 0.3, value: 0.05, source: 'p2' }); b.status.add('haste', { duration: 0.3, value: 0.05, source: 'p2' }); } }, ai: { bias: { heal: 1.15 } } },
  boil_over: { id: 'boil_over', side: 'survivor', cat: 'rescue', name: 'Boil Over', icon: '♨', rarity: 'uncommon', tier: 'basic', weight: 2,
    description: 'You wiggle free from the killer\'s grasp 25% faster.' },
  inner_focus: { id: 'inner_focus', side: 'survivor', cat: 'stealth', name: 'Inner Focus', icon: '◬', rarity: 'uncommon', tier: 'basic', weight: 2,
    description: 'When a teammate is hit, you see the killer for 3 s.',
    triggers: { [EV.KILLER_HIT]: (p, d, m) => { if (d.survivor !== p.owner && p.owner.standing) m.revealKillerTo(p.owner, 3, 'Inner Focus'); } } },
  champion_of_light: { id: 'champion_of_light', side: 'survivor', cat: 'anti', name: 'Champion of Light', icon: '☀', rarity: 'rare', tier: 'strong', weight: 1,
    description: 'Your flashlight blinds 50% faster. Bots with this perk look for flashlight saves.', ai: { bias: { protect: 1.2, chest: 1.4 } } },
  low_profile: { id: 'low_profile', side: 'survivor', cat: 'endgame', name: 'Low Profile', icon: '▁', rarity: 'uncommon', tier: 'basic', weight: 2,
    description: 'As the last survivor standing, you leave no scratch marks or blood.' },
  sole_survivor: { id: 'sole_survivor', side: 'survivor', cat: 'endgame', name: 'Sole Survivor', icon: '☥', rarity: 'rare', tier: 'basic', weight: 2,
    description: 'Each dead teammate lets you hide your aura from the killer once more. As the last survivor you repair 75% faster.',
    triggers: { [EV.SURVIVOR_KILLED]: (p, d) => { if (d.survivor !== p.owner) p.tokens++; } },
    actionMult: (p, sv, type, m) => (type === 'repair' && m.aliveCount() === 1 ? 1.75 : 1) },
  wiretap_eye: { id: 'wiretap_eye', side: 'survivor', cat: 'anti', name: 'Ward Breaker', icon: '⊘', rarity: 'uncommon', tier: 'basic', weight: 2,
    description: 'You disarm killer traps, Phantasms and locker locks 40% faster, and chests 20% faster.',
    actionMult: (p, sv, type) => (type === 'disarm' || type === 'device' || type === 'wipe' ? 1.4 : type === 'searchChest' ? 1.2 : 1), ai: { bias: { chest: 1.2 } } },
  dodge_instinct: { id: 'dodge_instinct', side: 'survivor', cat: 'anti', name: 'Danger Sense', icon: '⚠', rarity: 'uncommon', tier: 'strong', weight: 2,
    description: 'You sense incoming projectiles, bounds and creatures a moment earlier (better dodges against ranged powers), but are Exhausted for 20 s after a successful dodge.',
    triggers: { dodged: (p, d, m) => { if (d.survivor === p.owner) { p.owner.status.add('exhausted', { duration: 20, source: 'danger' }); m.perks.proc(p, 'Danger Sense'); } } } },
});
// Categories for the original perks
const CAT = { sprint_burst: 'chase', lithe: 'chase', dead_hard: 'chase', adrenaline: 'endgame', self_care: 'healing', borrowed_time: 'rescue', bond: 'rescue', kindred: 'rescue', resilience: 'objective', prove_thyself: 'objective',
  iron_will: 'stealth', urban_evasion: 'stealth', spine_chill: 'stealth', decisive_strike: 'rescue', unbreakable: 'healing', deliverance: 'rescue', small_game: 'stealth', calm_spirit: 'stealth', windows_of_opportunity: 'chase',
  dark_sense: 'stealth', botany: 'healing', well_make_it: 'rescue' };
for (const [k, c] of Object.entries(CAT)) { SURVIVOR_PERKS[k].cat = c; SURVIVOR_PERKS[k].weight ??= SURVIVOR_PERKS[k].tier === 'strong' ? 3 : 2; }
for (const k of ['sprint_burst', 'lithe', 'dead_hard']) SURVIVOR_PERKS[k].exhaustion = true;
// AI usage hints for the original perks
SURVIVOR_PERKS.self_care.ai = { bias: { healSelf: 1.1 } };
SURVIVOR_PERKS.botany.ai = { bias: { heal: 1.25 } };
SURVIVOR_PERKS.well_make_it.ai = { bias: { rescue: 1.15 }, dynBias: (p, ai) => (p.data.until > ai.m.time ? { heal: 1.8 } : null) };
SURVIVOR_PERKS.borrowed_time.ai = { bias: { rescue: 1.15 } };
SURVIVOR_PERKS.prove_thyself.ai = { bias: { joinGen: 1.35 } };
SURVIVOR_PERKS.urban_evasion.ai = { bias: { hide: 0.25 } };
SURVIVOR_PERKS.iron_will.ai = { bias: { hide: 0.2 } };
SURVIVOR_PERKS.resilience.ai = { dynBias: (p, ai) => (ai.sv.health === 'injured' ? { healSelf: 0.7, repair: 1.1 } : null) };
SURVIVOR_PERKS.adrenaline.ai = { dynBias: (p, ai) => (ai.m.gensDone >= ai.m.gensNeeded - 1 ? { heal: 0.6, healSelf: 0.5 } : null) };
SURVIVOR_PERKS.deliverance.ai = { bias: { rescue: 1.2 } };
SURVIVOR_PERKS.dead_hard.ai = { exhaustion: 'dodge' };
SURVIVOR_PERKS.sprint_burst.ai = { exhaustion: 'burst' };

export const SURVIVOR_PERK_IDS = Object.keys(SURVIVOR_PERKS);
export const STRONG_SURVIVOR_PERKS = SURVIVOR_PERK_IDS.filter((k) => SURVIVOR_PERKS[k].tier === 'strong');
export const BASIC_SURVIVOR_PERKS = SURVIVOR_PERK_IDS.filter((k) => SURVIVOR_PERKS[k].tier === 'basic');
export const PERK_CATEGORIES = ['objective', 'chase', 'healing', 'stealth', 'rescue', 'endgame', 'anti'];
// Meta builds used in late story levels.
export const META_BUILDS = [
  ['dead_hard', 'borrowed_time', 'sprint_burst', 'adrenaline'],
  ['lithe', 'decisive_strike', 'kindred', 'prove_thyself'],
  ['sprint_burst', 'iron_will', 'spine_chill', 'windows_of_opportunity'],
  ['dead_hard', 'unbreakable', 'deliverance', 'adrenaline'],
  ['lithe', 'borrowed_time', 'well_make_it', 'kindred'],
  ['overcome', 'off_the_record', 'hyperfocus', 'stake_out'],
  ['dead_hard', 'circle_of_healing', 'reassurance', 'deja_vu'],
];
// Themed builds for scenarios: each is a weighted category mix plus must-have perks.
export const BUILD_THEMES = {
  chase: { cats: { chase: 4, stealth: 1, healing: 1, rescue: 1 }, must: ['dead_hard', 'lithe', 'sprint_burst', 'overcome', 'windows_of_opportunity', 'quick_and_quiet', 'smash_hit'] },
  objective: { cats: { objective: 5, stealth: 1, endgame: 1 }, must: ['prove_thyself', 'hyperfocus', 'stake_out', 'deja_vu', 'technician', 'resilience', 'repressed_alliance'] },
  stealth: { cats: { stealth: 5, objective: 1 }, must: ['urban_evasion', 'iron_will', 'lightweight', 'spine_chill', 'calm_spirit', 'lucky_break', 'premonition'] },
  rescue: { cats: { rescue: 5, healing: 2 }, must: ['borrowed_time', 'kindred', 'reassurance', 'babysitter', 'breakout', 'deliverance', 'off_the_record'] },
  healing: { cats: { healing: 5, rescue: 1 }, must: ['botany', 'self_care', 'empathy', 'solidarity', 'circle_of_healing', 'desperate_measures', 'well_make_it'] },
  counter: { cats: { anti: 5, stealth: 2, chase: 1 }, must: ['vigilant_eye', 'steadfast', 'dodge_instinct', 'wiretap_eye', 'champion_of_light', 'distortion', 'spine_chill'] },
  awareness: { cats: { stealth: 3, chase: 2 }, must: ['spine_chill', 'alert', 'premonition', 'dark_sense', 'kindred', 'windows_of_opportunity', 'small_game'] },
  endgame: { cats: { endgame: 4, rescue: 2 }, must: ['adrenaline', 'hope', 'wake_up', 'no_one_left_behind', 'left_behind', 'borrowed_time', 'decisive_strike'] },
};

function weightedTake(rng, pool, wf) {
  const tot = pool.reduce((a, k) => a + wf(k), 0); let r = rng() * tot;
  for (let i = 0; i < pool.length; i++) { r -= wf(pool[i]); if (r <= 0) return pool.splice(i, 1)[0]; }
  return pool.pop();
}
// Weighted random loadout: reasonable builds are common (one exhaustion perk at most,
// usually a spread of categories), unusual ones still possible.
export function randomSurvivorPerks(rng, mode = 'random', i = 0) {
  if (mode === 'none') return [];
  if (mode === 'meta') return [...META_BUILDS[(i + Math.floor(rng() * META_BUILDS.length)) % META_BUILDS.length]];
  const theme = BUILD_THEMES[mode];
  if (theme) {
    const must = [...theme.must]; const out = [];
    while (out.length < 2 && must.length) { const k = must.splice(Math.floor(rng() * must.length), 1)[0]; if (SURVIVOR_PERKS[k].exhaustion && out.some((q) => SURVIVOR_PERKS[q].exhaustion)) continue; out.push(k); }
    const pool = SURVIVOR_PERK_IDS.filter((k) => !out.includes(k));
    while (out.length < 4 && pool.length) {
      const k = weightedTake(rng, pool, (q) => (theme.cats[SURVIVOR_PERKS[q].cat] || 0.3) * (SURVIVOR_PERKS[q].weight || 2));
      if (SURVIVOR_PERKS[k].exhaustion && out.some((q) => SURVIVOR_PERKS[q].exhaustion)) continue;
      out.push(k);
    }
    return out;
  }
  const pool = mode === 'strong' ? [...STRONG_SURVIVOR_PERKS] : mode === 'basic' ? [...BASIC_SURVIVOR_PERKS] : [...SURVIVOR_PERK_IDS];
  const out = [];
  while (out.length < 4 && pool.length) {
    // repeated categories get less likely, so builds spread out (but stacking is still possible)
    const k = weightedTake(rng, pool, (q) => { const d = SURVIVOR_PERKS[q]; const same = out.filter((o) => SURVIVOR_PERKS[o].cat === d.cat).length; return (d.weight || 2) * Math.pow(0.45, same); });
    if (SURVIVOR_PERKS[k].exhaustion && out.some((q) => SURVIVOR_PERKS[q].exhaustion)) continue;
    out.push(k);
  }
  return out;
}
