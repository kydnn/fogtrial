// Survivor entity: physical state, health states, timed actions. The AI only sets
// intents (moveTo / moveMode / startAction); the rules live here and in the match.
import { M, clamp, dist, uid, normAngle } from '../core/util.js';
import { StatusManager } from '../core/status.js';
import { EV } from '../core/events.js';
import { GEN_CHARGES, PALLET_DROP_TIME } from './objects.js';
import { makeItem, ITEMS } from '../items/items.js';

export const SPEED = { run: 4.0 * M, walk: 2.26 * M, crouch: 1.13 * M, crawl: 0.7 * M };
export const BLEED_OUT = 240;
export const HOOK_STAGE_TIME = 60;

const ACTION_DEF = {
  repair:      { range: 2.1, label: 'Repairing' },
  heal:        { range: 1.9, label: 'Healing', dur: 16 },
  healSelf:    { range: 0, label: 'Self-healing', dur: 16 },
  unhook:      { range: 1.9, label: 'Unhooking', dur: 1.0 },
  dropPallet:  { range: 2.3, label: 'Pallet', dur: PALLET_DROP_TIME },
  openGate:    { range: 1.8, label: 'Opening gate', dur: 20 },
  searchChest: { range: 1.6, label: 'Searching', dur: 10 },
  cleanse:     { range: 1.6, label: 'Cleansing', dur: 14 },
  disarm:      { range: 1.5, label: 'Disarming', dur: 3 },
  freeTrapped: { range: 1.6, label: 'Freeing', dur: 2.5 },
  escapeTrap:  { range: 0, label: 'Escaping trap', dur: 1.2 },
  recover:     { range: 0, label: 'Recovering', dur: 32 },
  mend:        { range: 0, label: 'Mending', dur: 8 },
  openHatch:   { range: 1.6, label: 'Opening hatch', dur: 6 },
  flashlight:  { range: 7, label: 'Flashlight', dur: 99 },
  unhookSelf:  { range: 0, label: 'Unhook attempt', dur: 2.5 },
  device:      { range: 1.8, label: 'Using' },          // killer-power devices (printers, pods…)
  useEmp:      { range: 0, label: 'EMP', dur: 2.5 },
  breakChain:  { range: 0, label: 'Breaking chain', dur: 1.0 },   // Cenobite
  solveBox:    { range: 0, label: 'Solving the box', dur: 6 },     // Cenobite Lament Configuration
  spray:       { range: 0, label: 'First Aid Spray', dur: 1.5 },    // Mastermind
  vaccinate:   { range: 0, label: 'Injecting vaccine', dur: 3 },    // Nemesis
};

export class Survivor {
  constructor({ name, color, difficulty, personality, perks = [], item = null, itemAddons = [] }) {
    this.id = uid('sv'); this.kind = 'survivor';
    this.name = name; this.color = color; this.difficulty = difficulty; this.personality = personality;
    this.x = 0; this.y = 0; this.r = 0.44 * M; this.facing = 0; this.vx = 0; this.vy = 0;
    this.health = 'healthy'; // healthy | injured | dying | carried | hooked | dead | escaped
    this.status = new StatusManager(this);
    this.hookStage = 0; this.hookTimer = 0; this.hook = null; this.hookCount = 0; this.unhookAttempts = 0; this.hookedAt = -999; this.unhookedAt = -999;
    this.bleed = BLEED_OUT; this.recovery = 0; this.healProgress = 0; this.healers = new Set(); this.mend = 0;
    this.wiggle = 0; this.trap = null; this.trapAttempts = 0;
    this.item = makeItem(item, itemAddons);
    this.perks = perks; // perk instances, filled by perk system
    this.action = null; this.vault = null; this.moveTo = null; this.moveMode = 'run';
    this.scratchT = 0; this.bloodT = 0; this.gruntT = 2;
    this.lastHitT = -999; this.downedAt = -999; this.carriedSince = 0;
    this.stats = { gens: 0, heals: 0, unhooks: 0, pallets: 0, stuns: 0, vaults: 0, chaseTime: 0, hits: 0, escapes: 0, totems: 0, chests: 0 };
    this.outcome = null; this.ai = null;
    this.unbreakableUsed = false; this.dsReady = false; this.lookTarget = null; this.emp = false; this.stalk = 0;
  }
  get alive() { return this.health !== 'dead' && this.health !== 'escaped'; }
  get standing() { return this.health === 'healthy' || this.health === 'injured'; }
  get busy() { return !!this.action || !!this.vault; }
  hasPerk(id) { return this.perks.some((p) => p.id === id); }
  perk(id) { return this.perks.find((p) => p.id === id); }

  speed() {
    const mods = this.status.mods();
    if (this.trap) return 0;
    let base = this.health === 'dying' ? SPEED.crawl : SPEED[this.moveMode] || SPEED.run;
    if (this.moveMode === 'crouch' && this.hasPerk('urban_evasion')) base *= 1.9;
    return Math.max(0, base * (1 + mods.speedPct));
  }

  // ---- actions --------------------------------------------------------
  canStart(type, target, m) {
    const def = ACTION_DEF[type]; if (!def) return false;
    if (!this.standing && !(this.health === 'dying' && type === 'recover')) return false;
    if (this.vault) return false;
    if (this.trap && type !== 'escapeTrap') return false;
    if (this.control && !this.control.allow?.includes(type)) return false;
    if (this.status.has('incapacitated') || this.status.has('chained') || this.status.has('grabbed')) { if (!['breakChain', 'mend', 'dropPallet', 'recover', 'escapeTrap', 'spray'].includes(type)) return false; }
    if (def.range && target && dist(this.x, this.y, target.x, target.y) > def.range * M + (type === 'repair' ? 0.6 * M : 0)) return false;
    switch (type) {
      case 'repair': return !target.done && target.blockedUntil <= m.time && target.repairers.size < 4 && !this.status.has('incapacitated');
      case 'heal': return target !== this && (target.health === 'injured' || target.health === 'dying') && !target.status.has('broken');
      case 'healSelf': if (m.cfg.mode === '2v8' && !this.hasPerk('class_medic')) return false; // 2v8: no self-healing (Medic excepted)
        return this.health === 'injured' && !this.status.has('broken') && ((this.item?.id === 'medkit' && this.item.charges > 0) || this.hasPerk('self_care') || this.hasPerk('class_medic') || m.perks.anySurvivorHas('circle_of_healing'));
      case 'unhook': return target.health === 'hooked' && target.hook;
      case 'dropPallet': return target.state === 'up' && !target.dropping && !((target.blockedUntil || 0) > m.time);
      case 'openGate': return target.powered && !target.open && !((this.gateBlockUntil || 0) > m.time) && !((target.blockedUntil || 0) > m.time) && (!target.user || target.user === this);
      case 'searchChest': return !target.opened && (!target.user || target.user === this);
      case 'cleanse': return !target.cleansed && (!target.user || target.user === this);
      case 'disarm': return target.state === 'set';
      case 'freeTrapped': return !!target.trap && target !== this;
      case 'escapeTrap': return !!this.trap;
      case 'recover': return this.health === 'dying';
      case 'mend': return this.status.has('deepWound');
      case 'openHatch': return m.hatch.state === 'closed' && this.item?.id === 'key' && m.aliveCount() <= 2;
      case 'flashlight': return this.item?.id === 'flashlight' && this.item.charges > 0;
      case 'unhookSelf': return false;
      case 'device': return !target.dead && target.usable(this, m);
      case 'useEmp': return !!this.emp;
      case 'breakChain': return this.status.has('chained');
      case 'solveBox': return !!this.box;
      case 'spray': return (this.sprays || 0) > 0 && this.status.has('infected');
      case 'vaccinate': return (this.vaccines || 0) > 0 && this.status.has('contaminated');
    }
    return true;
  }
  startAction(type, target, m) {
    if (this.action && this.action.type === type && this.action.target === target) return true;
    if (!this.canStart(type, target, m)) return false;
    this.stopAction(m);
    this.action = { type, target, t: 0, dur: ACTION_DEF[type].dur || 0, label: ACTION_DEF[type].label };
    this.moveTo = null;
    if (target && type !== 'flashlight') this.facing = Math.atan2(target.y - this.y, target.x - this.x);
    if (type === 'repair') { target.repairers.add(this); target.regressing = false; this.scT = 3 + Math.random() * 6; m.events.emit(EV.GENERATOR_START, { gen: target, survivor: this }); }
    if (type === 'heal') { target.healers.add(this); m.events.emit('healStart', { healer: this, target }); }
    if (type === 'healSelf') this.healers.add(this);
    if (type === 'openGate' || type === 'searchChest' || type === 'cleanse') target.user = this;
    if (type === 'dropPallet') { target.dropping = true; }
    return true;
  }
  stopAction(m) {
    const a = this.action; if (!a) return;
    m?.events?.emit('survivorActionStop', { survivor: this, type: a.type, target: a.target, done: a.type === 'repair' ? !!a.target.done : undefined });
    if (a.type === 'repair') a.target.repairers.delete(this);
    if (a.type === 'heal') a.target.healers.delete(this);
    if (a.type === 'healSelf') this.healers.delete(this);
    if ((a.type === 'openGate' || a.type === 'searchChest' || a.type === 'cleanse') && a.target.user === this) a.target.user = null;
    if (a.type === 'dropPallet' && a.t < a.dur) a.target.dropping = false;
    this.action = null;
  }

  startVault(obj, quality, m) {
    if (this.vault || !this.standing || this.trap) return false;
    if (obj.kind === 'window' && obj.blockedUntil > m.time) return false;
    if (obj.kind === 'pallet' && obj.state !== 'down') return false;
    this.stopAction(m);
    const side = obj.sideOf(this);
    const sides = obj.sides(1.05 * M);
    const from = { x: this.x, y: this.y }; const to = sides[1 - side];
    // fast vault needs running momentum; slower vaults otherwise
    let dur = quality === 'fast' ? 0.5 : quality === 'medium' ? 0.9 : 1.2;
    const mods = this.status.mods(); if (this.hasPerk('resilience') && this.health === 'injured') dur *= 0.91;
    if (mods.actionPct) dur /= 1 + mods.actionPct * 0.5;
    this.vault = { obj, from, to, t: 0, dur, quality };
    this.facing = Math.atan2(to.y - from.y, to.x - from.x);
    m.onVault(this, obj, quality);
    return true;
  }

  takeHit(m, { instadown = false, source = 'basic' } = {}) {
    if (!this.standing) return false;
    this.stopAction(m); this.vault = null; this.lastHitT = m.time; this.stats.hits++;
    const mods = this.status.mods();
    if (mods.endurance && !instadown || (mods.endurance && instadown)) {
      this.status.remove('endurance');
      this.status.add('deepWound', { duration: 20 }); this.mend = 0;
      if (this.health === 'healthy') this.health = 'injured';
      this.status.add('haste', { duration: 1.8, value: 0.5, source: 'hit' });
      m.events.emit(EV.SURVIVOR_INJURED, { survivor: this, endurance: true });
      return 'endurance';
    }
    if (this.health === 'healthy' && !instadown && !mods.exposed) {
      this.health = 'injured'; this.healProgress = 0;
      this.status.add('haste', { duration: 1.8, value: 0.5, source: 'hit' });
      m.events.emit(EV.SURVIVOR_INJURED, { survivor: this, source });
      return 'injured';
    }
    this.goDown(m, source);
    return 'downed';
  }
  goDown(m, source) {
    this.stopAction(m); this.vault = null;
    if (this.trap) { this.trap.victim = null; this.trap.state = 'unset'; this.trap = null; }
    this.health = 'dying'; this.healProgress = 0; this.recovery = 0; this.downedAt = m.time;
    this.status.remove('deepWound'); this.status.remove('endurance'); this.status.remove('kaguneMark'); this.status.remove('latched');
    const by = this.lastHitBy && m.time - this.lastHitT < 1 ? this.lastHitBy : null;
    m.events.emit(EV.SURVIVOR_DOWNED, { survivor: this, source, killer: by });
  }

  // ---- update ---------------------------------------------------------
  update(dt, m) {
    this.status.update(dt);
    if (!this.alive || this.health === 'hooked' || this.health === 'carried') { this.vx = this.vy = 0; return; }
    const mods = this.status.mods();
    if (this.health === 'dying') {
      this.bleed -= dt * (m.collapse ? 2 : 1);
      if (this.bleed <= 0) { m.killSurvivor(this, 'bled out'); return; }
    }
    // Deep wound timer → goes down if not mended
    if (mods.deepWound && this.status.timeLeft('deepWound') < dt * 1.5 && this.health === 'injured') {
      this.status.remove('deepWound'); this.goDown(m, 'deepwound');
    }
    if (this.control) {
      const c = this.control, ox = this.x, oy = this.y;
      if (this.action && !c.allow?.includes(this.action.type)) this.stopAction(m);
      if (this.action) this.updateAction(dt, m, mods);
      if (c.update(dt, m, this) === false || !this.standing) { this.control = null; this.status.remove('grabbed'); }
      this.vx = (this.x - ox) / dt; this.vy = (this.y - oy) / dt;
      return;
    }
    if (this.vault) { this.updateVault(dt, m); return; }
    if (this.action) { this.updateAction(dt, m, mods); }
    if (this.action && this.action.type !== 'flashlight') { this.vx = this.vy = 0; return; }
    // movement
    let moved = 0;
    if (!this.isPlayer && this.lookUntil && this.lookUntil < m.time) { this.lookTarget = null; this.lookUntil = 0; }
    if (this.moveTo && !this.trap) {
      const dx = this.moveTo.x - this.x, dy = this.moveTo.y - this.y; const d = Math.hypot(dx, dy);
      if (d > 2) {
        const sp = this.speed(); const step = Math.min(d, sp * dt);
        const ox = this.x, oy = this.y;
        m.world.move(this, (dx / d) * step, (dy / d) * step, this.r, (s) => s.kind !== 'gate' || !s.ref.open);
        this.vx = (this.x - ox) / dt; this.vy = (this.y - oy) / dt; moved = Math.hypot(this.vx, this.vy);
        if (!this.action || this.action.type !== 'flashlight') {
          // survivors can deliberately look at something (e.g. to reveal Ghost Face) while moving
          const want = this.lookTarget ? Math.atan2(this.lookTarget.y - this.y, this.lookTarget.x - this.x) : Math.atan2(dy, dx);
          this.facing += normAngle(want - this.facing) * Math.min(1, dt * 14);
        }
      } else { this.vx = this.vy = 0; }
    } else { this.vx = this.vy = 0; if (this.lookTarget && !this.action) this.facing += normAngle(Math.atan2(this.lookTarget.y - this.y, this.lookTarget.x - this.x) - this.facing) * Math.min(1, dt * 12); }
    // Scratch marks while running; blood while injured; grunts of pain.
    if (this.health !== 'dying' && moved > SPEED.walk * 1.15) {
      this.scratchT -= dt; if (this.scratchT <= 0) { this.scratchT = 0.22; m.addScratch(this); }
      if (!this._wasRunning) { this._wasRunning = true; m.perks.survivorStartRun(this); }
    } else this._wasRunning = false;
    if (this.health === 'injured' || this.health === 'dying') {
      this.bloodT -= dt * (mods.hemorrhage ? 2.5 : 1); if (this.bloodT <= 0) { this.bloodT = 0.9 + Math.random() * 0.6; m.addBlood(this); }
      this.gruntT -= dt;
      const quietHeal = (this.action?.type === 'healSelf' && this.hasPerk('bite_the_bullet')) || [...this.healers].some((h) => h.hasPerk?.('bite_the_bullet')) || (this.silentUntil || 0) > m.time;
      if (this.gruntT <= 0 && quietHeal) this.gruntT = 1;
      if (this.gruntT <= 0) { this.gruntT = (2.5 + Math.random() * 2.5) / m.perks.killerProduct('gruntRate'); if (!this.hasPerk('iron_will') || this.health === 'dying') m.addGrunt(this); }
    }
  }

  updateVault(dt, m) {
    const v = this.vault; v.t += dt;
    const k = clamp(v.t / v.dur, 0, 1);
    this.x = v.from.x + (v.to.x - v.from.x) * k; this.y = v.from.y + (v.to.y - v.from.y) * k;
    this.vx = (v.to.x - v.from.x) / v.dur; this.vy = (v.to.y - v.from.y) / v.dur;
    if (k >= 1) { this.vault = null; m.world.resolve(this, this.r, (s) => s.kind !== 'gate' || !s.ref.open); if (v.quality === 'fast') m.perks.survivorFastVault(this); }
  }

  updateAction(dt, m, mods) {
    const a = this.action, tg = a.target;
    const def = ACTION_DEF[a.type];
    if (tg && def.range && dist(this.x, this.y, tg.x, tg.y) > def.range * M + 0.8 * M) { this.stopAction(m); return; }
    let speed = 1 + (mods.actionPct || 0);
    if (this.hasPerk('resilience') && this.health === 'injured') speed += 0.09;
    speed *= m.perks.actionMult(this, a.type);
    a.t += dt;
    switch (a.type) {
      case 'repair': {
        if (tg.done || tg.blockedUntil > m.time) { this.stopAction(m); return; }
        const n = tg.repairers.size; const eff = [1, 1, 0.9, 0.8, 0.7][n] || 0.7;
        let rate = eff * speed * (1 + (mods.repairPct || 0)) * (m.repairMult || 1);
        if (this.item?.id === 'toolbox' && this.item.charges > 0) { rate *= this.item.repairMult; this.item.charges -= dt; }
        if (this.hasPerk('prove_thyself') && n > 1) rate *= 1 + 0.15 * (n - 1) / n * 1.0;
        tg.charges += rate * dt; tg.lastRepairT = m.time; tg.regressing = false;
        this.stats.gens += rate * dt / GEN_CHARGES;
        // skill checks
        this.scT -= dt;
        if (this.scT <= 0) { this.scT = 4 + Math.random() * 9; m.skillCheck(this, tg); }
        if (tg.charges >= GEN_CHARGES) m.completeGenerator(tg);
        break;
      }
      case 'heal': {
        if (!(tg.health === 'injured' || tg.health === 'dying') || tg.status.has('broken')) { this.stopAction(m); return; }
        let rate = speed / 16 * (1 + (tg.status.mods().healPct || 0));
        if (this.item?.id === 'medkit' && this.item.charges > 0) { rate *= 1.25; this.item.charges -= dt * 0.5; }
        rate *= m.perks.healMult(this, tg);
        const n = tg.healers.size; if (n > 1) rate *= [1, 1, 0.85, 0.75, 0.65][n];
        tg.healProgress += rate * dt;
        if (this.isPlayer) { this.scT = (this.scT ?? 6) - dt; if (this.scT <= 0) { this.scT = 5 + Math.random() * 7; m.startPlayerCheck(this, 'heal', tg); } }
        if (this.health === 'injured' && this.hasPerk('solidarity')) { this.healProgress += rate * dt * 0.5; if (this.healProgress >= 1) m.healed(this, this); }
        if (tg.healProgress >= 1) { m.healed(tg, this); this.stopAction(m); }
        break;
      }
      case 'healSelf': {
        if (this.health !== 'injured') { this.stopAction(m); return; }
        let rate = speed / 16 * (1 + (mods.healPct || 0));
        if (this.item?.id === 'medkit' && this.item.charges > 0) { rate *= this.item.healSpeed; this.item.charges -= dt; }
        else rate *= 0.5; // Self-Care
        this.healProgress += rate * dt;
        if (this.healProgress >= 1) { m.healed(this, this); this.stopAction(m); }
        break;
      }
      case 'unhook': if (a.t >= a.dur) { m.unhook(tg, this); this.stopAction(m); } break;
      case 'dropPallet': if (a.t >= a.dur) { const p = tg; this.action = null; m.dropPallet(p, this); } break;
      case 'openGate': if (a.t * speed >= a.dur) { m.openGate(tg, this); this.stopAction(m); } break;
      case 'searchChest': if (a.t * speed >= a.dur) { m.openChest(tg, this); this.stopAction(m); } break;
      case 'cleanse': if (a.t * speed >= a.dur) { m.cleanseTotem(tg, this); this.stopAction(m); } break;
      case 'disarm': if (tg.state !== 'set') { this.stopAction(m); return; } if (a.t * speed >= a.dur) { m.disarmTrap(tg, this); this.stopAction(m); } break;
      case 'freeTrapped': if (!tg.trap) { this.stopAction(m); return; } if (a.t >= a.dur) { m.releaseTrap(tg, this); this.stopAction(m); } break;
      case 'escapeTrap': if (!this.trap) { this.stopAction(m); return; } if (a.t >= a.dur) { this.action = null; m.trapEscapeAttempt(this); } break;
      case 'recover': {
        const cap = this.hasPerk('unbreakable') && !this.unbreakableUsed ? 1 : 0.95;
        this.recovery = Math.min(cap, this.recovery + dt / 32 * (this.hasPerk('unbreakable') && !this.unbreakableUsed ? 1.35 : 1));
        if (this.recovery >= 1) { this.unbreakableUsed = true; this.health = 'injured'; this.recovery = 0; this.stopAction(m); m.events.emit(EV.SURVIVOR_HEALED, { survivor: this, healer: this, fromDying: true }); }
        break;
      }
      case 'mend': if (!this.status.has('deepWound')) { this.stopAction(m); return; } if (a.t >= a.dur) { this.status.remove('deepWound'); if (this.status.has('kaguneMark')) { this.status.remove('kaguneMark'); m.events.emit('kaguneMarkCleared', { survivor: this }); } this.stopAction(m); } break;
      case 'openHatch': if (a.t * this.item.hatchSpeed >= a.dur) { m.openHatchWithKey(this); this.stopAction(m); } break;
      case 'device': if (tg.dead) { this.stopAction(m); return; } if (!tg.manualComplete && a.t * speed >= tg.useTime) { this.stopAction(m); tg.onUse(this, m); m.events.emit('deviceUsed', { survivor: this, device: tg }); } break;
      case 'breakChain': if (a.t >= a.dur) { const c = this.status.get('chained'); if (c) { c.value = (c.value ?? 3) - 1; if (c.value <= 0) { this.status.remove('chained'); m.events.emit('chainsBroken', { survivor: this }); } } this.stopAction(m); if (this.status.has('chained')) this.startAction('breakChain', null, m); } break;
      case 'solveBox': if (a.t * speed >= a.dur) { this.stopAction(m); m.killerWith('solveBox').power.solveBox?.(this, m); } break;
      case 'spray': if (a.t >= a.dur) { this.stopAction(m); this.sprays--; this.status.remove('infected'); m.killerWith('onSpray').power.onSpray?.(this, m); } break;
      case 'vaccinate': if (a.t >= a.dur) { this.stopAction(m); this.vaccines--; this.status.remove('contaminated'); this.ai?.note('Vaccinated — no longer contaminated', 'vax'); m.warn(this, 'Vaccinated'); } break;
      case 'useEmp': this.status.add('hindered', { duration: 0.15, value: 0.1, source: 'emp' }); if (a.t >= a.dur) { this.stopAction(m); m.killerWith('useEmp').power.useEmp?.(this, m); this.emp = false; } break;
      case 'flashlight': {
        if (!this.item || this.item.charges <= 0) { this.stopAction(m); return; }
        this.item.charges -= dt; m.flashlightTick(this, dt);
        if (a.t > 2.2) this.stopAction(m);
        break;
      }
    }
  }
}
export { ACTION_DEF, ITEMS };
