// Interactable map objects. Positions are world pixels.
import { M, uid } from '../core/util.js';

export const GEN_CHARGES = 90;        // seconds of solo repair
export const PALLET_DROP_TIME = 0.35;

// A vaultable low wall. alongX: obstacle line runs along x, so crossing is along y.
export class Window {
  constructor({ cx, cy, len, alongX }) {
    this.id = uid('win'); this.kind = 'window';
    this.x = cx * M; this.y = cy * M; this.alongX = alongX; this.len = len * M;
    const t = 1 * M; // matches template cell thickness
    this.rect = alongX ? { x: this.x - this.len / 2, y: this.y - t / 2, w: this.len, h: t } : { x: this.x - t / 2, y: this.y - this.len / 2, w: t, h: this.len };
    this.solid = { ...this.rect, blocksMove: true, blocksLOS: false, kind: 'window', ref: this };
    this.blockedUntil = 0;        // entity block (survivors cannot vault)
    this.killerBlockedUntil = 0;  // e.g. Bamboozle
    this.nx = alongX ? 0 : 1; this.ny = alongX ? 1 : 0; // crossing normal
    this.tile = null;
  }
  sides(off = 0.95 * M) { return [{ x: this.x - this.nx * off, y: this.y - this.ny * off }, { x: this.x + this.nx * off, y: this.y + this.ny * off }]; }
  sideOf(p) { return (p.x - this.x) * this.nx + (p.y - this.y) * this.ny < 0 ? 0 : 1; }
}

export class Pallet {
  constructor({ cx, cy, len, alongX }) {
    this.id = uid('pal'); this.kind = 'pallet';
    this.x = cx * M; this.y = cy * M; this.alongX = alongX; this.len = len * M;
    const t = 0.7 * M;
    this.rect = alongX ? { x: this.x - this.len / 2, y: this.y - t / 2, w: this.len, h: t } : { x: this.x - t / 2, y: this.y - this.len / 2, w: t, h: this.len };
    this.solid = { ...this.rect, blocksMove: true, blocksLOS: false, kind: 'pallet', ref: this };
    this.state = 'up'; this.dropT = 0; this.dropper = null;
    this.nx = alongX ? 0 : 1; this.ny = alongX ? 1 : 0;
    this.tile = null;
  }
  sides(off = 1.0 * M) { return [{ x: this.x - this.nx * off, y: this.y - this.ny * off }, { x: this.x + this.nx * off, y: this.y + this.ny * off }]; }
  sideOf(p) { return (p.x - this.x) * this.nx + (p.y - this.y) * this.ny < 0 ? 0 : 1; }
  // distance from point to the pallet's line segment (used for stun zone)
  stunZone(p) {
    const lx = Math.abs((p.x - this.x) * (this.alongX ? 1 : 0) + (p.y - this.y) * (this.alongX ? 0 : 1));
    const ln = Math.abs((p.x - this.x) * this.nx + (p.y - this.y) * this.ny);
    return lx < this.len / 2 + 0.2 * M && ln < 1.0 * M;
  }
}

export class Generator {
  constructor(x, y, name) {
    this.id = uid('gen'); this.kind = 'generator'; this.name = name;
    this.x = x; this.y = y; this.charges = 0; this.done = false;
    this.repairers = new Set(); this.regressing = false; this.regressRate = 0;
    this.blockedUntil = 0; this.lastRepairT = -999; this.kickT = -999; this.popArmed = false;
    const s = 1.4 * M;
    this.solid = { x: x - s / 2, y: y - s / 2, w: s, h: s, blocksMove: true, blocksLOS: false, kind: 'generator', ref: this };
  }
  get progress() { return this.charges / GEN_CHARGES; }
  slots() {
    const o = 1.25 * M;
    return [{ x: this.x, y: this.y - o }, { x: this.x + o, y: this.y }, { x: this.x, y: this.y + o }, { x: this.x - o, y: this.y }];
  }
}

export class Hook {
  constructor(x, y) { this.id = uid('hook'); this.kind = 'hook'; this.x = x; this.y = y; this.survivor = null; this.broken = false; }
}

export class Chest {
  constructor(x, y) { this.id = uid('chest'); this.kind = 'chest'; this.x = x; this.y = y; this.opened = false; this.progress = 0; this.user = null; }
}

export class Totem {
  constructor(x, y) { this.id = uid('totem'); this.kind = 'totem'; this.x = x; this.y = y; this.hex = null; this.cleansed = false; this.progress = 0; this.user = null; }
}

export class ExitGate {
  // side: 'n','s','e','w'. doorRect blocks the corridor until open; exitRect = escape zone.
  constructor({ x, y, side, doorRect, exitRect, name }) {
    this.id = uid('gate'); this.kind = 'gate'; this.name = name;
    this.x = x; this.y = y; this.side = side; this.doorRect = doorRect; this.exitRect = exitRect;
    this.powered = false; this.progress = 0; this.open = false; this.user = null;
    this.solid = { ...doorRect, blocksMove: true, blocksLOS: true, kind: 'gate', ref: this };
  }
}

export class Hatch {
  constructor(x, y) { this.kind = 'hatch'; this.x = x; this.y = y; this.state = 'hidden'; this.keyProgress = 0; }
}

export class Trap {
  constructor(x, y, state = 'unset') {
    this.id = uid('trap'); this.kind = 'trap'; this.x = x; this.y = y; this.state = state; this.victim = null;
    this.inGrass = false; this.disarmProgress = 0; this.setT = 0;
  }
}
