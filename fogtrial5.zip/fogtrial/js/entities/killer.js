// Killer entity (player controlled): movement, lunge attack, interactions, carrying,
// stuns, bloodlust. Powers plug in via killers/*.js.
import { M, clamp, dist, normAngle, angleDiff, uid } from '../core/util.js';
import { StatusManager } from '../core/status.js';
import { EV } from '../core/events.js';

export const KILLER_ACTIONS = {
  kick: { dur: 1.8, label: 'Damaging generator' },
  break: { dur: 2.6, label: 'Breaking pallet' },
  vault: { dur: 1.7, label: 'Vaulting' },
  pickup: { dur: 1.5, label: 'Picking up' },
  hook: { dur: 1.2, label: 'Hooking' },
  closeHatch: { dur: 1.5, label: 'Closing hatch' },
};

export class Killer {
  constructor(def, PowerClass, { perks = [], addons = [] } = {}) {
    this.id = uid('k'); this.kind = 'killer'; this.def = def; this.name = def.name;
    this.x = 0; this.y = 0; this.r = 0.56 * M; this.facing = 0; this.vx = 0; this.vy = 0;
    this.status = new StatusManager(this);
    this.perks = perks; this.addons = addons;
    this.carrying = null; this.action = null; this.stunT = 0; this.stunKind = null;
    this.attack = { state: 'ready', t: 0, held: 0, dir: 0, hitSomeone: false };
    this.bloodlust = 0; this.chaseT = 0;
    this.input = { mx: 0, my: 0, aim: 0, lmb: false, lmbP: false, rmb: false, rmbP: false, rmbR: false, e: false, eP: false, space: false, spaceP: false };
    this.power = new PowerClass(this, addons);
    this.terrorRadius = def.terror * M;
    this.baseTerror = this.terrorRadius; this.blindT = 0; this.lastSpeed = 0;
    this.stats = { hits: 0, downs: 0, hooks: 0, kicks: 0, palletsBroken: 0, stuns: 0, missed: 0, powerHits: 0 };
  }
  hasPerk(id) { return this.perks.some((p) => p.id === id); }
  get busy() { return !!this.action || this.stunT > 0; }

  baseSpeed(m) {
    const mods = this.status.mods();
    let s = this.def.speed * M;
    if (this.carrying) s = 3.68 * M * (this.hasPerk('agitation') ? 1.18 : 1);
    s *= this.power.speedMult(m);
    if (this.attack.state === 'lunge') s *= 1.55 * (m ? m.perks.killerProduct('lungeMult', this) : 1);
    else if (this.attack.state === 'hit') s *= this.attack.t < 1.2 ? 0.3 : 0.7;
    else if (this.attack.state === 'miss') s *= 0.55;
    s += this.bloodlust * 0.2 * M;
    return Math.max(0, s * (1 + mods.speedPct));
  }

  update(dt, m) {
    this.status.update(dt);
    this.blindT = Math.max(0, this.blindT - dt);
    const inp = this.input;
    if (this.stunT > 0) { this.stunT -= dt; this.vx = this.vy = 0; if (this.stunT <= 0) this.stunKind = null; this.power.update(dt, m, inp, true); this.clearPresses(); return; }
    if (inp.aim !== null && !this.power.lockFacing) this.facing = inp.aim;
    // Timed action
    if (this.action) { this.updateAction(dt, m); this.power.update(dt, m, inp, true); this.clearPresses(); return; }
    // Attack state machine
    const at = this.attack;
    if (at.state === 'lunge') {
      at.t += dt;
      const hit = this.tryHit(m);
      if (hit) { at.state = 'hit'; at.t = 0; }
      else if ((!inp.lmb && at.t > 0.15) || at.t > 0.5) { at.state = 'miss'; at.t = 0; this.stats.missed++; m.events.emit(EV.KILLER_MISS, { killer: this }); }
    } else if (at.state === 'hit') { at.t += dt; if (at.t > 2.7 * m.perks.killerCooldownMult('hit', this)) at.state = 'ready'; }
    else if (at.state === 'miss') { at.t += dt; if (at.t > 1.5 * m.perks.killerCooldownMult('miss', this)) at.state = 'ready'; }
    if (inp.lmbP && at.state === 'ready' && !this.carrying && this.power.canAttack(m) && !this.status.has('cannotAttack')) { at.state = 'lunge'; at.t = 0; at.dir = this.facing; m.fx.swing(this); this.power.onAttack?.(m); }

    // Space: context interaction
    if (inp.spaceP && at.state !== 'lunge') { const c = m.killerContext(this); if (c) this.startAction(c.type, c.target, m); }
    // Drop carried survivor (RMB/Q while carrying)
    if (this.carrying && inp.rmbP) { m.dropCarried('drop', this); }

    this.power.update(dt, m, inp, false);
    // Movement
    let mx = inp.mx, my = inp.my;
    if (this.power.overrideMove) { const o = this.power.overrideMove(dt, m); if (o) { mx = o.x; my = o.y; } }
    if (at.state === 'lunge') { const a = this.facing; const l = Math.hypot(mx, my); mx = Math.cos(a) * Math.max(0.6, l); my = Math.sin(a) * Math.max(0.6, l); }
    const l = Math.hypot(mx, my);
    if (l > 0.01) {
      const sp = this.baseSpeed(m); const ox = this.x, oy = this.y;
      const pf = this.power.moveFilter?.(m);
      const collided = m.world.move(this, (mx / l) * sp * dt, (my / l) * sp * dt, this.r, (s) => !(s.kind === 'gate' && s.ref.open) && (!pf || pf(s)));
      m.separateKiller(this);
      this.vx = (this.x - ox) / dt; this.vy = (this.y - oy) / dt;
      if (collided && this.power.onCollide) this.power.onCollide(m);
    } else { this.vx = this.vy = 0; }
    this.lastSpeed = Math.hypot(this.vx, this.vy);
    m.checkKillerTraps?.(this);
    this.clearPresses();
  }
  clearPresses() { const i = this.input; i.lmbP = i.rmbP = i.rmbR = i.eP = i.spaceP = false; i.wheel = 0; i.slot = 0; i.cycleP = false; }

  tryHit(m) {
    const reach = this.r + 1.0 * M + (this.attack.t > 0.25 ? 0.35 * M : 0);
    let best = null, bd = 1e9;
    for (const s of m.survivors) {
      if (!s.standing) continue;
      const d = dist(this.x, this.y, s.x, s.y); if (d > reach + s.r) continue;
      const ang = Math.atan2(s.y - this.y, s.x - this.x);
      if (angleDiff(ang, this.facing) > 0.85 && d > this.r + s.r + 4) continue;
      if (!m.world.losClear(this.x, this.y, s.x, s.y)) continue;
      if (s.vault && s.vault.t < s.vault.dur * 0.15) continue;
      if (d < bd) { bd = d; best = s; }
    }
    if (!best) return false;
    // Dead Hard style dodge: active i-frames
    if (best.dodgeT && best.dodgeT > m.time) { m.fx.text(best.x, best.y - 30, 'DODGED', '#ffd27a'); m.events.emit(EV.KILLER_MISS, { killer: this, dodged: best }); return false; }
    best.lastHitBy = this; const res = best.takeHit(m, { source: 'basic' });
    this.stats.hits++; this.attack.hitSomeone = true; this.bloodlust = 0; this.chaseT = 0;
    m.events.emit(EV.KILLER_HIT, { killer: this, survivor: best, result: res });
    m.fx.hit(best, res);
    return true;
  }

  startAction(type, target, m) {
    // 'custom' actions come from killer powers: target = { dur, label, done(m), tick?(m, a) }
    const def = type === 'custom' ? { dur: target.dur, label: target.label } : KILLER_ACTIONS[type]; if (!def) return;
    let dur = def.dur * (type === 'custom' ? 1 : m.perks.killerActionMult(type, this) * (this.power.actionMult?.(type, target, m) ?? 1));
    this.action = { type, target, t: 0, dur, label: def.label, from: { x: this.x, y: this.y } };
    if (type === 'vault') { const side = target.sideOf(this); this.action.to = target.sides(1.2 * M)[1 - side]; }
    if (type === 'pickup') m.events.emit('pickupStart', { killer: this, survivor: target });
    this.attack.state = 'ready';
  }
  updateAction(dt, m) {
    const a = this.action; a.t += dt;
    if (a.type === 'vault') { const k = clamp(a.t / a.dur, 0, 1); this.x = a.from.x + (a.to.x - a.from.x) * k; this.y = a.from.y + (a.to.y - a.from.y) * k; }
    if (a.type === 'pickup' && (a.target.health !== 'dying')) { this.action = null; return; }
    if (a.type === 'custom' && a.target.tick && a.target.tick(m, a) === false) { this.action = null; return; }
    if (a.t >= a.dur) {
      this.action = null;
      switch (a.type) {
        case 'kick': m.kickGenerator(a.target, this); break;
        case 'break': m.breakPallet(a.target, this); break;
        case 'vault': m.world.resolve(this, this.r); m.events.emit(EV.VAULT_PERFORMED, { who: this, obj: a.target }); if (this.hasPerk('bamboozle')) a.target.blockedUntil = Math.max(a.target.blockedUntil, m.time + 8); break;
        case 'pickup': m.pickUp(a.target, this); break;
        case 'hook': m.hookSurvivor(a.target, false, this); break;
        case 'closeHatch': m.closeHatch(); break;
        case 'custom': a.target.done(m); break;
      }
    }
  }
  stun(m, t, kind) {
    if (this.hasPerk('enduring') && kind === 'pallet') t *= 0.5;
    t *= m.perks.killerProduct('stunMult', this);
    this.stunT = Math.max(this.stunT, t); this.stunKind = kind; this.action = null; this.attack.state = 'ready';
    this.bloodlust = 0; this.stats.stuns++;
    if (this.carrying) m.dropCarried('stun', this);
    this.power.onStun?.(m);
    m.events.emit(EV.KILLER_STUNNED, { killer: this, kind });
  }
}
