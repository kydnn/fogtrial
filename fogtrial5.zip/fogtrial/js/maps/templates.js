// Chase-tile templates authored as 1m-per-character grids.
//  '#' wall   'W' window (vaultable low wall)   'P' pallet (stands in a gap)
//  'r' rock   'T' tree   'g' tall grass   'L' shack/building wall (same as # but drawn as wood)
//  'C' shipping container / metal crate (solid)   'w' water / tar pit (blocks movement, NOT sight)
//  '.' open ground
// Each template carries chase metadata the AI reasons about.
export const TEMPLATES = {
  jungle_gym: {
    type: 'jungle_gym', label: 'Jungle Gym', safety: 0.75, weight: 4,
    rows: [
      '..............',
      '.#####W####...',
      '.#............',
      '.#............',
      '.P......#.....',
      '.P......#.....',
      '.#......#.....',
      '.#......####W#',
      '.####.........',
      '..............',
    ],
  },
  jungle_gym_b: {
    type: 'jungle_gym', label: 'Jungle Gym', safety: 0.7, weight: 3,
    rows: [
      '.............',
      '.####PP####..',
      '......#......',
      '......#......',
      '.#....#....#.',
      '.W....W....#.',
      '.#.........#.',
      '.##########..',
      '.............',
    ],
  },
  shack: {
    type: 'shack', label: 'Shack', safety: 0.85, weight: 2, unique: true,
    rows: [
      '..............',
      '..LLLLLLLLLL..',
      '..L........L..',
      '..L........W..',
      '..L..LL....L..',
      '..W........L..',
      '..L........L..',
      '..LLLL..LLLL..',
      '..............',
      '....##PP##....',
      '..............',
    ],
  },
  t_wall: {
    type: 't_wall', label: 'T-Wall', safety: 0.55, weight: 3,
    rows: [
      '...........',
      '.####PP###.',
      '.....#.....',
      '.....#.....',
      '.....#.....',
      '.....#.....',
      '...........',
    ],
  },
  l_wall: {
    type: 'l_wall', label: 'L-Wall', safety: 0.5, weight: 3,
    rows: [
      '.........',
      '.#####...',
      '.#.......',
      '.#.......',
      '.#....##.',
      '.P.......',
      '.P.......',
      '.#.......',
      '.........',
    ],
  },
  long_wall: {
    type: 'long_wall', label: 'Long Wall', safety: 0.6, weight: 2,
    rows: [
      '..................',
      '..gg..............',
      '.#######W########.',
      '..............gg..',
      '..................',
    ],
  },
  short_wall: {
    type: 'short_wall', label: 'Short Wall', safety: 0.3, weight: 2,
    rows: [
      '.........',
      '.###PP##.',
      '.........',
    ],
  },
  debris: {
    type: 'debris', label: 'Debris Pallet', safety: 0.25, weight: 3,
    rows: [
      '..........',
      '..rr......',
      '..rrPPrr..',
      '......rr..',
      '..........',
    ],
  },
  rocks: {
    type: 'filler', label: 'Rocks', safety: 0.15, weight: 3, filler: true,
    rows: [
      '.......',
      '..rr...',
      '.rrr.r.',
      '..r..rr',
      '.......',
    ],
  },
  trees: {
    type: 'filler', label: 'Trees', safety: 0.12, weight: 3, filler: true,
    rows: [
      '........',
      '.T...T..',
      '...g....',
      '..ggT.T.',
      '.T..g...',
      '........',
    ],
  },
  grass: {
    type: 'grass', label: 'Tall Grass', safety: 0, weight: 2, filler: true,
    rows: [
      '.ggggg.',
      'ggggggg',
      'gggTggg',
      'ggggggg',
      '.ggg...',
    ],
  },
  // Main buildings (one per map, themed)
  main_house: {
    type: 'main', label: 'Farmhouse', safety: 0.9, weight: 0, main: true,
    rows: [
      '......................',
      '.LLLLLLLLL..LLLLLLLLL.',
      '.L..................L.',
      '.L..................L.',
      '.L...LLLLLWLLLLL....L.',
      '.L...L.........L....W.',
      '.W...L.........L....L.',
      '.L...P.........P....L.',
      '.L...P.........P....L.',
      '.L...L.........L....L.',
      '.L...LLLLL..LLLL....L.',
      '.L..................L.',
      '.LLLLLLLLLLWWLLLLLLLL.',
      '......................',
    ],
  },
  main_temple: {
    type: 'main', label: 'Ruined Chapel', safety: 0.85, weight: 0, main: true,
    rows: [
      '....................',
      '..rr.....rr.....rr..',
      '..rr.###W##.....rr..',
      '.....#.....#........',
      '.....#.....P.....rr.',
      '.rr..W.....P.....rr.',
      '.rr..#.....#........',
      '.....###PP##........',
      '..rr.........rr.....',
      '..rr.........rr.....',
      '....................',
    ],
  },
  main_factory: {
    type: 'main', label: 'Foundry Hall', safety: 0.88, weight: 0, main: true,
    rows: [
      '........................',
      '.######W######..#######.',
      '.#....................#.',
      '.#...##...........##..W.',
      '.#...##....###....##..#.',
      '.P.........#.#........#.',
      '.P.........#.#........P.',
      '.#...##....#W#....##..P.',
      '.#...##...........##..#.',
      '.#....................#.',
      '.###########..##W######.',
      '........................',
    ],
  },

  // ---------------- expansion tiles (new maps) ----------------
  container_yard: {
    type: 'containers', label: 'Container Stack', safety: 0.62, weight: 3,
    rows: [
      '..............',
      '.CCCCPPCCCCC..',
      '.C..........C.',
      '.C...CC.....C.',
      '.C...CC.....C.',
      '.CCCC..CWWCCC.',
      '..............',
    ],
  },
  container_row: {
    type: 'containers', label: 'Container Row', safety: 0.35, weight: 2,
    rows: [
      '...............',
      '.CCCCC..CCCCCC.',
      '.CCCCC..CCCCCC.',
      '...............',
    ],
  },
  cabin: {
    type: 'shack', label: 'Cabin', safety: 0.78, weight: 2,
    rows: [
      '.............',
      '..LLLLWLLL...',
      '..L......L...',
      '..W......L...',
      '..L......W...',
      '..LLL..LLL...',
      '.............',
      '...rrPPrr....',
      '.............',
    ],
  },
  fence_run: {
    type: 'long_wall', label: 'Fence Run', safety: 0.58, weight: 2,
    rows: [
      '.....................',
      '.######W#######W####.',
      '.....................',
    ],
  },
  double_pallet: {
    type: 'jungle_gym', label: 'Pallet Box', safety: 0.7, weight: 2,
    rows: [
      '...........',
      '.####PP###.',
      '.#.......#.',
      '.#.......#.',
      '.###PP####.',
      '...........',
    ],
  },
  ridge_gap: {
    type: 'ridge', label: 'Rock Ridge', safety: 0.45, weight: 3,
    rows: [
      '.................',
      '.rrrrrrPPrrrrrr..',
      '.rr..........rr..',
      '.................',
    ],
  },
  ridge_window: {
    type: 'ridge', label: 'Ridge Cut', safety: 0.5, weight: 2,
    rows: [
      '..............',
      '.rrrr.........',
      '.rrrr#W#rrrrr.',
      '.........rrrr.',
      '..............',
    ],
  },
  ward_pillars: {
    type: 'room', label: 'Pillared Ward', safety: 0.55, weight: 2,
    rows: [
      '...........',
      '.##.....##.',
      '.##..P..##.',
      '.....P.....',
      '.##.....##.',
      '.##.....##.',
      '...........',
    ],
  },
  hedge_loop: {
    type: 'jungle_gym', label: 'Hedge Loop', safety: 0.66, weight: 3,
    rows: [
      '.............',
      '.TTTT.TTTTT..',
      '.T.........T.',
      '.P....TT...T.',
      '.P....TT...W.',
      '.T.........T.',
      '.TTTTTT.TTT..',
      '.............',
    ],
  },
  dock_crane: {
    type: 'containers', label: 'Crane Base', safety: 0.5, weight: 2,
    rows: [
      '..........',
      '.##....##.',
      '.##....##.',
      '....PP....',
      '.##....##.',
      '.##....##.',
      '..........',
    ],
  },
  // expansion main buildings
  main_lodge: {
    type: 'main', label: 'Mountain Lodge', safety: 0.88, weight: 0, main: true,
    rows: [
      '......................',
      '.LLLLLLLWLLLLLLLLLLLL.',
      '.L.........L........L.',
      '.L.........L........W.',
      '.L...LL....P........L.',
      '.W...LL....P...LLL..L.',
      '.L.........L...L....L.',
      '.LLLLL..LLLLLLLL..LLL.',
      '......................',
      '..rr..rPPr...rr.......',
      '......................',
    ],
  },
  main_cathedral: {
    type: 'main', label: 'Grove Cathedral', safety: 0.86, weight: 0, main: true,
    rows: [
      '...................',
      '.#######WW#######..',
      '.#..............#..',
      '.#..##......##..#..',
      '.#..##......##..#..',
      '.P..............P..',
      '.P..............P..',
      '.#..##......##..#..',
      '.#..##......##..#..',
      '.#..............#..',
      '.######....######..',
      '...................',
    ],
  },
  main_warehouse: {
    type: 'main', label: 'Dock Warehouse', safety: 0.87, weight: 0, main: true,
    rows: [
      '........................',
      '.######W#######..######.',
      '.#......................',
      '.#..CCC....CCC....CCC.#.',
      '.#..CCC....CCC....CCC.#.',
      '.P....................W.',
      '.P....................#.',
      '.#..CCC....CCC....CCC.#.',
      '.#..CCC....CCC....CCC.#.',
      '.#....................#.',
      '.###########..#####W###.',
      '........................',
    ],
  },
  main_office: {
    type: 'main', label: 'Quarry Office', safety: 0.84, weight: 0, main: true,
    rows: [
      '..................',
      '.LLLLLLLWLLLLLL...',
      '.L............L...',
      '.L...rrrr.....W...',
      '.W...rrrr.....L...',
      '.L............L...',
      '.LLLLL..LLLLPPL...',
      '..................',
    ],
  },
};

// Rotate a char grid by k*90 degrees clockwise.
export function rotateRows(rows, k) {
  let g = rows.map((r) => r.split(''));
  const w = Math.max(...rows.map((r) => r.length));
  g = g.map((r) => { while (r.length < w) r.push('.'); return r; });
  for (let t = 0; t < (k % 4 + 4) % 4; t++) {
    const H = g.length, W = g[0].length;
    const n = Array.from({ length: W }, () => Array(H).fill('.'));
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) n[x][H - 1 - y] = g[y][x];
    g = n;
  }
  return g;
}

const SOLID = { '#': 'wall', L: 'wood', r: 'rock', T: 'tree', C: 'metal', w: 'water' };

// Parse a (rotated) grid into world pieces in meter coordinates relative to origin (ox, oy).
export function parseTemplate(grid, ox, oy) {
  const H = grid.length, W = grid[0].length;
  const at = (x, y) => (x < 0 || y < 0 || x >= W || y >= H ? '.' : grid[y][x]);
  const isWallish = (c) => c === '#' || c === 'L' || c === 'W' || c === 'r' || c === 'T' || c === 'C';
  const solids = [], windows = [], pallets = [], grass = [];
  // Solid rects: merge horizontal runs per kind, then merge vertically identical runs.
  for (const ch of Object.keys(SOLID)) {
    const runs = [];
    for (let y = 0; y < H; y++) {
      let x = 0;
      while (x < W) {
        if (grid[y][x] === ch) { let x2 = x; while (x2 + 1 < W && grid[y][x2 + 1] === ch) x2++; runs.push({ x, y, w: x2 - x + 1, h: 1 }); x = x2 + 1; }
        else x++;
      }
    }
    // vertical merge
    const merged = [];
    for (const r of runs) {
      const m = merged.find((q) => q.x === r.x && q.w === r.w && q.y + q.h === r.y);
      if (m) m.h++; else merged.push({ ...r });
    }
    // trees/rocks: single cells are fine
    for (const r of merged) solids.push({ x: ox + r.x, y: oy + r.y, w: r.w, h: r.h, kind: SOLID[ch] });
  }
  const seen = new Set();
  const group = (ch, x, y) => {
    // contiguous run horizontal or vertical
    const cells = [[x, y]]; seen.add(x + ',' + y);
    let horiz = at(x + 1, y) === ch, vert = at(x, y + 1) === ch;
    if (horiz) { let k = x + 1; while (at(k, y) === ch) { cells.push([k, y]); seen.add(k + ',' + y); k++; } }
    else if (vert) { let k = y + 1; while (at(x, k) === ch) { cells.push([x, k]); seen.add(x + ',' + k); k++; } }
    return { cells, horiz, vert };
  };
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const c = grid[y][x];
    if (c === 'g') grass.push({ x: ox + x + 0.5, y: oy + y + 0.5 });
    if ((c === 'W' || c === 'P') && !seen.has(x + ',' + y)) {
      const g = group(c, x, y);
      const x0 = Math.min(...g.cells.map((q) => q[0])), x1 = Math.max(...g.cells.map((q) => q[0]));
      const y0 = Math.min(...g.cells.map((q) => q[1])), y1 = Math.max(...g.cells.map((q) => q[1]));
      // orientation: does the obstacle line run along x? (walls on left/right ends)
      let alongX;
      if (g.horiz) alongX = true; else if (g.vert) alongX = false;
      else alongX = isWallish(at(x0 - 1, y0)) || isWallish(at(x1 + 1, y0));
      const piece = { cx: ox + (x0 + x1 + 1) / 2, cy: oy + (y0 + y1 + 1) / 2, len: alongX ? x1 - x0 + 1 : y1 - y0 + 1, alongX };
      (c === 'W' ? windows : pallets).push(piece);
    }
  }
  return { solids, windows, pallets, grass, w: W, h: H };
}
