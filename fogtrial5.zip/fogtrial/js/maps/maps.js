// Data-driven map definitions. Sizes are in meters (1 m = 32 px). Every map is far
// larger than the viewport; the generator lays out tiles differently per seed.
export const MAPS = {
  rotwood: {
    id: 'rotwood', name: 'Rotwood Forest', blurb: 'Dense pines, a ruined chapel and plenty of rock cover.',
    size: [104, 104], main: 'main_temple', tiles: 15, fillers: 30, grassPatches: 22, gens: 7, hooks: 12,
    weights: { jungle_gym: 4, jungle_gym_b: 3, shack: 1, t_wall: 3, l_wall: 3, long_wall: 2, short_wall: 2, debris: 3 },
    fillerWeights: { rocks: 3, trees: 6, grass: 2 },
    theme: { ground: '#18201a', ground2: '#1d261e', speck: '#2a3628', wall: '#5e625a', wallTop: '#7a7f74', wood: '#5c4630', woodTop: '#77603f', rock: '#4b4f4b', rockTop: '#646a64', tree: '#16251a', treeTop: '#24402a', grass: '#2c4a2a', border: '#0c100c', fog: [150, 175, 160] },
  },
  ashfarm: {
    id: 'ashfarm', name: 'Ashen Farm', blurb: 'An open farmstead. Tall corn hides survivors; tiles are spread out.',
    size: [116, 92], main: 'main_house', tiles: 13, fillers: 18, grassPatches: 34, gens: 7, hooks: 12,
    weights: { jungle_gym: 3, jungle_gym_b: 2, shack: 1, t_wall: 2, l_wall: 3, long_wall: 3, short_wall: 2, debris: 2 },
    fillerWeights: { rocks: 2, trees: 2, grass: 6 },
    theme: { ground: '#221d15', ground2: '#2a2319', speck: '#3a301f', wall: '#6b6155', wallTop: '#857a6b', wood: '#614629', woodTop: '#80603a', rock: '#4f4a43', rockTop: '#6a645b', tree: '#2a2617', treeTop: '#3e3a20', grass: '#5a5426', border: '#100d08', fog: [190, 170, 140] },
  },
  ironworks: {
    id: 'ironworks', name: 'Ironworks Yard', blurb: 'Industrial yard: strong loops, few hiding spots, a huge foundry.',
    size: [100, 100], main: 'main_factory', tiles: 18, fillers: 16, grassPatches: 8, gens: 7, hooks: 12,
    weights: { jungle_gym: 5, jungle_gym_b: 4, shack: 1, t_wall: 3, l_wall: 2, long_wall: 3, short_wall: 3, debris: 1 },
    fillerWeights: { rocks: 5, trees: 1, grass: 1 },
    theme: { ground: '#1a1b1e', ground2: '#202226', speck: '#2c2f33', wall: '#5d6168', wallTop: '#7c818a', wood: '#5a4733', woodTop: '#755d42', rock: '#45484d', rockTop: '#60646b', tree: '#1c241c', treeTop: '#2a3a2a', grass: '#33402e', border: '#0b0b0d', fog: [160, 165, 180] },
  },
  hollowmarsh: {
    id: 'hollowmarsh', name: 'Hollow Marsh', blurb: 'Foggy wetland with weak filler and long dead zones. Hard for survivors.',
    size: [112, 112], main: 'main_temple', tiles: 11, fillers: 26, grassPatches: 30, gens: 7, hooks: 13,
    weights: { jungle_gym: 2, jungle_gym_b: 2, shack: 1, t_wall: 3, l_wall: 3, long_wall: 2, short_wall: 4, debris: 5 },
    fillerWeights: { rocks: 2, trees: 5, grass: 5 },
    theme: { ground: '#16201f', ground2: '#1a2625', speck: '#243231', wall: '#565e5c', wallTop: '#717b78', wood: '#4d4130', woodTop: '#685840', rock: '#434a48', rockTop: '#5c6461', tree: '#142320', treeTop: '#1f3a33', grass: '#2b4a40', border: '#091010', fog: [140, 170, 165] },
  },
  // ---------------- expansion maps: each has its own layout style ----------------
  asylum: {
    id: 'asylum', name: 'Sunken Asylum', blurb: 'A walled asylum of linked wards: doorways, short sightlines and pallets in the doors. Ranged killers struggle; stealth and mobility shine.',
    size: [110, 96], layout: 'compound', compound: { cols: 4, rows: 3, room: 15, roomH: 13 }, main: null, tiles: 7, fillers: 14, grassPatches: 6, gens: 7, hooks: 13,
    weights: { t_wall: 2, l_wall: 2, short_wall: 2, debris: 2, ward_pillars: 3, jungle_gym: 1 },
    fillerWeights: { rocks: 2, trees: 3, grass: 1 },
    theme: { ground: '#1b1a1d', ground2: '#211f24', speck: '#2d2a31', wall: '#5a5560', wallTop: '#77717e', wood: '#4f4237', woodTop: '#685748', rock: '#47444b', rockTop: '#605c66', tree: '#1a1f1c', treeTop: '#27322b', grass: '#2f3a30', metal: '#3f4a52', metalTop: '#5a6872', water: '#16232b', border: '#0b0a0c', fog: [150, 145, 165] },
  },
  docks: {
    id: 'docks', name: 'Saltmere Docks', blurb: 'Harbour strips split by water channels: bridges are chokepoints, but you can see — and throw — across the water. Container stacks make strong loops.',
    size: [120, 100], layout: 'channels', channels: { count: 2, width: 4 }, main: 'main_warehouse', mainAt: [0.5, 0.5], tiles: 14, fillers: 10, grassPatches: 4, gens: 7, hooks: 13,
    weights: { container_yard: 4, container_row: 3, dock_crane: 3, l_wall: 1, short_wall: 2, debris: 1 },
    fillerWeights: { rocks: 2, trees: 1, grass: 1 },
    theme: { ground: '#1a1d20', ground2: '#1f2327', speck: '#2b3136', wall: '#59616a', wallTop: '#77808a', wood: '#5a4a39', woodTop: '#776350', rock: '#444a50', rockTop: '#5e666e', tree: '#1a221e', treeTop: '#26342c', grass: '#2e3c34', metal: '#3c5566', metalTop: '#55798f', water: '#0f2a36', border: '#0a0c0e', fog: [150, 170, 185] },
  },
  quarry: {
    id: 'quarry', name: 'Ember Quarry', blurb: 'A tar pit sinks the centre of the map; every route bends around it. Rock ridges with pallet gaps, long open lanes across the pit.',
    size: [112, 104], layout: 'pit', pit: { radius: 11, shelves: 4 }, main: 'main_office', mainAt: [0.22, 0.24], tiles: 12, fillers: 18, grassPatches: 6, gens: 7, hooks: 12,
    weights: { ridge_gap: 4, ridge_window: 3, l_wall: 2, debris: 3, t_wall: 1, jungle_gym_b: 1 },
    fillerWeights: { rocks: 6, trees: 1, grass: 1 },
    theme: { ground: '#221a16', ground2: '#291f1a', speck: '#3a2a22', wall: '#6a5a50', wallTop: '#86756a', wood: '#5c4430', woodTop: '#7a5c40', rock: '#5a4a42', rockTop: '#7a665a', tree: '#2a2018', treeTop: '#3a2e22', grass: '#4a3a24', metal: '#4a4440', metalTop: '#665e58', water: '#1a0f0c', waterGlow: 'rgba(220,90,30,0.22)', border: '#100b08', fog: [190, 150, 130] },
  },
  grove: {
    id: 'grove', name: 'Hallowed Grove', blurb: 'A cathedral in a clearing, ringed by deep woods. Thick tree cover hides survivors, but the woods hold few real loops.',
    size: [116, 116], layout: 'clearing', forest: { count: 190, clear: 19 }, main: 'main_cathedral', tiles: 10, fillers: 6, grassPatches: 30, gens: 7, hooks: 13,
    weights: { hedge_loop: 4, jungle_gym: 2, l_wall: 2, debris: 2, short_wall: 2, t_wall: 1 },
    fillerWeights: { rocks: 1, trees: 4, grass: 3 },
    theme: { ground: '#141c16', ground2: '#18221a', speck: '#22301f', wall: '#5b6158', wallTop: '#787f74', wood: '#4c3c2a', woodTop: '#66523a', rock: '#454a45', rockTop: '#5e655e', tree: '#122016', treeTop: '#1d3a24', grass: '#284a2c', metal: '#3f4a44', metalTop: '#5a6860', water: '#10201c', border: '#080c09', fog: [135, 165, 140] },
  },
  lodge: {
    id: 'lodge', name: 'Frostpeak Lodge', blurb: 'A snowbound ski lodge with cabins, fence runs and pallet boxes. Plenty of strong tiles, but wide snowfields between them.',
    size: [108, 100], main: 'main_lodge', tiles: 15, fillers: 14, grassPatches: 4, gens: 7, hooks: 12,
    weights: { cabin: 3, fence_run: 3, double_pallet: 3, jungle_gym: 2, l_wall: 2, short_wall: 2, debris: 1 },
    fillerWeights: { rocks: 3, trees: 4, grass: 0 },
    theme: { ground: '#c9ced4', ground2: '#bfc5cc', speck: '#d8dde2', wall: '#5a5f66', wallTop: '#7b828b', wood: '#5a4232', woodTop: '#7a5a44', rock: '#6b7178', rockTop: '#8b9199', tree: '#1c2a24', treeTop: '#2e4a3c', grass: '#8a9488', metal: '#4a5866', metalTop: '#64788a', water: '#7f99ad', border: '#2a2e33', fog: [215, 225, 235], snow: true },
  },
};
export const MAP_LIST = Object.values(MAPS);
