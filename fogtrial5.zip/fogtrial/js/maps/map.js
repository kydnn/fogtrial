// GameMap: procedural layout from a data definition + chase-tile metadata (loop graph),
// dead-zone analysis, spatial collision world and navigation grid.
import { M, mulberry32, rr, ri, pick, dist, clamp, smoothstep } from '../core/util.js';
import { World } from '../core/collision.js';
import { TEMPLATES, rotateRows, parseTemplate } from './templates.js';
import { NavGrid } from '../ai/navigation.js';
import { Window, Pallet, Generator, Hook, Chest, Totem, ExitGate, Hatch } from '../entities/objects.js';

const GEN_NAMES = 'ABCDEFGHIJKL'.split('');

function weightedPick(rng, weights) {
  const entries = Object.entries(weights).filter(([, w]) => w > 0);
  const tot = entries.reduce((a, [, w]) => a + w, 0); let r = rng() * tot;
  for (const [k, w] of entries) { r -= w; if (r <= 0) return k; }
  return entries[0][0];
}

export class GameMap {
  constructor(def, opts = {}) {
    this.def = def; this.name = def.name; this.theme = def.theme;
    this.seed = opts.seed ?? Math.floor(Math.random() * 1e9);
    this.rng = mulberry32(this.seed);
    this.wM = def.size[0]; this.hM = def.size[1];
    this.w = this.wM * M; this.h = this.hM * M;
    this.genCount = opts.gens ?? def.gens; this.hookCount = opts.hooks ?? def.hooks; this.gateCount = opts.gates ?? 2;
    this.solids = []; this.windows = []; this.pallets = []; this.gens = []; this.hooks = []; this.chests = []; this.totems = [];
    this.gates = []; this.tiles = []; this.grassCells = []; this.decor = [];
    this.world = new World(this.w, this.h);
    this.occ = new Uint8Array(this.wM * this.hM); // meter occupancy for placement
    if (opts.custom) opts.custom(this); else this.generate();
    this.finalize();
  }

  occupied(x0, y0, w, h) {
    for (let y = Math.floor(y0); y < Math.ceil(y0 + h); y++) for (let x = Math.floor(x0); x < Math.ceil(x0 + w); x++) {
      if (x < 0 || y < 0 || x >= this.wM || y >= this.hM) return true;
      if (this.occ[y * this.wM + x]) return true;
    }
    return false;
  }
  mark(x0, y0, w, h, v = 1) {
    for (let y = Math.floor(y0); y < Math.ceil(y0 + h); y++) for (let x = Math.floor(x0); x < Math.ceil(x0 + w); x++)
      if (x >= 0 && y >= 0 && x < this.wM && y < this.hM) this.occ[y * this.wM + x] = v;
  }

  // Place a template with origin (meters). Returns tile record.
  placeTemplate(key, ox, oy, rot) {
    const tpl = TEMPLATES[key];
    const grid = rotateRows(tpl.rows, rot);
    const p = parseTemplate(grid, ox, oy);
    const tile = {
      id: this.tiles.length, key, type: tpl.type, label: tpl.label, baseSafety: tpl.safety, filler: !!tpl.filler, main: !!tpl.main,
      x: (ox + p.w / 2) * M, y: (oy + p.h / 2) * M, rect: { x: ox * M, y: oy * M, w: p.w * M, h: p.h * M },
      radius: Math.hypot(p.w, p.h) / 2 * M, windows: [], pallets: [], solids: [], connected: [],
    };
    for (const s of p.solids) {
      const solid = { x: s.x * M, y: s.y * M, w: s.w * M, h: s.h * M, kind: s.kind, blocksMove: true, blocksLOS: s.kind !== 'water', tile: tile.id };
      this.solids.push(solid); tile.solids.push(solid);
    }
    for (const w of p.windows) { const o = new Window(w); o.tile = tile.id; this.windows.push(o); tile.windows.push(o); }
    for (const pl of p.pallets) { const o = new Pallet(pl); o.tile = tile.id; this.pallets.push(o); tile.pallets.push(o); }
    for (const g of p.grass) this.grassCells.push(g);
    this.tiles.push(tile);
    return tile;
  }

  tryPlace(key, margin, attempts = 60, near = null) {
    const tpl = TEMPLATES[key]; const rng = this.rng;
    for (let a = 0; a < attempts; a++) {
      const rot = ri(rng, 0, 3);
      const g = rotateRows(tpl.rows, rot); const w = g[0].length, h = g.length;
      let ox, oy;
      if (near) { ox = Math.round(near.x - w / 2 + rr(rng, -4, 4)); oy = Math.round(near.y - h / 2 + rr(rng, -4, 4)); }
      else { ox = ri(rng, 5, this.wM - w - 5); oy = ri(rng, 5, this.hM - h - 5); }
      if (ox < 4 || oy < 4 || ox + w > this.wM - 4 || oy + h > this.hM - 4) continue;
      if (this.occupied(ox - margin, oy - margin, w + margin * 2, h + margin * 2)) continue;
      this.mark(ox - 1, oy - 1, w + 2, h + 2);
      return this.placeTemplate(key, ox, oy, rot);
    }
    return null;
  }

  generate() {
    const d = this.def, rng = this.rng;
    const B = 3; // border thickness meters
    this.border = B;
    this.mark(0, 0, this.wM, B + 1); this.mark(0, this.hM - B - 1, this.wM, B + 1); this.mark(0, 0, B + 1, this.hM); this.mark(this.wM - B - 1, 0, B + 1, this.hM);
    // Exit gates on opposite sides
    const horizontalPair = rng() < 0.5;
    const sides = this.gateCount >= 2 ? (horizontalPair ? ['n', 's'] : ['w', 'e']) : [pick(rng, ['n', 's', 'e', 'w'])];
    if (this.gateCount >= 3) sides.push(horizontalPair ? pick(rng, ['w', 'e']) : pick(rng, ['n', 's']));
    const gaps = { n: [], s: [], e: [], w: [] };
    sides.forEach((side, k) => {
      const along = side === 'n' || side === 's' ? this.wM : this.hM;
      const c = Math.round(rr(rng, along * 0.25, along * 0.75));
      gaps[side].push([c - 2, c + 2]);
      const gw = 4;
      let door, exit, sw;
      if (side === 'n') { door = { x: (c - 2) * M, y: (B - 0.5) * M, w: gw * M, h: 0.5 * M }; exit = { x: (c - 2) * M, y: 0, w: gw * M, h: (B - 0.5) * M }; sw = { x: (c + 3.5) * M, y: (B + 1.8) * M }; this.mark(c - 4, B, 9, 4); }
      if (side === 's') { door = { x: (c - 2) * M, y: (this.hM - B) * M, w: gw * M, h: 0.5 * M }; exit = { x: (c - 2) * M, y: (this.hM - B + 0.5) * M, w: gw * M, h: (B - 0.5) * M }; sw = { x: (c + 3.5) * M, y: (this.hM - B - 1.8) * M }; this.mark(c - 4, this.hM - B - 4, 9, 4); }
      if (side === 'w') { door = { x: (B - 0.5) * M, y: (c - 2) * M, w: 0.5 * M, h: gw * M }; exit = { x: 0, y: (c - 2) * M, w: (B - 0.5) * M, h: gw * M }; sw = { x: (B + 1.8) * M, y: (c + 3.5) * M }; this.mark(B, c - 4, 4, 9); }
      if (side === 'e') { door = { x: (this.wM - B) * M, y: (c - 2) * M, w: 0.5 * M, h: gw * M }; exit = { x: (this.wM - B + 0.5) * M, y: (c - 2) * M, w: (B - 0.5) * M, h: gw * M }; sw = { x: (this.wM - B - 1.8) * M, y: (c + 3.5) * M }; this.mark(this.wM - B - 4, c - 4, 4, 9); }
      this.gates.push(new ExitGate({ x: sw.x, y: sw.y, side, doorRect: door, exitRect: exit, name: k === 0 ? 'Gate I' : k === 1 ? 'Gate II' : 'Gate III' }));
    });
    // Border walls with gaps
    const seg = (side, a, b) => {
      if (b <= a) return;
      const r = side === 'n' ? { x: a * M, y: 0, w: (b - a) * M, h: B * M } : side === 's' ? { x: a * M, y: (this.hM - B) * M, w: (b - a) * M, h: B * M }
        : side === 'w' ? { x: 0, y: a * M, w: B * M, h: (b - a) * M } : { x: (this.wM - B) * M, y: a * M, w: B * M, h: (b - a) * M };
      this.solids.push({ ...r, kind: 'border', blocksMove: true, blocksLOS: true });
    };
    for (const side of ['n', 's', 'e', 'w']) {
      const along = side === 'n' || side === 's' ? this.wM : this.hM;
      let start = side === 'n' || side === 's' ? 0 : B; const end = side === 'n' || side === 's' ? along : along - B;
      const gs = gaps[side].sort((a, b) => a[0] - b[0]);
      for (const [g0, g1] of gs) { seg(side, start, g0); start = g1; }
      seg(side, start, end);
    }
    // Map-specific large-scale structure (each new map has its own layout style)
    if (d.layout === 'compound') this.buildCompound(d.compound);
    if (d.layout === 'channels') this.buildChannels(d.channels);
    if (d.layout === 'pit') this.buildPit(d.pit);
    // Main building near the center (or where the layout asks)
    if (d.main) this.tryPlace(d.main, 3, 80, d.mainAt ? { x: this.wM * d.mainAt[0], y: this.hM * d.mainAt[1] } : { x: this.wM / 2 + rr(rng, -8, 8), y: this.hM / 2 + rr(rng, -8, 8) });
    // Chase tiles
    let placed = 0, shack = false;
    for (let i = 0; i < d.tiles * 4 && placed < d.tiles; i++) {
      let key = weightedPick(rng, d.weights);
      if (TEMPLATES[key].unique && shack) continue;
      if (this.tryPlace(key, 4, 25)) { placed++; if (key === 'shack') shack = true; }
    }
    // Filler LOS blockers / grass
    let f = 0;
    for (let i = 0; i < d.fillers * 4 && f < d.fillers; i++) if (this.tryPlace(weightedPick(rng, d.fillerWeights), 2, 15)) f++;
    // Dense woodland outside a central clearing (Hallowed Grove)
    if (d.layout === 'clearing') this.buildForest(d.forest);
    // Loose grass patches (cornfields / ferns)
    for (let i = 0; i < d.grassPatches; i++) {
      const cx = rr(rng, 6, this.wM - 6), cy = rr(rng, 6, this.hM - 6), rad = rr(rng, 2, 4.5);
      for (let y = Math.floor(cy - rad); y <= cy + rad; y++) for (let x = Math.floor(cx - rad); x <= cx + rad; x++) {
        if ((x + 0.5 - cx) ** 2 + (y + 0.5 - cy) ** 2 < rad * rad && rng() < 0.85) this.grassCells.push({ x: x + 0.5, y: y + 0.5 });
      }
    }
  }

  // Register a hand-built structure as one or more chase tiles the AI can reason about.
  addTileRecord(meta, rect, windows, pallets) {
    const tile = { id: this.tiles.length, key: meta.key, type: meta.type, label: meta.label, baseSafety: meta.safety, filler: false, main: !!meta.main,
      x: (rect.x + rect.w / 2) * M, y: (rect.y + rect.h / 2) * M, rect: { x: rect.x * M, y: rect.y * M, w: rect.w * M, h: rect.h * M },
      radius: Math.hypot(rect.w, rect.h) / 2 * M, windows, pallets, solids: [], connected: [] };
    for (const o of [...windows, ...pallets]) o.tile = tile.id;
    this.tiles.push(tile); return tile;
  }
  // Parse a char grid (template syntax) at (ox, oy) without registering a tile.
  placeRows(grid, ox, oy, kindLOS = true) {
    const p = parseTemplate(grid, ox, oy); const out = { windows: [], pallets: [], solids: [] };
    for (const q of p.solids) { const solid = { x: q.x * M, y: q.y * M, w: q.w * M, h: q.h * M, kind: q.kind, blocksMove: true, blocksLOS: q.kind !== 'water' && kindLOS }; this.solids.push(solid); out.solids.push(solid); }
    for (const w of p.windows) { const o = new Window(w); this.windows.push(o); out.windows.push(o); }
    for (const pl of p.pallets) { const o = new Pallet(pl); this.pallets.push(o); out.pallets.push(o); }
    for (const g of p.grass) this.grassCells.push(g);
    return out;
  }
  // SUNKEN ASYLUM: a walled compound split into wards. Walls between wards have doorways;
  // some doorways hold pallets and some walls have windows, so every ward is a small loop
  // and the compound is a maze of short sightlines.
  buildCompound(c = {}) {
    const rng = this.rng; const cols = c.cols || 4, rows = c.rows || 3, rw = c.room || 15, rh = c.roomH || 13;
    const W = cols * rw + 1, H = rows * rh + 1;
    const ox = Math.round((this.wM - W) / 2), oy = Math.round((this.hM - H) / 2);
    const g = Array.from({ length: H }, () => Array(W).fill('.'));
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (x % rw === 0 || y % rh === 0) g[y][x] = '#';
    // carve each wall segment: a doorway (sometimes with a pallet), sometimes a window
    const carve = (cells, outer) => {
      const n = cells.length; const door = ri(rng, 3, n - 6);
      const pal = !outer && rng() < 0.45;
      for (let k = 0; k < (pal ? 2 : 3); k++) { const [x, y] = cells[door + k]; g[y][x] = pal ? 'P' : '.'; }
      if (rng() < (outer ? 0.35 : 0.5)) { const wpos = door > n / 2 ? ri(rng, 1, Math.max(1, door - 4)) : ri(rng, Math.min(n - 3, door + 5), n - 3); for (let k = 0; k < 2; k++) { const [x, y] = cells[wpos + k] || []; if (x !== undefined && g[y][x] === '#') g[y][x] = 'W'; } }
    };
    for (let ry = 0; ry <= rows; ry++) for (let cx = 0; cx < cols; cx++) { const y = ry * rh; const cells = []; for (let x = cx * rw + 1; x < (cx + 1) * rw; x++) cells.push([x, y]); const outer = ry === 0 || ry === rows; if (!outer || rng() < 0.6) carve(cells, outer); }
    for (let rx = 0; rx <= cols; rx++) for (let cy = 0; cy < rows; cy++) { const x = rx * rw; const cells = []; for (let y = cy * rh + 1; y < (cy + 1) * rh; y++) cells.push([x, y]); const outer = rx === 0 || rx === cols; if (!outer || rng() < 0.6) carve(cells, outer); }
    // a pillar or bed-row in some wards gives a loop inside the room
    for (let cy = 0; cy < rows; cy++) for (let cx = 0; cx < cols; cx++) {
      if (rng() < 0.55) { const px = cx * rw + ri(rng, 4, rw - 6), py = cy * rh + ri(rng, 4, rh - 6); const kind = rng() < 0.5 ? '#' : 'C'; for (let y = py; y < py + 2; y++) for (let x = px; x < px + 3; x++) g[y][x] = kind; }
    }
    const placed = this.placeRows(g, ox, oy);
    this.mark(ox - 2, oy - 2, W + 4, H + 4);
    // each ward becomes a chase tile with the pallets/windows in its own walls
    for (let cy = 0; cy < rows; cy++) for (let cx = 0; cx < cols; cx++) {
      const r = { x: ox + cx * rw, y: oy + cy * rh, w: rw + 1, h: rh + 1 };
      const inR = (o) => o.x / M >= r.x - 0.5 && o.x / M <= r.x + r.w + 0.5 && o.y / M >= r.y - 0.5 && o.y / M <= r.y + r.h + 0.5 && o.tile === undefined;
      const ws = placed.windows.filter(inR), ps = placed.pallets.filter(inR);
      this.addTileRecord({ key: 'ward', type: 'room', label: 'Ward', safety: 0.5 + 0.08 * Math.min(3, ws.length + ps.length), main: cx === Math.floor(cols / 2) && cy === Math.floor(rows / 2) }, r, ws, ps);
    }
    this.compound = { x: ox * M, y: oy * M, w: W * M, h: H * M };
  }
  // SALTMERE DOCKS: water channels cut the map into strips; bridges are the only crossings,
  // but you can see (and throw) across the water.
  buildChannels(c = {}) {
    const rng = this.rng, B = this.border; const n = c.count || 2, width = c.width || 4;
    for (let k = 1; k <= n; k++) {
      const y0 = Math.round(this.hM * k / (n + 1) - width / 2 + rr(rng, -3, 3));
      let x = B; const bridges = [];
      for (let bx = ri(rng, 10, 18); bx < this.wM - 10; bx += ri(rng, 20, 30)) bridges.push(bx);
      for (const bx of [...bridges, this.wM - B]) {
        if (bx - x > 0) { this.solids.push({ x: x * M, y: y0 * M, w: (bx - x) * M, h: width * M, kind: 'water', blocksMove: true, blocksLOS: false }); this.mark(x, y0 - 1, bx - x, width + 2); }
        x = bx + 4;
      }
      this.channels = (this.channels || []).concat({ y: y0 * M, h: width * M, bridges: bridges.map((b) => (b + 2) * M) });
    }
  }
  // EMBER QUARRY: a sunken tar pit in the middle (blocks movement, open sightlines) ringed
  // by rock shelves, so most routes bend around the centre.
  buildPit(c = {}) {
    const rng = this.rng; const r = c.radius || 11; const cx = this.wM / 2 + rr(rng, -6, 6), cy = this.hM / 2 + rr(rng, -6, 6);
    for (let y = Math.floor(cy - r); y <= cy + r; y++) {
      let x0 = null;
      for (let x = Math.floor(cx - r * 1.3); x <= cx + r * 1.3 + 1; x++) {
        const inside = ((x + 0.5 - cx) / 1.3) ** 2 + (y + 0.5 - cy) ** 2 < r * r * (0.85 + 0.15 * Math.sin(x * 0.7 + y));
        if (inside && x0 === null) x0 = x;
        if ((!inside || x > cx + r * 1.3) && x0 !== null) { this.solids.push({ x: x0 * M, y: y * M, w: (x - x0) * M, h: M, kind: 'water', blocksMove: true, blocksLOS: false }); x0 = null; }
      }
    }
    this.mark(cx - r * 1.3 - 2, cy - r - 2, r * 2.6 + 4, r * 2 + 4);
    // rock shelves around the rim with a few pallet gaps
    for (let k = 0; k < (c.shelves || 4); k++) {
      const a = k * Math.PI * 2 / (c.shelves || 4) + rr(rng, -0.3, 0.3); const rx = Math.round(cx + Math.cos(a) * (r * 1.3 + 4)) - 7, ry = Math.round(cy + Math.sin(a) * (r + 4)) - 2;
      if (!this.occupied(rx, ry, 17, 4)) { this.mark(rx - 1, ry - 1, 19, 6); this.placeTemplate('ridge_gap', rx, ry, Math.abs(Math.sin(a)) > 0.7 ? 0 : 1); }
    }
    this.pit = { x: cx * M, y: cy * M, r: r * M };
  }
  // HALLOWED GROVE: thick woods everywhere except a clearing around the cathedral.
  buildForest(f = {}) {
    const rng = this.rng; const cx = this.wM / 2, cy = this.hM / 2, clear = f.clear || 20;
    let n = 0;
    for (let t = 0; t < (f.count || 160) * 6 && n < (f.count || 160); t++) {
      const x = ri(rng, 6, this.wM - 7), y = ri(rng, 6, this.hM - 7);
      if (Math.hypot(x - cx, y - cy) < clear) continue;
      if (this.occupied(x - 1, y - 1, 3, 3)) continue;
      this.mark(x, y, 1, 1); this.solids.push({ x: x * M, y: y * M, w: M, h: M, kind: 'tree', blocksMove: true, blocksLOS: true }); n++;
    }
  }

  // Put solids in world, build nav, then place gens/hooks/etc. on open ground.
  finalize() {
    const rng = this.rng;
    for (const s of this.solids) this.world.add(s);
    for (const w of this.windows) this.world.add(w.solid);
    for (const g of this.gates) this.world.add(g.solid);
    this.nav = new NavGrid(this.w, this.h);
    this.nav.build([...this.solids, ...this.windows.map((w) => w.solid), ...this.gates.map((g) => g.solid)], this.pallets, this.windows);
    for (const g of this.grassCells) {
      const i = this.nav.idxAt(g.x * M, g.y * M); this.nav.grass[i] = 1;
    }
    const isClear = (xm, ym, r) => {
      for (let y = Math.floor(ym - r); y <= ym + r; y++) for (let x = Math.floor(xm - r); x <= xm + r; x++) {
        if (x < 0 || y < 0 || x >= this.wM || y >= this.hM) return false;
        const i = y * this.nav.cols + x; if (this.nav.blocked[i] || this.nav.pallet[i] >= 0) return false;
      }
      return true;
    };
    const taken = [];
    const farPick = (count, minSpace, clearR, prefer = null, tries = 600) => {
      const out = [];
      for (let n = 0; n < count; n++) {
        let best = null, bestScore = -1;
        for (let t = 0; t < 60; t++) {
          let xm, ym;
          if (prefer && rng() < 0.7 && this.tiles.length) {
            const tl = pick(rng, this.tiles); const a = rng() * Math.PI * 2; const rad = tl.radius / M + rr(rng, 1.5, 4);
            xm = Math.round(tl.x / M + Math.cos(a) * rad) + 0.5; ym = Math.round(tl.y / M + Math.sin(a) * rad) + 0.5;
          } else { xm = Math.round(rr(rng, 6, this.wM - 6)) + 0.5; ym = Math.round(rr(rng, 6, this.hM - 6)) + 0.5; }
          if (!isClear(xm, ym, clearR)) continue;
          let md = 1e9; for (const p of [...out, ...taken]) md = Math.min(md, dist(xm, ym, p.x, p.y));
          if (md < minSpace) continue;
          const score = Math.min(md, 60) * rr(rng, 0.75, 1);
          if (score > bestScore) { bestScore = score; best = { x: xm, y: ym }; }
        }
        if (best) out.push(best); else if (tries-- > 0) n--;
        if (tries <= 0) break;
      }
      return out;
    };
    if (!this.customObjects) {
      // Generators: spread out, usually near structures.
      const gp = farPick(this.genCount, 20, 2, true);
      gp.forEach((p, k) => { const g = new Generator(p.x * M, p.y * M, GEN_NAMES[k]); this.gens.push(g); taken.push(p); });
      const hp = farPick(this.hookCount, 13, 1, false);
      hp.forEach((p) => { this.hooks.push(new Hook(p.x * M, p.y * M)); taken.push(p); });
      farPick(4, 18, 1, true).forEach((p) => { this.chests.push(new Chest(p.x * M, p.y * M)); taken.push(p); });
      farPick(5, 16, 1, true).forEach((p) => { this.totems.push(new Totem(p.x * M, p.y * M)); taken.push(p); });
      const hatchP = farPick(1, 10, 1, false)[0] || { x: this.wM / 2, y: this.hM / 2 };
      this.hatch = new Hatch(hatchP.x * M, hatchP.y * M);
      // Spawns: survivors together, killer far away.
      const sp = farPick(1, 14, 2, false)[0];
      let kp = null, best = -1;
      for (let t = 0; t < 80; t++) { const xm = Math.round(rr(rng, 8, this.wM - 8)) + 0.5, ym = Math.round(rr(rng, 8, this.hM - 8)) + 0.5; if (!isClear(xm, ym, 1)) continue; const d = dist(xm, ym, sp.x, sp.y); if (d > best) { best = d; kp = { x: xm, y: ym }; } }
      this.spawn = { killer: { x: kp.x * M, y: kp.y * M }, survivors: [] };
      for (let k = 0; k < 4; k++) { const i = this.nav.nearestOpen((sp.x + (k % 2) * 2 - 1) * M, (sp.y + Math.floor(k / 2) * 2 - 1) * M, 5); this.spawn.survivors.push(this.nav.center(i)); }
      this.trapSpawns = farPick(6, 10, 1, true).map((p) => ({ x: p.x * M, y: p.y * M }));
    }
    for (const g of this.gens) this.world.add(g.solid);
    // Re-block nav cells under generators
    for (const g of this.gens) for (const [x, y] of [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]]) { const i = this.nav.idxAt(g.x + x * M, g.y + y * M); this.nav.blocked[i] = 1; }
    this.analyzeTiles();
  }

  // Loop graph + dead zones: the metadata the chase AI reasons about.
  analyzeTiles() {
    const nav = this.nav;
    for (const t of this.tiles) {
      t.connected = this.tiles.filter((o) => o !== t && dist(o.x, o.y, t.x, t.y) < 34 * M).map((o) => o.id);
      // cells inside tile footprint
      const r = t.rect;
      for (let y = Math.floor(r.y / M) - 1; y <= Math.ceil((r.y + r.h) / M); y++) for (let x = Math.floor(r.x / M) - 1; x <= Math.ceil((r.x + r.w) / M); x++)
        if (x >= 0 && y >= 0 && x < nav.cols && y < nav.rows) nav.tileOf[y * nav.cols + x] = t.id;
    }
    // Dead zone value per cell: distance to nearest loopable structure.
    const loopTiles = this.tiles.filter((t) => t.baseSafety > 0.2);
    for (let i = 0; i < nav.cols * nav.rows; i++) {
      const c = nav.center(i); let best = 1e9;
      for (const t of loopTiles) {
        const dx = Math.max(t.rect.x - c.x, 0, c.x - (t.rect.x + t.rect.w)), dy = Math.max(t.rect.y - c.y, 0, c.y - (t.rect.y + t.rect.h));
        best = Math.min(best, Math.hypot(dx, dy));
      }
      nav.deadZone[i] = smoothstep(5 * M, 16 * M, best);
    }
    this.refreshTileSafety();
  }

  // Live tile strength: base safety scaled by remaining resources.
  refreshTileSafety(now = 0) {
    for (const t of this.tiles) {
      const up = t.pallets.filter((p) => p.state === 'up').length, down = t.pallets.filter((p) => p.state === 'down').length;
      const wins = t.windows.filter((w) => w.blockedUntil <= now).length;
      const res = up * 0.35 + down * 0.25 + wins * 0.3;
      t.resources = { up, down, wins };
      t.safety = clamp(t.baseSafety * (0.35 + Math.min(res, 1.2) * 0.6), 0, 1);
      if (t.main) t.safety = Math.max(t.safety, 0.45);
    }
  }

  // Open ground points spread apart (used by killer powers for lockers, printers…)
  openSpots(count, minSpace = 14, avoid = []) {
    const out = []; const rng = this.rng; const nav = this.nav;
    for (let t = 0; t < count * 80 && out.length < count; t++) {
      const xm = Math.floor(rr(rng, 6, this.wM - 6)) + 0.5, ym = Math.floor(rr(rng, 6, this.hM - 6)) + 0.5;
      let ok = true;
      for (let y = Math.floor(ym - 1); y <= ym + 1 && ok; y++) for (let x = Math.floor(xm - 1); x <= xm + 1; x++) { const i = y * nav.cols + x; if (nav.blocked[i] || nav.pallet[i] >= 0) { ok = false; break; } }
      if (!ok) continue;
      const p = { x: xm * M, y: ym * M };
      if ([...out, ...avoid].some((q) => dist(q.x, q.y, p.x, p.y) < minSpace * M)) continue;
      out.push(p);
    }
    return out;
  }
  tileAt(x, y) { const i = this.nav.idxAt(x, y); const t = this.nav.tileOf[i]; return t >= 0 ? this.tiles[t] : null; }
  isGrass(x, y) { return this.nav.grass[this.nav.idxAt(x, y)] === 1; }
}
