// Human survivor controller. Turns the player's input into the same intents the survivor AI
// uses (moveTo / moveMode / startAction / startVault), so every rule, perk and status effect
// works identically for the player and the bots.
//   WASD move · SHIFT walk · CTRL / C crouch · SPACE vault / drop pallet / skill checks
//   E (hold) interact with the nearest valid object · Q / RMB (hold) use item · F active perk
//   Carried: alternate A / D to wiggle · Hooked: E attempts an escape (first stage)
import { M, dist, angleDiff } from '../core/util.js';
import { ACTION_DEF } from '../entities/survivor.js';

// Actions that continue only while E (or the item key) is held
const HOLD = new Set(['repair', 'heal', 'healSelf', 'unhook', 'openGate', 'searchChest', 'cleanse', 'disarm', 'freeTrapped', 'recover', 'mend', 'openHatch', 'device', 'breakChain', 'solveBox', 'spray', 'flashlight']);

export class SurvivorController {
  constructor(m, s) {
    this.m = m; this.s = s; m.playerCtl ||= this; (m.playerCtls ||= []).push(this); this.grace = 0;
    this.in = { mx: 0, my: 0, walk: false, crouch: false, aimX: s.x + 40, aimY: s.y, e: false, eP: false, space: false, spaceP: false, item: false, itemP: false, perkP: false, left: false, right: false, leftP: false, rightP: false };
    this.held = null; this.lastWig = null; this.wigT = 0;
  }
  setInput(i) { Object.assign(this.in, i); }

  update(dt) {
    const m = this.m, s = this.s, I = this.in;
    if (!s.alive) { this.clear(); return; }
    s.lookTarget = { x: I.aimX, y: I.aimY };
    // --- skill checks first: SPACE answers them, the needle running out fails them
    if (s.skillCheck) {
      const c = s.skillCheck; const pos = (m.time - c.t0 - c.warn) / c.dur;
      if (I.spaceP && pos > -0.2) { m.answerPlayerCheck(s, true); I.spaceP = false; }
      else if (pos > 1.05 + this.grace) m.answerPlayerCheck(s, false);
      else if (c.kind === 'repair' && s.action?.type !== 'repair') s.skillCheck = null;
      else if (c.kind === 'heal' && s.action?.type !== 'heal') s.skillCheck = null;
    }
    // device interactions with a skill check (hacking a drone): one check halfway through
    const a = s.action;
    if (a?.type === 'device' && a.target.owner?.power?.onPlayerCheck && !a.checked && a.t > a.target.useTime * 0.45) { a.checked = true; m.startPlayerCheck(s, 'device', a.target); }
    switch (s.health) {
      case 'carried': return this.wiggle(dt);
      case 'hooked': return this.hooked();
      case 'dying': return this.downed();
    }
    if (s.trap) { if (I.eP && !s.action) s.startAction('escapeTrap', null, m); this.clear(); return; }
    // --- movement
    const moving = Math.hypot(I.mx, I.my) > 0.1;
    s.moveMode = I.crouch ? 'crouch' : I.walk ? 'walk' : 'run';
    if (moving) {
      // moving cancels most interactions, as in the original game
      if (s.action && !['flashlight', 'dropPallet', 'useEmp'].includes(s.action.type)) s.stopAction(m);
      s.moveTo = { x: s.x + I.mx * 2 * M, y: s.y + I.my * 2 * M };
    } else s.moveTo = null;
    // --- SPACE: vault / pallet
    if (I.spaceP && !s.vault) {
      const c = this.spaceContext();
      if (c?.type === 'vault') s.startVault(c.target, this.vaultQuality(c.target), m);
      else if (c?.type === 'dropPallet') s.startAction('dropPallet', c.target, m);
    }
    // --- E: hold to interact
    if (I.e) {
      const cur = s.action;
      if (!cur || !HOLD.has(cur.type)) {
        const c = this.eContext();
        if (c) {
          if (c.type === 'escapeHatch') m.escapeHatch(s);
          else if (c.type === 'useEmp' || c.type === 'spray') s.startAction(c.type, null, m);
          else s.startAction(c.type, c.target, m);
          this.held = 'e';
        }
      }
    } else if (this.held === 'e' && s.action && HOLD.has(s.action.type)) { s.stopAction(m); this.held = null; }
    // --- item (Q / RMB)
    const it = s.item;
    if (I.item && it && it.charges > 0) {
      if (it.id === 'flashlight') { if (s.action?.type !== 'flashlight') s.startAction('flashlight', null, m); s.facing = Math.atan2(I.aimY - s.y, I.aimX - s.x); this.held = 'item'; }
      else if (it.id === 'medkit' && s.health === 'injured' && s.action?.type !== 'healSelf') { s.startAction('healSelf', null, m); this.held = 'item'; }
    } else if (this.held === 'item' && s.action && (s.action.type === 'flashlight' || s.action.type === 'healSelf')) { s.stopAction(m); this.held = null; }
    if (I.itemP) {
      if (s.emp) s.startAction('useEmp', null, m);
      else if ((s.sprays || 0) > 0 && s.status.has('infected')) s.startAction('spray', null, m);
      else if (s.vaccines > 0 && s.status.has('contaminated')) s.startAction('vaccinate', null, m);
    }
    // --- F: active perk (first one that can fire right now)
    if (I.perkP) for (const p of s.perks) if (p.def.activate && m.perks.activate(s, p.id)) { m.warn(s, `${p.def.name}!`); break; }
    this.clearPresses();
  }
  clear() { this.clearPresses(); this.s.moveTo = null; }
  clearPresses() { const I = this.in; I.eP = I.spaceP = I.itemP = I.perkP = I.leftP = I.rightP = false; }

  wiggle(dt) {
    const s = this.s, I = this.in;
    // alternate A / D: each correct alternation keeps the wiggle going for a moment
    const press = I.leftP ? 'L' : I.rightP ? 'R' : null;
    if (press && press !== this.lastWig) { this.lastWig = press; this.wigT = 0.4; }
    this.wigT -= dt;
    if (this.wigT > 0) s.wiggle += dt / 16 * (s.wiggleMult ?? 1) * 1.15;
    this.clearPresses();
  }
  hooked() {
    const m = this.m, s = this.s, I = this.in;
    if (I.eP && s.hookStage === 1) {
      const dl = s.perk('deliverance');
      if (dl && dl.tokens > 0) { dl.tokens = 0; m.selfUnhook(s); m.warn(s, 'Deliverance!'); }
      else if (s.unhookAttempts < 3) m.selfUnhookAttempt(s);
    }
    this.clearPresses();
  }
  downed() {
    const m = this.m, s = this.s, I = this.in;
    const moving = Math.hypot(I.mx, I.my) > 0.1;
    if (moving) { if (s.action) s.stopAction(m); s.moveTo = { x: s.x + I.mx * 2 * M, y: s.y + I.my * 2 * M }; }
    else s.moveTo = null;
    if (I.e && !moving) { if (s.action?.type !== 'recover') s.startAction('recover', null, m); }
    else if (s.action?.type === 'recover' && !I.e) s.stopAction(m);
    this.clearPresses();
  }

  vaultQuality(obj) {
    const s = this.s; const sp = Math.hypot(s.vx, s.vy);
    const toward = Math.atan2(obj.y - s.y, obj.x - s.x); const heading = Math.atan2(s.vy, s.vx);
    if (s.moveMode === 'run' && sp > 3.2 * M && angleDiff(toward, heading) < 0.9) return 'fast';
    return sp > 1.5 * M ? 'medium' : 'slow';
  }
  // SPACE: vault a window or dropped pallet, or throw an up pallet
  spaceContext() {
    const m = this.m, s = this.s; if (!s.standing || s.action?.type === 'dropPallet') return null;
    let best = null, bd = 1.5 * M;
    for (const w of m.map.windows) { if (w.blockedUntil > m.time) continue; const d = dist(s.x, s.y, w.x, w.y); if (d < bd) { bd = d; best = { type: 'vault', target: w, label: 'Vault' }; } }
    for (const p of m.map.pallets) {
      const d = dist(s.x, s.y, p.x, p.y);
      if (p.state === 'down' && d < Math.max(bd, 1.4 * M)) { bd = d; best = { type: 'vault', target: p, label: 'Vault pallet' }; }
      else if (p.state === 'up' && d < (ACTION_DEF.dropPallet.range - 0.6) * M && d < bd + 0.6 * M && s.canStart('dropPallet', p, m)) { bd = d; best = { type: 'dropPallet', target: p, label: 'Drop pallet' }; }
    }
    return best;
  }
  // E: the most relevant interaction in reach
  eContext() {
    const m = this.m, s = this.s; if (!s.standing) return null;
    const near = (o, r) => dist(s.x, s.y, o.x, o.y) < r * M;
    const tryT = (type, target, label) => (s.canStart(type, target, m) ? { type, target, label } : null);
    for (const o of m.survivors) if (o !== s && o.health === 'hooked' && near(o, 1.9)) { const c = tryT('unhook', o, `Unhook ${o.name}`); if (c) return c; }
    for (const o of m.survivors) if (o !== s && o.trap && near(o, 1.6)) { const c = tryT('freeTrapped', o, `Free ${o.name}`); if (c) return c; }
    for (const o of m.survivors) if (o !== s && (o.health === 'dying' || o.health === 'injured') && near(o, 1.9)) { const c = tryT('heal', o, o.health === 'dying' ? `Pick up ${o.name}` : `Heal ${o.name}`); if (c) return c; }
    if (m.hatch.state === 'open' && near(m.hatch, 1.3)) return { type: 'escapeHatch', target: m.hatch, label: 'Jump into the hatch' };
    if (m.hatch.state === 'closed' && near(m.hatch, 1.6)) { const c = tryT('openHatch', m.hatch, 'Open the hatch (key)'); if (c) return c; }
    let best = null, bd = Infinity;
    const consider = (type, o, r, label) => { const d = dist(s.x, s.y, o.x, o.y); if (d < r * M && d < bd && s.canStart(type, o, m)) { bd = d; best = { type, target: o, label }; } };
    for (const g of m.map.gens) if (!g.done) consider('repair', g, 2.6, `Repair generator ${g.name}`);
    for (const g of m.map.gates) consider('openGate', g, 1.8, 'Open exit gate');
    for (const c of m.map.chests) consider('searchChest', c, 1.6, 'Search chest');
    for (const t of m.map.totems) consider('cleanse', t, 1.6, t.hex ? 'Cleanse hex totem' : 'Cleanse totem');
    for (const t of m.traps) if (t.state === 'set') consider('disarm', t, 1.5, 'Disarm trap');
    for (const d of m.devices) if (d.survivorUsable) consider('device', d, 1.8, d.useLabel || `Use ${d.label}`);
    if (best) return best;
    // actions on yourself
    if (s.status.has('chained')) return { type: 'breakChain', target: null, label: 'Break the chains' };
    if (s.box) return { type: 'solveBox', target: null, label: 'Solve the Lament Configuration' };
    if (s.status.has('deepWound')) return { type: 'mend', target: null, label: 'Mend' };
    if (s.health === 'injured' && s.canStart('healSelf', null, m)) return { type: 'healSelf', target: null, label: 'Heal yourself' };
    return null;
  }
  // Prompts for the HUD: what SPACE and E would do right now
  prompts() {
    const s = this.s, out = [];
    if (!s.alive) return out;
    if (s.health === 'carried') return [{ key: 'A / D', label: 'Wiggle free', prog: s.wiggle }];
    if (s.health === 'hooked') return s.hookStage === 1 && s.unhookAttempts < 3 ? [{ key: 'E', label: `Attempt to escape (${3 - s.unhookAttempts} left, 4%)`, prog: null }] : [];
    if (s.health === 'dying') return [{ key: 'E', label: 'Hold to recover', prog: s.recovery }];
    if (s.trap) return [{ key: 'E', label: 'Try to escape the trap', prog: null }];
    if (s.action) out.push({ key: '', label: s.action.type === 'device' && s.action.target?.useLabel ? s.action.target.useLabel + '…' : s.action.label, prog: this.progressOf(s.action) });
    const sp = this.spaceContext(); if (sp && !s.action) out.push({ key: 'SPACE', label: sp.label, prog: null });
    const e = this.eContext(); if (e && (!s.action || s.action.target !== e.target)) out.push({ key: 'E', label: e.label, prog: null });
    if (s.item?.id === 'flashlight' && s.item.charges > 0 && !s.action) out.push({ key: 'RMB', label: 'Flashlight', prog: null });
    if (s.emp) out.push({ key: 'Q', label: 'Use EMP', prog: null });
    return out;
  }
  progressOf(a) {
    const s = this.s, t = a.target;
    switch (a.type) {
      case 'repair': return t.progress;
      case 'heal': return t.healProgress;
      case 'healSelf': return s.healProgress;
      case 'recover': return s.recovery;
      case 'device': return t.kind === 'printer' ? t.data.charge / 100 : a.t / (t.useTime || 1);
      default: return a.dur ? a.t / a.dur : null;
    }
  }
}
