# Research notes (2026-10-08) — mechanics references used for this update
See conversation; key numbers are encoded directly in js/killers/*.js comments.
Singularity: 8 biopods shot as projectiles (22 m, 50 m/s), pod control view, 0.8 s tag lock (20 m),
Slipstream spreads within 6 m after 2 s, teleport to slipstreamed survivor seen by a pod, Overclock 5.7 s,
Overheat 3 s; EMP printers (4), 2.5 s arm, 10 m radius: clears slipstream + disables pods 45 s.
Cannibal: 3 charges (0.25/s regen), 2 s rev, 2.5 s sweep ramp to 5.35 m/s, dash re-press spends charge,
multi-hit, tantrum on obstacle / 3 s rev (3 s +1 s/charge, -90% speed), cooldowns hit 2 / miss 1.5+1/charge / obstacle 3 / break 1.
Skull Merchant (live 9.3 version): 6 drones, 7 s deploy cd, 10 m sweep radius at 105 deg/s, crouch/still avoid,
3 lock-on stacks -> injure/deep wound/broken + claw trap (45 s battery, radar visible, scan while trapped = 10% hindered 6 s),
hack 45 s disable / fail +1 stack, radar 32 m showing tracked survivors, recall 1 s -> undetectable 8 s.
Blight: 5 tokens 2 s each, rush 9.2 m/s 3 s, slam (>=45 deg) -> 1.25 s chain window -> lethal rush with special attack, fatigue 2.5 s.
Nurse: 3.85 m/s, 2 blink tokens 3 s recharge, 2 s charge 1.5-20 m through walls, chain window 1.5 s up to 12 m, fatigue 2/2.5 s +1 on attack.
Unknown: UVX 1 s charge, bouncing projectile, 2.25 m blast, Weakened (blast damages), remove by looking at him 10 s within 25 m,
hallucinations (max 4) dispel 4 s, teleport to hallucination (25 s cd).
Nemesis: tentacle 0.35 s charge, MR1 5 m, MR2 breaks pallets, MR3 6.5 m; contamination; 4 vaccine cases; 2 zombies 1 m/s 14 m vision.
Ghoul: 2 leap tokens (14 m), first leap latches (no damage), second leap -> grab attack (injure + deep wound + Kagune Mark),
Enraged Mode while marked: 3 tokens 2.5 s; mark cleared by mending/dying.
2v8: 13 gens / 8 needed, cages instead of hooks (60 s per state), classes (Escapist, Guide, Medic, Scout), no perks/items,
no self-heal, 3 hatches, Revealed status on chase start / gen kicked / gen completed, 3 gates.

## Implementation choices (this build)
- 2v8: cages use the normal two hook stages with 90 s per stage (60 s tested too killer-sided for the bots on the 1.4× map),
  generators repair 25% faster (BALANCE in `js/modes/twoVeight.js`), hatch disabled, classes replace perks/items (house rule toggle allows random items + 2 perks).
- Skull Merchant: drones are detected by survivors' AI through sight like other devices; standing still or crouching is safe; a botched hack (bot skill roll, or a missed skill check for the player) adds a lock-on.
- Unknown: "looking at" = facing within ~35° with line of sight (top-down adaptation).
- Nemesis: Mutation Rate 2 at 1 point, 3 at 3 points; zombies injure and contaminate.
- Ghoul: latch window 2 s, wall-cling window 1.5 s, Kagune Mark 40 s.
